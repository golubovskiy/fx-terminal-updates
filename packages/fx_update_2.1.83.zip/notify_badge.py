# -*- coding: utf-8 -*-
"""Значок «Уведомления» в строке меню главного окна (вместо прежней кнопки с текстом).

    * колокольчик с числом непрочитанных уведомлений «Алгоритмов»; цвет — по самому важному из них
      (как звук уведомления, quotes_tab.EVENT_SOUNDS): касание линии или резкое движение цены — красный,
      крупная сделка, айсберг, робот — жёлтый, остальное — синий; непрочитанных нет — серый контур;
    * наведение — всплывающее окно: работающие сейчас роботы и последние уведомления (новые — с точкой);
    * щелчок — окно «Уведомления» (панель, как другие окна из «Окна»); правый щелчок — меню звука
      (их подключает main_window).

Непрочитанные считает вкладка «Алгоритмы» (QuotesTab.unread / unread_level): уведомление, пришедшее, пока
окно «Уведомления» не видно; окно показали — прочитано. Значок только рисует то, что ему передали
(set_state), а содержимое всплывающего окна берёт у поставщика (popup_source)."""
from __future__ import annotations

import html
from typing import Callable

from PySide6 import QtCore, QtGui, QtWidgets

try:
    import fx_theme
except Exception:                    # модуль скопирован отдельно
    fx_theme = None

# Важность уведомления по его звуку: 0 — нет непрочитанных
LEVEL_BY_SOUND = {"pulse": 1, "robot": 2, "signal": 2, "alert": 3}
LEVEL_COLORS = {0: ("TEXT_DIM", "#8c9199"), 1: ("ACCENT", "#3d8bfd"), 2: ("WARN", "#e0b030"), 3: ("SELL", "#e61e1e")}
POPUP_EVENTS = 8                     # последних уведомлений во всплывающем окне
POPUP_ROBOTS = 5                     # работающих роботов в нём же
HOVER_DELAY_MS = 300                 # навели и задержали — тогда окно (мимоходом курсор не открывает)
DETAILS_MAX = 70                     # длинные детали в окне обрезаются


def level_of(event: dict) -> int:
    """Важность уведомления (1–3) по его звуку (event["sound"], quotes_tab.event_sound)."""
    return LEVEL_BY_SOUND.get(str(event.get("sound") or "pulse"), 1)


def badge_text(count: int) -> str:
    """Число на значке: пусто, «1»…«99», «99+»."""
    count = int(count or 0)
    if count <= 0:
        return ""
    return str(count) if count < 100 else "99+"


def _color(level: int) -> QtGui.QColor:
    attr, default = LEVEL_COLORS.get(level, LEVEL_COLORS[1])
    return QtGui.QColor(str(getattr(fx_theme, attr, default)) if fx_theme is not None else default)


def _short(text: str, limit: int = DETAILS_MAX) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def popup_html(rows: list[dict], robots: list[dict], unread: int, level: int) -> str:
    """Содержимое всплывающего окна (HTML для QLabel).
    rows — последние уведомления, новые первыми: {"time", "kind", "symbol", "title", "details", "new"};
    robots — работающие роботы: {"kind", "symbol", "side": "BUY"/"SELL", "text"}."""
    dim = str(getattr(fx_theme, "TEXT_DIM", "#8c9199")) if fx_theme is not None else "#8c9199"
    buy = str(getattr(fx_theme, "BUY", "#2ecc55")) if fx_theme is not None else "#2ecc55"
    sell = str(getattr(fx_theme, "SELL", "#e61e1e")) if fx_theme is not None else "#e61e1e"
    accent = _color(level if unread else 1).name()
    esc = html.escape
    head = "Уведомления" + (f" · <span style='color:{accent}'>новых: {unread}</span>" if unread else " · новых нет")
    out = [f"<div style='font-weight:600; margin-bottom:4px'>{head}</div>"]
    if robots:
        out.append(f"<div style='color:{dim}; margin-top:2px'>Работают сейчас</div><table cellspacing='0'>")
        for robot in robots[:POPUP_ROBOTS]:
            color = buy if robot.get("side") == "BUY" else sell
            out.append(f"<tr><td style='padding-right:8px'>{esc(str(robot.get('kind', '')))}</td>"
                       f"<td style='padding-right:8px'>{esc(str(robot.get('symbol', '')))}</td>"
                       f"<td style='color:{color}'>{esc(_short(robot.get('text', ''), 60))}</td></tr>")
        if len(robots) > POPUP_ROBOTS:
            out.append(f"<tr><td colspan='3' style='color:{dim}'>и ещё {len(robots) - POPUP_ROBOTS}</td></tr>")
        out.append("</table>")
    if rows:
        out.append(f"<div style='color:{dim}; margin-top:6px'>Последние</div><table cellspacing='0'>")
        for row in rows[:POPUP_EVENTS]:
            weight = "600" if row.get("new") else "400"
            dot = f"<span style='color:{accent}'>●</span> " if row.get("new") else "&nbsp;&nbsp;&nbsp;"
            title = esc(_short(row.get("title") or row.get("details") or "", 40))
            details = esc(_short(row.get("details") or "")) if row.get("title") else ""
            tail = f" — <span style='color:{dim}'>{details}</span>" if details else ""
            out.append(f"<tr style='font-weight:{weight}'><td style='padding-right:8px; color:{dim}'>{dot}"
                       f"{esc(str(row.get('time', '')))}</td>"
                       f"<td style='padding-right:8px'>{esc(str(row.get('kind', '')))}</td>"
                       f"<td style='padding-right:8px'>{esc(str(row.get('symbol', '')))}</td>"
                       f"<td>{title}{tail}</td></tr>")
        out.append("</table>")
    elif not robots:
        out.append(f"<div style='color:{dim}'>Пока ничего нет</div>")
    out.append(f"<div style='color:{dim}; margin-top:6px'>Щелчок — открыть окно «Уведомления» · "
               f"правый щелчок — звук</div>")
    return "".join(out)


class NotifyPopup(QtWidgets.QFrame):
    """Всплывающее окно значка: не забирает фокус и не ловит мышь (как мировое время у часов)."""

    def __init__(self, parent: QtWidgets.QWidget):
        super().__init__(parent, QtCore.Qt.WindowType.ToolTip | QtCore.Qt.WindowType.FramelessWindowHint)
        self.setObjectName("NotifyPopup")
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        bg = str(getattr(fx_theme, "BG_PANEL", "#232529")) if fx_theme is not None else "#232529"
        border = str(getattr(fx_theme, "BORDER_STRONG", "#4a4e56")) if fx_theme is not None else "#4a4e56"
        text = str(getattr(fx_theme, "TEXT", "#d3d6db")) if fx_theme is not None else "#d3d6db"
        self.setStyleSheet(f"QFrame#NotifyPopup {{ background-color: {bg}; border: 1px solid {border}; "
                           f"border-radius: 8px; }} QLabel {{ color: {text}; }}")
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        self.label = QtWidgets.QLabel(self)
        self.label.setTextFormat(QtCore.Qt.TextFormat.RichText)
        self.label.setWordWrap(False)
        layout.addWidget(self.label)

    def set_html(self, text: str) -> None:
        if text != self.label.text():
            self.label.setText(text)
            self.adjustSize()


def _ui_scale() -> float:
    """Во сколько раз шрифт интерфейса («Настройки» → «Размер шрифта») больше шрифта темы (appearance.ui_scale)."""
    try:
        import appearance
        return appearance.ui_scale()
    except Exception:                           # noqa: BLE001
        return 1.0


class NotifyBadgeButton(QtWidgets.QToolButton):
    """Колокольчик с числом непрочитанных; наведение — NotifyPopup с содержимым от popup_source()."""

    SIZE = QtCore.QSize(34, 24)                 # при шрифте темы; иначе — пропорционально шрифту интерфейса (2.1.83)

    def __init__(self, parent: QtWidgets.QWidget | None = None,
                 popup_source: Callable[[], str] | None = None):
        super().__init__(parent)
        self.setAutoRaise(True)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.popup_source = popup_source        # () -> HTML всплывающего окна (popup_html)
        self._scale = _ui_scale()               # колокольчик и число — под общий размер шрифта (2.1.83)
        try:
            import appearance
            appearance.NOTIFIER.changed.connect(self._rescale)
        except Exception:                       # noqa: BLE001
            pass
        self._count = 0
        self._level = 0
        self._popup: NotifyPopup | None = None
        self._hover = QtCore.QTimer(self)
        self._hover.setSingleShot(True)
        self._hover.setInterval(HOVER_DELAY_MS)
        self._hover.timeout.connect(self.show_popup)
        self._update_tip()

    # ---- состояние ---------------------------------------------------------------
    def set_state(self, count: int, level: int) -> None:
        """Число непрочитанных и важность самого важного из них; перерисовка — только если изменилось."""
        count, level = max(0, int(count or 0)), (int(level or 0) if count else 0)
        if (count, level) == (self._count, self._level):
            return
        self._count, self._level = count, level
        self._update_tip()
        self.update()

    def state(self) -> tuple[int, int]:
        return self._count, self._level

    def _update_tip(self) -> None:
        # Подсказка Qt не нужна, пока есть всплывающее окно — оставляем её короткой (для чтения с экрана).
        self.setAccessibleName(f"Уведомления: новых {self._count}" if self._count else "Уведомления")

    # ---- рисование ---------------------------------------------------------------
    def _rescale(self) -> None:
        """OK в «Настройках»: размер значка — под новый шрифт интерфейса."""
        scale = _ui_scale()
        if scale != self._scale:
            self._scale = scale
            self.updateGeometry()
            self.update()

    def sizeHint(self) -> QtCore.QSize:                                   # noqa: N802
        return QtCore.QSize(round(self.SIZE.width() * self._scale), round(self.SIZE.height() * self._scale))

    def minimumSizeHint(self) -> QtCore.QSize:                            # noqa: N802
        return self.sizeHint()

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:              # noqa: N802
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        if self.underMouse():
            hover = str(getattr(fx_theme, "BG_HOVER", "#33363c")) if fx_theme is not None else "#33363c"
            painter.setPen(QtCore.Qt.PenStyle.NoPen)
            painter.setBrush(QtGui.QColor(hover))
            painter.drawRoundedRect(QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1), 4, 4)
        color = _color(self._level if self._count else 0)
        # Рисунок — в размерах при шрифте темы (SIZE), увеличенный в _scale раз вместе со шрифтом интерфейса.
        painter.scale(self._scale, self._scale)
        width = self.width() / self._scale
        # Колокольчик в квадрате 16×16 слева: контур — нет новых, залит цветом важности — есть.
        h = self.height() / self._scale
        x0, y0 = 5.0, (h - 16) / 2.0
        bell = QtGui.QPainterPath()
        bell.moveTo(x0 + 2.0, y0 + 12.0)
        bell.cubicTo(x0 + 3.5, y0 + 10.5, x0 + 3.0, y0 + 7.0, x0 + 3.5, y0 + 5.5)
        bell.cubicTo(x0 + 4.2, y0 + 2.8, x0 + 6.0, y0 + 1.8, x0 + 8.0, y0 + 1.8)
        bell.cubicTo(x0 + 10.0, y0 + 1.8, x0 + 11.8, y0 + 2.8, x0 + 12.5, y0 + 5.5)
        bell.cubicTo(x0 + 13.0, y0 + 7.0, x0 + 12.5, y0 + 10.5, x0 + 14.0, y0 + 12.0)
        bell.closeSubpath()
        pen = QtGui.QPen(color, 1.4)
        pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(color if self._count else QtCore.Qt.BrushStyle.NoBrush)
        painter.drawPath(bell)
        painter.setBrush(color)
        painter.drawEllipse(QtCore.QPointF(x0 + 8.0, y0 + 13.8), 1.6, 1.6)          # язычок
        text = badge_text(self._count)
        if text:
            font = QtGui.QFont(self.font())
            font.setBold(True)
            font.setPixelSize(10)
            painter.setFont(font)
            fm = QtGui.QFontMetrics(font)
            w = max(14, fm.horizontalAdvance(text) + 6)
            rect = QtCore.QRectF(width - w - 1, 1, w, 13)
            painter.setPen(QtCore.Qt.PenStyle.NoPen)
            painter.setBrush(color)
            painter.drawRoundedRect(rect, 6.5, 6.5)
            painter.setPen(QtGui.QColor("#111111") if self._level == 2 else QtGui.QColor("#ffffff"))
            painter.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, text)
        painter.end()

    # ---- всплывающее окно --------------------------------------------------------
    def enterEvent(self, event) -> None:                                  # noqa: N802
        self._hover.start()
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:                                  # noqa: N802
        self._hover.stop()
        self.hide_popup()
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:                             # noqa: N802
        self._hover.stop()
        self.hide_popup()                        # щелчок — открывается само окно, подсказка не нужна
        super().mousePressEvent(event)

    def popup_visible(self) -> bool:
        return self._popup is not None and self._popup.isVisible()

    def show_popup(self) -> None:
        if self.popup_source is None or not self.underMouse():
            return
        try:
            text = self.popup_source()
        except Exception as exc:                 # поставщик сломался — без окна, но и без падения
            print(f"[уведомления] всплывающее окно: {type(exc).__name__}: {exc}")
            return
        if self._popup is None:
            self._popup = NotifyPopup(self)
        self._popup.set_html(text)
        self._place_popup()
        self._popup.show()
        self._popup.raise_()

    def refresh_popup(self) -> None:
        """Окно открыто — обновить содержимое (раз в секунду из главного окна)."""
        if self.popup_visible() and self.popup_source is not None:
            try:
                self._popup.set_html(self.popup_source())
                self._place_popup()
            except Exception:
                pass

    def hide_popup(self) -> None:
        if self._popup is not None:
            self._popup.hide()

    def _place_popup(self) -> None:
        """Под значком, правым краем к значку и в пределах экрана."""
        popup = self._popup
        popup.adjustSize()
        size = popup.sizeHint()
        anchor = self.mapToGlobal(QtCore.QPoint(self.width(), self.height() + 4))
        x, y = anchor.x() - size.width(), anchor.y()
        screen = QtGui.QGuiApplication.screenAt(anchor) or QtGui.QGuiApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            x = min(max(x, area.left() + 6), area.right() - size.width() - 6)
            if y + size.height() > area.bottom():
                y = self.mapToGlobal(QtCore.QPoint(0, -size.height() - 4)).y()
        popup.move(x, y)
