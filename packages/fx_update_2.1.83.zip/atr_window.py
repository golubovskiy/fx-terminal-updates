# -*- coding: utf-8 -*-
"""Окно «ATR» (меню «Окна» → «ATR», 2.1.13): средний истинный диапазон инструмента.

Сверху — инструмент («Каталог…» — любой из каталога брокера), таймфрейм, период, способ сглаживания
(RMA Уайлдера — по умолчанию, как в TradingView; SMA — как в MetaTrader 5; EMA; WMA) и «Без гэпов»
(ночной и выходной разрыв в ATR не входит). Ниже — четыре карточки:
    ATR таймфрейма — последнее значение в пунктах цены и в % от цены;
    дневной ATR — по завершённым дням (тем же периодом и сглаживанием);
    пройдено сегодня — диапазон сегодняшней сессии и его доля от дневного ATR (полоса);
    осталось до среднего — сколько ещё до дневного ATR (или «сверх среднего на …»).
Под ними — ATR выбранного таймфрейма за последние N свечей: N — список «100 / 300 / 1000 / Все свечи» (2.1.17,
VISIBLE_CHOICES; на расчёт не влияет — только сколько показано); переключатель «Линия / Столбики» справа
вверху (2.1.14). Столбики — от нижнего края графика (масштаб тот же, что у линии); яркий — ATR вырос
по сравнению с прошлым баром (волатильность расширяется), приглушённый — снизился.

Данные: свечи — тот же запрос Finam, что у графика (get_bars_dataframe), в фоновом потоке; сначала — из
кэша свечей графика (candle_cache), если он есть. Свечи таймфрейма обновляются раз в BARS_REFRESH_SEC,
дневные — раз в DAILY_REFRESH_SEC; между обновлениями последний бар и сегодняшний диапазон тянутся за
котировкой (MarketDataHub: последняя цена, максимум и минимум сессии). Подключение окно проверяет само
(раз в секунду): после переподключения к Finam подписка и свечи поднимаются заново.
Нагрузка (2.1.15, замер 10.11 — окно ATR на пике до 0,6 с в секунду): перерисовка не чаще REDRAW_MS и только
у видимой панели (в скрытой вкладке — при показе, showEvent); график и масштаб трогаются, только если изменились;
сглаживание — векторно (atr_core.smooth). Расчёт — atr_core.py (без Qt). Панель многоэкземплярная; инструмент и параметры переживают перезапуск
(state() / main_window: PanelSpec «atr»), а последние выбранные — значения нового окна (QSettings «atr/…»).
"""
from __future__ import annotations

import math
import sys
import traceback

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PySide6 import QtCore, QtGui, QtWidgets

import atr_core
import fx_theme
from app_common import (DEFAULT_HISTORY_PERIOD, DEFAULT_SYMBOLS, MIC_LABELS, TIMEFRAMES, TYPE_LABELS,
                        _friendly_symbol, history_start)

BARS_REFRESH_SEC = 60           # свечи таймфрейма — заново раз в минуту
DAILY_REFRESH_SEC = 600         # дневные — раз в 10 минут
REDRAW_MS = 500                 # перерисовка по котировкам — не чаще (2.1.15: было 300)
# Сколько последних свечей показывать на графике (2.1.17; 0 — все загруженные). Масштаб ставит окно само.
VISIBLE_CHOICES = ((100, "100 свечей"), (300, "300 свечей"), (1000, "1000 свечей"), (0, "Все свечи"))
DEFAULT_VISIBLE = 300
STYLES = (("line", "Линия"), ("bars", "Столбики"))
DIM_ALPHA = 110                 # столбик снижения ATR — тот же цвет, приглушённый
SETTINGS_PREFIX = "atr/"
RECENT_INTRADAY = pd.Timedelta(hours=2)   # повторная загрузка — только последние часы (и склейка с прежними)
RECENT_DAILY = pd.Timedelta(days=5)
_THREADS: set = set()           # фоновые загрузки, пока идут (чтобы поток не собрал сборщик мусора)
_QUIT_HOOKED = False


def _wait_threads() -> None:
    """Выход из терминала: дождаться идущих загрузок (до 3 с), иначе Qt роняет процесс на живом QThread."""
    for thread, _worker in list(_THREADS):
        try:
            thread.quit()
            thread.wait(3000)
        except Exception:
            pass


def merge_bars(old: pd.DataFrame, new: pd.DataFrame) -> pd.DataFrame:
    """Свежий кусок свечей поверх прежних: прежние до начала куска + кусок (последний бар — свежий)."""
    new = atr_core.clean_bars(new)
    if old is None or old.empty:
        return new
    if new.empty:
        return old
    return pd.concat([old[old.index < new.index[0]], new])


def colors() -> dict:
    """Цвета окна: тема, а поверх — «Настройки» → «Цвета» → «ATR» (appearance, 2.1.83): фон (окно и график; карточки
    и рамки — оттенки фона, fx_theme.shades), текст (подписи, значения, оси графика) и линия / столбики ATR.
    Читаются при создании окна — свои цвета меняются после перезапуска (фон и текст окна — ещё и сразу, стилем)."""
    out = {"bg": fx_theme.BG_WINDOW, "panel": fx_theme.BG_PANEL, "border": fx_theme.BORDER, "text": fx_theme.TEXT,
           "dim": fx_theme.TEXT_DIM, "line": fx_theme.ACCENT, "user_text": False}
    try:
        import appearance
        bg, text, line = (appearance.override(k) for k in ("atr.bg", "atr.text", "atr.line"))
    except Exception:
        return out
    if bg or text:
        sh = fx_theme.shades(QtGui.QColor(bg or out["bg"]).name(), QtGui.QColor(text or out["text"]).name())
        out.update(text=sh["TEXT"], dim=sh["TEXT_DIM"], user_text=bool(text))
        if bg:
            out.update(bg=bg, panel=sh["BG_PANEL"], border=sh["BORDER"])
    if line:
        out["line"] = line
    return out


def card_style(c: dict | None = None) -> str:
    """Стиль карточки (рамка и фон панели). Обе части — f-строки: в 2.1.13 вторая была обычной, «}}» и «{{» в ней
    оставались двойными, и Qt писал «Could not parse stylesheet of object QFrame» — карточки были без рамки.
    c — цвета окна (colors()); без них — цвета темы."""
    c = c or {"panel": fx_theme.BG_PANEL, "border": fx_theme.BORDER}
    return (f"QFrame {{ background: {c['panel']}; border: 1px solid {c['border']};"
            f" border-radius: 4px; }} QLabel {{ border: none; background: transparent; }}")


class _BarsWorker(QtCore.QObject):
    """Свечи инструмента из Finam (в фоновом потоке): finished(ключ, DataFrame, кусок ли это), error(ключ, текст)."""

    finished = QtCore.Signal(object, object, bool)
    error = QtCore.Signal(object, str)

    def __init__(self, client, key: tuple, symbol: str, timeframe: str, start: pd.Timestamp, end: pd.Timestamp,
                 partial: bool = False):
        super().__init__()
        self.client, self.key, self.partial = client, key, partial
        self.symbol, self.timeframe, self.start, self.end = symbol, timeframe, start, end

    @QtCore.Slot()
    def run(self) -> None:
        try:
            df = self.client.get_bars_dataframe(
                symbol=self.symbol, timeframe=self.timeframe,
                start_time=self.start.isoformat().replace("+00:00", "Z"),
                end_time=self.end.isoformat().replace("+00:00", "Z"))
            if df is not None and not df.empty and "timestamp" in df.columns:
                df = df.copy()
                df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
                df = df.set_index("timestamp")
            self.finished.emit(self.key, df, self.partial)
        except Exception:
            self.error.emit(self.key, traceback.format_exc())


class _IndexTimeAxis(pg.AxisItem):
    """Ось времени по номерам баров (ночи и выходные не растягивают линию): подписи — заранее."""

    def __init__(self):
        super().__init__(orientation="bottom")
        self._labels: list[str] = []

    def set_labels(self, labels: list[str]) -> None:
        self._labels = labels
        self.picture = None
        self.update()

    def tickStrings(self, values, scale, spacing):
        out = []
        for value in values:
            i = int(round(value))
            out.append(self._labels[i] if 0 <= i < len(self._labels) else "")
        return out


class AtrPanel(QtWidgets.QWidget):
    """Панель «ATR». host — главное окно (md_hub, sdk_client, display_tz, history_period, settings,
    _active_assets); state — сохранённое состояние панели (state()); autostart=False — без таймеров
    и сети (для проверок)."""

    def __init__(self, host, state: dict | None = None, parent=None, autostart: bool = True):
        super().__init__(parent)
        try:                                          # свои фон и текст окна (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "atr")
        except Exception:
            pass
        self._c = colors()
        self._values: list[QtWidgets.QLabel] = []      # крупные значения карточек (_restyle_values)
        self.host = host
        self._settings = getattr(host, "settings", None)
        saved = dict(self._defaults())
        saved.update({k: v for k, v in (state or {}).items() if v not in (None, "")})
        self._bars = atr_core.clean_bars(None)          # свечи таймфрейма
        self._daily = atr_core.clean_bars(None)         # дневные свечи
        self._quote = None                              # (последняя цена, максимум, минимум сессии)
        self._loading: set = set()                      # ключи идущих загрузок
        self._loaded_at: dict = {}                      # ключ -> время (с эпохи) последней загрузки
        self._sub = None
        self._sub_hub = None
        self._closed = False
        self._decimals = 2
        self._labels_key = None
        self._labels: list[str] = []
        self._dirty = False                             # скрытая панель пропустила перерисовку (showEvent)
        self._plot_key = None                           # что уже нарисовано на графике (_redraw)
        self._y_range = None
        self._shown_symbol = str(saved["symbol"])
        global _QUIT_HOOKED
        app = QtCore.QCoreApplication.instance()
        if app is not None and not _QUIT_HOOKED:
            app.aboutToQuit.connect(_wait_threads)
            _QUIT_HOOKED = True
        self._build_ui(saved)
        self._redraw_timer = QtCore.QTimer(self)
        self._redraw_timer.setSingleShot(True)
        self._redraw_timer.setInterval(REDRAW_MS)
        self._redraw_timer.timeout.connect(self._redraw_if_visible)
        self._tick_timer = QtCore.QTimer(self)
        self._tick_timer.setInterval(1000)
        self._tick_timer.timeout.connect(self._tick)
        self._update_title()
        if autostart:
            self._load_cache()
            self._tick_timer.start()
            QtCore.QTimer.singleShot(0, self._tick)

    # ---- настройки -------------------------------------------------------------------------

    def _defaults(self) -> dict:
        out = {"symbol": DEFAULT_SYMBOLS[0] if DEFAULT_SYMBOLS else "", "tf": "M5",
               "length": atr_core.DEFAULT_LENGTH, "method": atr_core.DEFAULT_METHOD, "gaps": False, "style": "line",
               "visible": DEFAULT_VISIBLE}
        if self._settings is not None:
            for key in out:
                value = self._settings.value(SETTINGS_PREFIX + key)
                if value not in (None, ""):
                    out[key] = value
        out["gaps"] = str(out["gaps"]).lower() in ("true", "1")
        if out["style"] not in dict(STYLES):
            out["style"] = "line"
        try:
            out["visible"] = int(out["visible"])
        except (TypeError, ValueError):
            out["visible"] = DEFAULT_VISIBLE
        if out["visible"] not in dict(VISIBLE_CHOICES):
            out["visible"] = DEFAULT_VISIBLE
        try:
            out["length"] = int(out["length"])
        except (TypeError, ValueError):
            out["length"] = atr_core.DEFAULT_LENGTH
        return out

    def state(self) -> dict:
        """Инструмент и параметры — для раскладки (main_window: PanelSpec «atr», save_state)."""
        return {"symbol": self.symbol(), "tf": self.timeframe(), "length": self.length(),
                "method": self.method(), "gaps": self.skip_gaps(), "style": self.style(),
                "visible": self.visible_bars()}

    def _remember(self) -> None:
        if self._settings is None:
            return
        for key, value in self.state().items():
            self._settings.setValue(SETTINGS_PREFIX + key, value)

    def symbol(self) -> str:
        return str(self.symbol_combo.currentData() or "")

    def timeframe(self) -> str:
        return self.tf_combo.currentText() or "M5"

    def length(self) -> int:
        return int(self.length_spin.value())

    def method(self) -> str:
        return str(self.method_combo.currentData() or atr_core.DEFAULT_METHOD)

    def skip_gaps(self) -> bool:
        return self.gaps_check.isChecked()

    def visible_bars(self) -> int:
        """Сколько последних свечей на графике; 0 — все загруженные."""
        value = self.visible_combo.currentData()
        return DEFAULT_VISIBLE if value is None else int(value)

    def style(self) -> str:
        """Вид графика: «line» — линия, «bars» — столбики."""
        return "bars" if self.style_buttons["bars"].isChecked() else "line"

    # ---- интерфейс -------------------------------------------------------------------------

    def _build_ui(self, saved: dict) -> None:
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(6)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(6)
        self.symbol_combo = QtWidgets.QComboBox()
        self.symbol_combo.setMinimumWidth(150)
        symbols = list(DEFAULT_SYMBOLS)
        if saved["symbol"] and saved["symbol"] not in symbols:
            symbols.insert(0, saved["symbol"])
        for symbol in symbols:
            self.symbol_combo.addItem(_friendly_symbol(symbol), symbol)
        index = self.symbol_combo.findData(saved["symbol"])
        self.symbol_combo.setCurrentIndex(index if index >= 0 else 0)
        self.catalog_btn = QtWidgets.QPushButton("Каталог…")
        self.catalog_btn.setToolTip("Выбрать инструмент из полного каталога брокера")
        self.catalog_btn.clicked.connect(lambda _checked=False: self._open_catalog())
        self.tf_combo = QtWidgets.QComboBox()
        self.tf_combo.addItems(list(TIMEFRAMES))
        tf_index = self.tf_combo.findText(str(saved["tf"]))
        self.tf_combo.setCurrentIndex(tf_index if tf_index >= 0 else 0)
        self.tf_combo.setToolTip("Таймфрейм свечей, по которым считается линия ATR и первая карточка")
        self.length_spin = QtWidgets.QSpinBox()
        self.length_spin.setRange(1, 200)
        self.length_spin.setValue(max(1, min(200, int(saved["length"]))))
        self.length_spin.setPrefix("Период ")
        self.length_spin.setKeyboardTracking(False)
        self.length_spin.setToolTip("Сколько баров сглаживается (обычно 14) — и для таймфрейма, и для дневного ATR")
        self.method_combo = QtWidgets.QComboBox()
        for key, title in atr_core.METHODS:
            self.method_combo.addItem(title, key)
        m_index = self.method_combo.findData(str(saved["method"]))
        self.method_combo.setCurrentIndex(m_index if m_index >= 0 else 0)
        self.method_combo.setToolTip("Сглаживание истинного диапазона: RMA Уайлдера — классический ATR (TradingView,\n"
                                     "TA-Lib); SMA — простое среднее (MetaTrader 5); EMA и WMA — быстрее реагируют")
        self.gaps_check = QtWidgets.QCheckBox("Без гэпов")
        self.gaps_check.setChecked(bool(saved["gaps"]))
        self.gaps_check.setToolTip("Разрыв между сессиями (ночь, выходные) в ATR не входит: на первом баре сессии\n"
                                   "берётся только High − Low. У дневного ATR это средний дневной диапазон (ADR).")
        self.visible_combo = QtWidgets.QComboBox()
        for count, title in VISIBLE_CHOICES:
            self.visible_combo.addItem(title, count)
        try:
            visible = int(saved.get("visible", DEFAULT_VISIBLE))
        except (TypeError, ValueError):
            visible = DEFAULT_VISIBLE
        v_index = self.visible_combo.findData(visible)
        self.visible_combo.setCurrentIndex(v_index if v_index >= 0 else self.visible_combo.findData(DEFAULT_VISIBLE))
        self.visible_combo.setToolTip("Сколько последних свечей показывать на графике. На расчёт ATR не влияет;\n"
                                      "сколько истории загружено — внизу окна («Свечи …»)")
        for widget in (self.symbol_combo, self.catalog_btn, self.tf_combo, self.length_spin, self.method_combo,
                       self.gaps_check, self.visible_combo):
            row.addWidget(widget)
        row.addStretch(1)
        # Переключатель вида графика (2.1.14): две кнопки, нажата одна
        self.style_group = QtWidgets.QButtonGroup(self)
        self.style_group.setExclusive(True)
        self.style_buttons = {}
        style = saved["style"] if saved.get("style") in dict(STYLES) else "line"
        for key, title in STYLES:
            button = QtWidgets.QPushButton(title)
            button.setCheckable(True)
            button.setChecked(key == style)
            button.setToolTip("ATR на графике — линией" if key == "line" else
                              "ATR на графике — столбиками: яркий — ATR вырос по сравнению с прошлым баром,\n"
                              "приглушённый — снизился")
            self.style_group.addButton(button)
            self.style_buttons[key] = button
            row.addWidget(button)
        layout.addLayout(row)

        cards = QtWidgets.QHBoxLayout()
        cards.setSpacing(6)
        self.atr_label, self.atr_note = self._card(cards, "ATR")
        self.daily_label, self.daily_note = self._card(cards, "Дневной ATR")
        self.passed_label, self.passed_note = self._card(cards, "Пройдено сегодня")
        self.left_label, self.left_note = self._card(cards, "До среднего")
        try:                                           # размер значений — вслед за шрифтом интерфейса (2.1.83)
            import appearance
            appearance.NOTIFIER.changed.connect(self._restyle_values)
        except Exception:                              # noqa: BLE001
            pass
        layout.addLayout(cards)

        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6)
        self.progress.setToolTip("Пройдено сегодня — доля от дневного ATR (полоса заполнена — день прошёл средний диапазон)")
        layout.addWidget(self.progress)

        self.axis = _IndexTimeAxis()
        self.plot = pg.PlotWidget(axisItems={"bottom": self.axis}, background=self._c["bg"])
        if self._c["user_text"]:                  # свой «Текст» окна — и подписи осей графика
            for name in ("bottom", "right"):
                self.plot.getAxis(name).setTextPen(pg.mkPen(self._c["dim"]))
        self.plot.showGrid(x=False, y=True, alpha=0.15)
        self.plot.setMenuEnabled(False)
        self.plot.setMouseEnabled(x=False, y=False)        # масштаб ставит окно само (последние N свечей)
        self.plot.hideButtons()
        self.plot.getPlotItem().showAxis("right")
        self.plot.getPlotItem().hideAxis("left")
        self.curve = self.plot.plot([], [], pen=pg.mkPen(self._c["line"], width=1.5))
        # «Все свечи» на M1–M5 — тысячи точек: рисуется только видимое, с прореживанием до ширины графика
        self.curve.setClipToView(True)
        self.curve.setDownsampling(auto=True, method="peak")
        self.bars_item = None                     # столбики — создаются при первом показе (_draw_bars)
        bright = pg.mkColor(self._c["line"])
        dim = pg.mkColor(self._c["line"])
        dim.setAlpha(DIM_ALPHA)
        self._brush_up, self._brush_down = pg.mkBrush(bright), pg.mkBrush(dim)
        layout.addWidget(self.plot, 1)

        self.status_label = QtWidgets.QLabel("Жду подключения к Finam…")
        self.status_label.setStyleSheet(f"color: {self._c['dim']};")
        layout.addWidget(self.status_label)

        self.symbol_combo.currentIndexChanged.connect(lambda _i: self._params_changed(reload=True))
        self.tf_combo.currentIndexChanged.connect(lambda _i: self._params_changed(reload=True))
        self.length_spin.valueChanged.connect(lambda _v: self._params_changed(reload=False))
        self.method_combo.currentIndexChanged.connect(lambda _i: self._params_changed(reload=False))
        self.gaps_check.toggled.connect(lambda _on: self._params_changed(reload=False))
        self.visible_combo.currentIndexChanged.connect(lambda _i: self._params_changed(reload=False))
        # нажали «Линия» — «Столбики» отжались: одного сигнала кнопки «Столбики» хватает на оба направления
        self.style_buttons["bars"].toggled.connect(lambda _on: self._params_changed(reload=False))

    def _value_style(self) -> str:
        """Крупное значение карточки: 15 px при шрифте темы — под общий размер шрифта интерфейса (2.1.83)."""
        try:
            import appearance
            size = appearance.ui_px(15)
        except Exception:                             # noqa: BLE001
            size = 15
        return f"color: {self._c['text']}; font-size: {size}px; font-weight: 600;"

    def _restyle_values(self) -> None:
        """OK в «Настройках»: значения карточек — под новый размер шрифта интерфейса."""
        for value in self._values:
            value.setStyleSheet(self._value_style())

    def _card(self, layout: QtWidgets.QHBoxLayout, title: str):
        frame = QtWidgets.QFrame()
        frame.setStyleSheet(card_style(self._c))
        box = QtWidgets.QVBoxLayout(frame)
        box.setContentsMargins(8, 4, 8, 4)
        box.setSpacing(0)
        head = QtWidgets.QLabel(title)
        head.setStyleSheet(f"color: {self._c['dim']};")
        value = QtWidgets.QLabel("—")
        value.setStyleSheet(self._value_style())
        self._values.append(value)
        note = QtWidgets.QLabel("")
        note.setStyleSheet(f"color: {self._c['dim']};")
        for widget in (head, value, note):
            box.addWidget(widget)
        layout.addWidget(frame, 1)
        return value, note

    def _update_title(self) -> None:
        symbol = self.symbol()
        self.setWindowTitle(f"ATR — {_friendly_symbol(symbol)}" if symbol else "ATR")

    def _open_catalog(self) -> None:
        assets = getattr(self.host, "_active_assets", None)
        if not assets:
            QtWidgets.QMessageBox.information(self, "Каталог не загружен",
                                              "Дождитесь загрузки каталога инструментов от брокера и попробуйте снова.")
            return
        from instrument_picker import InstrumentPickerDialog
        dlg = InstrumentPickerDialog(assets, MIC_LABELS, TYPE_LABELS, self._settings, self)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        symbol = dlg.chosen_symbol()
        if symbol:
            self.select_symbol(symbol)

    def select_symbol(self, symbol: str) -> None:
        index = self.symbol_combo.findData(symbol)
        if index < 0:
            self.symbol_combo.addItem(_friendly_symbol(symbol), symbol)
            index = self.symbol_combo.count() - 1
        self.symbol_combo.setCurrentIndex(index)

    def _params_changed(self, reload: bool) -> None:
        """Сменили параметр. reload — инструмент или таймфрейм: свечи заново (другой инструмент — и дневные,
        и подписка на котировку); период, сглаживание и «Без гэпов» — только пересчёт."""
        self._remember()
        if reload:
            self._update_title()
            self._bars = atr_core.clean_bars(None)
            if self.symbol() != self._shown_symbol:
                self._shown_symbol = self.symbol()
                self._daily = atr_core.clean_bars(None)
                self._quote = None
                self._close_sub()
            self._loaded_at.clear()
            self._load_cache()
            if self._tick_timer.isActive():
                QtCore.QTimer.singleShot(0, self._tick)
        self._schedule_redraw()

    # ---- данные ----------------------------------------------------------------------------

    def _load_cache(self) -> None:
        """Свечи из кэша графика (candle_cache) — сразу, пока идёт запрос к Finam."""
        try:
            import candle_cache
            cached = candle_cache.load_bars(self.symbol(), self.timeframe())
            if cached is not None and not cached.empty:
                self.set_bars(cached)
            daily = candle_cache.load_bars(self.symbol(), "D1")
            if daily is not None and not daily.empty:
                self.set_daily(daily)
        except Exception as exc:                    # кэш — дополнение; без него окно ждёт Finam
            print(f"[ATR] кэш свечей не прочитан: {type(exc).__name__}: {exc}", file=sys.stderr)

    def set_bars(self, df) -> None:
        self._bars = atr_core.clean_bars(df)
        if len(self._bars):
            self._decimals = atr_core.price_decimals(self._bars["close"].to_numpy())
        self._schedule_redraw()

    def set_daily(self, df) -> None:
        self._daily = atr_core.clean_bars(df)
        self._schedule_redraw()

    def on_quote(self, quote) -> None:
        """Котировка (MarketDataHub): последняя цена тянет последний бар, максимум и минимум сессии —
        сегодняшний диапазон."""
        if self._closed:
            return
        last, high, low = (getattr(quote, name, None) for name in ("last", "high", "low"))
        self._quote = (last, high, low)
        if last is not None and math.isfinite(last) and len(self._bars):
            j = len(self._bars) - 1
            cols = self._bars.columns
            c, h, lo = cols.get_loc("close"), cols.get_loc("high"), cols.get_loc("low")
            self._bars.iat[j, c] = float(last)
            if last > self._bars.iat[j, h]:
                self._bars.iat[j, h] = float(last)
            if last < self._bars.iat[j, lo]:
                self._bars.iat[j, lo] = float(last)
        self._schedule_redraw()

    def _tick(self) -> None:
        """Раз в секунду: подписка на котировку (и после переподключения), обновление свечей по сроку."""
        if self._closed:
            return
        hub = getattr(self.host, "md_hub", None)
        if hub is not self._sub_hub:
            self._close_sub()
        if hub is not None and self._sub is None and self.symbol():
            try:
                from core.models import InstrumentId
                self._sub = hub.subscribe_quotes(InstrumentId.parse(self.symbol()), self.on_quote)
                self._sub_hub = hub
            except Exception as exc:
                self._set_status(f"Котировка не подписана: {exc}")
        client = getattr(self.host, "sdk_client", None)
        if client is None:
            if not len(self._bars):
                self._set_status("Жду подключения к Finam…")
            return
        now = QtCore.QDateTime.currentSecsSinceEpoch()
        symbol, tf = self.symbol(), self.timeframe()
        for key, every in (((symbol, tf), BARS_REFRESH_SEC), ((symbol, "D1"), DAILY_REFRESH_SEC)):
            if key in self._loading or now - self._loaded_at.get(key, -10 ** 9) < every:
                continue
            self._fetch(client, key)

    def _fetch(self, client, key: tuple) -> None:
        """Загрузка свечей в фоне: первый раз — вся история (период из «Настроек», дневные — год), дальше —
        только последние часы (дни), склейка с прежними (merge_bars)."""
        symbol, tf = key
        end = pd.Timestamp.now(tz="UTC")
        have = self._daily if tf == "D1" else (self._bars if tf == self.timeframe() else None)
        partial = have is not None and len(have) > 0 and key in self._loaded_at
        if partial:
            start = have.index[-1] - (RECENT_DAILY if tf == "D1" else RECENT_INTRADAY)
            start = max(start, history_start(end, "1y", tf))          # не глубже лимита Finam для таймфрейма
        else:
            period = "1y" if tf == "D1" else str(getattr(self.host, "history_period", DEFAULT_HISTORY_PERIOD))
            start = history_start(end, period, tf)
        thread = QtCore.QThread()
        thread.setObjectName("atr-bars")
        worker = _BarsWorker(client, key, symbol, tf, start, end, partial)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(self._on_loaded)
        worker.error.connect(self._on_error)
        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(lambda t=thread, w=worker: _THREADS.discard((t, w)))
        _THREADS.add((thread, worker))
        self._loading.add(key)
        self._loaded_at[key] = QtCore.QDateTime.currentSecsSinceEpoch()    # и при ошибке — не чаще срока
        if not len(self._bars):
            self._set_status("Загружаю свечи…")
        thread.start()

    def _on_loaded(self, key, df, partial: bool = False) -> None:
        self._loading.discard(key)
        if self._closed or key[0] != self.symbol():
            return
        if key[1] == "D1":
            self.set_daily(merge_bars(self._daily, df) if partial else df)
        if key[1] == self.timeframe():
            self.set_bars(merge_bars(self._bars, df) if partial else df)
        # всего свечей в окне, а не в последней догрузке (2.1.16: писалось «Свечи D1: 4» — столько пришло догрузкой)
        total = len(self._daily) if key[1] == "D1" else len(self._bars)
        chunk = 0 if df is None else len(df)
        self._set_status(f"Свечи {key[1]}: {total}" + (f" (догружено {chunk})" if partial else "")
                         + f" · обновляются раз в {BARS_REFRESH_SEC} с, между обновлениями — по котировке")

    def _on_error(self, key, text: str) -> None:
        self._loading.discard(key)
        if self._closed:
            return
        last = str(text).strip().splitlines()[-1] if text else "ошибка"
        self._set_status(f"Свечи {key[1]} не загружены: {last[:160]}")

    def _set_status(self, text: str) -> None:
        self.status_label.setText(text)

    # ---- расчёт и показ --------------------------------------------------------------------

    def _redraw_if_visible(self) -> None:
        """По таймеру: панель в скрытой вкладке не рисуется (замер 10.11: окно ATR на пике — до 0,6 с в секунду
        на перерисовку), перерисуется, когда её покажут (showEvent)."""
        if self.isVisible():
            self._redraw()
        else:
            self._dirty = True

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if self._dirty:
            self._dirty = False
            self._schedule_redraw()

    def _schedule_redraw(self) -> None:
        if not self._redraw_timer.isActive():
            self._redraw_timer.start()

    def figures(self) -> dict:
        """Все числа окна (и для проверок): atr, atr_pct, daily, range, pct, left, series; with_today — на D1 в ATR
        входит идущий (неполный) день."""
        length, method, gaps = self.length(), self.method(), self.skip_gaps()
        series = atr_core.atr(self._bars, length, method, gaps) if len(self._bars) else np.array([])
        last_atr = float(series[-1]) if len(series) and np.isfinite(series[-1]) else None
        close = float(self._bars["close"].iloc[-1]) if len(self._bars) else None
        day_atr, prev_close = atr_core.daily_atr(self._daily, length, method, gaps)
        high = low = None
        if self._quote is not None:
            _last, high, low = self._quote
        if high is None or low is None:
            _done, today = atr_core.split_today(self._daily)
            if today is not None:
                high, low = float(today["high"]), float(today["low"])
        rng = atr_core.today_range(high, low, prev_close, gaps)
        prog = atr_core.progress(day_atr, rng)
        with_today = (self.timeframe() == "D1" and len(self._bars) > 0
                      and atr_core.split_today(self._bars)[1] is not None)
        return {"with_today": with_today,
                "atr": last_atr, "atr_pct": (100.0 * last_atr / close) if last_atr is not None and close else None,
                "daily": day_atr, "range": rng, "pct": prog["pct"] if prog else None,
                "left": prog["left"] if prog else None, "series": series}

    def _redraw(self) -> None:
        if self._closed:
            return
        f = self.figures()
        d = self._decimals
        name = {"rma": "RMA", "sma": "SMA", "ema": "EMA", "wma": "WMA"}.get(self.method(), self.method())
        self.atr_label.setText(atr_core.fmt(f["atr"], d))
        # На D1 последний бар — идущий день: ATR с ним ниже / выше «Дневного ATR» (тот — по завершённым дням)
        self.atr_note.setText(f"{self.timeframe()} · {name} {self.length()}"
                              + (" · с сегодняшним днём" if f["with_today"] else "")
                              + (f" · {f['atr_pct']:.2f} % цены" if f["atr_pct"] is not None else ""))
        self.daily_label.setText(atr_core.fmt(f["daily"], d))
        self.daily_note.setText(("ADR" if self.skip_gaps() else f"D1 · {name} {self.length()}")
                                + ("" if f["daily"] is not None else " · мало дней"))
        self.passed_label.setText(atr_core.fmt(f["range"], d))
        self.passed_note.setText(f"{f['pct']:.0f} % дневного ATR" if f["pct"] is not None else "")
        self.progress.setValue(int(max(0.0, min(100.0, f["pct"] or 0.0))))
        if f["left"] is None:
            self.left_label.setText("—")
            self.left_note.setText("")
        elif f["left"] >= 0:
            self.left_label.setText(atr_core.fmt(f["left"], d))
            self.left_note.setText("до дневного ATR")
        else:
            self.left_label.setText("+" + atr_core.fmt(-f["left"], d))
            self.left_note.setText("сверх дневного ATR")
        series = f["series"]
        labels = self._time_labels()
        if labels is not self.axis._labels:
            self.axis.set_labels(labels)
        n = len(series)
        count = self.visible_bars() or n
        first = max(0, n - count)
        x = np.arange(first, n, dtype=float)
        vals = series[first:]
        ok = np.isfinite(vals) if n else np.array([], dtype=bool)
        bottom = None
        if ok.any():
            lo, hi = float(vals[ok].min()), float(vals[ok].max())
            pad = (hi - lo) * 0.1 or abs(hi) * 0.05 or 1.0
            bottom = lo - pad
            # слева — с первого посчитанного значения: первые «Период − 1» баров ATR ещё нет (2.1.16: было пусто)
            y_range = (float(x[ok][0]) - 1.0, n + 2.0, bottom, hi + pad)
            if y_range != self._y_range:                  # масштаб — только когда он изменился
                self._y_range = y_range
                self.plot.setXRange(y_range[0], y_range[1], padding=0)
                self.plot.setYRange(y_range[2], y_range[3], padding=0)
        last = float(vals[ok][-1]) if ok.any() else None
        plot_key = (self.style(), n, first, last, bottom, int(ok.sum()))
        if plot_key == self._plot_key:
            return                                        # на графике всё то же (котировка не сдвинула ATR)
        self._plot_key = plot_key
        if self.style() == "bars" and bottom is not None:
            self.curve.setData([], [])
            self._draw_bars(x[ok], vals[ok], bottom, series[first - 1] if first > 0 else np.nan)
        else:
            if self.bars_item is not None:
                self.bars_item.setVisible(False)
            self.curve.setData(x[ok], vals[ok])

    def _draw_bars(self, x, vals, bottom: float, before: float) -> None:
        """Столбики ATR от нижнего края графика: яркий — ATR вырос к прошлому бару, приглушённый — снизился."""
        prev = np.concatenate(([before], vals[:-1]))
        rising = ~(vals < prev)                   # первый бар без прошлого (NaN) — яркий
        brushes = [self._brush_up if up else self._brush_down for up in rising]
        heights = vals - bottom
        if self.bars_item is None:
            self.bars_item = pg.BarGraphItem(x=x, height=heights, width=0.8, y0=bottom, brushes=brushes,
                                             pen=pg.mkPen(None))
            self.plot.addItem(self.bars_item)
        else:
            self.bars_item.setOpts(x=x, height=heights, width=0.8, y0=bottom, brushes=brushes)
        self.bars_item.setVisible(True)

    def _time_labels(self) -> list[str]:
        """Подписи оси: время бара (первый бар дня — дата); пересчёт — только когда сменились свечи."""
        if not len(self._bars):
            return []
        tz = str(getattr(self.host, "display_tz", "") or atr_core.MARKET_TZ)
        key = (len(self._bars), self._bars.index[0], self._bars.index[-1], tz, self.timeframe())
        if key == self._labels_key:
            return self._labels
        self._labels_key = key
        self._labels = self._make_labels(tz)
        return self._labels

    def _make_labels(self, tz: str) -> list[str]:
        try:
            local = self._bars.index.tz_convert(tz)
        except Exception:
            local = self._bars.index
        if self.timeframe() == "D1":
            return [t.strftime("%d.%m.%y") for t in local]
        labels, prev = [], None
        for t in local:
            day = t.date()
            labels.append(t.strftime("%d.%m") if day != prev else t.strftime("%H:%M"))
            prev = day
        return labels

    # ---- закрытие --------------------------------------------------------------------------

    def _close_sub(self) -> None:
        sub, self._sub, self._sub_hub = self._sub, None, None
        if sub is not None:
            try:
                sub.close()
            except Exception:
                pass

    def shutdown(self) -> None:
        """Панель закрыта: подписка, таймеры; идущие загрузки доработают и будут проигнорированы."""
        self._closed = True
        self._tick_timer.stop()
        self._redraw_timer.stop()
        self._close_sub()
