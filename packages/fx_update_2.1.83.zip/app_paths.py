# -*- coding: utf-8 -*-
"""Где лежит программа и где её данные (2.1.79, к сборке в exe) — только стандартная библиотека.

Два вида установки:

    из исходников (C:\\FX_Terminal, запуск python gui_app.py) — всё как раньше: данные (журналы logs/, базы *.db,
        рисунки, события, кэши) лежат рядом с кодом, DATA_DIR = APP_DIR;

    собранная программа (tools/build_exe.py: PyInstaller «папкой» + установщик Inno Setup) —
        %LOCALAPPDATA%\\Programs\\FX Terminal\\
            FX Terminal.exe     — окно терминала (без консоли)
            fx_python.exe       — тот же Python с консолью: установщик обновлений и проверки (python_command)
            _internal\\          — Python и библиотеки (PySide6, QtAds, pandas, fx_engine …), собраны PyInstaller
            app\\                — файлы терминала (.py, Sound, tests) обычной папкой: их меняют пакеты обновлений
        данные — %LOCALAPPDATA%\\FX_Terminal (переустановка и удаление программы их не трогают).

Настройки, токен Finam и заметки — в реестре (QSettings "MyTradingTools/FxTerminal"), одни на обе установки.
FX_DATA_DIR — своя папка данных (проверки и отладка).

Готовый модуль Rust (2.1.83). В собранной программе нет Rust и maturin, поэтому пакет обновления, меняющий
fx_engine, несёт уже собранный модуль: app\\engine\\fx_engine.cp313-win_amd64.pyd (его кладёт в пакет
tools/publish_update.py на компьютере автора). use_prebuilt_engine() (вызывается при импорте этого файла в
собранной программе; модули, импортирующие fx_engine, сначала импортируют app_paths) ставит первым в
sys.meta_path поиск, который на «import fx_engine» отдаёт этот файл вместо модуля
из _internal\\ (там тот, что был при сборке установщика). Файл подходит, только если его суффикс — этого Python
(importlib.machinery.EXTENSION_SUFFIXES); не подходит или не загрузился — берётся модуль из _internal, причина —
в engine_status(). Модуль загружается только при первом «import fx_engine», а не при импорте app_paths: установщик
обновлений (тоже импортирует app_paths) файл не открывает, и Windows даёт его заменить. Установка из исходников
папку engine\\ не читает — там модуль пересобирает сам updater (maturin).
"""
from __future__ import annotations

import importlib.machinery
import importlib.util
import os
import sys
from pathlib import Path

FROZEN = bool(getattr(sys, "frozen", False))          # запущена собранная программа (PyInstaller)
APP_DIR = Path(__file__).resolve().parent              # файлы терминала (.py); в собранной — папка app\
GUI_EXE_NAME = "FX Terminal.exe"
PYTHON_EXE_NAME = "fx_python.exe"
DATA_FOLDER_NAME = "FX_Terminal"
ENGINE_NAME = "fx_engine"                              # модуль Rust (fx_engine_rs)
ENGINE_DIR = APP_DIR / "engine"                        # готовый модуль из пакета обновления (собранная программа)


def _data_dir() -> Path:
    custom = os.environ.get("FX_DATA_DIR")
    if custom:
        return Path(custom)
    if not FROZEN:
        return APP_DIR
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / DATA_FOLDER_NAME


DATA_DIR = _data_dir()                                 # журналы, базы, рисунки, события, кэши
LOG_DIR = DATA_DIR / "logs"


def ensure_data_dir() -> Path:
    """Создать папку данных (и logs\\), если её ещё нет. Ошибку не поднимает — пишущий файл сам её увидит."""
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return DATA_DIR


def program_dir() -> Path:
    """Папка с exe собранной программы (на уровень выше app\\); из исходников — папка терминала."""
    return Path(sys.executable).resolve().parent if FROZEN else APP_DIR


def python_command() -> list[str]:
    """Чем запускать скрипты терминала (установщик обновлений, проверки tests/*.py): из исходников — тем же
    Python (sys.executable), в собранной программе — fx_python.exe (Python с консолью; fx_boot.py выполняет
    переданный ему .py). Окно терминала (FX Terminal.exe) для этого не годится: у него нет консоли."""
    if FROZEN:
        return [str(program_dir() / PYTHON_EXE_NAME)]
    return [sys.executable]


def gui_command(*args: str) -> list[str]:
    """Запуск окна терминала: из исходников — python gui_app.py, в собранной — FX Terminal.exe."""
    if FROZEN:
        return [str(program_dir() / GUI_EXE_NAME), *args]
    return [sys.executable, str(APP_DIR / "gui_app.py"), *args]


# ------------------------------------------------------------------ готовый модуль Rust (2.1.83)

_engine_status = "модуль fx_engine — из сборки программы"


def engine_status() -> str:
    """Откуда взят fx_engine (для журнала и диагностики)."""
    return _engine_status


def engine_file(folder: Path | None = None) -> Path | None:
    """Готовый модуль в папке engine\\ под этот Python: fx_engine + суффикс из EXTENSION_SUFFIXES (сначала самый
    точный, .cp313-win_amd64.pyd). Модули под другие версии Python (остались от прежних пакетов) не подходят."""
    folder = Path(folder or ENGINE_DIR)
    for suffix in importlib.machinery.EXTENSION_SUFFIXES:
        path = folder / (ENGINE_NAME + suffix)
        if path.is_file():
            return path
    return None


class _ReadyLoader:
    """Загрузчик уже загруженного модуля: find_spec грузит файл сам, чтобы при ошибке отдать импорт дальше
    (модулю из сборки), а импорт получает готовый модуль — без второй инициализации."""

    def __init__(self, module):
        self.module = module

    def create_module(self, spec):
        return self.module

    def exec_module(self, module):
        pass


class EngineFinder:
    """Поиск в sys.meta_path: «import fx_engine» — из папки engine\\, если там есть модуль под этот Python и он
    загружается; иначе None, и fx_engine ищется как обычно (модуль из сборки)."""

    def __init__(self, folder: Path | None = None):
        self.folder = Path(folder or ENGINE_DIR)
        self.tried = False

    def find_spec(self, name, path=None, target=None):
        global _engine_status
        if name != ENGINE_NAME or self.tried:
            return None
        self.tried = True                                  # один раз: модуль pyo3 грузится в процесс однажды
        path = engine_file(self.folder)
        if path is None:
            return None
        try:
            loader = importlib.machinery.ExtensionFileLoader(ENGINE_NAME, str(path))
            spec = importlib.util.spec_from_file_location(ENGINE_NAME, str(path), loader=loader)
            module = importlib.util.module_from_spec(spec)
            loader.exec_module(module)
        except (ImportError, OSError) as exc:
            _engine_status = f"готовый модуль {path.name} не загрузился ({exc}) — модуль fx_engine из сборки программы"
            return None
        _engine_status = f"модуль fx_engine — готовый из обновления: {path.name}"
        ready = importlib.util.spec_from_file_location(ENGINE_NAME, str(path), loader=_ReadyLoader(module))
        # Модуль с однофазной инициализацией (pyo3) уже в sys.modules, и импорт возьмёт его __spec__: со старым
        # (ExtensionFileLoader) Python создал бы модуль ещё раз — второй вызов PyInit, а pyo3 (abi3) его
        # запрещает: «may only be initialized once per interpreter process».
        module.__spec__ = ready
        module.__loader__ = ready.loader
        return ready


def use_prebuilt_engine(folder: Path | None = None, force: bool = False) -> bool:
    """Включить готовый модуль из engine\\ (собранная программа; force — проверки). Повторный вызов ничего не
    добавляет. -> True, если поиск стоит в sys.meta_path."""
    if not (FROZEN or force):
        return False
    if any(isinstance(f, EngineFinder) for f in sys.meta_path):
        return True
    sys.meta_path.insert(0, EngineFinder(folder))
    return True


use_prebuilt_engine()                                  # собранная программа: готовый fx_engine, если есть
