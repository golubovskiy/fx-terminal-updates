# -*- coding: utf-8 -*-
"""Окно «Доступно обновление» и проверка по таймеру (update_dialog.py, 2.1.68): ответ проверки из рабочего потока
приходит в поток интерфейса, окно без кнопки по умолчанию, «Позже» не спрашивает снова ту же версию, «Установить»
отдаёт команду updater. Сеть не нужна: update_online.check подменяется. Настройки терминала не меняются.
Запуск:  python tests/test_update_dialog_online.py"""
from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import update_dialog as ud  # noqa: E402
import update_online as uo  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def _wait(cond, ms: int = 3000) -> bool:
    end = time.monotonic() + ms / 1000.0
    while time.monotonic() < end:
        APP.processEvents()
        if cond():
            return True
        time.sleep(0.01)
    return False


def _result(target="2.1.70", status=uo.OK):
    steps = [{"version": "2.1.69", "date": "2026-11-15", "changes": ["первое"], "build_rust": False},
             {"version": target, "date": "2026-11-16", "changes": ["второе"], "build_rust": True}]
    return uo.Result(status, current="2.1.68", latest=target, steps=steps if status == uo.OK else [],
                     files=[str(ROOT / "_install" / "downloads" / f"fx_update_{s['version']}.zip") for s in steps]
                     if status == uo.OK else [], message="доступна версия " + target)


def test_check_result_arrives_in_gui_thread():
    owner = QtCore.QObject()
    seen = {}
    saved = uo.check
    uo.check = lambda root: (seen.setdefault("worker", threading.current_thread().name), _result())[1]
    try:
        ud.run_check(owner, ROOT, lambda res: seen.update(gui=threading.current_thread().name, res=res))
        assert _wait(lambda: "res" in seen), seen
    finally:
        uo.check = saved
    assert seen["worker"] == "update-check" and seen["gui"] == threading.main_thread().name
    assert seen["res"].target == "2.1.70"


def test_dialog_has_no_default_button_and_gives_command():
    parent = QtWidgets.QWidget()
    dlg = ud.OnlineUpdateDialog(parent, _result(), ROOT)
    buttons = dlg.findChildren(QtWidgets.QPushButton)
    assert {b.text() for b in buttons} == {"Установить и перезапустить", "Позже"}
    assert not any(b.isDefault() or b.autoDefault() for b in buttons)            # Enter из стакана не нажмёт
    text = " ".join(label.text() for label in dlg.findChildren(QtWidgets.QLabel))
    assert "2.1.68 → 2.1.70" in text and "пакетов: 2" in text and "fx_engine" in text
    browser = dlg.findChild(QtWidgets.QTextBrowser).toPlainText()
    assert browser.index("2.1.70") < browser.index("2.1.69")                     # новые сверху
    dlg.ok.click()
    assert dlg.result() == QtWidgets.QDialog.DialogCode.Accepted
    assert dlg.command[2] == "apply" and dlg.command[3].endswith("fx_update_2.1.69.zip")
    assert dlg.command[4].endswith("fx_update_2.1.70.zip") and "--restart" in dlg.command
    parent.deleteLater()
    APP.processEvents()


def test_auto_checker_postpones_and_installs():
    window = QtWidgets.QWidget()
    installed = []
    saved = (ud.FIRST_CHECK_MS, ud.auto_check_enabled)
    ud.FIRST_CHECK_MS = 10 ** 9                       # без проверки по таймеру: результаты подаём сами
    try:
        checker = ud.AutoChecker(window, ROOT, install=lambda cmd: installed.append(cmd))
        checker._done(_result())                      # нашлось — окно
        dlg = checker._dialog
        assert dlg is not None and dlg.isVisible() and not dlg.isModal()
        assert dlg.testAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating)
        dlg.reject()                                  # «Позже»
        APP.processEvents()
        assert checker._dialog is None and installed == []
        checker._done(_result())                      # та же версия — не спрашиваем
        assert checker._dialog is None
        checker._done(_result("2.1.71"))              # новее — спрашиваем
        dlg = checker._dialog
        assert dlg is not None
        dlg.ok.click()
        APP.processEvents()
        assert len(installed) == 1 and installed[0][3].endswith("fx_update_2.1.69.zip"), installed
        checker._done(_result(status=uo.ERROR))       # сбой сети — окна нет
        assert checker._dialog is None
        ud.auto_check_enabled = lambda: False          # проверка выключена — check() ничего не запускает
        checker.check()
        assert not checker._busy
    finally:
        ud.FIRST_CHECK_MS, ud.auto_check_enabled = saved
        window.deleteLater()
        APP.processEvents()


def test_no_key_means_no_auto_check():
    saved = uo.PUBLIC_KEYS
    try:
        uo.PUBLIC_KEYS = ()
        window = QtWidgets.QWidget()
        assert ud.start_auto_check(window, ROOT) is None and not hasattr(window, "_update_checker")
        window.deleteLater()
    finally:
        uo.PUBLIC_KEYS = saved


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
