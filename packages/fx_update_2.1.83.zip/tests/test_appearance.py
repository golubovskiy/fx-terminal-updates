# -*- coding: utf-8 -*-
"""Проверка цветов и шрифтов из «Настроек» (appearance.py, appearance_pages.py) и окна стакана с ними:
сохранение и чтение, применение к стакану сразу (NOTIFIER.changed), кружки-индикаторы, звук «Уведомлений»
стакана, диалог настроек стакана, а также что окно стакана вообще создаётся (на этом раньше ловилась ошибка порядка инициализации).
Настройки терминала не трогаются — всё пишется во временный ini.  Запуск:  python tests/test_appearance.py"""
from __future__ import annotations

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):           # offscreen-Qt не видит шрифты Windows без подсказки
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))
# Окна стакана при закрытии сохраняют настройки (scalper_widget.save_config): в тестах — во временный файл,
# иначе тест перезаписал бы настоящий ~/.scalper_widget.json (настройки стаканов и шаблоны).
import tempfile as _tempfile  # noqa: E402
os.environ["SCALPER_CONFIG"] = os.path.join(_tempfile.mkdtemp(prefix="fx_scalper_cfg_"), "scalper.json")

from PySide6 import QtCore, QtGui, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import appearance  # noqa: E402

_TMP = tempfile.mkdtemp(prefix="fx_appearance_")
_INI = os.path.join(_TMP, "settings.ini")


def _temp_settings() -> QtCore.QSettings:
    return QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)


appearance._settings = _temp_settings          # все чтения и записи модуля — во временный файл

import scalper_widget as sw  # noqa: E402
import appearance_pages  # noqa: E402


def _clear():
    st = _temp_settings()
    st.clear()
    st.sync()


class FakeManager:
    hub = None

    def friendly(self, s):
        return s

    def from_friendly(self, text):
        return text

    def symbols(self):
        return ["USDRUBF@RTSX"]

    def catalog_symbols(self):
        return []


def _window():
    return sw.TerminalScalperWindow(FakeManager(), "USDRUBF@RTSX", "", 0.01, sw.Settings(), {}, embedded=True)


def test_color_overrides_roundtrip():
    _clear()
    appearance.save_overrides("dark", {"dom.bid": "#112233", "chart.up": "#80ff0000", "bad.key": "#000000",
                                       "dom.ask": "не цвет"})
    got = appearance.overrides("dark")
    assert got == {"dom.bid": "#112233", "chart.up": "#80ff0000"}, got
    assert appearance.overrides("light") == {}
    appearance.save_overrides("dark", {})                                    # «Сброс» — записей нет
    assert appearance.overrides("dark") == {}


def test_defaults_and_hex():
    assert appearance.default_color("dom.bid", "dark") == sw.CS_DARK["bid"].name()
    # сетка полупрозрачная — цвет с прозрачностью, #AARRGGBB; полоса объёма непрозрачная — #RRGGBB
    assert len(appearance.default_color("dom.grid", "dark")) == 9
    assert len(appearance.default_color("dom.gold", "dark")) == 7
    assert appearance.default_color("chart.bg", "light") == "#ffffff"
    for _group, items in appearance.COLOR_GROUPS:                            # у каждого ключа стакана есть цвет
        for key, _title in items:
            if key.startswith("dom."):
                assert key[4:] in sw.CS_DARK and key[4:] in sw.CS_LIGHT, key


def test_fonts_roundtrip_and_bad_values():
    _clear()
    prefs = appearance.FontPrefs(dom_family="Arial", dom_size=12, dom_row=15, dom_weight="Жирное",
                                 tape_size=11, chart_size=9, dom_antialias=False, dom_price="last3", dom_price_bold=2)
    appearance.save_fonts(prefs)
    assert appearance.load_fonts() == prefs
    st = _temp_settings()
    st.setValue("fonts/dom_row", "999")
    st.setValue("fonts/tick_weight", "Курсив")
    st.setValue("fonts/dom_size", "abc")
    st.setValue("fonts/dom_price", "что-то")
    st.setValue("fonts/dom_price_bold", "9")
    st.sync()
    got = appearance.load_fonts()
    assert got.dom_price == "sep" and got.dom_price_bold == appearance.PRICE_BOLD[-1]   # цена — по умолчанию
    assert got.dom_row == appearance.ROW_HEIGHTS[-1] and got.tick_weight == "Обычное"
    assert got.dom_size == 0 and got.dom_family == "Arial"                  # битое значение — по умолчанию


def test_stack_window_uses_colors_fonts_and_updates_live():
    _clear()
    appearance.save_overrides(appearance.saved_theme(), {"dom.bid": "#123456"})
    appearance.save_fonts(appearance.FontPrefs(dom_row=14))
    win = _window()
    try:
        assert sw.CS["bid"].name() == "#123456"
        assert win.ladder.row_h == 14 and win.ladder.base_row_h == 14
        assert win._hk_menu_actions, "пункты меню с горячими клавишами не заведены"
        win.ladder.grab()                                                    # отрисовка без стакана не падает
        win.tape.grab()
        # ОК в настройках: новая высота строки и шрифт — в открытом окне сразу
        appearance.save_fonts(appearance.FontPrefs(dom_row=18, dom_weight="Жирное"))
        appearance.NOTIFIER.changed.emit()
        assert win.ladder.row_h == 18 and sw.FONTS.dom_weight == "Жирное"
        assert win.ladder._font().bold()
    finally:
        win.close()
        win.deleteLater()


def test_status_leds():
    _clear()
    win = _window()
    try:
        assert isinstance(win.led_conn, sw._Led)
        win.on_status("STREAMING")
        assert win.led_conn._color.name() == sw.LED_ON
        win.on_error("обрыв потока")
        assert win.led_err._color.name() == sw.LED_ERR and "обрыв потока" in win.led_err.toolTip()
        win.on_status("STREAMING")                                           # поток снова пошёл — гаснет
        assert win.led_err._color.name() == sw.LED_NO_ERR and "обрыв потока" in win.led_err.toolTip()
        win.on_error("ещё раз")
        win.led_err.clicked.emit()                                           # щелчок — сброс
        assert win.led_err._color.name() == sw.LED_NO_ERR
        win.led_conn.grab()
    finally:
        win.close()
        win.deleteLater()


def test_pages():
    _clear()
    page = appearance_pages.ColorsPage("dark", "#888888")
    sw_bid = next(s for s in page.swatches if s.key == "dom.bid")
    sw_up = next(s for s in page.swatches if s.key == "chart.up")
    sw_bid.set_value("#010203")
    sw_up.set_value(sw_up.default)                                           # равен умолчанию — не изменение
    assert page.values() == {"dom.bid": "#010203"} and page.changed_areas() == {"dom"}
    page.reset_all()
    assert page.values() == {}
    fonts = appearance_pages.FontsPage("#888888")
    fonts.dom_row.setValue(20)
    assert fonts.values().dom_row == 20 and not fonts.chart_changed()
    fonts.chart_size.setCurrentIndex(fonts.chart_size.findData(10))
    assert fonts.chart_changed()
    fonts.dom_price.setCurrentIndex(fonts.dom_price.findData("last2"))
    fonts.dom_price_bold.setCurrentIndex(fonts.dom_price_bold.findData(2))
    assert fonts.values().dom_price == "last2" and fonts.values().dom_price_bold == 2



def test_stack_notifications_use_terminal_sound():
    _clear()
    played = []
    sw.set_notice_sound(played.append)
    win = _window()
    try:
        win.s.notify_big, win.s.big_volume, win.s.big_volume2 = True, 100, 1000
        win.on_book([(100.00, 500, 0)], snapshot=True)                       # уже стоял при подключении — молча
        assert played == []
        win.on_book([(100.01, 600, 0)], snapshot=False)                      # появился новый — звук «signal»
        assert played == ["signal"], played
        win._last_notify = 0.0
        win.notify("проверка")
        assert played[-1] == "pulse"
    finally:
        sw.set_notice_sound(None)
        win.close()
        win.deleteLater()


def test_stack_settings_dialog_builds():
    win = _window()
    try:
        dlg = sw.SettingsDialog(win, win.symbol, win.s, {})
        assert dlg.nav.objectName() == "settingsNav" and dlg.nav.count() == len(sw.SETTINGS_SPEC)
        assert all(dlg.nav.item(i).sizeHint().height() == 26 for i in range(dlg.nav.count()))
        dlg.grab()
        dlg.deleteLater()
    finally:
        win.close()
        win.deleteLater()


def test_digits_and_active_frame():
    assert sw.fmt_amount(100000) == "100 000" and sw.fmt_amount(100000, split=False) == "100000"
    assert sw.fmt_amount(11233, short=True) == "11,2K"
    _clear()
    a, b = _window(), _window()
    try:
        a.set_active(True)
        assert appearance.active_frame_color() in a._root.styleSheet()
        b.set_active(True)
        a.set_active(False)
        assert "transparent" in a._root.styleSheet()
        st = _temp_settings()
        st.setValue(appearance.ACTIVE_FRAME_KEY, False)
        st.sync()
        b.set_active(True)
        assert "transparent" in b._root.styleSheet()                     # галочка выключена — рамки нет
    finally:
        for w in (a, b):
            w.close()
            w.deleteLater()

if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
