# -*- coding: utf-8 -*-
"""Готовый модуль Rust в пакете обновления (2.1.83): tools/publish_update.py кладёт fx_engine….pyd из колеса
maturin в пакет (engine/…, manifest "engine"); updater принимает .pyd только так; собранная программа ставит
такой пакет без maturin, а app_paths.use_prebuilt_engine отдаёт на «import fx_engine» модуль из engine\\
(не подходит или не грузится — модуль из сборки программы).
Всё во временных папках, без Qt, сети и maturin. Пакеты собирает сам тест (_package — как в tools/make_update.py):
в собранной программе папки tools\\ с make_update.py нет, а проверки идут и там.
Запуск:  python tests/test_engine_prebuilt.py"""
from __future__ import annotations

import importlib.machinery
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import app_paths  # noqa: E402
import update_online  # noqa: E402
import updater  # noqa: E402


def _tool(name: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


publish_update = _tool("publish_update")                 # приходит этим же пакетом (и в собранную программу)


def _package(src: Path, version: str, files: list[str], out: Path, build_rust: bool = False) -> Path:
    """Пакет из файлов src — тот же manifest.json, что у tools/make_update.build (version.py — всегда)."""
    rels = list(dict.fromkeys([*files, "version.py"]))
    manifest = {"format": updater.FORMAT, "app": "FX Terminal", "version": version, "date": "2026-11-16",
                "changes": ["проверка"], "files": {}, "delete": [], "pip": [], "build_rust": build_rust}
    for rel in rels:
        assert updater.allowed_path(rel) is None, rel
        manifest["files"][rel] = {"sha256": updater.sha256_file(src / rel), "size": (src / rel).stat().st_size}
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"fx_update_{version}.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(updater.MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=1))
        for rel in rels:
            zf.write(src / rel, rel)
    updater.read_package(target)
    return target

PYD = "fx_engine.cp313-win_amd64.pyd"
VERSION_PY = 'VERSION = "{v}"\nBUILD_DATE = "2026-11-16"\n\nCHANGES: list[tuple[str, str, list[str]]] = [\n]\n'


def quiet(*_a, **_k):
    pass


def _fake_wheel(folder: Path, data: bytes = b"MZ fake engine") -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    wheel = folder / "fx_engine-0.7.0-cp313-cp313-win_amd64.whl"
    with zipfile.ZipFile(wheel, "w") as zf:
        zf.writestr("fx_engine/__init__.py", "from .fx_engine import *\n")
        zf.writestr(f"fx_engine/{PYD}", data)
        zf.writestr("fx_engine-0.7.0.dist-info/METADATA", "Name: fx_engine\n")
    return wheel


def _source(version: str = "2.0.1") -> Path:
    """«Папка автора»: version.py, модуль, исходник Rust; пакет с пересборкой Rust."""
    src = Path(tempfile.mkdtemp(prefix="fx_eng_src_"))
    (src / "version.py").write_text(VERSION_PY.format(v=version), encoding="utf-8")
    (src / "a.py").write_text("A = 2\n", encoding="utf-8")
    (src / "fx_engine_rs" / "src").mkdir(parents=True)
    (src / "fx_engine_rs" / "src" / "lib.rs").write_text("// v2\n", encoding="utf-8")
    return src


def test_allowed_pyd_only_engine():
    assert updater.allowed_path(f"engine/{PYD}") is None
    assert updater.allowed_path("engine/fx_engine.pyd") is None
    for bad in (PYD, "engine/other.pyd", "engine/sub/fx_engine.pyd", f"brokers/{PYD}", "engine/fx_engine_x.pyd",
                "engine/fx_engine.dll"):
        assert updater.allowed_path(bad), bad


def test_embed_engine_into_package():
    src = _source()
    try:
        pkg = _package(src, "2.0.1", ["a.py", "fx_engine_rs/src/lib.rs"], src / "out", build_rust=True)
        wheel = _fake_wheel(src / "wheel")
        new = publish_update.embed_engine(pkg, src / "pub", src, wheel=wheel, log=quiet)
        assert new != pkg and new.name == pkg.name
        man = updater.read_package(new)                                   # суммы и пути — как при установке
        assert man["engine"] == f"engine/{PYD}" and man["build_rust"] is True
        assert set(man["files"]) == {"a.py", "fx_engine_rs/src/lib.rs", "version.py", f"engine/{PYD}"}
        with zipfile.ZipFile(new) as zf:
            assert zf.read(f"engine/{PYD}") == b"MZ fake engine"
        assert publish_update.embed_engine(new, src / "pub2", src, wheel=wheel, log=quiet) == new   # уже есть
        plain = _package(src, "2.0.1", ["a.py"], src / "out2")
        assert publish_update.embed_engine(plain, src / "pub3", src, wheel=wheel, log=quiet) == plain
        entry = update_online.entry_for(new, "packages/fx_update_2.0.1.zip")
        assert entry["engine"] is True and entry["build_rust"] is True
    finally:
        shutil.rmtree(src, ignore_errors=True)


def test_engine_wheel_choice_and_sources_check():
    src = _source()
    try:
        pkg = _package(src, "2.0.1", ["fx_engine_rs/src/lib.rs"], src / "out", build_rust=True)
        wheel = _fake_wheel(publish_update.wheels_dir(src))
        later = time.time() + 60
        os.utime(wheel, (later, later))                                   # колесо новее исходников — берём его
        assert publish_update.engine_wheel(src, build=False) == wheel
        new = publish_update.embed_engine(pkg, src / "pub", src, log=quiet)
        assert updater.read_package(new)["engine"] == f"engine/{PYD}"
        earlier = time.time() - 3600
        os.utime(wheel, (earlier, earlier))                               # исходники новее — колесо старое
        assert publish_update.engine_wheel(src, build=False) is None
        assert publish_update.embed_engine(pkg, src / "pub2", src, build=False, log=quiet) == pkg  # пробный запуск
        (src / "fx_engine_rs" / "src" / "lib.rs").write_text("// другой\n", encoding="utf-8")
        try:
            publish_update.embed_engine(pkg, src / "pub3", src, log=quiet)
            raise AssertionError("модуль из чужих исходников принят")
        except publish_update.PublishError as exc:
            assert "поставьте пакет 2.0.1" in str(exc)
        bad = src / "bad.whl"
        with zipfile.ZipFile(bad, "w") as zf:
            zf.writestr("fx_engine/fx_engine.cpython-313-x86_64-linux-gnu.so", b"ELF")
        try:
            publish_update.engine_from_wheel(bad)
            raise AssertionError("колесо без .pyd принято")
        except publish_update.PublishError as exc:
            assert "Windows" in str(exc)
    finally:
        shutil.rmtree(src, ignore_errors=True)


def test_frozen_installs_engine_without_maturin():
    src = _source()
    root = Path(tempfile.mkdtemp(prefix="fx_eng_root_"))
    saved = updater.FROZEN
    try:
        (root / "version.py").write_text(VERSION_PY.format(v="2.0.0"), encoding="utf-8")
        (root / "a.py").write_text("A = 1\n", encoding="utf-8")
        updater.ensure_baseline(root)
        pkg = _package(src, "2.0.1", ["a.py", "fx_engine_rs/src/lib.rs"], src / "out", build_rust=True)
        new = publish_update.embed_engine(pkg, src / "pub", src, wheel=_fake_wheel(src / "wheel"), log=quiet)
        updater.FROZEN = True
        plan = updater.plan(root, updater.read_package(pkg))              # без готового модуля — только установщик
        assert not plan["requires_ok"] and updater.FROZEN_BLOCK in plan["warnings"]
        plan = updater.plan(root, updater.read_package(new))
        assert plan["requires_ok"] and not plan["build_rust"] and plan["engine"] == f"engine/{PYD}", plan
        res = updater.apply_chain(root, [new], checks=False, log=quiet)   # maturin не запускается
        assert res["status"] == "ok", res
        assert (root / "engine" / PYD).read_bytes() == b"MZ fake engine"
        assert (root / "a.py").read_text(encoding="utf-8") == "A = 2\n"
        updater.FROZEN = False                                            # из исходников — пересборка, как раньше
        assert updater.plan(root, updater.read_package(new))["build_rust"] is True
    finally:
        updater.FROZEN = saved
        shutil.rmtree(src, ignore_errors=True)
        shutil.rmtree(root, ignore_errors=True)


def test_engine_file_and_broken_module():
    folder = Path(tempfile.mkdtemp(prefix="fx_eng_dir_"))
    status = app_paths._engine_status
    try:
        assert app_paths.engine_file(folder) is None
        (folder / "fx_engine.cp20-fake_arch.pyd").write_bytes(b"x")             # чужой Python — не подходит
        assert app_paths.engine_file(folder) is None
        suffix = importlib.machinery.EXTENSION_SUFFIXES[0]
        broken = folder / ("fx_engine" + suffix)
        broken.write_bytes(b"not a module")
        assert app_paths.engine_file(folder) == broken
        finder = app_paths.EngineFinder(folder)
        assert finder.find_spec("numpy") is None and not finder.tried
        assert finder.find_spec("fx_engine") is None                             # не грузится — модуль из сборки
        assert "не загрузился" in app_paths.engine_status()
        assert "fx_engine" not in sys.modules or sys.modules["fx_engine"].__spec__.origin != str(broken)
    finally:
        app_paths._engine_status = status
        shutil.rmtree(folder, ignore_errors=True)
    if not app_paths.FROZEN:
        assert not any(isinstance(f, app_paths.EngineFinder) for f in sys.meta_path)   # из исходников — выключен


def _built_engine() -> Path | None:
    """Файл собранного fx_engine этого Python (колесо maturin кладёт его в папку fx_engine/), без импорта."""
    for entry in sys.path:
        for folder in (Path(entry or ".") / "fx_engine", Path(entry or ".")):
            for suffix in importlib.machinery.EXTENSION_SUFFIXES:
                path = folder / ("fx_engine" + suffix)
                if path.is_file():
                    return path
    return None


def test_real_engine_from_engine_dir():
    """Настоящий модуль (если собран): копия в engine\\ грузится оттуда, отдельным процессом — модуль pyo3
    загружается в процесс один раз."""
    built = _built_engine()
    if built is None:
        print("    (fx_engine не собран — пропуск)")
        return
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        tmp = Path(tmp)
        engine = tmp / "engine"
        engine.mkdir()
        shutil.copy2(built, engine / built.name)
        script = tmp / "probe.py"
        script.write_text(
            "import json, sys\n"
            f"sys.path.insert(0, {str(ROOT)!r})\n"
            "import app_paths\n"
            "sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, app_paths.EngineFinder)]\n"
            f"app_paths.use_prebuilt_engine({str(engine)!r}, force=True)\n"
            "import fx_engine\n"
            "print(json.dumps({'file': fx_engine.__spec__.origin, 'version': fx_engine.__version__,\n"
            "                  'status': app_paths.engine_status()}, ensure_ascii=True))\n",
            encoding="utf-8")
        res = subprocess.run([*app_paths.python_command(), str(script)], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=120, cwd=str(tmp))
        assert res.returncode == 0, res.stdout + res.stderr
        info = json.loads(res.stdout.strip().splitlines()[-1])
        assert Path(info["file"]).resolve() == (engine / built.name).resolve(), info
        assert "готовый из обновления" in info["status"] and info["version"], info


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
