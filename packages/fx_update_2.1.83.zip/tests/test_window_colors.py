# -*- coding: utf-8 -*-
"""Свои цвета окон (2.1.83): «Фон окон» / «Текст» всего приложения (оттенки — fx_theme.shades), фон и текст окон
«Тики Bid/Ask», «Покупка/Продажа», «Баланс покупок/продаж», «Алгоритмы», «Открытый интерес», «CNY Forward»,
«Опционы», «ATR», «Заметки» (appearance.window_qss), цвета их графиков (палитры окон), размеры шрифта окон и
часов и кнопка «▶» FX Robot End в одном столбце со звуками сделок.
Настройки терминала не трогаются: все чтения и записи — во временный файл.  Запуск:  python tests/test_window_colors.py"""
from __future__ import annotations

import os
import sys
import tempfile
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))

from PySide6 import QtCore, QtGui, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import appearance  # noqa: E402

_INI = os.path.join(tempfile.mkdtemp(prefix="fx_wincolors_"), "settings.ini")
appearance._settings = lambda: QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)

import fx_theme  # noqa: E402


def _set(values: dict, fonts: dict | None = None) -> QtCore.QSettings:
    st = appearance._settings()
    st.clear()
    appearance.save_overrides("dark", values, st)
    prefs = appearance.FontPrefs(**(fonts or {}))
    appearance.save_fonts(prefs, st)
    st.sync()
    return st


def _light(color: str) -> int:
    return QtGui.QColor(color).lightness()


def test_shades_follow_background():
    dark = fx_theme.shades("#202830", "#e0e0e0")
    assert dark["BG_WINDOW"] == "#202830" and dark["TEXT"] == "#e0e0e0"
    assert _light(dark["BG_PANEL"]) > _light("#202830") and _light(dark["BG_INPUT"]) < _light("#202830")
    assert _light("#202830") < _light(dark["TEXT_DIM"]) < _light("#e0e0e0")
    light = fx_theme.shades("#f0f0f0", "#202020")                  # светлый фон — поля светлее, панели темнее
    assert _light(light["BG_PANEL"]) < _light("#f0f0f0") <= _light(light["BG_INPUT"])
    assert fx_theme.mix("#000000", "#ffffff", 0.5) in ("#808080", "#7f7f7f")


def test_every_color_has_default():
    for theme in ("dark", "light"):
        for key in appearance.COLOR_TITLES:
            assert QtGui.QColor(appearance.default_color(key, theme)).isValid(), (theme, key)
    assert appearance.default_color("app.bg", "dark") == fx_theme.base_colors("dark")["BG_WINDOW"]
    _set({"app.bg": "#203040"})
    assert appearance.default_color("algo.bg", "dark") == "#203040"          # окно — как всё приложение
    _set({})


def test_app_background_and_text():
    try:
        _set({"app.bg": "#203040", "app.text": "#f0e0c0"})
        qss = fx_theme.stylesheet("dark")
        assert fx_theme.BG_WINDOW == "#203040" and fx_theme.TEXT == "#f0e0c0"
        assert fx_theme.BG_PANEL != fx_theme.base_colors("dark")["BG_PANEL"]
        assert "#203040" in qss and "#f0e0c0" in qss
        _set({})
        fx_theme.stylesheet("dark")
        assert fx_theme.BG_WINDOW == fx_theme.base_colors("dark")["BG_WINDOW"]       # сброс — снова тема
        assert fx_theme.TEXT == fx_theme.base_colors("dark")["TEXT"]
    finally:
        _set({})
        fx_theme.stylesheet("dark")


def test_window_rules():
    assert appearance.window_qss("dark", _set({})) == ""                           # ничего не задано — правил нет
    st = _set({"algo.bg": "#101010", "notes.text": "#eeeeee"}, {"notes_pt": 13})
    qss = appearance.window_qss("dark", st)
    assert "QWidget#fxAlgo { background-color: #101010; }" in qss
    assert "#fxNotes QLabel" in qss and "#eeeeee" in qss and "font-size: 13pt" in qss
    assert "fxAtr" not in qss and "fxOptions" not in qss
    import app_common
    full = app_common.app_stylesheet("dark")
    assert "QWidget#fxAlgo { background-color: #101010; }" in full
    APP.setStyleSheet(full)                                                       # Qt разбирает стиль без ошибок
    widget = QtWidgets.QWidget()
    appearance.style_window(widget, "algo")
    assert widget.objectName() == "fxAlgo" and widget.testAttribute(QtCore.Qt.WidgetAttribute.WA_StyledBackground)
    APP.setStyleSheet("")
    _set({})


def test_window_palettes():
    _set({"opt.chart_bg": "#000011", "opt.call": "#00ff00", "opt.text": "#fafafa",
          "atr.bg": "#111111", "atr.line": "#ff00ff", "atr.text": "#eeeeee"})
    import options_theme
    pal = options_theme.palette()
    assert pal["bg"] == "#000011" and pal["call"] == "#00ff00" and pal["text"] == pal["chart_text"] == "#fafafa"
    import atr_window
    c = atr_window.colors()
    assert c["bg"] == "#111111" and c["line"] == "#ff00ff" and c["text"] == "#eeeeee" and c["user_text"]
    assert "#111111" not in atr_window.card_style(c) and c["panel"] in atr_window.card_style(c)
    with tempfile.TemporaryDirectory() as tmp:
        host = SimpleNamespace(md_hub=None, sdk_client=None, display_tz="Europe/Moscow", history_period="1m",
                               _active_assets=None,
                               settings=QtCore.QSettings(os.path.join(tmp, "atr.ini"), QtCore.QSettings.Format.IniFormat))
        panel = atr_window.AtrPanel(host, None, autostart=False)
        assert panel.objectName() == "fxAtr"
        assert panel.curve.opts["pen"].color().name() == "#ff00ff"
        panel.close()
        panel.deleteLater()
    _set({})
    assert atr_window.colors()["line"] == fx_theme.ACCENT and options_theme.palette()["call"] == fx_theme.BUY


def test_dashboard_colors():
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    import matplotlib.colors as mc
    import cny_forward_tab
    _set({"cny.dash_bg": "#101418", "cny.dash_text": "#e0e0e0"})
    fig = Figure()
    axes = fig.subplots(2, 1)
    axes[0].plot([1, 2], [1, 2], label="a")
    axes[0].legend()
    axes[0].set_title("Базис", loc="left")
    cny_forward_tab._apply_dashboard_colors(fig, axes)
    assert mc.to_hex(fig.get_facecolor()) == "#101418" and mc.to_hex(axes[1].get_facecolor()) == "#101418"
    assert mc.to_hex(axes[0]._left_title.get_color()) == "#e0e0e0"
    _set({})
    fig2 = Figure()
    ax2 = fig2.subplots(1, 1)
    cny_forward_tab._apply_dashboard_colors(fig2, [ax2])                       # не задано — как было
    assert mc.to_hex(fig2.get_facecolor()) == "#ffffff"


def test_ticks_and_balance_look():
    import tick_volume_window as tv
    import order_flow
    _set({"ticks.ask": "#00ff00", "ticks.large": "#123456", "ticks.clock": "#ff0000", "ticks.plot_bg": "#000000",
          "ticks.text": "#ffffff", "balance.up": "#0000ff", "balance.plot_bg": "#010203"},
         {"ticks_clock_px": 24, "ticks_pt": 11, "balance_pt": 12, "flow_pt": 13})
    look = tv._user_look()
    assert tv.ASK_COLOR.name() == "#00ff00" and tv.LARGE_COLOR.name() == "#123456"
    assert look["clock"] == "#ff0000" and look["clock_px"] == 24 and look["plot_bg"] == "#000000"
    assert look["axis_pt"] == 11 and look["axis_text"]
    assert tv.BID_COLOR.name() == "#e61e1e"                                    # не задано — как было
    bal = order_flow.balance_look()
    assert bal["up"] == "#0000ff" and bal["plot_bg"] == "#010203" and bal["axis_pt"] == 12
    qss = appearance.window_qss("dark", appearance._settings())
    for name, size in (("fxTickWindow", 11), ("fxBalance", 12), ("fxOrderFlow", 13)):
        assert f"QWidget#{name}, #{name} QWidget {{ font-size: {size}pt; }}" in qss, name
    _set({})
    look = tv._user_look()
    assert tv.ASK_COLOR.name() == "#2ecc55" and look["clock_px"] == tv.CLOCK_PX and look["axis_text"] is None
    assert appearance.default_color("balance.up", "dark") == appearance.chart_hex("up")   # как свечи графиков
    from candlestick_item import BULL_COLOR
    assert order_flow.balance_look()["up"] == BULL_COLOR


def test_robot_end_play_in_one_column():
    import settings_dialog
    st = QtCore.QSettings(os.path.join(tempfile.mkdtemp(), "s.ini"), QtCore.QSettings.Format.IniFormat)
    dlg = settings_dialog.SettingsDialog(st, None)
    try:
        dlg.sections.setCurrentRow(list(dlg.PAGES).index("Звук"))
        dlg.show()
        APP.processEvents()
        right = lambda w: w.mapTo(dlg, QtCore.QPoint(w.width(), 0)).x()
        end = dlg.robot_end_play
        plays = list(dlg.trade_sound_plays.values())
        assert plays and all(abs(right(end) - right(p)) <= 2 for p in plays), (right(end), [right(p) for p in plays])
        assert all(end.width() == p.width() for p in plays)
    finally:
        dlg.reject()
        dlg.deleteLater()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
