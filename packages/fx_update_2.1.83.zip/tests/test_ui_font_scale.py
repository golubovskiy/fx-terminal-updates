# -*- coding: utf-8 -*-
"""Подписи со своим размером — вслед за общим размером шрифта интерфейса (2.1.83, «Настройки» → «Размер шрифта»):
карточки «Открытого интереса», «Опционов» («Открытый интерес» и «Гамма (GEX)»), значения «ATR», всплывающее
«Мировое время» и значок уведомлений. При «Как в теме» — прежние размеры; после OK в «Настройках»
(appearance.NOTIFIER.changed) открытые окна пересчитывают размеры сами.
Настройки терминала не трогаются: всё — во временный файл.  Запуск:  python tests/test_ui_font_scale.py"""
from __future__ import annotations

import os
import sys
import tempfile
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
APP.setProperty("fx_base_font_pt", 9)             # шрифт темы, как его запоминает app_common.apply_app_font_size

import appearance  # noqa: E402

_TMP = tempfile.mkdtemp(prefix="fx_uifont_")
_INI = os.path.join(_TMP, "settings.ini")
appearance._settings = lambda: QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)


def _font(size: int) -> None:
    """«Размер шрифта» в настройках и OK: окна получают appearance.NOTIFIER.changed."""
    st = appearance._settings()
    st.setValue(appearance.UI_FONT_KEY, size)
    st.sync()
    appearance.NOTIFIER.changed.emit()


def test_scale_numbers():
    _font(0)
    assert appearance.ui_scale() == 1.0 and appearance.ui_px(15) == 15 and appearance.ui_pt(9) == 9
    _font(12)
    assert abs(appearance.ui_scale() - 12 / 9) < 1e-9
    assert appearance.ui_px(15) == 20 and appearance.ui_pt(9) == 12 and appearance.ui_px(10) == 13
    _font(1)                                                       # мусор в настройках — не меньше половины
    assert appearance.ui_scale() == 0.5 and appearance.ui_px(10) == 6
    _font(0)


def test_open_interest_cards():
    import open_interest_tab
    _font(0)
    tab = open_interest_tab.OpenInterestTab()
    try:
        assert "QLabel#oi { font-size: 20px;" in tab.styleSheet()
        _font(12)
        assert "QLabel#oi { font-size: 27px;" in tab.styleSheet() and "QLabel#name { font-size: 19px;" in tab.styleSheet()
    finally:
        _font(0)
        tab.stop()
        tab.deleteLater()


def test_options_cards():
    from options_oi_view import OIProfileView
    from options_gex_view import GexView
    _font(0)
    view, gex = OIProfileView(), GexView()
    try:
        assert "font-size:15px" in view.call_card.value_label.styleSheet()
        assert "font-size:10px" in view.call_card.title_label.styleSheet()
        _font(12)
        assert "font-size:20px" in view.call_card.value_label.styleSheet()
        assert "font-size:13px" in view.call_card.title_label.styleSheet()
        assert "font-size:20px" in gex.total_card.value_label.styleSheet()
        import options_oi_view as ov
        ov.set_card_value(gex.mode_card, "#00ff00", 13)               # как при новых данных GEX
        assert "font-size:17px" in gex.mode_card.value_label.styleSheet() and "#00ff00" in \
            gex.mode_card.value_label.styleSheet()
        _font(0)
        assert "font-size:13px" in gex.mode_card.value_label.styleSheet()   # размер своей карточки помнится
    finally:
        _font(0)
        view.deleteLater()
        gex.deleteLater()


def test_atr_values():
    import atr_window
    _font(0)
    host = SimpleNamespace(md_hub=None, sdk_client=None, display_tz="Europe/Moscow", history_period="1m",
                           _active_assets=None,
                           settings=QtCore.QSettings(os.path.join(_TMP, "atr.ini"), QtCore.QSettings.Format.IniFormat))
    panel = atr_window.AtrPanel(host, None, autostart=False)
    try:
        assert "font-size: 15px" in panel.atr_label.styleSheet()
        _font(12)
        assert "font-size: 20px" in panel.atr_label.styleSheet() and "font-size: 20px" in panel.left_label.styleSheet()
    finally:
        _font(0)
        panel.close()
        panel.deleteLater()


def test_world_time_and_badge():
    import status_clock
    import notify_badge
    _font(0)
    qss = status_clock._world_time_qss()
    assert "font-size: 9pt;" in qss and "font-size: 10pt;" in qss
    badge = notify_badge.NotifyBadgeButton(popup_source=lambda: "x")
    try:
        assert badge.sizeHint() == QtCore.QSize(34, 24)
        _font(12)
        qss = status_clock._world_time_qss()
        assert "font-size: 12pt;" in qss and "font-size: 13pt;" in qss
        assert badge.sizeHint() == QtCore.QSize(45, 32)
        badge.set_state(7, 2)
        badge.resize(badge.sizeHint())
        assert not badge.grab().isNull()                              # рисуется в новом размере без ошибок
    finally:
        _font(0)
        badge.deleteLater()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
