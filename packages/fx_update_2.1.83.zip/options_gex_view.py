# -*- coding: utf-8 -*-
"""Вкладка «Гамма (GEX)» опционной цепочки FX Terminal: гамма-экспозиция по страйкам и суммарная GEX по цене.

Чистое представление без сети и файлов: родитель (options_chain_chart_widget) передаёт профиль
option_levels.gex_profile (фьючерсов на 1% движения) и множитель стоимости контракта (option_levels.contract_units)
для показа в рублях. Расчёты — option_levels.py.

Графики:
    сверху  — GEX по страйкам: коллы зелёным вверх («+»), путы красным вниз («−»), точка — нетто страйка;
    снизу   — суммарная GEX всех опционов экспирации при разной цене базового актива: красная зона —
              отрицательная гамма (хедж может усиливать ход), зелёная — положительная (хедж может гасить ход);
              вертикальные линии — Gamma flip (смена знака) и текущая цена.
Подсказки: наведите мышь на страйк — GEX коллов / путов / нетто и OI; на кривую — сколько фьючерсов хеджерам
купить или продать при движении на 1%, если цена окажется там.

Единицы — переключатель «фьючерсов на 1%» / «₽ на 1%» (₽ = фьючерсы × цена × множитель контракта;
выбор хранится в QSettings). Знак — допущение: дилеры (маркет-мейкеры) длинные по коллам и короткие по путам;
кто на какой стороне OI на самом деле, Finam не показывает.
"""
from __future__ import annotations

import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, Signal
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QSplitter, QToolTip, QVBoxLayout, QWidget

import option_levels as ol
import options_oi_view as ov

UNITS_KEY = "options/gex_units"            # "fut" — фьючерсов на 1%, "rub" — рублей на 1%
NET_COLOR = "#e8ecf3"
FLIP_COLOR = ol.LEVEL_COLORS["gamma_flip"]
POS_FILL = (53, 201, 139, 55)
NEG_FILL = (237, 91, 104, 55)
ASSUMPTION = "Знак — допущение: дилеры длинные CALL и короткие PUT (Finam не показывает, кто на какой стороне OI)."


def fmt_gex(value: float | None, rub: bool) -> str:
    """GEX для подписей: фьючерсы — «+1 234 фьюч.», рубли — «+3,1 млн ₽» / «+450 тыс. ₽»."""
    if value is None:
        return "—"
    if not rub:
        return f"{value:+,.0f}".replace(",", " ") + " фьюч."
    a = abs(value)
    for size, digits, name in ((1e9, 2, "млрд ₽"), (1e6, 1, "млн ₽"), (1e3, 0, "тыс. ₽"), (1.0, 0, "₽")):
        if a >= size or size == 1.0:
            return f"{value / size:+.{digits}f}".replace(".", ",") + " " + name


def _with_zero_crossings(curve: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Кривая с точками ровно на нуле между соседями разного знака — заливки зон смыкаются без щелей."""
    out = []
    for (p0, v0), (p1, v1) in zip(curve, curve[1:]):
        out.append((p0, v0))
        if v0 and v1 and (v0 < 0) != (v1 < 0):
            out.append((p0 + (p1 - p0) * v0 / (v0 - v1), 0.0))
    if curve:
        out.append(curve[-1])
    return out


class GexView(QWidget):
    unitsChanged = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        ov.apply_palette()
        try:                                       # карточки — вслед за шрифтом интерфейса (2.1.83)
            import appearance
            appearance.NOTIFIER.changed.connect(self._restyle_cards)
        except Exception:                          # noqa: BLE001
            pass
        self._sig = None
        self._profile: dict | None = None
        self._units: float | None = None          # множитель стоимости контракта (None — рубли недоступны)
        self._title = ""
        self._items: list = []                    # пересоздаваемые элементы графиков (столбики, заливки, подписи)
        self._ranged_for: str | None = None       # для какого заголовка уже выставлен диапазон по цене
        self._build_ui()
        self._hook_hover()

    # ---- интерфейс -----------------------------------------------------------------------
    def _restyle_cards(self) -> None:
        ov.restyle_cards(self)


    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 6, 0, 0)
        outer.setSpacing(8)
        self.note_label = QLabel("")
        self.note_label.setStyleSheet(f"color:{ov.MUTED};")
        self.note_label.setWordWrap(True)
        outer.addWidget(self.note_label)

        cards = QHBoxLayout()
        self.total_card = ov.OIProfileView._card("GEX СЕЙЧАС", ov.TEXT)
        self.total_card.setToolTip("Суммарная гамма-экспозиция всех опционов экспирации при текущей цене:\n"
                                   "сколько фьючерсов хеджерам продать (+) или купить (−) при росте цены на 1%")
        self.mode_card = ov.OIProfileView._card("РЕЖИМ", ov.TEXT)
        self.mode_card.setToolTip("Положительная гамма — хеджеры торгуют против движения (продают на росте, покупают\n"
                                  "на падении): ход гасится, рынок «вязкий». Отрицательная — по движению: ход усиливается")
        self.flip_card = ov.OIProfileView._card("GAMMA FLIP", FLIP_COLOR)
        self.flip_card.setToolTip("Цена, где суммарная GEX меняет знак; в скобках — расстояние от текущей цены")
        self.top_card = ov.OIProfileView._card("КРУПНЕЙШИЙ СТРАЙК", ov.HIGHLIGHT)
        self.top_card.setToolTip("Страйк с наибольшей по модулю нетто-GEX (коллы + путы)")
        self.cards = (self.total_card, self.mode_card, self.flip_card, self.top_card)
        for card in self.cards:
            cards.addWidget(card, 1)
        units_box = QVBoxLayout()
        units_box.addWidget(QLabel("Единицы"))
        self.units_combo = QComboBox()
        self.units_combo.addItem("фьючерсов на 1%", "fut")
        self.units_combo.addItem("₽ на 1%", "rub")
        saved = str(QSettings("MyTradingTools", "FxTerminal").value(UNITS_KEY, "fut"))
        self.units_combo.setCurrentIndex(max(0, self.units_combo.findData(saved)))
        self.units_combo.currentIndexChanged.connect(self._on_units)
        units_box.addWidget(self.units_combo)
        cards.addLayout(units_box)
        outer.addLayout(cards)

        vertical = QSplitter(Qt.Orientation.Vertical)
        self.strike_plot = pg.PlotWidget()
        ov.OIProfileView._style_plot(self.strike_plot)
        # Обозначения — цветными значками прямо в заголовке: легенда pyqtgraph рисовала значки пустых
        # элементов серыми (01.11, скриншот)
        self.strike_plot.setTitle(
            f"GEX по страйкам &nbsp; <span style='color:{ov.CALL_COLOR}'>■ CALL (+)</span> &nbsp; "
            f"<span style='color:{ov.PUT_COLOR}'>■ PUT (−)</span> &nbsp; "
            f"<span style='color:{NET_COLOR}'>● нетто</span>", color=ov.CHART_TEXT, size="12pt")
        self.strike_plot.addItem(pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(ov.CHART_MUTED, width=1)))
        vertical.addWidget(self.strike_plot)

        self.curve_plot = pg.PlotWidget()
        ov.OIProfileView._style_plot(self.curve_plot)
        self.curve_plot.setTitle("Суммарная GEX по цене базового актива", color=ov.CHART_TEXT, size="12pt")
        self.curve_plot.setLabel("bottom", "Цена базового актива")
        self.curve_plot.setXLink(self.strike_plot)
        self.curve_plot.addItem(pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(ov.CHART_MUTED, width=1)))
        self.curve = self.curve_plot.plot([], [], pen=pg.mkPen(ov.CHART_TEXT, width=2))
        vertical.addWidget(self.curve_plot)

        self.price_lines = []
        self.flip_lines = []
        for plot in (self.strike_plot, self.curve_plot):
            price = pg.InfiniteLine(angle=90, pen=pg.mkPen(ov.PRICE_COLOR, width=1, style=Qt.PenStyle.DashLine))
            flip = pg.InfiniteLine(angle=90, pen=pg.mkPen(FLIP_COLOR, width=1.5))
            for line in (price, flip):
                line.setZValue(40)
                line.hide()
                plot.addItem(line, ignoreBounds=True)
            self.price_lines.append(price)
            self.flip_lines.append(flip)
        vertical.setStretchFactor(0, 1)
        vertical.setStretchFactor(1, 1)
        outer.addWidget(vertical, 1)

    def _on_units(self, _i: int) -> None:
        QSettings("MyTradingTools", "FxTerminal").setValue(UNITS_KEY, self.units_combo.currentData())
        self._sig = None
        if self._profile is not None:
            self._render()
        self.unitsChanged.emit()

    def _rub(self) -> bool:
        return self.units_combo.currentData() == "rub" and self._units is not None

    def _scale(self, price: float) -> float:
        """Множитель «фьючерсы → выбранные единицы» при цене price (рубли: × цена × множитель контракта)."""
        return price * self._units if self._rub() else 1.0

    # ---- API для родителя ------------------------------------------------------------------

    def clear(self) -> None:
        self._drop_items()
        self.curve.setData([], [])
        for card in self.cards:
            card.value_label.setText("—")
        for line in self.price_lines + self.flip_lines:
            line.hide()
        self.note_label.setText("")
        self._sig, self._profile, self._ranged_for = None, None, None
        for line in getattr(self, "_hover_lines", {}).values():
            line.hide()

    def set_data(self, profile: dict | None, title: str, units: float | None) -> None:
        """profile — option_levels.gex_profile (или None — нет данных); units — option_levels.contract_units
        базового актива (None — показ в рублях недоступен)."""
        sig = (title, units, self.units_combo.currentData(),
               None if profile is None else (round(profile["total"], 6), profile["flip"], profile["price"],
                                             tuple((k, round(c, 6), round(p, 6)) for k, c, p, _a, _b in
                                                   profile["strikes"])))
        if sig == self._sig:
            return
        self._sig = sig
        self._profile, self._units, self._title = profile, units, title
        rub_item = self.units_combo.model().item(1)
        if rub_item is not None:
            rub_item.setEnabled(units is not None)
            rub_item.setToolTip("" if units is not None else "Стоимость контракта этого базового актива неизвестна")
        if profile is None:
            self.clear()
            self._sig = sig
            self.note_label.setText(f"{title}: нет опционов с открытым интересом и IV — GEX не посчитать. "
                                    "Ждём котировки Finam.")
            return
        self._render()

    # ---- отрисовка -------------------------------------------------------------------------

    def _drop_items(self) -> None:
        for plot, item in self._items:
            plot.removeItem(item)
        self._items = []

    def _add(self, plot, item, **kw) -> None:
        plot.addItem(item, **kw)
        self._items.append((plot, item))

    def _render(self) -> None:
        prof = self._profile
        rub = self._rub()
        price = prof["price"]
        unit_name = "млн ₽ на 1%" if rub else "фьючерсов на 1%"
        div = 1e6 if rub else 1.0                 # рубли на осях — в миллионах
        self._drop_items()

        strikes = prof["strikes"]
        ks = [k for k, *_r in strikes]
        step = min((b - a for a, b in zip(ks, ks[1:])), default=price * 0.01)
        width = step * 0.6
        calls = [c * self._scale(price) / div for _k, c, _p, _a, _b in strikes]
        puts = [p * self._scale(price) / div for _k, _c, p, _a, _b in strikes]
        self._add(self.strike_plot, pg.BarGraphItem(x=ks, y0=[0.0] * len(ks), height=calls, width=width,
                                                     brush=pg.mkBrush(ov.CALL_COLOR), pen=pg.mkPen(ov.CALL_COLOR)))
        self._add(self.strike_plot, pg.BarGraphItem(x=ks, y0=puts, height=[-p for p in puts], width=width,
                                                     brush=pg.mkBrush(ov.PUT_COLOR), pen=pg.mkPen(ov.PUT_COLOR)))
        self._add(self.strike_plot, pg.ScatterPlotItem(x=ks, y=[c + p for c, p in zip(calls, puts)], symbol="o",
                                                        size=7, brush=pg.mkBrush(NET_COLOR), pen=None))
        self.strike_plot.setLabel("left", unit_name)

        # Кривая: рубли при каждой цене кривой — по этой цене (стоимость контракта меняется вместе с ценой)
        curve = [(p, v * self._scale(p) / div) for p, v in prof["curve"]]
        curve = _with_zero_crossings(curve)
        xs = [p for p, _v in curve]
        ys = [v for _p, v in curve]
        self.curve.setData(xs, ys)
        # Заливка зон — заливкой кривой до нуля (fillLevel). FillBetweenItem между кривыми без пера не рисовал
        # ничего: PlotDataItem без пера не строит свою линию (01.11, скриншот — зон не было видно)
        for values, fill in (([max(v, 0.0) for v in ys], POS_FILL), ([min(v, 0.0) for v in ys], NEG_FILL)):
            item = pg.PlotDataItem(xs, values, pen=None, fillLevel=0.0, brush=pg.mkBrush(*fill))
            item.setZValue(-5)
            self._add(self.curve_plot, item)
        self.curve_plot.setLabel("left", unit_name)
        self._zone_label(curve, positive=False)
        self._zone_label(curve, positive=True)

        for line in self.price_lines:
            line.setPos(price)
            line.show()
        flip = prof["flip"]
        for line in self.flip_lines:
            line.setVisible(flip is not None)
            if flip is not None:
                line.setPos(flip)
        if flip is not None and ys:
            label = pg.TextItem(f"Gamma flip ≈ {flip:g}", color=FLIP_COLOR, anchor=(1.05, 0))
            label.setPos(flip, max(ys))
            self._add(self.curve_plot, label)
        # По цене — диапазон кривой (крайние страйки с OI ±1%, не шире ±15%): дальние страйки (у CR до 17 при цене
        # 12.27) растягивали оба графика, а кривая занимала половину ширины. Ставим при смене инструмента или
        # экспирации — дальше масштаб и сдвиг пользователя не сбиваются; по высоте — по видимой части.
        if xs and self._ranged_for != self._title:
            self._ranged_for = self._title
            self.curve_plot.setXRange(xs[0], xs[-1], padding=0.02)
        for plot in (self.strike_plot, self.curve_plot):
            plot.enableAutoRange(axis="y")
            plot.setAutoVisible(y=True)
        self._fill_cards()

    def _zone_label(self, curve, positive: bool) -> None:
        pts = [(p, v) for p, v in curve if (v > 0 if positive else v < 0)]
        if len(pts) < 3:
            return
        text = ("Положительная гамма:\nхедж может гасить ход" if positive
                else "Отрицательная гамма:\nхедж может усиливать ход")
        x = (pts[0][0] + pts[-1][0]) / 2
        peak = max(abs(v) for _p, v in curve) or 1.0
        depth = max(abs(v) for _p, v in pts)
        color = ov.CALL_COLOR if positive else ov.PUT_COLOR
        if depth >= 0.25 * peak:                   # зона глубокая — подпись посередине заливки
            item = pg.TextItem(text, color=color, anchor=(0.5, 0.5))
            item.setPos(x, depth / 2 if positive else -depth / 2)
        else:
            # Мелкая зона (01.11: отрицательная гамма CR — до −3 000 при пике +40 000): подпись в заливке
            # налезала на кривую. Ставим её по другую сторону нуля — там над зоной пусто (кривая с другим знаком)
            item = pg.TextItem(text, color=color, anchor=(0.5, 1.15) if not positive else (0.5, -0.15))
            item.setPos(x, 0.0)
        self._add(self.curve_plot, item)

    def _fill_cards(self) -> None:
        prof = self._profile
        rub = self._rub()
        price = prof["price"]
        total = prof["total"] * self._scale(price)
        color = ov.CALL_COLOR if total > 0 else ov.PUT_COLOR if total < 0 else ov.TEXT
        self.total_card.value_label.setText(fmt_gex(total, rub))
        ov.set_card_value(self.total_card, color)                  # размер — под шрифт интерфейса (2.1.83)
        mode = ("положительная — гасит ход" if total > 0 else "отрицательная — усиливает ход" if total < 0
                else "нейтральная")
        self.mode_card.value_label.setText(mode)
        ov.set_card_value(self.mode_card, color, 13)
        flip = prof["flip"]
        self.flip_card.value_label.setText(f"{flip:g} ({(flip / price - 1) * 100:+.2f}%)" if flip else "нет в ±15%")
        if prof["strikes"]:
            k, c, p, _a, _b = max(prof["strikes"], key=lambda r: abs(r[1] + r[2]))
            self.top_card.value_label.setText(f"{k:g}: {fmt_gex((c + p) * self._scale(price), rub)}")
        units = "₽" if rub else "фьючерсов"
        note = (f"{self._title}: GEX — сколько {units} хеджерам продать (+) или купить (−) при росте цены на 1% "
                f"(на падении — наоборот). {ASSUMPTION}")
        if self.units_combo.currentData() == "rub" and self._units is None:
            note += " Рубли для этого базового актива недоступны — показано в фьючерсах."
        self.note_label.setText(note)

    # ---- подсказки при наведении ---------------------------------------------------------

    def _hook_hover(self) -> None:
        """Мышь над графиком — подсказка и вертикальная линия-курсор (как на вкладке «Волатильность»)."""
        self._hover_lines = {}
        for plot, handler in ((self.strike_plot, self._strike_tip), (self.curve_plot, self._curve_tip)):
            line = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen(ov.CHART_MUTED, width=1,
                                                                          style=Qt.PenStyle.DotLine))
            line.setZValue(50)
            line.hide()
            plot.addItem(line, ignoreBounds=True)
            self._hover_lines[plot] = line
            plot.scene().sigMouseMoved.connect(lambda pos, p=plot, h=handler: self._on_hover(p, h, pos))

    def _on_hover(self, plot, handler, pos) -> None:
        vb = plot.getPlotItem().vb
        line = self._hover_lines[plot]
        if not vb.sceneBoundingRect().contains(pos) or self._profile is None:
            if line.isVisible():
                line.hide()
                QToolTip.hideText()
            return
        result = handler(vb.mapSceneToView(pos).x())
        if result is None:
            line.hide()
            QToolTip.hideText()
            return
        at, text = result
        line.setPos(at)
        line.show()
        QToolTip.showText(QCursor.pos(), text, plot)

    def _strike_tip(self, x: float):
        strikes = self._profile["strikes"]
        if not strikes:
            return None
        k, c, p, coi, poi = min(strikes, key=lambda r: abs(r[0] - x))
        rub, s = self._rub(), self._scale(self._profile["price"])
        oi = lambda v: f"{v:,.0f}".replace(",", " ")
        side = lambda g, n: f"{fmt_gex(g * s, rub)} · OI {oi(n)}" if n else "нет OI"
        lines = [f"<b>Страйк {k:g}</b>",
                 f"<span style='color:{ov.CALL_COLOR}'>CALL: {side(c, coi)}</span>",
                 f"<span style='color:{ov.PUT_COLOR}'>PUT: {side(p, poi)}</span>",
                 f"нетто: <b>{fmt_gex((c + p) * s, rub)}</b>"]
        return k, "<br>".join(lines)

    def _curve_tip(self, x: float):
        curve = self._profile["curve"]
        value = ol._interp(curve, x)
        if value is None:
            return None
        rub = self._rub()
        v = value * self._scale(x)
        n = fmt_gex(abs(v), rub).lstrip("+")
        price = self._profile["price"]
        lines = [f"<b>Цена {x:.5g}</b> ({(x / price - 1) * 100:+.2f}% от текущей)",
                 f"суммарная GEX: <b>{fmt_gex(v, rub)}</b>"]
        if v > 0:
            lines.append(f"<span style='color:{ov.CALL_COLOR}'>положительная гамма: на +1% хеджеры продадут ≈{n}, "
                         f"на −1% купят — ход гасится</span>")
        elif v < 0:
            lines.append(f"<span style='color:{ov.PUT_COLOR}'>отрицательная гамма: на +1% хеджеры купят ≈{n}, "
                         f"на −1% продадут — ход усиливается</span>")
        return x, "<br>".join(lines)
