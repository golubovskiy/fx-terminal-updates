# -*- coding: utf-8 -*-
"""Робот и сборка заявок из сделок — на Rust (этап 3 переноса «Алгоритмов», с 2.1.52) — без Qt.

Расчёт — fx_engine.OrderAssembler и fx_engine.RobotTracker (fx_engine_rs/src/algo/robot.rs, модуль 0.5.0 и новее):
склейка сделок в заявки, серии роботов, паузы, «стала роботом», забывание. Этот модуль — обёртка с тем же API,
что у эталона на Python (robot_core.OrderAssembler / RobotTracker), чтобы вкладка «Алгоритмы» (quotes_tab.py)
не менялась: она создаёт их через order_assembler() и robot_tracker().

Сверки «в тени» у этого этапа не было (решение 14.11): Rust сразу вместо Python. Вместо неё —
tests/test_robot_rust.py: случайные потоки сделок через Rust и через эталон, события и серии должны совпасть
точно; проверка идёт при установке каждого обновления, уже с собранным модулем.

Что остаётся в Python и почему:
    * серии для вкладки — словари того же вида, что у эталона (поля — robot_core.RobotTracker): вкладка дописывает
      в них своё (on_chart, chart_id, note_hint, logged …) и читает их в десятке мест. Rust отдаёт числа серии
      после каждой заявки, обёртка переносит их в словарь; время (started, last_ts) — те же объекты, что пришли;
    * сводка серии, регулярность для показа и журнал серий (robot_core.robot_info / regularity / append_series) —
      читают словарь; решение «серия — робот» (и регулярность для него) принимает Rust;
    * номера серий (uid) — общий счётчик вкладки; Rust нумерует серии инструмента по-своему.

Запасного расчёта на Python нет (с 2.1.57, как у детекторов с 2.1.38; robot_core остаётся эталоном в проверках):
    * модуля fx_engine нет или он старый (нет классов NEEDED) — роботы и сборка заявок НЕ РАБОТАЮТ (заявок и
      серий нет), в журнале об этом строка при запуске: модуль нужно пересобрать (обновление с пересборкой Rust);
    * ошибка Rust в вызове — строка в журнал, расчёт этого инструмента создаётся заново: недособранные заявки
      теряются, идущие серии закрываются (вкладка получает по ним «серия кончилась» при следующей заявке — их
      заметки и значки на графике завершаются как обычно); MAX_ERRORS ошибок — расчёт этого инструмента выключен
      до перезапуска терминала.
"""
from __future__ import annotations

import sys
from typing import Iterator

import pandas as pd

import robot_core

NEEDED = ("OrderAssembler", "RobotTracker")        # fx_engine 0.5.0 и новее
GONE, UPDATED, ANNOUNCE = 0, 1, 2                 # виды событий Rust (algo/robot.rs: EventKind)
MAX_ERRORS = 3                                    # столько ошибок Rust у инструмента — и расчёт выключен до перезапуска

_engine_module = None            # None — ещё не пробовали; False — классов нет; иначе fx_engine


def engine():
    """Модуль fx_engine с роботом; None — модуля нет или он старый: роботы не работают (строка в журнал — раз)."""
    global _engine_module
    if _engine_module is None:
        _engine_module = False
        try:
            import app_paths  # готовый fx_engine из обновления (2.1.83)
            import fx_engine
            missing = [name for name in NEEDED if not hasattr(fx_engine, name)]
            if missing:
                print(f"[rust-алгоритмы] в fx_engine {getattr(fx_engine, '__version__', '?')} нет "
                      f"{', '.join(missing)} — роботы и сборка заявок из сделок НЕ РАБОТАЮТ: нужен модуль 0.5.0 "
                      "или новее (обновление с пересборкой Rust)", file=sys.stderr)
            else:
                _engine_module = fx_engine
                where = f"; {app_paths.engine_status()}" if app_paths.FROZEN else ""     # собранная программа
                print(f"[rust-алгоритмы] роботов и сборку заявок из сделок считает Rust (fx_engine {fx_engine.__version__}){where}")
        except Exception as exc:
            print(f"[rust-алгоритмы] модуль fx_engine не загружен ({type(exc).__name__}: {exc}) — роботы и сборка "
                  "заявок из сделок НЕ РАБОТАЮТ: модуль нужно собрать (обновление с пересборкой Rust)", file=sys.stderr)
    return _engine_module or None


def config(cfg: dict) -> tuple:
    """Настройки робота инструмента -> числа для Rust (algo/robot.rs: Config). Значения по умолчанию и разбор —
    те же, что у эталона (robot_core.RobotTracker.on_order, is_robot, max_gap_of, pause_sec, min_regularity)."""
    return (float(cfg.get("min_lots", 0) or 0),
            robot_core.max_gap_of(cfg),
            max(0.0, float(cfg.get("size_tolerance", 0.0))) / 100.0,
            robot_core.pause_sec(cfg),
            int(cfg.get("min_count", 5)),
            float(cfg.get("min_turnover", 0) or 0),
            float(cfg.get("min_interval", 0) or 0),
            robot_core.min_regularity(cfg))


def _ns(ts) -> int:
    """Биржевое время (pd.Timestamp) -> наносекунды epoch."""
    return int(pd.Timestamp(ts).value)


def _is_buy(side) -> bool:
    return str(side).upper().endswith("BUY")


class _Rust:
    """Общее для обёрток: Rust-объект инструмента, счёт ошибок и пересоздание. make — как создать Rust-объект
    (None — модуля нет: расчёт выключен с самого начала)."""
    WHAT = ""

    def __init__(self, make, symbol: str = ""):
        self._make, self._symbol, self._errors = make, symbol, 0
        self._rs = self._create()

    def _create(self):
        if self._make is None:
            return None
        try:
            return self._make()
        except Exception as exc:
            print(f"[rust-алгоритмы] {self.WHAT}{' ' + self._symbol if self._symbol else ''}: Rust-расчёт не создан — "
                  f"{type(exc).__name__}: {exc}; расчёт выключен", file=sys.stderr)
            return None

    @property
    def off(self) -> bool:
        """Расчёт инструмента не работает: модуля нет или набралось MAX_ERRORS ошибок."""
        return self._rs is None

    def _failed(self, method: str, exc: Exception) -> None:
        self._errors += 1
        off = self._errors >= MAX_ERRORS
        print(f"[rust-алгоритмы] {self.WHAT}{' ' + self._symbol if self._symbol else ''}: ошибка Rust в {method} — "
              f"{type(exc).__name__}: {exc}; "
              + ("расчёт этого инструмента выключен до перезапуска терминала" if off
                 else "расчёт создан заново (накопленное потеряно)"), file=sys.stderr)
        self._rs = None if off else self._create()
        self._reset()

    def _reset(self) -> None:
        """Состояние обёртки после пересоздания Rust-объекта."""


# ---- сделки -> агрессивные заявки ---------------------------------------------------------------------

class OrderAssembler(_Rust):
    """Сборка заявок на Rust с API robot_core.OrderAssembler. pending — стороны собираемых заявок (вкладке
    нужно только «есть ли что-то в работе»): сторона (is_buy) -> {ts, ts_last, side} первой сделки; объёмы — в Rust."""
    WHAT = "сборка заявок"

    def __init__(self, make, pending: dict | None = None, symbol: str = ""):
        self.pending = {} if pending is None else pending
        super().__init__(make, symbol)

    def _reset(self) -> None:
        self.pending.clear()                         # недособранные заявки теряются

    def _orders(self, rows) -> list[dict]:
        orders = []
        for is_buy, _ts, _ts_last, size, turnover, value, parts, seen in rows:
            head = self.pending.pop(is_buy)
            orders.append({"ts": head["ts"], "ts_last": head["ts_last"], "side": head["side"], "size": size,
                           "turnover": turnover, "value": value, "parts": parts, "seen": seen})
        return orders

    def add(self, ts, price: float, size: float, side: str, turnover: float, mono: float) -> list[dict]:
        """Сделка. Возвращает заявки, которые этой сделкой закончились (по порядку)."""
        if self._rs is None:
            return []
        is_buy = _is_buy(side)
        try:
            finished = self._orders(self._rs.add(_ns(ts), float(price), float(size), is_buy, float(turnover),
                                                 float(mono)))
        except Exception as exc:
            self._failed("add", exc)
            return []
        head = self.pending.get(is_buy)
        if head is None:
            self.pending[is_buy] = {"ts": ts, "ts_last": ts, "side": side}
        else:
            head["ts_last"] = max(head["ts_last"], ts)
        return finished

    def flush(self, mono: float, flush_sec: float = robot_core.ORDER_FLUSH_SEC) -> list[dict]:
        """Заявки, к которым давно не приходили куски, — закончены, по времени."""
        if self._rs is None:
            return []
        try:
            return self._orders(self._rs.flush(float(mono), float(flush_sec)))
        except Exception as exc:
            self._failed("flush", exc)
            return []


# ---- робот --------------------------------------------------------------------------------------------

class RobotTracker(_Rust):
    """Серии роботов на Rust с API robot_core.RobotTracker. chains — словари серий для вкладки (тот же список,
    что в состоянии инструмента), announced — когда какого робота объявляли (зеркало того, что помнит Rust)."""
    WHAT = "робот"

    def __init__(self, make, uids: Iterator[int], chains: list | None = None, announced: dict | None = None,
                 symbol: str = ""):
        self.uids = uids
        self.chains = [] if chains is None else chains
        self.announced = {} if announced is None else announced
        self._by_id: dict[int, dict] = {}            # номер серии у Rust -> словарь серии
        self._orphans: list[dict] = []               # серии, которых Rust уже не знает: закрыть при следующей заявке
        super().__init__(make, symbol)
        self._reset()                                # серии, переданные готовыми, Rust-ядру не передать

    def _reset(self) -> None:
        """Rust-объект новый (или выключен): серий он не знает — вкладке о них сообщим «серия кончилась»."""
        self._orphans.extend(self.chains)
        self.chains.clear()
        self._by_id.clear()

    def _take_orphans(self) -> list[tuple]:
        events = [("gone", chain) for chain in self._orphans]
        self._orphans.clear()
        return events

    def on_order(self, ts, price: float, size: float, side: str, turnover: float, now: float,
                 cfg: dict) -> tuple[list[tuple], bool]:
        """Заявка (собранная из сделок). Возвращает (события, учтена) — как robot_core.RobotTracker.on_order:
        ("gone", серия), ("grew", серия) — серия на графике выросла, ("announce", серия, notify)."""
        events = self._take_orphans()
        if self._rs is None:
            return events, False
        is_buy = _is_buy(side)
        try:
            rows, counted, state = self._rs.on_order(_ns(ts), float(price), float(size), is_buy, float(turnover),
                                                     float(now), config(cfg))
        except Exception as exc:
            self._failed("on_order", exc)
            return events + self._take_orphans(), False
        tempo = None
        if state is not None:
            head, sums, tempo = state
            chain_id, created, paused = head[0], head[5], head[6]
            if created:
                chain = self._by_id[chain_id] = {
                    "is_buy": is_buy, "size": size, "started": ts, "last_ts": ts, "seen": now,
                    "count": 1, "volume": size, "turnover": turnover, "gaps_sum": 0.0,
                    "price": price, "pmin": price, "pmax": price, "announced": False,
                    "uid": next(self.uids), "price0": price, "pv": price * size}
                self.chains.append(chain)
            else:
                chain = self._by_id[chain_id]
                if paused:                   # вернулся после паузы — тот же робот; пауза не идёт в темп серии
                    chain["pause_n"], chain["pause_max"] = tempo[2], tempo[3]
                    chain["chart_closed"] = False
                chain["count"] = head[3]
                chain["volume"], chain["turnover"], chain["pv"] = sums[0], sums[1], sums[2]
                gap = tempo[4]
                if gap is not None:
                    gaps = chain.setdefault("gaps", [])         # для показа регулярности и журнала серий
                    gaps.append(gap)
                    if len(gaps) > robot_core.REGULARITY_GAPS_KEEP:
                        del gaps[0]
                    chain["gaps_sum"], chain["gaps_sq"] = sums[3], sums[4]
                    chain["gmin"], chain["gmax"] = tempo[0], tempo[1]
                chain["last_ts"], chain["seen"], chain["price"] = ts, now, price
                chain["pmin"], chain["pmax"] = sums[6], sums[7]
        for kind, chain_id, notify in rows:
            if kind == GONE:
                chain = self._by_id.pop(chain_id)
                for i, other in enumerate(self.chains):
                    if other is chain:
                        del self.chains[i]
                        break
                events.append(("gone", chain))
            elif kind == UPDATED:
                chain = self._by_id[chain_id]
                if chain.get("on_chart"):
                    events.append(("grew", chain))       # робот на графике растёт вместе с серией
            elif kind == ANNOUNCE:
                chain = self._by_id[chain_id]
                chain["announced"] = True
                if notify:
                    self.announced[(is_buy, round(float(size), 6))] = now
                chain["reg_announce"] = tempo[5] if tempo is not None else None
                events.append(("announce", chain, bool(notify)))
        return events, bool(counted)

    def clear(self) -> list[dict]:
        """Робот выключен в настройках: все серии забыты. Возвращает их (и те, что ждали закрытия после сбоя)."""
        gone = [chain for _kind, chain in self._take_orphans()] + list(self.chains)
        self.chains.clear()
        self._by_id.clear()
        if self._rs is not None:
            try:
                self._rs.clear()
            except Exception as exc:
                self._failed("clear", exc)
                self._orphans.clear()                # всё уже отдано в gone
        return gone

    def _chains_of(self, ids) -> list[dict]:
        return [self._by_id[i] for i in ids]

    def working(self, now: float, cfg: dict, check_interval: bool = True) -> list[dict]:
        """Серии-роботы, которые работают сейчас (или на паузе); check_interval — ещё и «Мин. интервал»."""
        if self._rs is None:
            return []
        try:
            return self._chains_of(self._rs.working(float(now), config(cfg), bool(check_interval)))
        except Exception as exc:
            self._failed("working", exc)
            return []

    def best(self, now: float, cfg: dict) -> dict | None:
        """Действующий робот инструмента — самый крупный по обороту (первый из равных)."""
        if self._rs is None:
            return None
        try:
            chain_id = self._rs.best(float(now), config(cfg))
            return None if chain_id is None else self._by_id[chain_id]
        except Exception as exc:
            self._failed("best", exc)
            return None

    def stopped(self, now: float, cfg: dict) -> list[dict]:
        """Серии, которые замолчали дольше допустимого."""
        if self._rs is None:
            return []
        try:
            return self._chains_of(self._rs.stopped(float(now), config(cfg)))
        except Exception as exc:
            self._failed("stopped", exc)
            return []


# ---- что создаёт вкладка ------------------------------------------------------------------------------

def order_assembler(pending: dict | None = None, symbol: str = "") -> OrderAssembler:
    """Сборка заявок инструмента на Rust; модуля нет — выключена (заявок нет)."""
    mod = engine()
    return OrderAssembler(None if mod is None else mod.OrderAssembler, pending, symbol)


def robot_tracker(uids: Iterator[int], chains: list | None = None, announced: dict | None = None,
                  symbol: str = "") -> RobotTracker:
    """Серии роботов инструмента на Rust; модуля нет — выключены (серий нет)."""
    mod = engine()
    return RobotTracker(None if mod is None else mod.RobotTracker, uids, chains, announced, symbol)
