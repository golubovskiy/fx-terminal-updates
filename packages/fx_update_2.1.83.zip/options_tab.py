# -*- coding: utf-8 -*-
"""Вкладка «Опционы» главного окна FX Terminal.

Тонкая обёртка над options_chain_chart_widget.OptionsChainChartWidget:
  * виджет создаётся лениво — когда панель впервые становится видимой (PanelSpec.on_show), а не на старте терминала
    (цепочка поднимает 10–20 gRPC-стримов; на старте и так идёт залп других подписок);
  * использует общий FinamStreamClient терминала (host.sdk_client) для цепочки и НЕ закрывает его;
    котировки — из хаба подписок терминала (host.md_hub): одна пакетная подписка, потоки
    группами по 10 символов держит и переподключает шлюз;
  * при переподключении (_shutdown_connections) полностью останавливается, а после
    создания нового клиента поднимается заново, если вкладка открыта;
  * запоминает выбранный базовый актив (QSettings терминала).

Подключение в gui_app.py: см. комментарии «Опционы» в MainWindow.
"""
from __future__ import annotations

import sys
import traceback

from PySide6 import QtCore, QtWidgets

from options_common import underlying_choices

SETTINGS_KEY = "options/underlying"

_HINT_IDLE = "Цепочка опционов загрузится при открытии вкладки"


class OptionsTab(QtWidgets.QWidget):
    def __init__(self, host, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        try:                                          # свои фон и текст окна (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "opt")
        except Exception:
            pass
        self._host = host
        self._widget = None
        self._layout = QtWidgets.QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._placeholder = QtWidgets.QLabel(_HINT_IDLE)
        self._placeholder.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._placeholder.setWordWrap(True)
        self._layout.addWidget(self._placeholder)

    # ---- вызывается терминалом ----------------------------------------------
    def activate(self) -> None:
        """Вкладку открыли: при первом показе создаём виджет."""
        if self._widget is None:
            self._create_widget()

    def stop(self) -> None:
        """Из _shutdown_connections(): остановить потоки и отпустить клиент.
        Клиент общий, закрывает его терминал, не мы."""
        widget = self._widget
        if widget is None:
            return
        self._widget = None
        try:
            self._host.settings.setValue(SETTINGS_KEY, widget.underlying)
        except Exception:
            pass
        try:
            widget.shutdown()
        except Exception:
            print("[shutdown] Ошибка остановки виджета «Опционы»:", file=sys.stderr)
            traceback.print_exc()
        self._layout.removeWidget(widget)
        widget.hide()
        widget.setParent(None)
        widget.deleteLater()
        self._set_message("Переподключение к Finam…")

    def on_client_ready(self) -> None:
        """После (пере)подключения: если вкладка сейчас открыта — поднимаем цепочку на новом клиенте."""
        if self._widget is None and self._is_current():
            self._create_widget()

    # ---- внутреннее -----------------------------------------------------------
    def _is_current(self) -> bool:
        """Вкладка сейчас на экране (панель открыта и является текущей вкладкой своей области)."""
        return self.isVisible()

    def _set_message(self, text: str) -> None:
        self._placeholder.setText(text)
        self._placeholder.show()

    def _create_widget(self) -> None:
        client = getattr(self._host, "sdk_client", None)
        if client is None:
            self._set_message("Нет подключения к Finam: откройте «Настройки…» и введите токен")
            return
        try:
            from options_chain_chart_widget import OptionsChainChartWidget
        except Exception as exc:        # нет файла / finam-sdk / protobuf
            traceback.print_exc()
            self._set_message(
                f"Не удалось загрузить модуль опционов:\n{exc}\n\n"
                "Рядом с gui_app.py должны лежать options_chain_chart_widget.py, "
                "options_oi_view.py, options_common.py и options_theme.py."
            )
            return

        # Сохранённый инструмент годится, только пока он среди актуальных контрактов
        # (после экспирации вместо него берётся ближайший по ролловеру).
        saved = str(self._host.settings.value(SETTINGS_KEY, "") or "")
        underlying = saved if saved in underlying_choices() else None
        try:
            widget = OptionsChainChartWidget(
                underlying=underlying,
                parent=self,
                client=client,
                hub=getattr(self._host, "md_hub", None),
            )
        except Exception as exc:
            traceback.print_exc()
            self._set_message(f"Не удалось открыть цепочку опционов:\n{exc}")
            return
        self._widget = widget
        self._placeholder.hide()
        self._layout.addWidget(widget)
