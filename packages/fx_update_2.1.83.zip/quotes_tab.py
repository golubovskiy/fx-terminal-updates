# -*- coding: utf-8 -*-
"""Вкладка «Алгоритмы»: таблица инструментов (цена, изменение, оборот), детекторы роботов,
айсбергов, спредовых роботов и крупных сделок, уведомления со звуком, окна Level 2.

Откуда данные: подписки в MarketDataHub (services/market_data_hub.py) — котировки,
сделки и стакан по каждому инструменту таблицы; у брокера одна подписка на инструмент
на весь терминал, переподключение и отсев повторов по trade_id делает FinamGateway,
стакан приходит готовым снимком (шлюз собирает его из изменений Finam), каждый —
без прореживания (subscribe_orderbook(lossless=True)), чтобы детекторы не пропускали
короткие изменения. Без шлюза (не запустился) данных нет.
Поток стакана открывается только там, где он нужен: включены айсберги или спредовый робот,
либо открыто окно Level 2.

Расчёты «Алгоритмов» — в Rust (модуль fx_engine): «Цена», «Рост оборота», «Наращивание», маркет-мейкер
(services/algo_shadow.py), сборка заявок и роботы (robot_rust.py), спредовый робот (spread_rust.py), айсберги
(iceberg_rust.py, с 2.1.64). Эталоны на Python (algo_core, mm_detector, escalation_detector, robot_core,
spread_core, iceberg_core) в работе не участвуют — с ними Rust сверяется проверками при установке обновления.
У вкладки остаются таблица, настройки, уведомления, линии и значки на графике, отметки в стаканах, журналы.
"""
from __future__ import annotations

import heapq
import itertools
import json
import math
import random
import re
from collections import OrderedDict, deque
import sys
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PySide6 import QtCore, QtGui, QtWidgets

from finam_sdk_client import FinamStreamClient
from finam_terminal import INSTRUMENTS, to_friendly_symbol, from_friendly_symbol

from events_journal import EventsJournal, trim as trim_events  # noqa: E402
import mm_detector  # noqa: E402
# Детекторы без Qt (эталон на Python, перенос на Rust): имена остаются доступны и отсюда (qt.VolumeSurge в проверках)
from algo_core import PriceMoveDetector, PriceMoveWindow, VolumeSurge  # noqa: E402,F401
from services import algo_shadow  # noqa: E402  — детекторы считает Rust (2.1.38), Python — эталон в проверках
from services import log_mode  # noqa: E402  — тихий режим журналов (2.1.65): журнал серий роботов — только при FX_LOGS=1
import notify_merge  # noqa: E402
import notify_badge  # noqa: E402  (важность уведомления, всплывающее окно значка)
import robot_notes  # noqa: E402
import iceberg_kind  # noqa: E402
import iceberg_core  # noqa: E402  — айсберги: эталон на Python (вынесен из вкладки в 2.1.64), настройки, стороны
import iceberg_rust  # noqa: E402  — айсберги считает Rust (fx_engine 0.7.0, с 2.1.64)
import escalation_detector  # noqa: E402
import mm_marks  # noqa: E402  — события ММ и «Наращивания» на графике и в стакане (2.1.2)
import robot_core  # noqa: E402  — сборка заявок из сделок и робот: пороги, сводка серии, журнал; эталон для Rust
import robot_rust  # noqa: E402  — сборку заявок и серии роботов считает Rust (fx_engine 0.5.0, с 2.1.52)
import spread_core  # noqa: E402  — спредовый робот: эталон на Python (вынесен из вкладки в 2.1.58)
import spread_rust  # noqa: E402  — спредового робота считает Rust (fx_engine 0.6.0, с 2.1.58)
import mm_summary  # noqa: E402  — сводка исходов по журналам mm_events (2.1.12)
from candlestick_item import BULL_COLOR, BEAR_COLOR  # noqa: E402  — цвета свечей из «Настроек» (appearance.py)

STREAM_STAGGER_MS = 350     # пауза между стартами gRPC-потоков (не открываем десяток разом)
CHART_EVENTS_PER_SYMBOL = 200   # сколько событий (роботы, айсберги) помнить для графиков на инструмент
MM_CHART_EVENTS_PER_SYMBOL = 300  # и отдельно — событий ММ и «Наращивания» (их больше, роботов не вытесняют)
DUPLICATE_EVENT_SEC = 5.0
BIG_TRADE_PIN_SEC = 5.0     # крупная сделка — столько секунд закреплена вверху окна уведомлений   # одинаковое уведомление чаще — отбрасываем
# Расчёт айсбергов (ожидание восстановления объёма после сделки, счёт исполненного, кандидаты) — в iceberg_core.py
# и на Rust (iceberg_rust.py, 2.1.64); срок ожидания считается по часам терминала (time.monotonic) от прихода
# сделки, а не от её биржевого времени: при отставании ленты Finam больше 2 с срок истекал раньше, чем сделка
# доходила, и айсберги не находились совсем (до 2.0.69).
ICEBERG_REANNOUNCE_SEC = 60.0   # кандидат-айсберг на той же цене повторно не объявляем
# Детектор следов маркет-мейкера (mm_detector.py): журнал (консоль + logs/mm_events_ДАТА.csv), а с 2.1.2 — значки
# на графике и отметки в стакане (mm_marks.py). Настройки инструмента → «Маркет-мейкер»: вкл. (по умолчанию —
# да; выключен — поток стакана ему не нужен), типы событий, чувствительность, «на графике», «в стакане».
# FX_MM_DETECTOR=0 — выключить детектор совсем.
MM_DETECTOR_ENABLED = __import__("os").environ.get("FX_MM_DETECTOR", "1") != "0"
MM_PRINT_PER_MIN = 20       # строк детектора в консоль на инструмент в минуту (в CSV пишется всё)
# Стаканы для детектора открываются не при запуске, а через MM_START_DELAY_MS и по одному раз в
# MM_STREAM_GAP_MS: 30.10 десяток дополнительных потоков стакана, открытых в первые секунды вместе со всеми
# остальными, уронил python.exe (access violation в потоке grpc без Python-кадров — тот же залп потоков,
# что ронял терминал в начале проекта).
MM_START_DELAY_MS = 60_000
MM_STREAM_GAP_MS = 3_000
MM_LOG_DIR = app_paths.LOG_DIR
# Колонки журнала logs/mm_events_ДАТА.csv. С 2.1.12 — ещё outcome (итог: защита «устоял» / «пробит», снятие
# «ушли с дороги» / «приманка», mm_summary.event_outcome) и sens (чувствительность детектора ММ; у «Наращивания»
# пусто). Файл дня, начатый до обновления, дописывается прежними колонками (MM_CSV_OLD_COLUMNS).
MM_CSV_HEADER = "time;symbol;kind;stage;side;price;volume;refills;executed;seconds;level;through;outcome;sens;text"
MM_CSV_OLD_COLUMNS = 13
# Сделки -> агрессивные заявки и робот — в robot_core.py (без Qt, 2.1.39): там и пороги склейки.
ORDER_MERGE_SEC = robot_core.ORDER_MERGE_SEC
ORDER_FLUSH_SEC = robot_core.ORDER_FLUSH_SEC


# Юаневый квартальный фьючерс: тикер CRZ6@RTSX, а на бирже он называется «CNY-12.26»
# (to_friendly_symbol и название из каталога дают «CR-12.26»). Та же логика, что в gui_app.
_CR_SYMBOL_RE = re.compile(r"^CR([HMUZ])(\d)@RTSX$")
_CR_CODE_TO_MONTH = {"H": 3, "M": 6, "U": 9, "Z": 12}


def _strip_venue_text(text: str) -> str:
    """Название вида «CNYRUB_TOM@MISX» -> «CNYRUB_TOM»; обычные названия не трогаем."""
    return text.split("@", 1)[0] if re.fullmatch(r"[\w.\-]+@[A-Za-z]{3,6}", text) else text


def _friendly_symbol(symbol: str) -> str:
    m = _CR_SYMBOL_RE.match(str(symbol))
    if m:
        return f"CNY-{_CR_CODE_TO_MONTH[m.group(1)]}.2{m.group(2)}"
    try:
        return to_friendly_symbol(symbol)
    except Exception:
        return symbol


def _hover_tint() -> str:
    """rgb для полупрозрачной подсветки при наведении: светлая на тёмной теме, тёмная на светлой."""
    try:
        import fx_theme
        return str(getattr(fx_theme, "HOVER_TINT", "255, 255, 255"))
    except Exception:
        return "255, 255, 255"

def _quotes_decimal(value, default=0.0) -> float:
    if isinstance(value, dict):
        value = value.get("value", default)
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _positive_decimal(value) -> float | None:
    """Число > 0 из decimal-обёртки Finam или обычного значения; иначе None."""
    if isinstance(value, dict):
        value = value.get("value")
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number > 0 else None


def _quotes_lot_size(symbol: str) -> float:
    """
    Размер лота: сначала проверенная таблица терминала (INSTRUMENTS — в том числе
    спот CNYRUB_TOM / CNY000000TOD = 1000), затем эвристика по тикеру; иначе 1.
    """
    known = INSTRUMENTS.get(str(symbol))
    if known:
        return float(known)
    raw = str(symbol).split("@", 1)[0].upper()
    if raw in {"USDRUBF", "EURRUBF", "CNYRUBF"}:
        return 1000.0
    if raw.startswith(("SI", "EU", "CR")) and raw.endswith(tuple("0123456789")):
        # Датированные фьючерсы котируются в рублях за ЛОТ БАЗОВОГО АКТИВА, а не за 1 единицу:
        #   Si, Eu — рублей за 1000 USD/EUR, контракт = 1000 единиц, т.е. цена 87 050 уже
        #   стоимость одного контракта в рублях -> множитель 1 (раньше стоял 1000, и сделка
        #   в 1 контракт «весила» 87 млн ₽ вместо 87 тыс.);
        #   CR (юань) — рублей за 1 юань, контракт = 1000 юаней -> множитель 1000.
        if raw.startswith(("SI", "EU")):
            return 1.0
        return 1000.0   # CR
    return 1.0


def _quotes_money(value: float) -> str:
    value = float(value or 0.0)
    if abs(value) >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f} млрд ₽"
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.2f} млн ₽"
    return f"{value:,.0f} ₽".replace(",", " ")


def _compact_form(dialog: QtWidgets.QWidget, form: QtWidgets.QFormLayout, width: int = 120) -> None:
    """Числовые поля настроек — узкие (по содержимому), а не на всю ширину окна."""
    form.setFieldGrowthPolicy(QtWidgets.QFormLayout.FieldGrowthPolicy.FieldsStayAtSizeHint)
    form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter)
    for spin in dialog.findChildren(QtWidgets.QAbstractSpinBox):
        spin.setFixedWidth(int(width * 1.35) if spin.property("wide") else width)
        spin.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)


class Level2Dialog(QtWidgets.QDialog):
    """Живой Level 2: агрегированные bid/ask уровни по цене.

    Своего потока не открывает: стакан приходит из потока вкладки «Алгоритмы»
    (вкладка держит его, пока окно открыто, даже если поиск айсбергов выключен)."""

    MAX_LEVELS = 40     # уровней с каждой стороны от спреда

    def __init__(self, tab: "QuotesTab", symbol: str):
        super().__init__(tab)
        self.setWindowTitle(f"Стакан Level 2 — {_friendly_symbol(symbol)}")
        self.resize(520, 680)
        self.symbol = symbol
        self._tab = tab
        self._scrolled = False

        root = QtWidgets.QVBoxLayout(self)
        self.info = QtWidgets.QLabel("Подключение к Level 2…")
        root.addWidget(self.info)
        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Bid", "Цена", "Ask"])
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(20)
        header = self.table.horizontalHeader()
        for col in range(3):
            header.setSectionResizeMode(col, QtWidgets.QHeaderView.ResizeMode.Stretch)
        root.addWidget(self.table)
        bottom = QtWidgets.QHBoxLayout()
        bottom.addStretch(1)
        close_btn = QtWidgets.QPushButton("Закрыть")
        close_btn.clicked.connect(self.close)
        bottom.addWidget(close_btn)
        root.addLayout(bottom)

        # Стакан обновляется часто — перерисовываем не чаще 10 раз в секунду.
        self._render_timer = QtCore.QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(100)
        self._render_timer.timeout.connect(self._render)
        tab.book_updated.connect(self._on_book_updated)
        tab._l2_attach(symbol)
        if getattr(tab.host, "md_hub", None) is None:
            self.info.setText("Нет подключения к Finam")
        self._render()

    @QtCore.Slot(str)
    def _on_book_updated(self, symbol: str) -> None:
        if symbol == self.symbol and not self._render_timer.isActive():
            self._render_timer.start()

    def _render(self) -> None:
        state = self._tab.orderbook_state.get(self.symbol) or {}
        bids, asks = state.get("bids") or {}, state.get("asks") or {}
        best_bid = max(bids) if bids else None
        best_ask = min(asks) if asks else None
        name = _friendly_symbol(self.symbol)
        if best_bid is not None and best_ask is not None:
            self.info.setText(f"{name}    Bid {best_bid:g}    Ask {best_ask:g}    Спред {best_ask - best_bid:g}")
        elif state:
            self.info.setText(f"{name}    Level 2 обновляется…")
        ask_prices = sorted(asks)[: self.MAX_LEVELS]
        bid_prices = sorted(bids, reverse=True)[: self.MAX_LEVELS]
        prices = sorted(set(ask_prices) | set(bid_prices), reverse=True)
        self.table.setRowCount(len(prices))
        bull, bear = QtGui.QColor(BULL_COLOR), QtGui.QColor(BEAR_COLOR)
        bold = QtGui.QFont(self.table.font())
        bold.setBold(True)
        best_row = 0
        for r, price in enumerate(prices):
            bid_item = QtWidgets.QTableWidgetItem(f"{bids[price]:,.0f}".replace(",", " ") if price in bids else "")
            price_item = QtWidgets.QTableWidgetItem(f"{price:.8g}")
            ask_item = QtWidgets.QTableWidgetItem(f"{asks[price]:,.0f}".replace(",", " ") if price in asks else "")
            bid_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            price_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            ask_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter)
            bid_item.setForeground(bull)
            ask_item.setForeground(bear)
            if price in asks:
                price_item.setForeground(bear)
            elif price in bids:
                price_item.setForeground(bull)
            if price in (best_bid, best_ask):
                for item in (bid_item, price_item, ask_item):
                    item.setFont(bold)
            if price == best_ask:
                best_row = r
            self.table.setItem(r, 0, bid_item)
            self.table.setItem(r, 1, price_item)
            self.table.setItem(r, 2, ask_item)
        if prices and not self._scrolled:
            self._scrolled = True     # один раз: спред посередине окна
            self.table.scrollToItem(self.table.item(best_row, 1), QtWidgets.QAbstractItemView.ScrollHint.PositionAtCenter)

    def closeEvent(self, event):
        try:
            self._tab.book_updated.disconnect(self._on_book_updated)
        except Exception:
            pass
        self._tab._l2_detach(self.symbol)
        super().closeEvent(event)


class QuotesEventMarker(pg.GraphicsObject):
    """Компактный маркер события для будущего/текущего графика.

    Полная информация намеренно показывается только в tooltip.
    """

    def __init__(self, icon: str, tooltip):
        super().__init__()
        self.icon = icon
        self.tooltip = self._format_tooltip(icon, tooltip)
        self.setAcceptHoverEvents(True)
        self.setZValue(50)

    @staticmethod
    def _runtime_text(started) -> str:
        try:
            start = pd.Timestamp(started)
            if start.tzinfo is None:
                start = start.tz_localize("UTC")
            elapsed = max(0, int((pd.Timestamp.now(tz="UTC") - start).total_seconds()))
        except Exception:
            elapsed = 0
        h, rem = divmod(elapsed, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    @staticmethod
    def _format_tooltip(icon: str, details) -> str:
        if isinstance(details, str):
            return details
        d = details or {}
        if icon == "🤖":
            return (
                "🤖 Robot\n"
                f"Объём: {d.get('volume', 0):,.0f} лотов\n"
                f"Оборот: {_quotes_money(float(d.get('turnover', 0)))}\n"
                f"Сделок: {d.get('count', 0)}\n"
                f"Интервал: {float(d.get('interval', 0)):.0f} сек\n"
                f"Работа: {QuotesEventMarker._runtime_text(d.get('started'))}"
            )
        return (
            "🧊 Iceberg\n"
            f"Цена: {float(d.get('price', 0)):.8g}\n"
            f"Восстановлений: {d.get('hits', 0)}\n"
            f"Видимый объём: {float(d.get('visible', 0)):,.0f} лотов"
        )

    def setPos(self, *args):
        super().setPos(*args)

    def boundingRect(self):
        return QtCore.QRectF(-9, -9, 18, 18)

    def paint(self, painter, option, widget=None):
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QBrush(QtGui.QColor("#202632")))
        painter.drawEllipse(self.boundingRect())
        painter.setPen(QtGui.QPen(QtGui.QColor("#ffffff")))
        painter.drawText(self.boundingRect(), QtCore.Qt.AlignmentFlag.AlignCenter, self.icon)

    def hoverEnterEvent(self, event):
        QtWidgets.QToolTip.showText(event.screenPos(), self.tooltip)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        QtWidgets.QToolTip.hideText()
        super().hoverLeaveEvent(event)


class RobotSettingsDialog(QtWidgets.QDialog):
    def __init__(self, settings: dict, parent=None, embedded: bool = False):
        super().__init__(parent)
        if embedded:     # страница окна «Настройки алгоритмов», а не отдельный диалог
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle("Робот — настройки")
        form = QtWidgets.QFormLayout(self)
        self.enabled = QtWidgets.QCheckBox("Искать робота")
        self.enabled.setChecked(bool(settings.get("enabled", False)))
        self.min_count = QtWidgets.QSpinBox()
        self.min_count.setRange(2, 100)
        self.min_count.setValue(int(settings.get("min_count", 8)))
        self.interval = QtWidgets.QDoubleSpinBox()
        self.interval.setRange(0.1, 300.0)
        self.interval.setDecimals(1)
        self.interval.setValue(float(settings.get("interval", 5.0)))
        self.interval.setToolTip(
            "Робот — подряд идущие сделки одной стороны и одного объёма, у которых пауза до\n"
            "предыдущей такой же сделки не больше этого значения. Постоянный интервал не нужен,\n"
            "чужие сделки между ними не мешают. Пауза дольше — робот считается остановившимся."
        )
        # «Мин. интервал» (с 2.0.78): средняя пауза серии не меньше — иначе это не робот (robot_notes.interval_ok)
        self.min_interval = QtWidgets.QDoubleSpinBox()
        self.min_interval.setRange(0.0, 300.0)
        self.min_interval.setDecimals(1)
        self.min_interval.setSingleStep(0.5)
        self.min_interval.setSpecialValueText("не ограничивать")
        self.min_interval.setProperty("wide", True)
        self.min_interval.setValue(float(settings.get("min_interval", 0.0) or 0.0))
        self.min_interval.setToolTip(
            "Средний интервал серии должен быть не меньше этого. Одинаковые сделки чаще —\n"
            "скорее пачка от одного крупного участника, маркет-мейкер или ручной «разгон», а не\n"
            "робот-исполнитель: такую серию не объявляем и на графике не показываем.\n"
            "Куски одной сделки (одно время, ближе 0,1 с) не считаются и при 0. 0 — не ограничивать."
        )
        # «Мин. регулярность» (2.1.40, robot_core.regularity): доля пауз серии около медианной — ритм робота
        self.min_regularity = QtWidgets.QSpinBox()
        self.min_regularity.setRange(0, 100)
        self.min_regularity.setSingleStep(10)
        self.min_regularity.setSuffix(" %")
        self.min_regularity.setSpecialValueText("не проверять")
        self.min_regularity.setProperty("wide", True)
        try:
            self.min_regularity.setValue(int(round(float(settings.get("min_regularity", robot_core.MIN_REGULARITY_PCT)))))
        except (TypeError, ValueError):
            self.min_regularity.setValue(int(robot_core.MIN_REGULARITY_PCT))
        self.min_regularity.setToolTip(
            "Какая доля пауз серии должна быть близка к её обычной паузе (±25 % от медианы).\n"
            "Робот-исполнитель ставит заявки в своём ритме, случайная череда одинаковых объёмов — как придётся.\n"
            "Пока по умолчанию не проверяется: на ленте с точностью до секунды признак надёжен только для\n"
            "всей закончившейся серии, а в момент объявления отсеивает мало. Регулярность показывается в\n"
            "уведомлении; при запуске со всеми журналами (FX_LOGS=1 или --logs) пишется в logs/robots_ДАТА.csv.\n"
            "Пока пауз меньше трёх, судить не по чему — серия проходит. 0 — не проверять."
        )
        # «Пауза робота» (с 2.0.86): объявленный робот, замолчавший дольше «Макс. интервала», — тот же, если вернулся
        # не позже этого (QuotesTab._robot_alive_sec); 0 — без пауз, останавливается по «Макс. интервалу»
        self.pause_sec = QtWidgets.QSpinBox()
        self.pause_sec.setRange(0, 600)
        self.pause_sec.setSingleStep(10)
        self.pause_sec.setSuffix(" с")
        self.pause_sec.setSpecialValueText("без пауз")
        self.pause_sec.setValue(int(float(settings.get("pause_sec", 60) if settings.get("pause_sec") is not None else 60)))
        self.pause_sec.setToolTip(
            "Робот уже объявлен и замолчал дольше «Макс. интервала», но вернулся с тем же объёмом и стороной\n"
            "не позже этого — это тот же робот на паузе: строка в уведомлениях не пропадает, повторно он\n"
            "не объявляется. Паузы не входят в средний интервал. 0 — без пауз: остановка по «Макс. интервалу»."
        )
        self.size_tolerance = QtWidgets.QDoubleSpinBox()
        self.size_tolerance.setRange(0.0, 50.0)
        self.size_tolerance.setDecimals(1)
        self.size_tolerance.setSuffix(" %")
        self.size_tolerance.setValue(float(settings.get("size_tolerance", 0.0)))
        self.size_tolerance.setToolTip("Насколько может отличаться объём сделок одного робота. 0 — строго одинаковый.")
        self.min_lots = QtWidgets.QSpinBox()
        self.min_lots.setRange(0, 10_000_000)
        self.min_lots.setValue(int(settings.get("min_lots", 0) or 0))
        self.min_lots.setToolTip("Сделки меньше этого объёма (в лотах) роботом не считаются — мелочь не мешает\n"
                                 "искать крупных. 0 — любой объём.")
        self.min_turnover = QtWidgets.QDoubleSpinBox()
        self.min_turnover.setRange(0, 1_000_000_000)
        self.min_turnover.setDecimals(0)
        self.min_turnover.setValue(float(settings.get("min_turnover", 0)))
        self.chart = QtWidgets.QCheckBox("Показывать робота на графике")
        self.chart.setChecked(bool(settings.get("chart", False)))
        # «Наращивание» (escalation_detector.py): журнал logs/mm_events_ДАТА.csv, с 2.1.2 — и на графике / в стакане
        self.esc_enabled = QtWidgets.QCheckBox("Искать наращивание объёма")
        self.esc_enabled.setChecked(bool(settings.get("esc_enabled", True)))
        self.esc_enabled.setToolTip("Цепочка рыночных заявок одной стороны через примерно равный шаг, каждая\n"
                                    "больше предыдущей (например 10 → 50 → 250 → 500 лотов через ≈5 с).\n"
                                    "Шаг определяется сам. Если рынок за те же секунды разгоняется так же —\n"
                                    "пишется «По объёму рынка (POV)», иначе «Наращивание».")
        self.esc_min_links = QtWidgets.QSpinBox()
        self.esc_min_links.setRange(3, 20)
        self.esc_min_links.setValue(int(settings.get("esc_min_links", 4)))
        self.esc_growth = QtWidgets.QDoubleSpinBox()
        self.esc_growth.setRange(1.05, 20.0)
        self.esc_growth.setDecimals(2)
        self.esc_growth.setPrefix("× ")
        self.esc_growth.setValue(float(settings.get("esc_growth", 1.3)))
        self.esc_growth.setToolTip("Во сколько раз, не меньше, каждое звено больше предыдущего")
        self.esc_tolerance = QtWidgets.QDoubleSpinBox()
        self.esc_tolerance.setRange(5.0, 90.0)
        self.esc_tolerance.setDecimals(0)
        self.esc_tolerance.setSuffix(" %")
        self.esc_tolerance.setValue(float(settings.get("esc_tolerance", 30.0)))
        self.esc_tolerance.setToolTip("Насколько промежуток между звеньями может отличаться от шага цепочки")
        self.esc_min_first = QtWidgets.QSpinBox()
        self.esc_min_first.setRange(1, 10_000_000)
        self.esc_min_first.setValue(int(settings.get("esc_min_first", 10)))
        self.esc_min_first.setToolTip("Первое звено — не меньше стольких лотов. Меньше порог — больше случайных\n"
                                      "совпадений в оживлённой ленте")
        self.esc_min_total = QtWidgets.QSpinBox()
        self.esc_min_total.setRange(0, 100_000_000)
        self.esc_min_total.setValue(int(settings.get("esc_min_total", 0)))
        self.esc_min_total.setToolTip("Всего лотов в цепочке, не меньше. 0 — без ограничения")
        self.esc_show = QtWidgets.QCheckBox("Показывать наращивание на графике и в стакане")
        self.esc_show.setChecked(bool(settings.get("esc_show", True)))
        self.esc_show.setToolTip("График — значок «↗» справа вверху: при наведении список последних цепочек;\n"
                                 "стакан — отметка у цены последнего звена, пока цепочка идёт.")
        form.addRow(self.enabled)
        form.addRow("Минимум сделок:", self.min_count)
        form.addRow("Мин. интервал между сделками, сек:", self.min_interval)
        form.addRow("Макс. интервал между сделками, сек:", self.interval)
        form.addRow("Пауза робота, не дольше:", self.pause_sec)
        form.addRow("Мин. регулярность серии:", self.min_regularity)
        form.addRow("Допуск объёма:", self.size_tolerance)
        form.addRow("Минимум лотов в сделке:", self.min_lots)
        form.addRow("Минимальный оборот:", self.min_turnover)
        form.addRow(self.chart)
        form.addRow(self.esc_enabled)
        form.addRow("Звеньев, не меньше:", self.esc_min_links)
        form.addRow("Рост звена:", self.esc_growth)
        form.addRow("Допуск шага:", self.esc_tolerance)
        form.addRow("Первое звено, лотов:", self.esc_min_first)
        form.addRow("Всего лотов, не меньше:", self.esc_min_total)
        form.addRow(self.esc_show)
        _compact_form(self, form)
        if not embedded:
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
            buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            form.addRow(buttons)

    def value(self) -> dict:
        return {
            "enabled": self.enabled.isChecked(),
            "min_count": self.min_count.value(),
            "interval": self.interval.value(),
            "min_interval": self.min_interval.value(),
            "pause_sec": self.pause_sec.value(),
            "min_regularity": float(self.min_regularity.value()),
            "size_tolerance": self.size_tolerance.value(),
            "min_lots": self.min_lots.value(),
            "min_turnover": self.min_turnover.value(),
            "chart": self.chart.isChecked(),
            "esc_enabled": self.esc_enabled.isChecked(),
            "esc_min_links": self.esc_min_links.value(),
            "esc_growth": self.esc_growth.value(),
            "esc_tolerance": self.esc_tolerance.value(),
            "esc_min_first": self.esc_min_first.value(),
            "esc_min_total": self.esc_min_total.value(),
            "esc_show": self.esc_show.isChecked(),
        }


class IcebergSettingsDialog(QtWidgets.QDialog):
    """Вкладка «Айсберг» окна «Настройки алгоритмов»; у каждой настройки одна задача:
        поиск   — «Искать айсберги», видимый объём, множитель, удержание (поля активны, пока поиск включён);
        порог   — «Крупный айсберг, исполнено от» (лоты на цене айсберга): с него уведомление и запись в историю
                  (с 2.0.73 один порог; в 2.0.71–2.0.72 было два одинаковых — для уведомлений и для истории);
        график  — «Показывать айсберги на графике» (идущие — все, и сохранённые) и «Сохранять в историю»
                  (копит историю и при выключенном показе)."""

    def __init__(self, settings: dict, parent=None, embedded: bool = False,
                 history_count=None, clear_history=None):
        """history_count() -> сколько айсбергов инструмента в истории; clear_history() — очистить её
        (кнопка «Очистить историю», с 2.0.84; без них кнопки нет)."""
        super().__init__(parent)
        if embedded:     # страница окна «Настройки алгоритмов», а не отдельный диалог
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle("Айсберг — настройки")
        self._history_count, self._clear_history = history_count, clear_history
        form = QtWidgets.QFormLayout(self)

        def lots_spin(value, special):
            spin = QtWidgets.QSpinBox()
            spin.setRange(0, 100_000_000)
            spin.setSingleStep(100)
            spin.setSuffix(" лотов")
            spin.setSpecialValueText(special)
            spin.setProperty("wide", True)
            spin.setValue(int(value or 0))
            return spin

        def indented(text):
            label = QtWidgets.QLabel(text)
            label.setIndent(18)          # поле зависит от галочки над ним
            return label

        # ---- поиск
        self.enabled = QtWidgets.QCheckBox("Искать айсберги")
        self.enabled.setChecked(bool(settings.get("enabled", False)))
        self.visible_lots = lots_spin(settings.get("visible_lots", 0), "не ограничивать")
        self.visible_lots.setToolTip(
            "Видимая часть айсберг-заявки в стакане, лотов. Уровни, где виден меньший объём,\n"
            "не считаются айсбергом. 0 — не ограничивать."
        )
        self.multiplier = QtWidgets.QSpinBox()
        self.multiplier.setRange(2, 100)
        self.multiplier.setValue(int(settings.get("multiplier", 5) or 5))
        self.multiplier.setToolTip(
            "Сколько раз должна исполниться видимая часть айсберг-заявки\n"
            "(это и множитель объёма, и минимум исполнений — одно и то же).\n"
            "Если задан видимый объём, на цене должно быть исполнено не меньше\n"
            "«видимый объём × множитель» лотов."
        )
        self.hold_sec = QtWidgets.QSpinBox()
        self.hold_sec.setRange(1, 600)
        self.hold_sec.setSuffix(" с")
        self.hold_sec.setValue(int(settings.get("hold_sec", 15) or 15))
        self.hold_sec.setToolTip(
            "Айсберг — «стена»: цена раз за разом упирается в уровень и отбивается от него.\n"
            "Уровень должен продержаться не меньше этого времени, и за это время цена не должна\n"
            "пройти по ту сторону. Прошла раньше — это был не айсберг (например, спредовый робот);\n"
            "прошла позже — айсберг закончился."
        )
        # ---- порог: уведомление и история
        self.min_lots = lots_spin(settings.get("min_lots", 0), "любой")
        self.min_lots.setToolTip(
            "Айсберг, на цене которого исполнено не меньше этого числа лотов:\n"
            "• уведомления «Айсберг» и «Айсберг закончился»;\n"
            "• запись в историю графика (если включено «Сохранять в историю»).\n"
            "Мельче — только линия на графике, пока он держится. Без стакана (поиск по ленте сделок) —\n"
            "порог самого поиска. 0 — любой."
        )
        # ---- график и история
        self.chart = QtWidgets.QCheckBox("Показывать айсберги на графике")
        self.chart.setChecked(bool(settings.get("chart", False)))
        self.chart.setToolTip("Пунктир на цене айсберга: циан — покупка (bid), розовый — продажа (ask).\n"
                              "Показывает и идущие айсберги, и сохранённые в истории.")
        # История: закончившиеся айсберги — в logs/iceberg_history.jsonl; график рисует их и после перезапуска.
        self.history = QtWidgets.QCheckBox("Сохранять в историю графика")
        self.history.setChecked(bool(settings.get("history", False)))
        self.history.setToolTip(
            "Закончившийся крупный айсберг (цена прошла за уровень или он минуту молчал; порог — «Крупный\n"
            "айсберг, исполнено от») сохраняется на диск — график рисует его и после перезапуска терминала.\n"
            "Копится и при выключенном «Показывать на графике». Хранится 30 дней."
        )

        form.addRow(self.enabled)
        self._search_rows = [(indented("Видимый объём айсберг-заявки:"), self.visible_lots),
                             (indented("Множитель (мин. исполнений):"), self.multiplier),
                             (indented("Удержание уровня, не меньше:"), self.hold_sec)]
        for label, field in self._search_rows:
            form.addRow(label, field)
        form.addRow("Крупный айсберг, исполнено от:", self.min_lots)
        form.addRow(self.chart)
        form.addRow(self.history)
        self.clear_btn = None
        if clear_history is not None:
            # Очистка истории инструмента: сохранённые айсберги и закончившиеся линии с графика (идущие остаются)
            self.clear_btn = QtWidgets.QPushButton("Очистить историю")
            self.clear_btn.setToolTip("Удалить сохранённые айсберги этого инструмента из истории графика\n"
                                      "и закончившиеся линии с открытых графиков. Идущие айсберги остаются.")
            self.clear_btn.clicked.connect(self._on_clear_history)
            self.history_info = QtWidgets.QLabel("")
            self.history_info.setProperty("muted", True)
            row = QtWidgets.QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.addWidget(self.clear_btn)
            row.addWidget(self.history_info, 1)
            form.addRow(row)
            self._refresh_history_info()
        _compact_form(self, form)
        # Зависимые поля активны, только когда включён поиск.
        self.enabled.toggled.connect(self._sync_enabled)
        self._sync_enabled()
        if not embedded:
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
            buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            form.addRow(buttons)

    def _refresh_history_info(self) -> None:
        try:
            n = int(self._history_count()) if self._history_count is not None else 0
        except Exception:
            n = 0
        word = "айсберг" if n % 10 == 1 and n % 100 != 11 else (
            "айсберга" if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14 else "айсбергов")
        self.history_info.setText(f"в истории {n} {word}" if n else "история пуста")
        self.clear_btn.setEnabled(n > 0)

    def _on_clear_history(self) -> None:
        answer = QtWidgets.QMessageBox.question(
            self, "Очистить историю айсбергов",
            "Удалить сохранённые айсберги этого инструмента из истории графика?\n"
            "Закончившиеся линии уберутся и с открытых графиков; идущие айсберги останутся.",
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No)
        if answer != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        try:
            self._clear_history()
        except Exception:
            traceback.print_exc()
        self._refresh_history_info()

    def _sync_enabled(self, *_args) -> None:
        on = self.enabled.isChecked()
        for label, field in self._search_rows:
            label.setEnabled(on)
            field.setEnabled(on)
        for w in (self.min_lots, self.chart, self.history):
            w.setEnabled(on)

    def value(self) -> dict:
        return {
            "enabled": self.enabled.isChecked(),
            "min_lots": self.min_lots.value(),
            "visible_lots": self.visible_lots.value(),
            "multiplier": self.multiplier.value(),
            "hold_sec": self.hold_sec.value(),
            "chart": self.chart.isChecked(),
            "history": self.history.isChecked(),
        }


class QuoteNotificationsDialog(QtWidgets.QDialog):
    """Вкладка «Уведомления» окна «Настройки алгоритмов»: резкое движение цены, крупная сделка, рост оборота.
    Поля каждой проверки — под её галочкой, с отступом, и активны, только пока она включена (как во вкладке
    «Айсберг»). Объёмы — в лотах (с 2.0.72 и у «Роста оборота»: было «Прирост оборота» в ₽ без единиц)."""

    def __init__(self, settings: dict, parent=None, embedded: bool = False):
        super().__init__(parent)
        if embedded:     # страница окна «Настройки алгоритмов», а не отдельный диалог
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle("Уведомления — настройки")
        form = QtWidgets.QFormLayout(self)

        def indented(text):
            label = QtWidgets.QLabel(text)
            label.setIndent(18)          # поле зависит от галочки над ним
            return label

        def seconds_spin(value, default):
            spin = QtWidgets.QSpinBox()
            spin.setRange(1, 3600)
            spin.setSuffix(" с")
            spin.setValue(int(value or default))
            return spin

        # ---- резкое движение цены
        self.price_enabled = QtWidgets.QCheckBox("Резкое движение цены (за короткое время)")
        self.price_enabled.setChecked(bool(settings.get("price_enabled", False)))
        self.price_pct = QtWidgets.QDoubleSpinBox()
        self.price_pct.setRange(0.01, 100)
        self.price_pct.setDecimals(2)
        self.price_pct.setSingleStep(0.05)
        self.price_pct.setSuffix(" %")
        self.price_pct.setValue(float(settings.get("price_pct", 1.0)))
        self.price_pct.setToolTip("Цена прошла не меньше этого (от минимума окна вверх или от максимума вниз).\n"
                                  "Для юаня 1 % — почти дневной ход; разумнее 0,2–0,3 %.")
        self.price_window = seconds_spin(settings.get("price_window", 15), 15)
        # ---- крупная сделка
        self.trade_enabled = QtWidgets.QCheckBox("Крупная исполненная сделка")
        self.trade_enabled.setChecked(bool(settings.get("trade_enabled", False)))
        # Порог крупной сделки — в лотах (раньше в рублях оборота: на CNYRUBF 10 млн ₽ ≈ 820 лотов, на Si ≈ 123 —
        # неудобно пересчитывать). Лоты — одной рыночной заявки (её куски в ленте склеиваются, см. _add_to_order).
        self.trade_lots = QtWidgets.QSpinBox()
        self.trade_lots.setRange(1, 100_000_000)
        self.trade_lots.setSingleStep(100)
        self.trade_lots.setSuffix(" лотов")
        self.trade_lots.setProperty("wide", True)
        self.trade_lots.setValue(int(settings.get("trade_lots", 500) or 500))
        self.trade_lots.setToolTip("Уведомить, если одна рыночная заявка (её куски в ленте складываются)\n"
                                   "исполнилась на столько лотов или больше. В уведомлении — лоты, цена и оборот в ₽.")
        # ---- рост оборота (VolumeSurge)
        self.turnover_enabled = QtWidgets.QCheckBox("Рост оборота (всплеск объёма торгов)")
        self.turnover_enabled.setChecked(bool(settings.get("turnover_enabled", False)))
        self.turnover_period = seconds_spin(settings.get("turnover_period", 60), 60)
        self.volume_lots = QtWidgets.QSpinBox()
        self.volume_lots.setRange(0, 100_000_000)
        self.volume_lots.setSingleStep(100)
        self.volume_lots.setSuffix(" лотов")
        self.volume_lots.setSpecialValueText("любой")
        self.volume_lots.setProperty("wide", True)
        self.volume_lots.setValue(int(settings.get("volume_lots", VolumeSurge.DEFAULT_LOTS) or 0))
        self.volume_lots.setToolTip("Сколько лотов должно пройти в ленте за период (обе стороны вместе).")
        self.volume_ratio = QtWidgets.QDoubleSpinBox()
        self.volume_ratio.setRange(0, 100)
        self.volume_ratio.setDecimals(1)
        self.volume_ratio.setSingleStep(0.5)
        self.volume_ratio.setPrefix("× ")
        self.volume_ratio.setSpecialValueText("не сравнивать")
        self.volume_ratio.setProperty("wide", True)
        self.volume_ratio.setValue(float(settings.get("volume_ratio", 0) or 0))
        self.volume_ratio.setToolTip(
            "Объём за период должен быть во столько раз больше обычного — среднего за период\n"
            f"по последним {VolumeSurge.BASELINE_SEC // 60} минутам. Порог сам подстраивается под инструмент и время\n"
            "дня. Первые минуты после запуска (истории ещё нет) — не уведомляет. 0 — не сравнивать."
        )

        self._groups = [
            (self.price_enabled, [(indented("Порог движения:"), self.price_pct),
                                  (indented("За время:"), self.price_window)]),
            (self.trade_enabled, [(indented("Порог сделки:"), self.trade_lots)]),
            (self.turnover_enabled, [(indented("Период:"), self.turnover_period),
                                     (indented("Объём за период, не меньше:"), self.volume_lots),
                                     (indented("И больше обычного:"), self.volume_ratio)]),
        ]
        for check, rows in self._groups:
            form.addRow(check)
            for label, field in rows:
                form.addRow(label, field)
            check.toggled.connect(self._sync_enabled)
        _compact_form(self, form)
        self._sync_enabled()
        if not embedded:
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
            buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            form.addRow(buttons)

    def _sync_enabled(self, *_args) -> None:
        for check, rows in self._groups:
            for label, field in rows:
                label.setEnabled(check.isChecked())
                field.setEnabled(check.isChecked())

    def value(self) -> dict:
        return {
            "price_enabled": self.price_enabled.isChecked(),
            "price_pct": self.price_pct.value(),
            "price_window": self.price_window.value(),
            "trade_enabled": self.trade_enabled.isChecked(),
            "trade_lots": self.trade_lots.value(),
            "turnover_enabled": self.turnover_enabled.isChecked(),
            "turnover_period": self.turnover_period.value(),
            "volume_lots": self.volume_lots.value(),
            "volume_ratio": self.volume_ratio.value(),
        }


SpreadRobotTracker = spread_core.SpreadRobotTracker    # эталон на Python (spread_core.py); в работе — Rust (spread_rust)


class SpreadSettingsDialog(QtWidgets.QDialog):
    def __init__(self, settings: dict, parent=None, embedded: bool = False):
        super().__init__(parent)
        if embedded:
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle("Спредовый робот — настройки")
        form = QtWidgets.QFormLayout(self)
        self.enabled = QtWidgets.QCheckBox("Искать спредового робота")
        self.enabled.setChecked(bool(settings.get("enabled", False)))
        self.enabled.setToolTip(
            "Робот, который держит заявку одного и того же объёма у лучшей цены и переставляет её\n"
            "вслед за рынком: заявку съели или сняли — тот же объём появился на другой цене."
        )
        self.min_lots = QtWidgets.QSpinBox()
        self.min_lots.setRange(10, 10_000_000)
        self.min_lots.setSuffix(" лотов")
        self.min_lots.setValue(int(settings.get("min_lots", 300) or 300))
        self.min_lots.setToolTip("Для CNYRUB_TOM спредовый робот держит около 1 000 лотов — можно поставить 800.")
        self.tolerance = QtWidgets.QDoubleSpinBox()
        self.tolerance.setRange(0.0, 50.0)
        self.tolerance.setDecimals(1)
        self.tolerance.setSuffix(" %")
        self.tolerance.setValue(float(settings.get("tolerance", 3) or 0))
        self.tolerance.setToolTip("Насколько может отличаться объём при перестановке (поверх заявки робота бывают чужие).")
        self.min_requotes = QtWidgets.QSpinBox()
        self.min_requotes.setRange(2, 100)
        self.min_requotes.setValue(int(settings.get("min_requotes", 10) or 10))
        self.min_requotes.setToolTip("Сколько раз за последнюю минуту заявка того же объёма переставлялась.\n"
                                     "Кроме этого числа робот признаётся, только если перестановки растянуты хотя бы\n"
                                     "на 20 с и шли минимум по 3 разным ценам (одна вспышка на месте — не робот).")
        self.chart = QtWidgets.QCheckBox("Показывать спредового робота на графике")
        self.chart.setChecked(bool(settings.get("chart", False)))
        form.addRow(self.enabled)
        form.addRow("Объём заявки робота, не меньше:", self.min_lots)
        form.addRow("Допуск объёма:", self.tolerance)
        form.addRow("Перестановок за минуту, не меньше:", self.min_requotes)
        form.addRow(self.chart)
        _compact_form(self, form)
        if not embedded:
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
            buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            form.addRow(buttons)

    def value(self) -> dict:
        return {
            "enabled": self.enabled.isChecked(),
            "min_lots": self.min_lots.value(),
            "tolerance": self.tolerance.value(),
            "min_requotes": self.min_requotes.value(),
            "chart": self.chart.isChecked(),
        }


class MMSettingsDialog(QtWidgets.QDialog):
    """Детектор маркет-мейкера (mm_detector.py) по инструменту — простые настройки (2.1.2): вкл., какие события
    показывать, чувствительность, где показывать. Значения — QuotesTab.DEFAULT_MM."""

    TYPES = (("defense", "Защита уровня",
              "У лучших цен объём съедают сделками, и вскоре на той же цене снова столько же — раз за разом.\n"
              "На графике — в списке значка «М»; в стакане — рамка у цены, пока защита идёт."),
             ("absorb", "Поглощение",
              "По рынку купили (продали) в разы больше обычного, а цена не сдвинулась: встречную сторону пополняли.\n"
              "На графике — в списке значка «М»; в стакане — рамка у цены на минуту."),
             ("requote", "Перестановка котировки",
              "Крупная заявка ездит вслед за ценой (котирующий маркет-мейкер). На графике — в списке значка «М»."),
             ("pull", "Снятие и приманка",
              "Крупную заявку у лучшей цены сняли без сделок, и цена прошла через это место («ушли с дороги»)\n"
              "или ушла в другую сторону; заявку ставят и снимают раз за разом («приманка»).\n"
              "На графике — в списке значка «М»; приманка — ещё и рамка в стакане, пока повторяется."))
    SENSITIVITY = (("low", "Низкая — только явные"), ("normal", "Обычная"), ("high", "Высокая — и слабые следы"))

    def __init__(self, settings: dict, parent=None, embedded: bool = False):
        super().__init__(parent)
        if embedded:
            self.setWindowFlags(QtCore.Qt.WindowType.Widget)
        self.setWindowTitle("Маркет-мейкер — настройки")
        form = QtWidgets.QFormLayout(self)
        self.enabled = QtWidgets.QCheckBox("Искать следы маркет-мейкера")
        self.enabled.setChecked(bool(settings.get("enabled", True)))
        self.enabled.setToolTip("Поведение в стакане, типичное для маркет-мейкера или крупного игрока. Детектору нужен\n"
                                "поток стакана; выключен — стакан для него не открывается. События пишутся и в журнал\n"
                                "logs/mm_events_ДАТА.csv.")
        form.addRow(self.enabled)
        self.types = {}
        for key, text, tip in self.TYPES:
            box = QtWidgets.QCheckBox(text)
            box.setChecked(bool(settings.get(key, True)))
            box.setToolTip(tip)
            self.types[key] = box
            form.addRow("Показывать:" if key == self.TYPES[0][0] else "", box)
        self.sensitivity = QtWidgets.QComboBox()
        for key, text in self.SENSITIVITY:
            self.sensitivity.addItem(text, key)
        index = self.sensitivity.findData(settings.get("sensitivity", "normal"))
        self.sensitivity.setCurrentIndex(index if index >= 0 else 1)
        self.sensitivity.setToolTip("Пороги, от которых событие объявляется: доливов для защиты, во сколько раз больше\n"
                                    "обычного для поглощения, размер снятой заявки и т. д. Низкая — событий меньше,\n"
                                    "высокая — больше (и ложных тоже).")
        form.addRow("Чувствительность:", self.sensitivity)
        self.chart = QtWidgets.QCheckBox("На графике")
        self.chart.setChecked(bool(settings.get("chart", True)))
        self.chart.setToolTip("События маркет-мейкера — списком в значке «М» справа вверху\n"
                              "графика (наведите — последние события и счёт по видам).")
        self.dom = QtWidgets.QCheckBox("В стакане")
        self.dom.setChecked(bool(settings.get("dom", True)))
        self.dom.setToolTip("Рамка у цены и подпись слева от стакана: защита и приманка — пока идут, поглощение — минуту.\n"
                            "Подсказка — при наведении на подпись или рамку.")
        form.addRow("Где:", self.chart)
        form.addRow("", self.dom)
        self.summary = QtWidgets.QPushButton("Сводка исходов…")
        self.summary.setToolTip("Чем кончались события по журналам logs/mm_events_ДАТА.csv: защита устояла или\n"
                                "пробита, снятия — «ушли с дороги» или «приманка»; по инструментам, за последние дни.")
        self.summary.clicked.connect(lambda _checked=False: self._show_summary())
        form.addRow("", self.summary)
        self.enabled.toggled.connect(self._sync_enabled)
        self._sync_enabled(self.enabled.isChecked())
        _compact_form(self, form)
        if not embedded:
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
            buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            form.addRow(buttons)

    def _sync_enabled(self, on: bool) -> None:
        for widget in (*self.types.values(), self.sensitivity, self.chart, self.dom):
            widget.setEnabled(bool(on))

    def _show_summary(self) -> None:
        MMSummaryDialog(self).exec()

    def value(self) -> dict:
        out = {"enabled": self.enabled.isChecked(), "sensitivity": self.sensitivity.currentData() or "normal",
               "chart": self.chart.isChecked(), "dom": self.dom.isChecked()}
        out.update({key: box.isChecked() for key, box in self.types.items()})
        return out


class MMSummaryDialog(QtWidgets.QDialog):
    """Сводка исходов событий маркет-мейкера (mm_summary.report) по журналам logs/mm_events_ДАТА.csv — 2.1.12."""

    DAYS = (1, 3, 7, 30)

    def __init__(self, parent=None, log_dir=None):
        super().__init__(parent)
        self.setWindowTitle("Маркет-мейкер — сводка исходов")
        self.log_dir = Path(log_dir) if log_dir is not None else MM_LOG_DIR
        layout = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("За последние:"))
        self.days = QtWidgets.QComboBox()
        for days in self.DAYS:
            self.days.addItem(f"{days} дн.", days)
        self.days.setCurrentIndex(self.DAYS.index(7))
        top.addWidget(self.days)
        top.addStretch(1)
        layout.addLayout(top)
        self.text = QtWidgets.QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.NoWrap)
        self.text.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.SystemFont.FixedFont))
        layout.addWidget(self.text, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Close)
        buttons.button(QtWidgets.QDialogButtonBox.StandardButton.Close).setText("Закрыть")
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.days.currentIndexChanged.connect(lambda _index: self.refresh())
        self.resize(960, 460)
        self.refresh()

    def refresh(self) -> None:
        self.text.setPlainText(mm_summary.report(int(self.days.currentData() or 7), self.log_dir))



class InstrumentSettingsDialog(QtWidgets.QDialog):
    """Все настройки алгоритмов инструмента в одном окне: Робот · Айсберг · Спред · Маркет-мейкер · Уведомления."""

    PAGES = ("robot", "iceberg", "spread", "mm", "notify")

    def __init__(self, tab: "QuotesTab", symbol: str, page: str = "robot"):
        super().__init__(tab)
        self.setWindowTitle(f"Алгоритмы — {tab._instrument_name(symbol)}")
        self.robot = RobotSettingsDialog(tab._settings_for(tab.robot_settings, symbol, tab.DEFAULT_ROBOT), self, embedded=True)
        self.iceberg = IcebergSettingsDialog(tab._settings_for(tab.iceberg_settings, symbol, tab.DEFAULT_ICEBERG), self,
                                             embedded=True,
                                             history_count=lambda: tab.iceberg_history_count(symbol),
                                             clear_history=lambda: tab.clear_iceberg_history(symbol))
        self.notify = QuoteNotificationsDialog(tab._notify_settings_for_dialog(symbol), self, embedded=True)
        self.spread = SpreadSettingsDialog(tab._settings_for(tab.spread_settings, symbol, tab.DEFAULT_SPREAD), self, embedded=True)
        self.mm = MMSettingsDialog(tab._settings_for(tab.mm_settings, symbol, tab.DEFAULT_MM), self, embedded=True)
        self.tabs = QtWidgets.QTabWidget(self)
        self.tabs.setDocumentMode(True)
        self.tabs.addTab(self.robot, "Робот")
        self.tabs.addTab(self.iceberg, "Айсберг")
        self.tabs.addTab(self.spread, "Спред")
        self.tabs.addTab(self.mm, "Маркет-мейкер")
        self.tabs.addTab(self.notify, "Уведомления")
        self.tabs.setCurrentIndex(self.PAGES.index(page) if page in self.PAGES else 0)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.tabs)
        layout.addWidget(buttons)


def _theme_color(name: str, default: str) -> str:
    """Цвет темы для вкладки; «Текст» и «Фон» вкладки из «Настройки» → «Цвета» → «Алгоритмы» (2.1.83) — поверх
    темы: TEXT, приглушённый TEXT_DIM и фон панелей BG_PANEL выводятся из них (fx_theme.shades)."""
    try:
        import fx_theme
        value = str(getattr(fx_theme, name, default))
    except Exception:
        return default
    if name in ("TEXT", "TEXT_DIM", "BG_PANEL"):
        try:
            import appearance
            bg, text = appearance.override("algo.bg"), appearance.override("algo.text")
            if bg or text:
                sh = fx_theme.shades(QtGui.QColor(bg or fx_theme.BG_WINDOW).name(),
                                     QtGui.QColor(text or fx_theme.TEXT).name())
                if name != "BG_PANEL" or bg:
                    return sh[name]
        except Exception:
            pass
    return value


_ICON_CACHE: dict[str, tuple] = {}


def _draw_glyph(kind: str, color: str) -> QtGui.QPixmap:
    dpr = 2.0
    app = QtWidgets.QApplication.instance()
    screen = app.primaryScreen() if app is not None else None
    if screen is not None:
        dpr = max(dpr, float(screen.devicePixelRatio()))
    size = 16
    pm = QtGui.QPixmap(int(size * dpr), int(size * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    pen = QtGui.QPen(QtGui.QColor(color), 1.4)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    P = QtCore.QPointF
    if kind == "book":            # стакан: полосы разной длины справа и слева от центра
        for y, left, right in ((4, 4, 13), (7, 6, 12), (10, 3, 10), (13, 5, 12)):
            p.drawLine(P(left, y), P(right, y))
        p.drawLine(P(8, 2.5), P(8, 14.5))
    elif kind == "chart":         # график: ломаная со стрелкой
        p.drawPolyline([P(2.5, 12.5), P(6, 8.5), P(9, 10.5), P(13.5, 4.5)])
        p.drawLine(P(13.5, 4.5), P(10.5, 4.5))
        p.drawLine(P(13.5, 4.5), P(13.5, 7.5))
    else:                         # настройки: три ползунка
        for y, knob in ((4.5, 10), (8, 5.5), (11.5, 9)):
            p.drawLine(P(2.5, y), P(13.5, y))
            p.setBrush(QtGui.QColor(_theme_color("BG_PANEL", "#232427")))
            p.drawEllipse(P(knob, y), 1.8, 1.8)
    p.end()
    return pm


def _row_icon(kind: str) -> QtGui.QIcon:
    """Новый QIcon на каждый вызов (картинки кэшируются): приглушённый в покое, светлый при наведении."""
    if kind not in _ICON_CACHE:
        _ICON_CACHE[kind] = (_draw_glyph(kind, _theme_color("TEXT_DIM", "#8b9098")),
                             _draw_glyph(kind, _theme_color("TEXT", "#d7dae0")))
    normal, bright = _ICON_CACHE[kind]
    icon = QtGui.QIcon()
    icon.addPixmap(normal, QtGui.QIcon.Mode.Normal)
    icon.addPixmap(bright, QtGui.QIcon.Mode.Active)
    return icon


def _status_icon(state: str) -> QtGui.QIcon:
    """Точка состояния связи у названия инструмента: ok — зелёная, wait — серая, retry — красная."""
    key = f"dot-{state}"
    if key not in _ICON_CACHE:
        color = {"ok": BULL_COLOR, "retry": BEAR_COLOR}.get(state, "#8b9098")
        pm = QtGui.QPixmap(20, 20)
        pm.setDevicePixelRatio(2.0)
        pm.fill(QtCore.Qt.GlobalColor.transparent)
        p = QtGui.QPainter(pm)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        p.setPen(QtCore.Qt.PenStyle.NoPen)
        p.setBrush(QtGui.QColor(color))
        p.drawEllipse(QtCore.QPointF(5, 5), 3, 3)
        p.end()
        _ICON_CACHE[key] = (pm,)
    return QtGui.QIcon(_ICON_CACHE[key][0])


# Звук уведомления по его типу (имена сигналов — sound_notifier: pulse / signal / alert).
EVENT_SOUNDS = {
    "Цена": "alert",        # резкое движение цены
    "Алерт": "alert",       # касание линии на графике
    "Сделка": "signal",     # крупная исполненная сделка
    "Robot": "robot",       # свой звук FX Robot (sound_notifier.ROBOT)
    "🧊 Iceberg": "signal",
    "Оборот": "pulse",
    "Спред": "robot",       # спредовый робот — тоже робот
}
# Журнал уведомлений «Алгоритмов»: до MAX_EVENTS последних событий, не старше EVENTS_KEEP_DAYS.
# Раньше хранилось 300 — на волатильности (ЦБ) это меньше часа. Журнал живёт в своём файле
# (EVENTS_FILE, формат JSON Lines — см. events_journal.py), а не в настройках терминала.
# Новые события дописываются в конец файла не чаще раза в EVENTS_SAVE_MS; целиком файл переписывается
# только когда разросся. Раньше (EVENTS_LEGACY_FILE, до 29.10) весь журнал ~1,5 МБ переписывался при каждой
# пачке событий — ~2,4 ГБ записи за 17 часов; старый файл при первом запуске переносится и удаляется.
# Срок — 2 дня: при потоке событий 29.10 (до 2700 в час) 5000 событий — это меньше суток, неделя
# не набиралась никогда.
# Предупреждение «лента сделок Finam отстаёт» в шапке вкладки (см. QuotesTab._update_feed_lag).
FEED_LAG_WARN_SEC = 10.0
FEED_LAG_COLOR = "#e0b030"

MAX_EVENTS = 5000
EVENTS_KEEP_DAYS = 2
EVENTS_FILE = app_paths.DATA_DIR / "quotes_events.jsonl"
EVENTS_LEGACY_FILE = app_paths.DATA_DIR / "quotes_events.json"
EVENTS_SAVE_MS = 5000


# Как показывать тип события в окне уведомлений (в самих событиях хранятся прежние ключи —
# по ним выбирается звук и читаются старые сохранённые записи).
EVENT_TYPE_LABELS = {
    "Robot": "🤖 Робот",
    "🧊 Iceberg": "🧊 Айсберг",
    "Сделка": "💰 Сделка",
    "Цена": "⚡ Цена",
    "Оборот": "📊 Оборот",
    "Алерт": "🔔 Алерт",
    "Спред": "🔄 Спредовый",
}


def _plural(n: int, one: str, few: str, many: str) -> str:
    """1 сделка, 2 сделки, 5 сделок."""
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def event_sound(event: dict) -> str:
    return EVENT_SOUNDS.get(str(event.get("type", "")), "pulse")


PINNED_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 7    # строка — закреплённый робот: "BUY" / "SELL"
NOTE_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 8      # снимок строки для «В заметки» (время, тип, инструмент…)
ICEBERG_MULT_MIGRATED_KEY = "quotes/iceberg_mult5"   # 2.0.51: сохранённый множитель 3 (старое умолчание) → 5
EVENT_ID_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 9  # id события строки (склеенная строка обновляется на месте)
# (+10 — тикер строки события.) Закреплённая строка действующего робота: (тикер, uid серии) — «В заметки» по ней
# ждёт остановки робота (QuotesTab.wait_robot_note), чтобы сохранить серию целиком.
ROBOT_UID_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 11
WAIT_MARK = " · 📝 ждёт остановки"
STOPPED_MARK = " · остановился"          # строка робота в «Уведомлениях», когда он остановился (2.1.77)
FILTER_KEY = "quotes/notify_filter"                       # QSettings: фильтр окна «Уведомления»


class _PinnedFrameDelegate(QtWidgets.QStyledItemDelegate):
    """Обводит закреплённые строки (действующие роботы) рамкой цвета стороны."""

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        side = index.data(PINNED_ROLE)
        if not side:
            return
        painter.save()
        pen = QtGui.QPen(QtGui.QColor(BULL_COLOR if side == "BUY" else BEAR_COLOR), 1.2)
        painter.setPen(pen)
        r = QtCore.QRectF(option.rect).adjusted(0.5, 1.5, -0.5, -1.5)
        painter.drawLine(r.topLeft(), r.topRight())
        painter.drawLine(r.bottomLeft(), r.bottomRight())
        if index.column() == 0:
            painter.drawLine(r.topLeft(), r.bottomLeft())
        if index.column() == index.model().columnCount() - 1:
            painter.drawLine(r.topRight(), r.bottomRight())
        painter.restore()


class QuotesNotificationsPanel(QtWidgets.QWidget):
    """Окно «Уведомления» — панель рабочих областей, как другие окна из меню «Окна» (с 2.0.95; раньше —
    отдельный диалог): закрепляется в любом пространстве, выносится в плавающее окно, одно на терминал
    (PanelSpec «notifications», single). Живое: пока панель видна, новые события появляются сверху сразу
    (вкладка вызывает add_event); пока скрыта (вкладка за другой, закрыта) — вкладка помечает её устаревшей
    (mark_stale), и при показе список перечитывается. Показали — уведомления прочитаны (QuotesTab
    .mark_notifications_read: значок в строке меню гаснет). Список — тот же self.events вкладки."""

    COLUMNS = ["Время", "Тип", "Инструмент", "Событие", "Детали"]

    @staticmethod
    def _event_time(event: dict, tz_name: str) -> str:
        """Время события в часовом поясе терминала: «06.10 07:39:09». У старых записей без ts — как было (UTC)."""
        ts = event.get("ts")
        if ts:
            try:
                return pd.Timestamp(ts).tz_convert(tz_name).strftime("%d.%m %H:%M:%S")
            except Exception:
                pass
        old = event.get("time", "")
        return f"{old} UTC" if old else ""

    def __init__(self, events: list[dict], parent=None, display_tz: str = "Europe/Moscow", sound=None,
                 robots_source=None, tab=None):
        """parent — окно, над которым живёт диалог (главное окно терминала); tab — вкладка «Алгоритмы»
        (заметки, очистка журнала). Без tab вкладкой считается parent (как раньше)."""
        super().__init__(parent)
        self._tab = tab if tab is not None else parent
        self.setWindowTitle("Уведомления")
        self._stale = False       # пока панель скрыта, пришли события — при показе перечитать список
        self._robots_source = robots_source   # callable() -> список действующих роботов (см. QuotesTab.active_robots)
        self._events = events
        self._tz = display_tz
        self._sound = sound

        layout = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QHBoxLayout()
        self.count_label = QtWidgets.QLabel("")
        self.count_label.setStyleSheet("color:#8a8f9c;")
        top.addWidget(self.count_label)
        top.addSpacing(16)
        # Фильтры: тип, инструмент, «оборот от» (роботы и крупные сделки) — запоминаются (FILTER_KEY)
        self.kind_combo = QtWidgets.QComboBox()
        self.kind_combo.addItem("Все типы", "")
        for key, label in EVENT_TYPE_LABELS.items():
            self.kind_combo.addItem(label, key)
        self.symbol_combo = QtWidgets.QComboBox()
        self.symbol_combo.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.min_check = QtWidgets.QCheckBox("Оборот от")
        self.min_check.setToolTip("Скрыть роботов, айсберги и крупные сделки с оборотом меньше порога\n"
                                  "(у айсберга — исполненное по нему; у остальных событий оборот не проверяется)")
        self.min_spin = QtWidgets.QDoubleSpinBox()
        self.min_spin.setRange(0.1, 10_000)
        self.min_spin.setDecimals(1)
        self.min_spin.setSuffix(" млн ₽")
        self.min_spin.setValue(3.0)
        for w in (QtWidgets.QLabel("Тип:"), self.kind_combo, QtWidgets.QLabel("Инструмент:"), self.symbol_combo,
                  self.min_check, self.min_spin):
            top.addWidget(w)
        self._load_filter()
        self.kind_combo.currentIndexChanged.connect(lambda _i: self._filter_changed())
        self.symbol_combo.currentIndexChanged.connect(lambda _i: self._filter_changed())
        self.min_check.toggled.connect(lambda _on: self._filter_changed())
        self.min_spin.valueChanged.connect(lambda _v: self._filter_changed())
        top.addStretch(1)
        # Сразу с родителем: setVisible(True) у виджета без родителя показывает его отдельным окном. До 2.0.96
        # флажок так и создавался — на миг окном, а потом в раскладке; отложенная окраска шапки окна
        # (fx_theme) успевала превратить его, панель и всю цепочку докинга в отдельные окна Windows.
        self.sound_check = QtWidgets.QCheckBox("Звук", self)
        self.sound_check.setToolTip("Звуковые уведомления: FX Pulse / FX Signal / FX Alert")
        self.sound_check.setVisible(sound is not None)
        if sound is not None:
            self.sound_check.setChecked(bool(sound.enabled))
            self.sound_check.toggled.connect(sound.set_enabled)
        top.addWidget(self.sound_check)
        layout.addLayout(top)

        self.table = QtWidgets.QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 120)
        self.table.setColumnWidth(1, 120)
        self.table.setColumnWidth(2, 110)
        self.table.setColumnWidth(3, 230)
        # Прокрутка по пикселям: поправка «на высоту новой строки» — в пикселях. В режиме по строкам
        # (по умолчанию у Qt) та же поправка уводила список на десятки строк — список «дребезжал».
        self.table.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        # Действующие роботы закреплены первыми строками ленты и обведены рамкой цвета стороны;
        # строка обновляется раз в секунду и уходит сама, когда робот остановился.
        self.table.setItemDelegate(_PinnedFrameDelegate(self.table))
        self._pinned = 0          # сколько верхних строк заняты действующими роботами
        self._stopped_at: dict = {}   # (инструмент, серия) -> когда робот остановился (пока вы читаете список)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._table_menu)
        self.table.itemSelectionChanged.connect(self._on_selection)
        # Пока вы читаете (список прокручен вниз или выделены строки), новые события не вставляются, а копятся
        # в _pending — строки не двигаются. Кнопка «▲ Новых: N» (или возврат наверх без выделения) показывает их.
        self._pending: list[dict] = []
        self.new_btn = QtWidgets.QPushButton("")
        self.new_btn.setAutoDefault(False)
        self.new_btn.setVisible(False)
        self.new_btn.setToolTip("Пока вы читаете список, новые события ждут здесь — щелчок показывает их сверху")
        self.new_btn.clicked.connect(self._show_pending)
        # По ширине текста, по центру (как «новые сообщения» в мессенджерах), а не во всё окно (02.11)
        self.new_btn.setSizePolicy(QtWidgets.QSizePolicy.Policy.Maximum, QtWidgets.QSizePolicy.Policy.Fixed)
        self.new_btn.setStyleSheet("QPushButton { padding: 2px 14px; }")
        new_row = QtWidgets.QHBoxLayout()
        new_row.setContentsMargins(0, 0, 0, 0)
        new_row.addStretch(1)
        new_row.addWidget(self.new_btn)
        new_row.addStretch(1)
        layout.addLayout(new_row)
        layout.addWidget(self.table, 1)
        self.table.verticalScrollBar().valueChanged.connect(lambda _v: self._maybe_flush())

        self._robots_timer = QtCore.QTimer(self)
        self._robots_timer.setInterval(1000)
        self._robots_timer.timeout.connect(self.refresh_robots)

        buttons = QtWidgets.QHBoxLayout()
        clear_btn = QtWidgets.QPushButton("Очистить список")
        clear_btn.setAutoDefault(False)
        clear_btn.clicked.connect(self._clear)
        buttons.addWidget(clear_btn)
        self.notes_btn = QtWidgets.QPushButton("В заметки")
        self.notes_btn.setAutoDefault(False)
        self.notes_btn.setToolTip("Добавить выбранные события в окно «Заметки» (можно выбрать несколько; правый клик — то же)")
        self.notes_btn.setEnabled(False)
        self.notes_btn.clicked.connect(self._add_selected_to_notes)
        buttons.addWidget(self.notes_btn)
        buttons.addStretch(1)              # «Закрыть» больше не нужна: панель закрывается крестиком вкладки
        layout.addLayout(buttons)
        self.reload()

    def sizeHint(self) -> QtCore.QSize:                                   # noqa: N802
        return QtCore.QSize(900, 560)        # плавающее окно панели — прежнего размера диалога

    # ---- действующие роботы ------------------------------------------------------

    def mark_stale(self) -> None:
        """Пока панель скрыта, пришли или изменились события: при показе список перечитается целиком."""
        self._stale = True

    def showEvent(self, event):
        if self._stale:
            self._stale = False
            self.reload()                  # reload пересобирает и закреплённых роботов
        else:
            self.refresh_robots()
        self._robots_timer.start()
        tab = self._tab
        if tab is not None and hasattr(tab, "mark_notifications_read"):
            tab.mark_notifications_read()  # окно на экране — уведомления прочитаны, значок гаснет
        super().showEvent(event)

    def hideEvent(self, event):
        self._robots_timer.stop()      # закрытое окно ничего не пересчитывает
        super().hideEvent(event)

    def refresh_robots(self) -> None:
        """Пересобрать закреплённые строки роботов (в начале ленты), не трогая уведомления под ними.
        Пока вы читаете список (_reading) — _refresh_robots_reading: строки привязаны к роботам, экран не
        сдвигается; иначе — строки по порядку списка роботов (самые крупные сверху)."""
        if self._robots_source is None:
            return
        try:
            robots = list(self._robots_source())
        except Exception as exc:
            print(f"[Алгоритмы] список роботов: {type(exc).__name__}: {exc}", file=sys.stderr)
            robots = []
        if self._reading():
            self._refresh_robots_reading(robots)
            return
        self._stopped_at.clear()
        if not robots and not self._pinned:
            return     # роботов нет и не было: setUpdatesEnabled(True) ниже перерисовал бы всю таблицу (2.0.98)
        bar = self.table.verticalScrollBar()
        keep = bar.value() > 0
        old_height = sum(self.table.rowHeight(r) for r in range(self._pinned))
        self.table.setUpdatesEnabled(False)
        while self._pinned > len(robots):
            self.table.removeRow(0)
            self._pinned -= 1
        while self._pinned < len(robots):
            self.table.insertRow(0)
            self._pinned += 1
        now = pd.Timestamp.now(tz="UTC")
        for row, robot in enumerate(robots):
            self._fill_robot_row(row, robot, now)
        self.table.setUpdatesEnabled(True)
        if keep:   # читаете старые уведомления — экран не сдвигается из-за появления/ухода роботов
            new_height = sum(self.table.rowHeight(r) for r in range(self._pinned))
            bar.setValue(bar.value() + new_height - old_height)

    STOPPED_KEEP_SEC = 30.0       # остановившийся робот держится в закреплённых, пока вы читаете, — не дольше

    def _row_robot_key(self, row: int):
        """(инструмент, номер серии) робота в закреплённой строке; None — не робот (спредовый, крупная сделка)."""
        item = self.table.item(row, 0)
        key = item.data(ROBOT_UID_ROLE) if item is not None else None
        try:
            return (key[0], key[1]) if key is not None and key[1] is not None else None
        except (TypeError, IndexError):
            return None

    def _refresh_robots_reading(self, robots: list) -> None:
        """Закреплённые строки, пока вы читаете список (он прокручен или в нём выделена строка).

        Строка привязана к своему роботу по номеру серии, а не к месту в списке (2.1.21). Раньше строки
        заполнялись по порядку: робот уходил — остальные сдвигались на строку вверх, а в последних строках
        оставался прежний текст, и один и тот же робот стоял в списке по нескольку раз с застывшим временем
        (10.11: «35 сделок × 50 лотов» — пять строк). Теперь: работающий робот обновляет свою строку; новый —
        встаёт сверху; остановившийся — помечается «остановлен» и через STOPPED_KEEP_SEC убирается (выделенная
        строка остаётся, пока выделена). Экран при этом не сдвигается."""
        if not robots and not self._pinned:
            return                    # роботов нет и не было — таблицу не трогаем (как в refresh_robots)
        now = pd.Timestamp.now(tz="UTC")
        mono = time.monotonic()
        by_key = {(r.get("symbol", ""), r.get("uid")): r for r in robots if r.get("uid") is not None}
        others = [r for r in robots if r.get("uid") is None]          # спредовые, крупные сделки — по порядку
        selected = {index.row() for index in self.table.selectionModel().selectedRows()}
        bar = self.table.verticalScrollBar()
        keep = bar.value() > 0
        old_height = sum(self.table.rowHeight(r) for r in range(self._pinned))
        self.table.setUpdatesEnabled(False)
        seen, other_i, drop = set(), 0, []
        for row in range(self._pinned):
            key = self._row_robot_key(row)
            if key is None:
                if other_i < len(others):
                    self._fill_robot_row(row, others[other_i], now)
                    other_i += 1
                elif row not in selected:
                    drop.append(row)
                continue
            if key in by_key and key not in seen:
                seen.add(key)
                self._stopped_at.pop(key, None)
                self._fill_robot_row(row, by_key[key], now)
                continue
            since = self._stopped_at.setdefault(key, mono)
            item = self.table.item(row, 3)
            if item is not None and not item.text().endswith(" · остановлен"):
                item.setText(item.text() + " · остановлен")
            if (mono - since > self.STOPPED_KEEP_SEC or key in seen) and row not in selected:
                drop.append(row)
        for row in reversed(drop):
            key = self._row_robot_key(row)
            if key is not None and key not in seen:
                self._stopped_at.pop(key, None)
            self.table.removeRow(row)
            self._pinned -= 1
        fresh = [r for key, r in by_key.items() if key not in seen] + others[other_i:]
        for robot in reversed(fresh):
            self.table.insertRow(0)
            self._pinned += 1
            self._fill_robot_row(0, robot, now)
        self.table.setUpdatesEnabled(True)
        if keep:
            new_height = sum(self.table.rowHeight(r) for r in range(self._pinned))
            bar.setValue(bar.value() + new_height - old_height)

    def _fill_robot_row(self, row: int, robot: dict, now) -> None:
        if robot.get("kind") == "spread":
            self._fill_spread_row(row, robot, now)
            return
        if robot.get("kind") == "big":
            self._fill_big_trade_row(row, robot)
            return
        is_buy = robot.get("side") == "BUY"
        side = "покупка" if is_buy else "продажа"
        color = QtGui.QColor(BULL_COLOR if is_buy else BEAR_COLOR)
        tint = QtGui.QColor(color)
        tint.setAlpha(28)
        try:
            elapsed = max(0, int((now - robot["started"]).total_seconds()))
        except Exception:
            elapsed = 0
        h, rem = divmod(elapsed, 3600)
        m, sec = divmod(rem, 60)
        count = int(robot.get("count", 0))
        size = float(robot.get("size", 0) or 0)
        lots = _plural(size, "лот", "лота", "лотов") if size.is_integer() else "лота"
        details = (
            f"{count} {_plural(count, 'сделка', 'сделки', 'сделок')} × {size:g} {lots}, "
            f"интервал ≈ {float(robot.get('interval', 0)):.1f} с, оборот {_quotes_money(float(robot.get('turnover', 0)))}"
            + (f", {robot_notes.tempo_text(robot.get('cv'))}" if robot.get("cv") is not None else "")
            + (f", регулярность {robot['regularity'] * 100:.0f} %" if robot.get("regularity") is not None else "")
            + (f", пауз {int(robot['pause_n'])} (до {float(robot.get('pause_max') or 0):.0f} с)"
               if robot.get("pause_n") else "")
            + (robot.get("note_hint") or "")         # « · 📝 заметка от …» — о таком роботе есть заметка
        )
        paused = float(robot.get("paused_sec") or 0)
        uid = robot.get("uid")
        waiting = self._tab is not None and hasattr(self._tab, "robot_note_waiting") and self._tab.robot_note_waiting(uid)
        values = [
            f"с {self._event_time({'ts': pd.Timestamp(robot['started']).isoformat()}, self._tz)[-8:]}"
            if robot.get("started") is not None else "",
            "🤖 Робот",
            _friendly_symbol(robot.get("symbol", "")),
            f"{side.capitalize()} · {h:02d}:{m:02d}:{sec:02d}"                   # время работы — на виду
            + (f" · пауза {paused:.0f} с" if paused else "") + (WAIT_MARK if waiting else ""),
            details,
        ]
        bold = QtGui.QFont(self.table.font())
        bold.setBold(True)
        for col, text in enumerate(values):
            item = self.table.item(row, col)
            if item is None:
                item = QtWidgets.QTableWidgetItem()
                self.table.setItem(row, col, item)
            item.setText(text)
            item.setData(PINNED_ROLE, "BUY" if is_buy else "SELL")
            item.setData(NOTE_ROLE, dict(zip(("time", "kind", "symbol", "title", "details"), values)))
            item.setData(ROBOT_UID_ROLE, (robot.get("symbol", ""), uid))
            item.setBackground(QtGui.QBrush(tint))
            item.setFont(bold if col == 3 else self.table.font())
            item.setForeground(QtGui.QBrush(color) if col == 3 else QtGui.QBrush())
            item.setToolTip(f"Действующий робот ({side}), работает {h:02d}:{m:02d}:{sec:02d}\n{details}"
                            + ("\n📝 Заметка будет добавлена, когда робот остановится" if waiting else
                               "\n«В заметки» — заметка со всей серией, когда робот остановится"))

    def _fill_big_trade_row(self, row: int, trade: dict) -> None:
        """Крупная сделка: закреплена сверху на несколько секунд, ярко подсвечена цветом стороны."""
        is_buy = trade.get("side") == "BUY"
        color = QtGui.QColor(BULL_COLOR if is_buy else BEAR_COLOR)
        tint = QtGui.QColor(color)
        tint.setAlpha(70)                               # заметнее, чем у роботов
        values = [
            self._event_time({"ts": trade.get("time")}, self._tz) if trade.get("time") else "",
            EVENT_TYPE_LABELS.get("Сделка", "Сделка"),
            _friendly_symbol(trade.get("symbol", "")),
            trade.get("title", ""),
            trade.get("details", ""),
        ]
        bold = QtGui.QFont(self.table.font())
        bold.setBold(True)
        for col, text in enumerate(values):
            item = self.table.item(row, col)
            if item is None:
                item = QtWidgets.QTableWidgetItem()
                self.table.setItem(row, col, item)
            item.setText(str(text))
            item.setData(PINNED_ROLE, "BUY" if is_buy else "SELL")
            item.setData(NOTE_ROLE, dict(zip(("time", "kind", "symbol", "title", "details"), (str(v) for v in values))))
            item.setData(ROBOT_UID_ROLE, None)
            item.setBackground(QtGui.QBrush(tint))
            item.setFont(bold)
            item.setForeground(QtGui.QBrush(color) if col == 3 else QtGui.QBrush())
            item.setToolTip(f"{trade.get('title', '')}\n{trade.get('details', '')}")

    def _fill_spread_row(self, row: int, robot: dict, now) -> None:
        is_buy = robot.get("side") == "BUY"
        side = "покупка" if is_buy else "продажа"
        color = QtGui.QColor(BULL_COLOR if is_buy else BEAR_COLOR)
        tint = QtGui.QColor(color)
        tint.setAlpha(28)
        try:
            elapsed = max(0, int((now - pd.Timestamp(robot["started"])).total_seconds()))
        except Exception:
            elapsed = 0
        h, rem = divmod(elapsed, 3600)
        m, sec = divmod(rem, 60)
        size = float(robot.get("size", 0) or 0)
        details = (f"~{size:,.0f} лотов, цена {float(robot.get('price', 0) or 0):.8g}, "
                   f"перестановок {int(robot.get('per_minute', 0))} за минуту, всего {int(robot.get('requotes', 0))}"
                   ).replace(",", " ")
        started = robot.get("started")
        values = [
            f"с {self._event_time({'ts': pd.Timestamp(started).isoformat()}, self._tz)[-8:]}" if started is not None else "",
            "🔄 Спредовый",
            _friendly_symbol(robot.get("symbol", "")),
            f"{side.capitalize()} · {h:02d}:{m:02d}:{sec:02d}",
            details,
        ]
        bold = QtGui.QFont(self.table.font())
        bold.setBold(True)
        for col, text in enumerate(values):
            item = self.table.item(row, col)
            if item is None:
                item = QtWidgets.QTableWidgetItem()
                self.table.setItem(row, col, item)
            item.setText(text)
            item.setData(PINNED_ROLE, "BUY" if is_buy else "SELL")
            item.setData(NOTE_ROLE, dict(zip(("time", "kind", "symbol", "title", "details"), values)))
            item.setData(ROBOT_UID_ROLE, None)
            item.setBackground(QtGui.QBrush(tint))
            item.setFont(bold if col == 3 else self.table.font())
            item.setForeground(QtGui.QBrush(color) if col == 3 else QtGui.QBrush())
            item.setToolTip(f"Спредовый робот ({side}): держит заявку одного объёма у лучшей цены и переставляет её\n{details}")

    # ---- данные ----------------------------------------------------------------

    def set_display_tz(self, tz_name: str) -> None:
        if tz_name and tz_name != self._tz:
            self._tz = tz_name
            self.reload()

    def reload(self) -> None:
        """Полностью перерисовать список (при открытии окна и смене часового пояса)."""
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        self._pinned = 0
        for event in reversed(self._events[-MAX_EVENTS:]):
            self._insert(event, self.table.rowCount())
        self.table.setUpdatesEnabled(True)
        self._fill_symbols()
        self.refresh_robots()
        self._apply_filter()
        self._update_count()
        if self._sound is not None:
            self.sound_check.blockSignals(True)
            self.sound_check.setChecked(bool(self._sound.enabled))
            self.sound_check.blockSignals(False)

    def _reading(self) -> bool:
        """Вы читаете список: он прокручен от начала или в нём выделены строки (например, для «В заметки»)."""
        return self.table.verticalScrollBar().value() > 0 or bool(self.table.selectionModel().selectedRows())

    def add_event(self, event: dict) -> None:
        """Новое событие — строкой сверху. Пока вы читаете список, оно ждёт в _pending (строки не двигаются)."""
        if self._reading():
            self._pending.append(event)
            self._update_new_button()
            return
        row = self._pinned                    # сразу под закреплёнными роботами
        self._insert(event, row)
        self._trim()
        self._flash(row)
        self._note_symbol(event)
        self.table.setRowHidden(row, not self._passes(event))
        self._update_count()

    def upsert_event(self, event: dict) -> None:
        """Склеенное событие (notify_merge) обновилось: пока вы читаете — строка меняется на месте; иначе
        старая строка уходит, а событие встаёт наверх ленты, как новое."""
        row = self._row_of_event(event.get("id"))
        if self._reading():
            if row is not None:
                self._fill_row(row, event)
            elif not any(e.get("id") == event.get("id") for e in self._pending):
                self._pending.append(event)
                self._update_new_button()
            return
        if row is not None:
            self.table.removeRow(row)
        self.add_event(event)

    def _row_of_event(self, event_id) -> int | None:
        if not event_id:
            return None
        for row in range(self._pinned, self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is not None and item.data(EVENT_ID_ROLE) == event_id:
                return row
        return None

    # ---- фильтр ----------------------------------------------------------------------
    def _settings(self):
        host = getattr(self._tab, "host", None)
        return getattr(host, "settings", None)

    def _load_filter(self) -> None:
        st = self._settings()
        try:
            data = json.loads(str(st.value(FILTER_KEY, "") or "{}")) if st is not None else {}
        except ValueError:
            data = {}
        i = self.kind_combo.findData(data.get("kind", ""))
        self.kind_combo.setCurrentIndex(max(0, i))
        self._wanted_symbol = data.get("symbol", "")
        self.min_check.setChecked(bool(data.get("min_on", False)))
        try:
            self.min_spin.setValue(float(data.get("min_mln", 3.0)))
        except (TypeError, ValueError):
            pass

    def _filter_changed(self) -> None:
        self._wanted_symbol = self.symbol_combo.currentData() or ""
        st = self._settings()
        if st is not None:
            st.setValue(FILTER_KEY, json.dumps({"kind": self.kind_combo.currentData() or "",
                                                "symbol": self._wanted_symbol, "min_on": self.min_check.isChecked(),
                                                "min_mln": self.min_spin.value()}))
        self._apply_filter()

    def _passes(self, event: dict) -> bool:
        return notify_merge.passes_filter(
            event, kind=self.kind_combo.currentData() or None, symbol=self.symbol_combo.currentData() or None,
            min_turnover=self.min_spin.value() * 1e6 if self.min_check.isChecked() else 0.0)

    def _fill_symbols(self) -> None:
        symbols = sorted({str(e.get("symbol", "")) for e in self._events if e.get("symbol")},
                         key=_friendly_symbol)
        self.symbol_combo.blockSignals(True)
        self.symbol_combo.clear()
        self.symbol_combo.addItem("Все", "")
        for sym in symbols:
            self.symbol_combo.addItem(_friendly_symbol(sym), sym)
        i = self.symbol_combo.findData(getattr(self, "_wanted_symbol", ""))
        self.symbol_combo.setCurrentIndex(max(0, i))
        self.symbol_combo.blockSignals(False)

    def _note_symbol(self, event: dict) -> None:
        sym = str(event.get("symbol", ""))
        if sym and self.symbol_combo.findData(sym) < 0:
            self.symbol_combo.blockSignals(True)
            self.symbol_combo.addItem(_friendly_symbol(sym), sym)
            self.symbol_combo.blockSignals(False)

    def _apply_filter(self, rows=None) -> None:
        """Скрыть строки, не подходящие под фильтр окна. rows — только эти строки (например, только что
        вставленные из «▲ Новых событий»); без него — весь список."""
        by_id = {e.get("id"): e for e in self._events if e.get("id")}
        shown = 0
        for row in (range(self._pinned, self.table.rowCount()) if rows is None else rows):
            item = self.table.item(row, 0)
            event = by_id.get(item.data(EVENT_ID_ROLE)) if item is not None else None
            if event is None and item is not None:     # старые записи без id — по снимку строки
                snap = item.data(NOTE_ROLE) or {}
                event = {"type": next((k for k, v in EVENT_TYPE_LABELS.items() if v == snap.get("kind")),
                                      snap.get("kind")),
                         "symbol": item.data(EVENT_ID_ROLE + 1) or ""}
            ok = event is None or self._passes(event)
            if self.table.isRowHidden(row) == ok:      # только если меняется: setRowHidden на каждой из ~1000
                self.table.setRowHidden(row, not ok)   # строк заново раскладывал таблицу (щелчок «▲ Новых» тормозил)
            shown += ok
        if rows is None:
            self._shown = shown
        self._update_count()

    def _trim(self) -> None:
        while self.table.rowCount() > MAX_EVENTS + self._pinned:
            self.table.removeRow(self.table.rowCount() - 1)

    def _update_new_button(self) -> None:
        n = len(self._pending)
        self.new_btn.setVisible(n > 0)
        self.new_btn.setText(f"▲ Новых событий: {n} — показать")

    def _show_pending(self) -> None:
        """Кнопка «▲ Новых»: вставить накопленное сверху и перейти к началу списка. Сначала вставка, потом
        прокрутка наверх — одна перерисовка (раньше прокрутка вызывала вставку из обработчика полосы, и строки
        вставлялись посреди прокрутки)."""
        self.table.blockSignals(True)                  # снятие выделения — без _on_selection (вставим сами)
        self.table.clearSelection()
        self.table.blockSignals(False)
        self.notes_btn.setEnabled(False)
        self._flush_pending()
        bar = self.table.verticalScrollBar()
        bar.blockSignals(True)
        bar.setValue(0)
        bar.blockSignals(False)

    def _maybe_flush(self) -> None:
        if self._pending and not self._reading():
            self._flush_pending()

    def _on_selection(self) -> None:
        self.notes_btn.setEnabled(bool(self.table.selectionModel().selectedRows()))
        self._maybe_flush()

    def _flush_pending(self) -> None:
        events, self._pending = self._pending, []
        if events:
            self.table.setUpdatesEnabled(False)
            for event in events:              # по порядку: самое новое окажется верхним
                old = self._row_of_event(event.get("id"))
                if old is not None:           # склеенная строка обновилась, пока вы читали, — без дубля
                    self.table.removeRow(old)
                self._insert(event, self._pinned)
                self._note_symbol(event)
            self._trim()
            self._apply_filter(range(self._pinned, min(self.table.rowCount(), self._pinned + len(events))))
            self.table.setUpdatesEnabled(True)
            for row in range(self._pinned, self._pinned + min(len(events), 20)):
                self._flash(row)
        self._update_new_button()
        self._update_count()
        self.refresh_robots()

    def _insert(self, event: dict, row: int) -> None:
        self.table.insertRow(row)
        self._fill_row(row, event)

    def _fill_row(self, row: int, event: dict) -> None:
        typ = str(event.get("type", ""))
        title = str(event.get("title", ""))
        details = str(event.get("details", ""))
        if title == typ:          # у старых записей заголовок повторял тип — выводим его из текста
            title = ""
            head = details.split(":", 1)[0].strip().lower()
            if typ == "Robot" and head in ("покупка", "продажа"):
                title = f"Робот: {head}"
                details = details.split(":", 1)[1].strip()
            elif typ == "🧊 Iceberg":
                title = "Айсберг: кандидат (по сделкам)" if head == "кандидат" else "Айсберг"
        values = [
            self._event_time(event, self._tz), EVENT_TYPE_LABELS.get(typ, typ), _friendly_symbol(event.get("symbol", "")),
            title, details,
        ]
        exchange = event.get("exchange_ts")
        snapshot = dict(zip(("time", "kind", "symbol", "title", "details"), (str(v) for v in values)))
        for col, value in enumerate(values):
            item = QtWidgets.QTableWidgetItem(str(value))
            item.setData(NOTE_ROLE, snapshot)
            item.setData(EVENT_ID_ROLE, event.get("id"))
            item.setData(EVENT_ID_ROLE + 1, event.get("symbol", ""))
            if col == 0 and exchange:
                item.setToolTip(f"Срабатывание: {value}\nБиржевое время: {self._event_time({'ts': exchange}, self._tz)}")
            if col == len(values) - 1 and value:
                item.setToolTip(str(value))          # длинные детали обрезаются — полный текст в подсказке
            self.table.setItem(row, col, item)

    def _flash(self, row: int) -> None:
        """Свежая строка на пару секунд выделяется жирным — видно, что пришло новое."""
        items = [self.table.item(row, col) for col in range(self.table.columnCount())]
        font = QtGui.QFont(self.table.font())
        font.setBold(True)
        for item in items:
            if item is not None:
                item.setFont(font)

        def unbold(items=items):
            plain = QtGui.QFont(self.table.font())
            for item in items:
                try:
                    if item is not None and item.tableWidget() is not None:
                        item.setFont(plain)
                except RuntimeError:
                    pass

        QtCore.QTimer.singleShot(2500, unbold)

    def _update_count(self) -> None:
        total = len(self._events)
        hidden = sum(1 for r in range(self._pinned, self.table.rowCount()) if self.table.isRowHidden(r))
        self.count_label.setText(f"Событий: {total}" if not hidden else
                                 f"Событий: {total}, показано {self.table.rowCount() - self._pinned - hidden}")

    # ---- в заметки ---------------------------------------------------------------------
    def _notes_store(self):
        tab = self._tab
        host = getattr(tab, "host", None)
        return getattr(host, "notes_store", None)

    def _table_menu(self, pos) -> None:
        if self.table.itemAt(pos) is None:
            return
        menu = QtWidgets.QMenu(self)
        action = menu.addAction("Добавить в заметки")
        action.setEnabled(self._notes_store() is not None)
        action.triggered.connect(self._add_selected_to_notes)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _add_selected_to_notes(self) -> None:
        store = self._notes_store()
        if store is None:
            QtWidgets.QMessageBox.information(self, "Заметки", "Окно «Заметки» недоступно (старая версия gui_app.py?).")
            return
        rows = sorted(index.row() for index in self.table.selectionModel().selectedRows())
        added = 0
        queued: set = set()                              # серии роботов, поставленные в ожидание этим нажатием
        for row in reversed(rows):                       # в заметках старые — ниже, как и в ленте
            item = self.table.item(row, 0)
            snap = item.data(NOTE_ROLE) if item is not None else None
            if not snap:
                continue
            uids = self._working_robots(row, item, snap)
            if uids:                                     # робот ещё работает — заметка со всей серией после остановки
                for symbol, uid in uids:
                    if uid in queued:                    # тот же робот выделен дважды (своя строка и уведомление)
                        continue
                    if self._tab.wait_robot_note(symbol, uid):
                        queued.add(uid)
                continue
            store.add(symbol=snap.get("symbol", ""), kind=snap.get("kind", ""), title=snap.get("title", ""),
                      details=snap.get("details", ""), event_time=snap.get("time", ""))
            added += 1
        waiting = len(queued)
        parts = ([f"добавлено в заметки: {added}"] if added else []) + \
                ([f"о роботах — каждая, когда её робот остановится: {waiting}"] if waiting > 1 else
                 [f"о роботе — когда остановится: {waiting}"] if waiting else [])
        if added or waiting:
            # Выделение — признак «вы читаете список» (_reading): пока оно есть, новые уведомления ждут в _pending,
            # а закреплённые роботы не добавляются и не уходят. После «В заметки» выделение больше не нужно —
            # снимаем его, иначе окно «замирало», пока не щёлкнешь мышью по списку (02.11).
            self.table.clearSelection()                  # → _on_selection → накопленное встаёт наверх
            self.refresh_robots()                        # «📝 ждёт остановки» в строке робота — сразу
        if parts:                                        # после снятия выделения: _flush_pending пересчитывает счётчик
            self.count_label.setText("; ".join(parts).capitalize())
            QtCore.QTimer.singleShot(4000, self._update_count)

    def _working_robots(self, row: int, item, snap: dict) -> list[tuple[str, int]]:
        """Работающие серии роботов, о которых строка: закреплённая строка робота — её серия; уведомление
        «Робот: покупка / продажа» — работающие сейчас роботы того же инструмента и стороны. Пусто — робот
        уже остановился (или строка не о роботе): заметка добавляется сразу, как раньше."""
        tab = self._tab
        if tab is None or not hasattr(tab, "wait_robot_note"):
            return []
        if row < self._pinned:
            pinned = item.data(ROBOT_UID_ROLE)
            if pinned and pinned[1] is not None and pinned[1] in tab.robot_uids(pinned[0]):
                return [tuple(pinned)]
            return []
        title = str(snap.get("title", "")).lower()
        symbol = item.data(EVENT_ID_ROLE + 1)
        if not symbol or not title.startswith("робот"):
            return []
        side = "BUY" if "покуп" in title else "SELL" if "продаж" in title else None
        return [(symbol, uid) for uid in tab.robot_uids(symbol, side)]

    def _clear(self) -> None:
        self._pending.clear()
        self._update_new_button()
        self._events.clear()   # тот же список, что хранит вкладка
        while self.table.rowCount() > self._pinned:      # закреплённые роботы остаются
            self.table.removeRow(self.table.rowCount() - 1)
        self._update_count()
        tab = self._tab
        if tab is not None and hasattr(tab, "_events_cleared"):
            tab._events_cleared()


# Прежнее имя (до 2.0.95 окно было диалогом) — для старого кода и проверок.
QuotesNotificationsDialog = QuotesNotificationsPanel


class QuotesTab(QtWidgets.QWidget):
    """Вкладка «Алгоритмы» (бывшие «Котировки»): live quote + trade based Robot/Iceberg monitor."""

    # Новое уведомление (dict события) — для звука и других подписчиков. Испускается только
    # для действительно добавленных событий (повторы-дубли отбрасываются раньше).
    event_added = QtCore.Signal(dict)
    # Робот, о котором было уведомление, остановился (символ, сводка серии robot_core.robot_info): звук
    # FX Robot End (main_window → SoundNotifier.play_robot_end), с 2.1.77
    robot_stopped = QtCore.Signal(str, dict)
    book_updated = QtCore.Signal(str)      # стакан инструмента обновился (для окон Level 2)
    HEADERS = ["Название", "Цена", "Изменение", "Оборот", "Реализация", "Робот", "Айсберг", ""]
    COL_NAME, COL_PRICE, COL_CHANGE, COL_TURNOVER, COL_REAL, COL_ROBOT, COL_ICEBERG, COL_TOOLS = range(8)
    # Ранжирование строк: (режим, подпись в списке «Сортировка», колонка, по убыванию по умолчанию).
    # В режимах «изменение», «оборот», «робот» таблица пересортировывается сама раз в SORT_INTERVAL_MS —
    # строки переезжают по мере изменения цены, оборота и работы роботов; «по названию» — при добавлении.
    SORT_MODES = (
        ("manual", "Свой порядок", None, False),
        ("name", "По названию", COL_NAME, False),
        ("change", "По изменению с открытия", COL_CHANGE, True),
        ("turnover", "По обороту", COL_TURNOVER, True),
        ("robot", "Где работает робот", COL_ROBOT, True),
    )
    SORT_INTERVAL_MS = 2000
    # Новый инструмент — все алгоритмы и уведомления ВЫКЛЮЧЕНЫ: включаете то, что нужно, в его настройках.
    # min_interval — «Мин. интервал между сделками» (средняя пауза серии, с 2.0.78; 0 — не ограничивать)
    DEFAULT_ROBOT = {"enabled": False, "min_count": 8, "interval": 5.0, "min_interval": 0.0, "pause_sec": 60,
                     "min_regularity": robot_core.MIN_REGULARITY_PCT,     # % (2.1.40, robot_core.regularity)
                     "size_tolerance": 0.0, "min_lots": 0,
                     "min_turnover": 0.0, "chart": False,
                     # «Наращивание» — независимо от «Искать робота»; esc_show — на графике и в стакане (2.1.2)
                     "esc_enabled": True, "esc_min_links": 4, "esc_growth": 1.3, "esc_tolerance": 30.0,
                     "esc_min_first": 10, "esc_min_total": 0, "esc_show": True}
    # min_lots — «Крупный айсберг, исполнено от» (лоты на цене айсберга): с него уведомление и запись в историю
    # (history — сохранять, iceberg_kind). Один порог с 2.0.73: был notify_min_lots и history_min_lots
    # (переносятся в min_lots — больший из двух, см. _load_state), ещё раньше — min_turnover в ₽.
    DEFAULT_ICEBERG = {"enabled": False, "min_lots": 0, "visible_lots": 0, "multiplier": 5, "hold_sec": 15,
                       "chart": False, "history": False}
    # Робот переставляет ТОЧНО тот же объём: приращение уровня при перестановке — ровно его заявка
    # (чужие заявки на уровне на приращение не влияют), поэтому допуск маленький.
    DEFAULT_SPREAD = {"enabled": False, "min_lots": 300, "tolerance": 3.0, "min_requotes": 10, "chart": False}
    # Детектор маркет-мейкера (2.1.2): включён и показывается везде — он и раньше работал по всем инструментам
    # (только в журнал). Типы — группы mm_marks.GROUPS; sensitivity — mm_detector.SENSITIVITY.
    DEFAULT_MM = {"enabled": True, "defense": True, "absorb": True, "requote": True, "pull": True,
                  "sensitivity": "normal", "chart": True, "dom": True}
    # volume_lots / volume_ratio — «Рост оборота» (VolumeSurge, с 2.0.72): лотов за период и «во сколько раз больше
    # обычного» (0 — не сравнивать). Прежний «Прирост оборота» в ₽ (turnover_delta) пересчитывается в лоты по цене.
    # volume_ratio по умолчанию ×3 с 2.0.73 (в 2.0.72 — 0: только абсолютный порог, и в активные часы «Оборот»
    # приходил по каждому инструменту раз в минуту — CNY000000TOD 30 000 лотов за 60 с при обычных ~30 000).
    DEFAULT_NOTIFY = {"price_enabled": False, "price_pct": 1.0, "price_window": 15, "trade_enabled": False,
                      "trade_lots": 500, "turnover_enabled": False, "turnover_period": 60,
                      "volume_lots": VolumeSurge.DEFAULT_LOTS, "volume_ratio": 3.0}

    def __init__(self, host: "MainWindow", instrument_picker_cls=None, mic_labels=None, type_labels=None):
        super().__init__()
        try:                                          # свои фон и текст вкладки (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "algo")
        except Exception:
            traceback.print_exc()
        self.host = host
        self.instrument_picker_cls = instrument_picker_cls
        self.mic_labels = mic_labels or {}
        self.type_labels = type_labels or {}
        self.symbols: list[str] = []
        self.rows: dict[str, dict] = {}
        self.robot_settings: dict[str, dict] = {}
        self.iceberg_settings: dict[str, dict] = {}
        self.notify_settings: dict[str, dict] = {}
        self.spread_settings: dict[str, dict] = {}
        self.mm_settings: dict[str, dict] = {}
        self._mm_cfg_cache: dict[str, dict] = {}     # настройки ММ по инструменту (их читают сделки и стаканы)
        self._mm_shaper = mm_marks.EventShaper()     # события ММ / «Наращивания» -> график и стакан
        self.mm_chart_events: dict[str, OrderedDict] = {}
        # Подписки в хабе по инструменту (Subscription; имена словарей — с тех времён, когда
        # здесь хранились QThread своих потоков).
        self.trade_threads: dict[str, object] = {}
        self._level2_dialogs: list[Level2Dialog] = []
        self.book_threads: dict[str, object] = {}
        self._mm: dict[str, mm_detector.MMDetector] = {}          # детектор маркет-мейкера по инструменту
        self._mm_streams_ready = False      # стаканы для детектора — только после отложенного старта
        self._mm_start_scheduled = False
        self._mm_printed: dict[str, list] = {}                    # [минута, строк выведено, пропущено]
        self._mm_journal = mm_detector.PullJournal()   # снятия заявок — в журнал только с итогом «с выводом»
        self.orderbook_state: dict[str, dict] = {}
        self.events: list[dict] = []
        self._events_unsaved: list[dict] = []     # ещё не дописанные в файл (дозапись раз в EVENTS_SAVE_MS)
        self._journal = None                      # EventsJournal — создаётся в _load_events
        self.unread = 0
        self.unread_level = 0       # важность самого важного непрочитанного (notify_badge.level_of): цвет значка
        # Окно «Уведомления» — одна панель на терминал (notifications_panel); имя поля — с тех времён, когда это
        # был диалог.
        self._notifications_dialog: QuotesNotificationsPanel | None = None
        self._big_trades: list[dict] = []        # крупные сделки, закреплённые на BIG_TRADE_PIN_SEC
        self._retries: dict[tuple[str, str], int] = {}   # (вид потока, тикер) -> число перезапусков подряд
        self._link: dict[tuple[str, str], tuple[str, str]] = {}   # (вид, тикер) -> (ok|wait|retry, пояснение)
        self._start_queue: list[tuple[str, str]] = []    # потоки, ждущие старта (по одному раз в STREAM_STAGGER_MS)
        self._queue_timer = QtCore.QTimer(self)
        self._queue_timer.setSingleShot(True)
        self._queue_timer.timeout.connect(self._drain_start_queue)
        self._l2_watch: dict[str, int] = {}              # тикер -> число открытых окон Level 2
        self._recent_events: dict[tuple, float] = {}     # антиспам: ключ события -> время последнего
        self._flash: dict[str, float] = {}               # тикер -> до какого момента подсвечена цена
        self._flash_timer = QtCore.QTimer(self)
        self._flash_timer.setInterval(120)
        self._flash_timer.timeout.connect(self._fade_flashes)
        self._sort_mode, self._sort_desc = "manual", False     # см. SORT_MODES; сохраняется в quotes/state
        self._robot_rank: dict[str, float] = {}                 # тикер -> оборот работающих роботов (для режима «robot»)
        self._sort_timer = QtCore.QTimer(self)
        self._sort_timer.setInterval(self.SORT_INTERVAL_MS)
        self._sort_timer.timeout.connect(self._resort)
        # События для графиков (роботы и айсберги) по инструментам: id -> последнее состояние.
        # Новый график берёт отсюда историю, открытый — получает обновления через host.add_quote_event_to_chart.
        self.chart_events: dict[str, OrderedDict] = {}
        self._chart_ids = itertools.count(1)
        # История айсбергов для графика (iceberg_kind.HISTORY_FILE_NAME): читается при первой надобности.
        # _ice_session — метка сеанса: записи этого сеанса график уже получил живыми событиями.
        self._ice_session = f"{int(time.time())}-{random.randrange(1 << 30):x}"
        self._ice_history: list[dict] | None = None
        self._ice_journal = EventsJournal(MM_LOG_DIR / iceberg_kind.HISTORY_FILE_NAME,
                                          iceberg_kind.HISTORY_KEEP_DAYS, iceberg_kind.HISTORY_MAX)
        self._robot_uids = itertools.count(1)                   # номера серий роботов (chain["uid"])
        self._robot_note_wait: dict[int, str] = {}             # uid серии -> тикер: «В заметки» ждёт остановки робота
        self._order_timer = QtCore.QTimer(self)     # дособирает заявки из сделок (см. _add_to_order)
        self._order_timer.setInterval(200)
        self._order_timer.timeout.connect(self._flush_orders)
        self._robot_timer = QtCore.QTimer(self)           # раз в секунду: «работает ЧЧ:ММ:СС» и конец серии робота
        self._robot_timer.setInterval(1000)
        self._robot_timer.timeout.connect(self._tick_robots)
        self._load_state()
        self._load_events()
        self._build_ui()
        self._rebuild_table()
        self._apply_sort_mode(self._sort_mode, self._sort_desc, save=False)

    def _build_ui(self):
        dim = _theme_color("TEXT_DIM", "#8b9098")
        text = _theme_color("TEXT", "#d7dae0")
        tint = _hover_tint()
        self.setStyleSheet(f"""
            QPushButton#pill {{ background: transparent; color: {text}; border: 1px solid {dim};
                                border-radius: 10px; padding: 2px 12px; min-height: 14px; }}
            QPushButton#pill:hover {{ border-color: {text}; background: rgba({tint}, 0.06); }}
            QPushButton#pill:pressed {{ background: rgba({tint}, 0.12); }}
            QPushButton#pill:disabled {{ color: {dim}; border-color: rgba(139, 144, 152, 0.4); }}
            QToolButton#rowTool {{ background: transparent; border: none; border-radius: 3px; padding: 2px; }}
            QToolButton#rowTool:hover {{ background: rgba({tint}, 0.10); }}
            QHeaderView::section:vertical {{ color: {dim}; padding: 0 2px; }}
        """)
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)
        top = QtWidgets.QHBoxLayout()
        top.setSpacing(6)                 # кнопки-«пилюли» чуть меньше, как в «Заметках» (03.11): поле 2×12 px
        add = QtWidgets.QPushButton("Добавить инструмент")
        add.setObjectName("pill")
        add.clicked.connect(self.add_instrument)
        top.addWidget(add)
        self.remove_btn = QtWidgets.QPushButton("Удалить")
        self.remove_btn.setObjectName("pill")
        self.remove_btn.setToolTip("Удалить выбранный инструмент (Delete)")
        self.remove_btn.clicked.connect(self.remove_selected)
        top.addWidget(self.remove_btn)
        # Лента сделок Finam отстаёт от биржи (29.10 — до 129 с при живом стакане): роботы, айсберги и
        # крупные сделки в это время — по старым сделкам. Обновляется раз в секунду (_update_feed_lag).
        self.lag_label = QtWidgets.QLabel()
        self.lag_label.setStyleSheet(f"color:{FEED_LAG_COLOR}; font-weight:600;")
        self.lag_label.setToolTip("Сделки приходят от Finam позже биржи. Стакан при этом может идти вживую.\n"
                                  "Роботы, айсберги и крупные сделки сейчас — с этой задержкой.\n"
                                  "Шлюз сам переоткрывает поток сделок, если задержка больше обычной на 20 с.")
        self.lag_label.hide()
        top.addWidget(self.lag_label)
        top.addStretch(1)
        sort_label = QtWidgets.QLabel("Сортировка:")
        sort_label.setStyleSheet(f"color:{dim};")
        top.addWidget(sort_label)
        self.sort_combo = QtWidgets.QComboBox()
        for mode, title, _col, _desc in self.SORT_MODES:
            self.sort_combo.addItem(title, mode)
        self.sort_combo.setToolTip(
            "Как ранжировать инструменты. По изменению, обороту и роботам таблица пересортировывается "
            "сама каждые 2 секунды. Щелчок по заголовку колонки — тот же выбор; повторный щелчок — в обратную сторону.")
        self.sort_combo.currentIndexChanged.connect(self._on_sort_combo)
        top.addWidget(self.sort_combo)
        root.addLayout(top)

        self.table = QtWidgets.QTableWidget(0, len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.setMouseTracking(True)
        # Слева узкая «ручка» ⋮ — за неё строку можно перетащить; порядок сохраняется.
        vheader = self.table.verticalHeader()
        vheader.setVisible(True)
        vheader.setSectionsMovable(True)
        vheader.setDefaultSectionSize(26)
        vheader.setFixedWidth(16)
        vheader.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Fixed)
        vheader.sectionMoved.connect(self._on_row_moved)
        hheader = self.table.horizontalHeader()
        hheader.setStretchLastSection(False)
        hheader.setSectionsClickable(True)
        hheader.setHighlightSections(False)
        hheader.sectionClicked.connect(self._on_header_clicked)
        widths = (170, 100, 95, 120, 110, 160, 150, 86)
        for col, width in enumerate(widths):
            self.table.setColumnWidth(col, width)
        hheader.setSectionResizeMode(self.COL_TOOLS, QtWidgets.QHeaderView.ResizeMode.Fixed)
        self.table.cellClicked.connect(self._on_cell_clicked)
        self.table.cellDoubleClicked.connect(self._on_cell_double_clicked)
        root.addWidget(self.table)
        QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.Key.Key_Delete), self.table,
                        activated=self.remove_selected, context=QtCore.Qt.ShortcutContext.WidgetShortcut)

        self.hint = QtWidgets.QLabel(
            "Робот — серии одинаковых сделок одной стороны; айсберг — восстановление объёма на цене. "
            "Сортировка — список справа вверху или щелчок по заголовку; строки перетаскиваются за ⋮ "
            "(это включает «Свой порядок»); двойной щелчок по строке — график."
        )
        self.hint.setWordWrap(True)
        self.hint.setStyleSheet(f"color:{dim}; font-size:11px;")
        root.addWidget(self.hint)

    def _load_state(self):
        raw = self.host.settings.value("quotes/state", "")
        if raw:
            try:
                state = json.loads(str(raw))
                self.symbols = list(dict.fromkeys(state.get("symbols", [])))
                self.robot_settings = state.get("robot", {})
                self.iceberg_settings = state.get("iceberg", {})
                # 2.0.51: множитель айсберга по умолчанию 5 (было 3). Окно настроек сохраняет все поля, поэтому
                # у инструментов, где айсберг включали, записано прежнее умолчание 3 — переводим на 5; другое
                # число — ваш выбор, его не трогаем. Отметка «перевели» ставится при первом сохранении состояния
                # (_save_state), вместе с уже переведёнными настройками: выставленное потом вручную 3 останется.
                migrated = str(self.host.settings.value(ICEBERG_MULT_MIGRATED_KEY, "")).lower() in ("1", "true")
                if not migrated:
                    for cfg in self.iceberg_settings.values():
                        if isinstance(cfg, dict) and int(cfg.get("multiplier", 0) or cfg.get("min_hits", 0) or 0) == 3:
                            cfg["multiplier"] = 5
                # 2.0.73: два порога айсберга (уведомления и истории) — один min_lots, больший из заданных
                for cfg in self.iceberg_settings.values():
                    if isinstance(cfg, dict) and "min_lots" not in cfg:
                        cfg["min_lots"] = int(max(float(cfg.pop("notify_min_lots", 0) or 0),
                                                  float(cfg.pop("history_min_lots", 0) or 0)))
                self.notify_settings = state.get("notify", {})
                self.spread_settings = state.get("spread", {})
                self.mm_settings = state.get("mm", {})
                self._mm_cfg_cache = {}
                self.events = state.get("events", [])[-MAX_EVENTS:]     # старое место журнала — перенос
                sort = state.get("sort") or {}
                if sort.get("mode") in {m for m, *_ in self.SORT_MODES}:
                    self._sort_mode, self._sort_desc = sort["mode"], bool(sort.get("desc", False))
            except Exception:
                pass

    def _save_state(self):
        """Список инструментов и настройки — в настройках терминала; журнал уведомлений — в EVENTS_FILE."""
        state = {"symbols": self.symbols, "robot": self.robot_settings, "iceberg": self.iceberg_settings, "notify": self.notify_settings, "spread": self.spread_settings,
                 "mm": self.mm_settings, "sort": {"mode": self._sort_mode, "desc": self._sort_desc}}
        self.host.settings.setValue("quotes/state", json.dumps(state, ensure_ascii=False))
        self.host.settings.setValue(ICEBERG_MULT_MIGRATED_KEY, True)   # множитель 3 → 5 уже в сохранённом (2.0.51)

    def _load_events(self) -> None:
        """Журнал уведомлений из EVENTS_FILE (нет его — из старого EVENTS_LEGACY_FILE, нет и его — то, что было
        в настройках: перенос со старых версий). События старше EVENTS_KEEP_DAYS отбрасываются."""
        self._journal = EventsJournal(EVENTS_FILE, EVENTS_KEEP_DAYS, MAX_EVENTS, legacy_path=EVENTS_LEGACY_FILE)
        loaded = self._journal.load()
        if loaded is not None:
            self.events = loaded
        else:                                              # файлов нет: журнал из настроек (если был) — в файл
            self.events = trim_events(self.events, EVENTS_KEEP_DAYS, MAX_EVENTS)
            if self.events:
                self._journal.rewrite(self.events)

    def _save_events(self, now: bool = False) -> None:
        """Дописать новые события в файл не чаще раза в EVENTS_SAVE_MS (now=True — сразу: выход из терминала).
        Файл переписывается целиком, только если разросся (см. EventsJournal.append)."""
        timer = self.__dict__.get("_events_timer")
        if timer is None:
            timer = self._events_timer = QtCore.QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(lambda: self._save_events(now=True))
        if not now:
            if not timer.isActive():
                timer.start(EVENTS_SAVE_MS)
            return
        timer.stop()
        pending, self._events_unsaved = self._events_unsaved, []
        if self._journal is not None and pending:
            self._journal.append(pending, current=self.events)

    def _events_cleared(self) -> None:
        """Журнал очищен в окне уведомлений — файл переписать из того, что осталось (обычно пусто)."""
        self._events_unsaved = []
        timer = self.__dict__.get("_events_timer")
        if timer is not None:
            timer.stop()
        if self._journal is not None:
            self._journal.rewrite(self.events)

    def _settings_for(self, mapping, symbol, default):
        value = dict(default)
        saved = mapping.get(symbol, {})
        value.update(saved)
        # Раньше у айсберга было два поля — «Минимум исполнений» (min_hits) и «Множитель»:
        # это одно и то же, остался один «multiplier». Старое значение переносим.
        if "multiplier" in default and "min_hits" in saved and "multiplier" not in saved:
            value["multiplier"] = saved["min_hits"]
        return value

    def add_instrument(self):
        if not self.host._active_assets:
            QtWidgets.QMessageBox.information(self, "Каталог не загружен", "Дождитесь загрузки каталога брокера.")
            return
        dlg = self.instrument_picker_cls(self.host._active_assets, self.mic_labels, self.type_labels, self.host.settings, self)
        if dlg.exec() != QtWidgets.QDialog.Accepted:
            return
        symbol = dlg.chosen_symbol()
        if not symbol or symbol in self.symbols:
            return
        self.symbols.append(symbol)
        self._save_state()
        self._rebuild_table()
        self._resort()                        # новый инструмент — на своё место в текущем ранжировании
        self._start_streams()

    def remove_selected(self):
        row = self.table.currentRow()
        if row < 0:
            return
        item = self.table.item(row, 0)
        symbol = item.data(QtCore.Qt.ItemDataRole.UserRole) if item else None
        if symbol not in self.symbols:
            return
        # Сначала убираем из списка: отложенные старты и автоперезапуски потоков
        # этого инструмента после этого уже ничего не поднимут.
        self.symbols.remove(symbol)
        self._stop_trade_stream(symbol)
        self._stop_book_stream(symbol)
        self.rows.pop(symbol, None)
        self.orderbook_state.pop(symbol, None)
        for key in [k for k in self._retries if k[1] == symbol]:
            self._retries.pop(key, None)
        for key in [k for k in self._link if k[1] == symbol]:
            self._link.pop(key, None)
        self._flash.pop(symbol, None)
        self._mm.pop(symbol, None)
        mm_marks.board().clear(symbol)            # отметки ММ / «Наращивания» в стаканах этого инструмента
        self._save_state()
        self._rebuild_table()
        self._start_quote_stream()

    def _rebuild_table(self):
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        for symbol in self.symbols:
            self._ensure_row(symbol)
            self._render_row(symbol)   # состояние (цена, оборот…) не должно теряться при перестройке
        self.table.setVerticalHeaderLabels(["⋮"] * len(self.symbols))
        self.table.setUpdatesEnabled(True)
        self._update_unread()

    @staticmethod
    def _new_row_state() -> dict:
        return {"price": None, "open": None, "turnover": 0.0, "realization": 0.0, "robot": None, "robot_last": None, "robot_chains": [], "robot_announced": {}, "iceberg": {}, "last_price_alert": None}

    def _ensure_row(self, symbol):
        """Состояние инструмента + строка таблицы (создаётся, только если её ещё нет)."""
        if symbol not in self.rows:
            self.rows[symbol] = self._new_row_state()
        if self._row_for(symbol) >= 0:
            return
        row = self.table.rowCount()
        self.table.insertRow(row)
        item = QtWidgets.QTableWidgetItem(self._instrument_name(symbol))
        item.setData(QtCore.Qt.ItemDataRole.UserRole, symbol)
        item.setIcon(_status_icon("wait"))
        item.setToolTip(f"{symbol}\nПодключение…")
        self.table.setItem(row, self.COL_NAME, item)
        right = QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter
        for col in range(1, self.COL_TOOLS):
            cell = QtWidgets.QTableWidgetItem("—")
            if col <= self.COL_REAL:
                cell.setTextAlignment(right)
            self.table.setItem(row, col, cell)
        self.table.item(row, self.COL_ROBOT).setToolTip("Робот — щелчок открывает его настройки")
        self.table.item(row, self.COL_ICEBERG).setToolTip("Айсберг — щелчок открывает его настройки")

        tools = QtWidgets.QWidget()
        lay = QtWidgets.QHBoxLayout(tools)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.setSpacing(2)
        for kind, tip, callback in (
            ("book", "Стакан Level 2", lambda s=symbol: self._open_level2(s)),
            ("chart", "График", lambda s=symbol: self._open_chart(s)),
            ("settings", "Настройки алгоритмов: робот, айсберг, уведомления", lambda s=symbol: self._open_settings(s)),
        ):
            btn = QtWidgets.QToolButton()
            btn.setObjectName("rowTool")
            btn.setAutoRaise(True)
            btn.setIcon(_row_icon(kind))
            btn.setIconSize(QtCore.QSize(16, 16))
            btn.setToolTip(tip)
            btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, cb=callback: cb())
            lay.addWidget(btn)
        lay.addStretch(1)
        self.table.setCellWidget(row, self.COL_TOOLS, tools)

    def _render_row(self, symbol):
        """Выводит сохранённое состояние инструмента в ячейки его строки."""
        row = self._row_for(symbol)
        state = self.rows.get(symbol)
        if row < 0 or state is None:
            return
        price, open_price = state.get("price"), state.get("open")
        self.table.item(row, self.COL_PRICE).setText(f"{price:.8g}" if price else "—")
        change = self.table.item(row, self.COL_CHANGE)
        if price and open_price:
            pct = (price - open_price) / open_price * 100
            change.setText(f"{pct:+.2f}%")
            change.setForeground(QtGui.QBrush(QtGui.QColor(BULL_COLOR if pct >= 0 else BEAR_COLOR)))
        else:
            change.setText("—")
            change.setForeground(QtGui.QBrush())
        turnover = state.get("turnover")
        self.table.item(row, self.COL_TURNOVER).setText(_quotes_money(turnover) if turnover else "—")
        self.table.item(row, self.COL_REAL).setText(f"{state.get('realization', 0):,.0f}".replace(",", " "))
        self._update_robot_cell(symbol)
        self._update_iceberg_cell(symbol)
        self._update_link_cell(symbol)

    # ---------------------------------------------------------------- таблица: события

    def _symbol_at(self, row: int) -> str | None:
        item = self.table.item(row, self.COL_NAME)
        return item.data(QtCore.Qt.ItemDataRole.UserRole) if item is not None else None

    def _on_cell_clicked(self, row: int, col: int) -> None:
        symbol = self._symbol_at(row)
        if symbol is None:
            return
        if col == self.COL_ROBOT:
            self._open_settings(symbol, "robot")
        elif col == self.COL_ICEBERG:
            self._open_settings(symbol, "iceberg")

    def _on_cell_double_clicked(self, row: int, col: int) -> None:
        symbol = self._symbol_at(row)
        if symbol is not None and col not in (self.COL_ROBOT, self.COL_ICEBERG, self.COL_TOOLS):
            self._open_chart(symbol)

    def _sort_key(self, col: int, symbol: str):
        """Ключ сортировки строки по колонке. Инструменты без данных (нет цены открытия, роботов)
        при сортировке по убыванию оказываются внизу."""
        state = self.rows.get(symbol) or {}
        price, open_price = state.get("price"), state.get("open")
        if col == self.COL_NAME:
            return self._instrument_name(symbol).lower()
        if col == self.COL_PRICE:
            return price or 0.0
        if col == self.COL_CHANGE:
            return (price - open_price) / open_price if price and open_price else -1e9
        if col == self.COL_TURNOVER:
            return state.get("turnover") or 0.0
        if col == self.COL_REAL:
            return state.get("realization") or 0.0
        if col == self.COL_ROBOT:
            # Сначала инструменты, где робот работает СЕЙЧАС (серийный или спредовый, _robot_rank —
            # их оборот), крупнейший сверху; дальше — остальные по обороту инструмента.
            if symbol in self._robot_rank:
                return (1, self._robot_rank[symbol])
            return (0, state.get("turnover") or 0.0)
        if col == self.COL_ICEBERG:
            ice = state.get("iceberg") or {}
            try:
                return pd.Timestamp(ice.get("time")).timestamp() if ice.get("time") is not None else 0.0
            except Exception:
                return 0.0
        return 0.0

    def _sort_mode_info(self, mode: str):
        for item in self.SORT_MODES:
            if item[0] == mode:
                return item
        return self.SORT_MODES[0]

    def _on_sort_combo(self, index: int) -> None:
        mode = self.sort_combo.itemData(index)
        if mode and mode != self._sort_mode:
            self._apply_sort_mode(mode, self._sort_mode_info(mode)[3])

    def _apply_sort_mode(self, mode: str, desc: bool, save: bool = True) -> None:
        """Включить режим ранжирования: список «Сортировка», значок в заголовке, автопересортировка."""
        _m, _title, col, _default = self._sort_mode_info(mode)
        self._sort_mode, self._sort_desc = mode, desc
        index = self.sort_combo.findData(mode)
        if index >= 0 and index != self.sort_combo.currentIndex():
            self.sort_combo.blockSignals(True)
            self.sort_combo.setCurrentIndex(index)
            self.sort_combo.blockSignals(False)
        header = self.table.horizontalHeader()
        if col is None:
            self._sort_timer.stop()
            header.setSortIndicatorShown(False)
        else:
            header.setSortIndicatorShown(True)
            header.setSortIndicator(col, QtCore.Qt.SortOrder.DescendingOrder if desc else QtCore.Qt.SortOrder.AscendingOrder)
            self._resort()
            if mode == "name":
                self._sort_timer.stop()       # названия не меняются — пересортировка только при добавлении
            else:
                self._sort_timer.start()
        if save:
            self._save_state()

    def _resort(self) -> None:
        """Пересортировать строки по текущему режиму. Таблица перестраивается, только если порядок
        действительно изменился; выделенная строка и прокрутка сохраняются."""
        col = self._sort_mode_info(self._sort_mode)[2]
        if col is None or not self.symbols:
            return
        if col == self.COL_ROBOT:
            rank: dict[str, float] = {}
            try:
                for robot in self.active_robots():
                    sym = robot.get("symbol")
                    rank[sym] = rank.get(sym, 0.0) + float(robot.get("turnover") or 0.0)
                for robot in self.active_spreads():      # у спредового — объём заявки в лотах, в деньги
                    sym = robot.get("symbol")
                    money = (float(robot.get("size") or 0) * float(robot.get("price") or 0)
                             * _quotes_lot_size(sym))
                    rank[sym] = rank.get(sym, 0.0) + money
            except Exception as exc:
                print(f"[Алгоритмы] сортировка по роботам: {type(exc).__name__}: {exc}", file=sys.stderr)
            self._robot_rank = rank
        order = sorted(self.symbols, key=lambda s, c=col: self._sort_key(c, s), reverse=self._sort_desc)
        if order == self.symbols:
            return
        selected = self._symbol_at(self.table.currentRow()) if self.table.currentRow() >= 0 else None
        scroll = self.table.verticalScrollBar().value()
        self.symbols = order
        self._rebuild_table()
        if selected:
            row = self._row_for(selected)
            if row >= 0:
                self.table.setCurrentCell(row, self.COL_NAME)
        self.table.verticalScrollBar().setValue(scroll)

    def _on_header_clicked(self, col: int) -> None:
        """Щелчок по заголовку. Название / Изменение / Оборот / Робот — включают соответствующий
        режим ранжирования (повторный щелчок — в обратную сторону). Остальные колонки (цена,
        реализация, айсберг) — разовая сортировка: порядок сохраняется, режим — «Свой порядок»."""
        if col == self.COL_TOOLS or not self.symbols:
            return
        for mode, _title, mode_col, default_desc in self.SORT_MODES:
            if mode_col == col:
                desc = (not self._sort_desc) if mode == self._sort_mode else default_desc
                self._apply_sort_mode(mode, desc)
                return
        self._apply_sort_mode("manual", False, save=False)
        self.symbols.sort(key=lambda s, c=col: self._sort_key(c, s), reverse=True)   # числа — по убыванию
        self._save_state()
        self._rebuild_table()
        header = self.table.horizontalHeader()
        header.setSortIndicatorShown(True)
        header.setSortIndicator(col, QtCore.Qt.SortOrder.DescendingOrder)

    def _on_row_moved(self, _logical: int, _old_visual: int, _new_visual: int) -> None:
        """Строку перетащили за ⋮ — запоминаем новый порядок, режим — «Свой порядок»
        (иначе автосортировка тут же вернула бы строку на место)."""
        vheader = self.table.verticalHeader()
        order = []
        for visual in range(self.table.rowCount()):
            symbol = self._symbol_at(vheader.logicalIndex(visual))
            if symbol:
                order.append(symbol)
        if sorted(order) != sorted(self.symbols):
            return
        self.symbols = order
        self._apply_sort_mode("manual", False, save=False)
        self._save_state()
        QtCore.QTimer.singleShot(0, self._rebuild_table)    # не перестраиваем внутри сигнала заголовка

    def _fade_flashes(self) -> None:
        now = time.monotonic()
        for symbol, until in list(self._flash.items()):
            if now < until:
                continue
            self._flash.pop(symbol, None)
            row = self._row_for(symbol)
            item = self.table.item(row, self.COL_PRICE) if row >= 0 else None
            if item is not None:
                item.setBackground(QtGui.QBrush())
        if not self._flash:
            self._flash_timer.stop()

    def _flash_price(self, symbol: str, up: bool) -> None:
        """Короткая подсветка ячейки цены: зелёная — рост, красная — падение."""
        row = self._row_for(symbol)
        item = self.table.item(row, self.COL_PRICE) if row >= 0 else None
        if item is None:
            return
        color = QtGui.QColor(BULL_COLOR if up else BEAR_COLOR)
        color.setAlpha(70)
        item.setBackground(QtGui.QBrush(color))
        self._flash[symbol] = time.monotonic() + 0.45
        if not self._flash_timer.isActive():
            self._flash_timer.start()

    def _instrument_name(self, symbol: str) -> str:
        """Название инструмента из каталога; symbol остаётся внутренним идентификатором."""
        if _CR_SYMBOL_RE.match(str(symbol)):
            return _friendly_symbol(symbol)   # в каталоге он «CR-12.26», а должен быть «CNY-12.26»
        for asset in getattr(self.host, "_active_assets", []) or []:
            if str(asset.get("symbol", "")).strip() != symbol:
                continue
            for key in ("name", "short_name", "shortName", "description", "title"):
                value = asset.get(key)
                if value:
                    return _strip_venue_text(str(value))
        return _friendly_symbol(symbol)

    def _open_chart(self, symbol: str) -> None:
        """Кнопка 📈: отдельное окно графика с инструментом этой строки."""
        import sys
        import traceback

        print(f"[Алгоритмы] 📈 нажата для {symbol}", file=sys.stderr, flush=True)
        opener = getattr(self.host, "open_quote_chart_window", None)
        if opener is None:
            msg = "в главном окне нет метода open_quote_chart_window (старая версия gui_app.py?)"
            print(f"[Алгоритмы] {msg}", file=sys.stderr, flush=True)
            QtWidgets.QMessageBox.warning(self, "График", f"Не удалось открыть график {symbol}:\n{msg}")
            return
        try:
            opener(symbol)
        except Exception as exc:
            # Раньше здесь печаталось только сообщение и без трейсбека — кнопка «молчала».
            traceback.print_exc()
            QtWidgets.QMessageBox.warning(
                self, "График", f"Не удалось открыть график {symbol}:\n{exc}\n\nПодробности — в консоли."
            )

    def _set_button(self, row, col, text, callback):
        btn = QtWidgets.QPushButton(text)
        # clicked(bool) передаёт «checked» (=False) первым аргументом и затирал
        # symbol в callback'ах вида lambda s=symbol: ... — отсюда «нажата для False».
        # Поэтому вызываем callback без аргументов: symbol уже зашит в его default.
        btn.clicked.connect(lambda _checked=False, cb=callback: cb())
        self.table.setCellWidget(row, col, btn)

    def _row_for(self, symbol):
        """Строка инструмента. Запомненная строка проверяется одним обращением к ячейке (после сортировки,
        добавления или удаления она не та — тогда перебор и новая карта). Раньше — перебор всех строк на каждый
        вызов, а на одну котировку их было четыре (_render_row и ячейки робота, айсберга, связи)."""
        cache = self.__dict__.setdefault("_row_cache", {})
        role = QtCore.Qt.ItemDataRole.UserRole
        r = cache.get(symbol)
        if r is not None and r < self.table.rowCount():
            item = self.table.item(r, 0)
            if item is not None and item.data(role) == symbol:
                return r
        cache.clear()
        found = -1
        for r in range(self.table.rowCount()):
            item = self.table.item(r, 0)
            if item is None:
                continue
            sym = item.data(role)
            cache[sym] = r
            if sym == symbol:
                found = r
        return found

    def _open_level2(self, symbol):
        for dlg in self._level2_dialogs:
            if dlg.symbol == symbol:
                dlg.show(); dlg.raise_(); dlg.activateWindow()
                return
        dlg = Level2Dialog(self, symbol)
        dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()
        self._level2_dialogs.append(dlg)
        dlg.destroyed.connect(lambda *_: self._level2_dialogs.remove(dlg) if dlg in self._level2_dialogs else None)

    def _l2_attach(self, symbol: str) -> None:
        """Окно Level 2 открыто — держим поток стакана инструмента, даже если айсберги выключены."""
        self._l2_watch[symbol] = self._l2_watch.get(symbol, 0) + 1
        self._sync_book_stream(symbol)

    def _l2_detach(self, symbol: str) -> None:
        count = self._l2_watch.get(symbol, 0) - 1
        if count > 0:
            self._l2_watch[symbol] = count
        else:
            self._l2_watch.pop(symbol, None)
        self._sync_book_stream(symbol)

    def _book_needed(self, symbol: str) -> bool:
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        spread = self._settings_for(self.spread_settings, symbol, self.DEFAULT_SPREAD)
        return (bool(cfg.get("enabled", False)) or bool(spread.get("enabled", False))
                or self._l2_watch.get(symbol, 0) > 0
                or (MM_DETECTOR_ENABLED and self._mm_streams_ready and self._mm_on(symbol)))

    def _sync_book_stream(self, symbol: str) -> None:
        """Поток стакана — только там, где он нужен (айсберги, спредовый робот или детектор ММ включены, открыт Level 2)."""
        if symbol not in self.symbols:
            return
        if self._book_needed(symbol):
            if symbol not in self.book_threads and self._md_hub() is not None:
                self._enqueue_start("book", symbol)
        elif symbol in self.book_threads:
            self._stop_book_stream(symbol)
            self.orderbook_state.pop(symbol, None)
            self._link.pop(("book", symbol), None)
            self._update_link_cell(symbol)

    def _open_settings(self, symbol, page: str = "robot"):
        dlg = InstrumentSettingsDialog(self, symbol, page)
        if dlg.exec() != QtWidgets.QDialog.Accepted:
            return
        old_robot = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        self.robot_settings[symbol] = dlg.robot.value()
        self._esc_settings_changed(symbol, old_robot)
        self.iceberg_settings[symbol] = dlg.iceberg.value()
        self.notify_settings[symbol] = dlg.notify.value()
        self.spread_settings[symbol] = dlg.spread.value()
        old_mm = self._mm_cfg(symbol)
        self.mm_settings[symbol] = dlg.mm.value()
        self._mm_settings_changed(symbol, old_mm)
        self._save_state()
        self._sync_book_stream(symbol)
        self._refresh_robot(symbol)
        self._render_row(symbol)

    def _robot_dialog(self, symbol):
        self._open_settings(symbol, "robot")

    def _iceberg_dialog(self, symbol):
        self._open_settings(symbol, "iceberg")

    def _notify_dialog(self, symbol):
        self._open_settings(symbol, "notify")

    def _start_streams(self):
        """Котировки, затем сделки и стаканы — подписки в хабе по очереди, а не все сразу."""
        if not self.symbols or self._md_hub() is None:
            return
        self._enqueue_start("quote", "")
        for symbol in self.symbols:
            if symbol not in self.trade_threads:
                self._enqueue_start("trade", symbol)
        for symbol in self.symbols:
            if symbol not in self.book_threads and self._book_needed(symbol):
                self._enqueue_start("book", symbol)
        if MM_DETECTOR_ENABLED and not self._mm_start_scheduled:
            self._mm_start_scheduled = True
            QtCore.QTimer.singleShot(MM_START_DELAY_MS, self._start_mm_streams)

    def _start_mm_streams(self) -> None:
        """Детектору маркет-мейкера нужен стакан по всем инструментам: открываем недостающие по одному,
        раз в MM_STREAM_GAP_MS (не залпом — см. MM_START_DELAY_MS)."""
        self._mm_streams_ready = True
        missing = [s for s in self.symbols if s not in self.book_threads]
        for i, symbol in enumerate(missing):
            QtCore.QTimer.singleShot(i * MM_STREAM_GAP_MS, lambda s=symbol: self._sync_book_stream(s))
        if missing:
            print(f"[мм] детектор: открываю стакан по {len(missing)} инструментам, по одному раз в "
                  f"{MM_STREAM_GAP_MS // 1000} с")

    def _enqueue_start(self, kind: str, symbol: str) -> None:
        key = (kind, symbol)
        if key not in self._start_queue:
            self._start_queue.append(key)
            self._set_link(kind, symbol, "wait", "подключение…")
        if not self._queue_timer.isActive():
            self._queue_timer.start(50 if len(self._start_queue) == 1 else STREAM_STAGGER_MS)

    def _drain_start_queue(self) -> None:
        if not self._start_queue:
            return
        kind, symbol = self._start_queue.pop(0)
        try:
            self._restart_stream(kind, symbol)
        except Exception:
            traceback.print_exc()
        if self._start_queue:
            self._queue_timer.start(STREAM_STAGGER_MS)

    # ---- состояние связи (точка у названия) -------------------------------------
    STREAM_LABELS = {"quote": "котировки", "trade": "сделки", "book": "стакан"}

    def _set_link(self, kind: str, symbol: str, state: str, text: str) -> None:
        self._link[(kind, symbol)] = (state, text)
        if kind == "quote":
            for s in self.symbols:
                self._update_link_cell(s)
        else:
            self._update_link_cell(symbol)

    def _update_link_cell(self, symbol: str) -> None:
        row = self._row_for(symbol)
        item = self.table.item(row, self.COL_NAME) if row >= 0 else None
        if item is None:
            return
        parts = [("quote", "")] + [("trade", symbol)] + ([("book", symbol)] if symbol in self.book_threads or ("book", symbol) in self._link else [])
        states, lines = [], [symbol]
        for kind, sym in parts:
            st, text = self._link.get((kind, sym), ("wait", "нет подключения"))
            states.append(st)
            lines.append(f"{self.STREAM_LABELS[kind].capitalize()}: {text}")
        overall = "retry" if "retry" in states else ("wait" if "wait" in states else "ok")
        tip = "\n".join(lines)
        cache = self.__dict__.setdefault("_link_cell_cache", {})
        if cache.get(symbol) == (overall, tip, id(item)):
            return                        # то же состояние — новый QIcon не ставим (каждый — перерисовка строки)
        cache[symbol] = (overall, tip, id(item))
        item.setIcon(_status_icon(overall))
        item.setToolTip(tip)

    # ---- подписки в MarketDataHub ------------------------------------------------------
    # У каждого инструмента свои подписки (котировки, сделки, стакан); у брокера — одна
    # подписка на инструмент на весь терминал, переподключение и отсев повторов делает
    # FinamGateway. trade_threads / book_threads хранят Subscription.

    def _md_hub(self):
        return getattr(self.host, "md_hub", None)


    def _watch_hub_connection(self, hub) -> None:
        if getattr(self, "_conn_hub", None) is not hub:
            self._conn_hub = hub
            hub.on_connection(self._on_hub_connection)

    def _on_hub_connection(self, state) -> None:
        """Связь со шлюзом пропала — точки у названий становятся «нет связи»; вернутся
        к «данные идут» с первыми данными (это делают обработчики котировок, сделок, стакана)."""
        if state.connected or self._conn_hub is not self._md_hub():
            return
        reason = state.reason or "нет связи"
        for (kind, symbol), (st, _text) in list(self._link.items()):
            if st == "ok":
                self._set_link(kind, symbol, "retry", f"нет связи ({reason}), переподключение…")

    def _on_hub_quote(self, symbol: str, quote) -> None:
        """Quote из хаба (поля из прошлых сообщений подставлены) -> прежний разбор _on_quote."""
        data = {"symbol": symbol}
        for name in ("last", "close", "open", "turnover"):
            value = getattr(quote, name)
            if value is not None:
                data[name] = {"value": repr(float(value))}
        self._on_quote(data)

    def _on_hub_trade(self, symbol: str, trade) -> None:
        """Trade из хаба -> прежний разбор _on_trade. Сделки «задним числом» (история, которую
        Finam присылает при подписке и после переподключения) пропускаем: они уже прошли, и
        детекторы роботов / крупных сделок приняли бы их за новые."""
        if trade.is_snapshot:
            return
        if MM_DETECTOR_ENABLED and self._mm_on(symbol):
            side = trade.side.value if trade.side is not None else None
            lag = self._mm_lag(symbol, time.time() - float(trade.ts)) if trade.ts else 0.0
            self._mm_events(symbol, self._mm_for(symbol).on_trade(
                time.monotonic(), float(trade.price), float(trade.volume),
                "B" if side == "buy" else "S" if side == "sell" else None, lag=lag))
        from datetime import datetime, timezone
        self._on_trade(symbol, {
            "trade_id": trade.trade_id,
            "price": {"value": repr(float(trade.price))},
            "size": {"value": repr(float(trade.volume))},
            "side": "SIDE_BUY" if trade.side is not None and trade.side.value == "buy"
                    else "SIDE_SELL" if trade.side is not None else "",
            "timestamp": datetime.fromtimestamp(trade.ts, tz=timezone.utc).isoformat(),
        })

    def _on_hub_book(self, symbol: str, book) -> None:
        """Снимок стакана из хаба (шлюз уже собрал его из изменений) -> состояние и детекторы."""
        if symbol not in self.symbols:
            return
        self._retries.pop(("book", symbol), None)
        state = self.orderbook_state.setdefault(symbol, {"rows": {}, "bids": {}, "asks": {}})
        state["bids"].clear(); state["asks"].clear()
        state["bids"].update(book.bids)          # уровни стакана — пары (цена, объём)
        state["asks"].update(book.asks)
        if MM_DETECTOR_ENABLED and self._mm_on(symbol):
            self._mm_events(symbol, self._mm_for(symbol).on_book(time.monotonic(), state["bids"], state["asks"]))
        self._after_book_update(symbol, state)

    # ---- детектор маркет-мейкера: журнал, график и стакан (mm_marks, 2.1.2) -----------------

    def _mm_lag(self, symbol: str, raw: float) -> float:
        """Опоздание сделки сверх обычного: часы ПК могут расходиться с биржей на секунды, поэтому из
        «сейчас − время биржи» вычитается привычное значение (минимум, медленно подтягивающийся вверх)."""
        bases = self.__dict__.setdefault("_mm_lag_base", {})
        base = bases.get(symbol)
        base = raw if base is None or raw < base else base + (raw - base) * 0.001
        bases[symbol] = base
        return max(0.0, raw - base)

    def _mm_for(self, symbol: str) -> "mm_detector.MMDetector":
        det = self._mm.get(symbol)
        if det is None:
            # с 2.1.38 считает Rust (services/algo_shadow.RustMM); эталон на Python — в проверках
            det = self._mm[symbol] = algo_shadow.mm_detector(symbol, self._mm_cfg(symbol).get("sensitivity", "normal"))
        return det

    def _mm_cfg(self, symbol: str) -> dict:
        """Настройки ММ инструмента (с умолчаниями) — из кэша: их читает каждая сделка и каждый снимок стакана."""
        cfg = self._mm_cfg_cache.get(symbol)
        if cfg is None:
            cfg = self._mm_cfg_cache[symbol] = self._settings_for(self.mm_settings, symbol, self.DEFAULT_MM)
        return cfg

    def _mm_on(self, symbol: str) -> bool:
        return bool(self._mm_cfg(symbol).get("enabled", True))

    def _mm_settings_changed(self, symbol: str, old: dict) -> None:
        """Настройки ММ сохранены: чувствительность — детектору; выключили детектор — забыть его состояние;
        выключили показ (или часть типов) — убрать с графиков и из стакана то, что уже показано."""
        self._mm_cfg_cache.pop(symbol, None)
        new = self._mm_cfg(symbol)
        on = bool(new.get("enabled", True))
        det = self._mm.get(symbol)
        if not on:
            self._mm.pop(symbol, None)
        elif det is not None and new.get("sensitivity") != old.get("sensitivity"):
            det.configure(new.get("sensitivity", "normal"))
        hidden = {g for g in mm_marks.GROUPS if not (on and new.get(g, True))}      # эти группы не показываем

        def kinds(groups):
            return {k for k, g in mm_marks.GROUP_OF.items() if g in groups}

        if not (on and new.get("dom", True)):
            mm_marks.board().clear(symbol, kinds(mm_marks.GROUPS))
        elif hidden:
            mm_marks.board().clear(symbol, kinds(hidden))
        if not (on and new.get("chart", True)):
            self._clear_mm_chart_events(symbol)
        elif hidden:
            self._clear_mm_chart_events(symbol, hidden)

    def _esc_settings_changed(self, symbol: str, old: dict) -> None:
        """«Наращивание» выключили или убрали его показ — значки с графиков и отметки из стакана."""
        new = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        if new.get("esc_enabled", True) and new.get("esc_show", True):
            return
        if old.get("esc_enabled", True) and old.get("esc_show", True):
            mm_marks.board().clear(symbol, {"escalation"})
            self._clear_mm_chart_events(symbol, escalation=True)

    def _clear_mm_chart_events(self, symbol: str, groups: set | None = None,
                               escalation: bool = False) -> None:
        """Убрать события ММ (groups — только этих групп; None — все, кроме «Наращивания»; escalation=True —
        только «Наращивание») из памяти и с открытых графиков инструмента."""
        store = self.mm_chart_events.get(symbol) or {}
        gone = []
        for event_id, event in list(store.items()):
            group = mm_marks.GROUP_OF.get((event.get("details") or {}).get("kind"), "")
            if escalation:
                hit = group == "escalation"
            else:
                hit = group != "escalation" and (groups is None or group in groups)
            if hit:
                store.pop(event_id, None)
                gone.append(event_id)
        if not gone:
            return
        try:
            self.host.add_quote_event_to_chart({"id": "", "type": "mm", "symbol": symbol, "time": None, "price": 0.0,
                                                "details": {"remove": gone}})
        except Exception:
            traceback.print_exc()

    def _mm_show(self, symbol: str, rows: list, tag: str) -> None:
        """Строки журнала ММ / «Наращивания» -> значки на графиках и отметки в стаканах (mm_marks)."""
        if tag == "нр":
            cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
            on = bool(cfg.get("esc_show", True))
            show = {"chart": on, "dom": on, "groups": {"escalation"}}
        else:
            cfg = self._mm_cfg(symbol)
            show = {"chart": bool(cfg.get("chart", True)), "dom": bool(cfg.get("dom", True)),
                    "groups": {g for g in mm_marks.GROUPS if cfg.get(g, True)}}
        try:
            for item in self._mm_shaper.feed(symbol, rows, show):
                self._emit_mm_chart_event(symbol, item)
        except Exception:
            traceback.print_exc()

    def _emit_mm_chart_event(self, symbol: str, item: dict) -> None:
        """Событие ММ / «Наращивания» — в память для новых графиков (своя очередь, MM_CHART_EVENTS_PER_SYMBOL) и
        на открытые графики инструмента. Тот же id — то же событие (эпизод обновился)."""
        event = {"id": item["id"], "type": "mm", "symbol": symbol, "time": item["time"],
                 "price": float(item["price"]), "details": item["details"]}
        store = self.mm_chart_events.setdefault(symbol, OrderedDict())
        store[item["id"]] = event
        store.move_to_end(item["id"])
        while len(store) > MM_CHART_EVENTS_PER_SYMBOL:
            store.popitem(last=False)
        try:
            self.host.add_quote_event_to_chart(event)
        except Exception:
            traceback.print_exc()

    def _mm_events(self, symbol: str, events: list[dict], tag: str = "мм") -> None:
        """События детектора — на графики и в стаканы (_mm_show, по настройкам инструмента), в
        logs/mm_events_ДАТА.csv и в консоль/журнал (не больше MM_PRINT_PER_MIN строк
        в минуту на инструмент, чтобы при неудачных порогах не залить журнал). Снятие крупной заявки и его итог —
        только вместе и только если итог что-то показал (mm_detector.PullJournal): до 2.0.92 ~90 % строк журнала
        были снятиями с итогом «вывода нет». «Снята» пишется со своим временем, поэтому в файле строки снятий
        могут идти не по порядку времени (на PULL_FOLLOW_SEC раньше итога)."""
        if not events:
            return
        journal = self.__dict__.get("_mm_journal")
        if journal is None:
            journal = self.__dict__["_mm_journal"] = mm_detector.PullJournal()
        rows = journal.rows(symbol, events, time.time())
        if not rows:
            return
        self._mm_show(symbol, rows, tag)
        now = datetime.now()
        events = [e for _t, e in rows]
        try:
            MM_LOG_DIR.mkdir(exist_ok=True)
            path = MM_LOG_DIR / f"mm_events_{now:%Y-%m-%d}.csv"
            new = not path.exists()
            wide = new or self._mm_csv_wide(path)
            sens = "" if tag == "нр" else str(self._mm_cfg(symbol).get("sensitivity", "normal"))
            with open(path, "a", encoding="utf-8-sig" if new else "utf-8") as fh:
                if new:
                    fh.write(MM_CSV_HEADER + "\n")
                    self.__dict__.setdefault("_mm_csv_kind", {})[str(path)] = True
                for t, e in rows:
                    when = datetime.fromtimestamp(t)
                    row = [when.strftime("%H:%M:%S.%f")[:-3], symbol, e.get("kind", ""), e.get("stage", ""),
                           e.get("side", ""), e.get("price", ""), e.get("volume", ""), e.get("refills", ""),
                           e.get("executed", ""), f"{e['seconds']:.0f}" if "seconds" in e else "",
                           f"{e['level']:.0f}" if e.get("level") else "", e.get("through", "")]
                    if wide:
                        row += [mm_summary.event_outcome(e), sens if e.get("kind") != "escalation" else ""]
                    row.append(str(e.get("text", "")).replace(";", ","))
                    fh.write(";".join(str(x) for x in row) + "\n")
        except OSError:
            pass
        minute = int(time.time() // 60)
        printed = self._mm_printed.setdefault(symbol, [minute, 0, 0])
        if printed[0] != minute:
            if printed[2]:
                print(f"[мм] {_friendly_symbol(symbol)}: ещё {printed[2]} событий за минуту — в mm_events CSV")
            printed[:] = [minute, 0, 0]
        for e in events:
            if printed[1] < MM_PRINT_PER_MIN:
                printed[1] += 1
                print(f"[{tag}] {_friendly_symbol(symbol)}: {e.get('text', '')}")
            else:
                printed[2] += 1

    def _mm_csv_wide(self, path) -> bool:
        """Журнал дня уже с колонками outcome / sens (2.1.12)? Файл, начатый прежней версией, — нет: его
        дописываем прежними колонками, чтобы строки не съехали. Ответ запоминается на путь."""
        known = self.__dict__.setdefault("_mm_csv_kind", {})
        key = str(path)
        if key not in known:
            try:
                with open(path, encoding="utf-8-sig") as fh:
                    known[key] = "outcome" in fh.readline().split(";")
            except OSError:
                known[key] = False
        return known[key]

    def _sync_hub_quotes(self, hub) -> None:
        """Котировки: подписаться на новые инструменты, отписаться от удалённых (без пересоздания
        остальных подписок — иначе у брокера рвались бы и общие с другими окнами потоки)."""
        from core.models import InstrumentId
        subs = self.__dict__.setdefault("_quote_subs", {})
        for symbol in [s for s in subs if s not in self.symbols]:
            subs.pop(symbol).close()
        for symbol in self.symbols:
            if symbol not in subs:
                subs[symbol] = hub.subscribe_quotes(InstrumentId.parse(symbol),
                                                    lambda q, s=symbol: self._on_hub_quote(s, q))

    def _start_quote_stream(self):
        hub = self._md_hub()
        if hub is None:
            return
        self._watch_hub_connection(hub)
        self._sync_hub_quotes(hub)

    def _stop_quote_stream(self):
        for sub in self.__dict__.get("_quote_subs", {}).values():
            sub.close()
        self.__dict__["_quote_subs"] = {}

    def _start_trade_stream(self, symbol):
        # symbol может уже не быть в списке: отложенный старт после «Удалить»
        hub = self._md_hub()
        if symbol not in self.symbols or symbol in self.trade_threads or hub is None:
            return
        from core.models import InstrumentId
        self._watch_hub_connection(hub)
        self.trade_threads[symbol] = hub.subscribe_trades(
            InstrumentId.parse(symbol), lambda t, s=symbol: self._on_hub_trade(s, t))

    def _start_book_stream(self, symbol):
        hub = self._md_hub()
        if symbol not in self.symbols or symbol in self.book_threads or hub is None:
            return
        from core.models import InstrumentId
        self._watch_hub_connection(hub)
        # lossless: детекторы видят каждое изменение стакана, а не только последний снимок,
        # который успел забрать GUI.
        self.book_threads[symbol] = hub.subscribe_orderbook(
            InstrumentId.parse(symbol), lambda b, s=symbol: self._on_hub_book(s, b), lossless=True)

    def _stop_book_stream(self, symbol):
        sub = self.book_threads.pop(symbol, None)
        if sub is not None:
            sub.close()

    def _restart_stream(self, kind: str, symbol: str) -> None:
        if self._md_hub() is None:
            return
        if kind == "quote":
            if self.symbols:
                self._start_quote_stream()      # пересоздаётся со всем текущим списком инструментов
        elif symbol in self.symbols:
            if kind == "trade":
                self._start_trade_stream(symbol)
            elif kind == "book" and self._book_needed(symbol):
                self._start_book_stream(symbol)

    def _after_book_update(self, symbol, state):
        """Стакан обновился (state["bids"] / state["asks"]: цена -> объём): окна Level 2,
        спредовый робот, айсберги. Снимок стакана приходит из хаба (_on_hub_book)."""
        if self._link.get(("book", symbol), ("",))[0] != "ok":
            self._set_link("book", symbol, "ok", "данные идут")
        self.book_updated.emit(symbol)
        now = pd.Timestamp.now(tz="UTC")
        self._detect_spread(symbol, state, now)
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg.get("enabled", False):
            ice = state.get("ice")
            if ice is not None:
                ice.clear_pending()
            return
        # Расчёт — Rust (iceberg_rust.IcebergTracker; эталон и описание — iceberg_core.py): после сделки ждём
        # восстановления видимого объёма на той же цене; айсберг — «стена»: объём раз за разом восстанавливается,
        # исполнено уже больше, чем когда-либо было видно в стакане, уровень держится не меньше hold_sec, и цена
        # не прошла сквозь него. Здесь — что делать с подтверждённым айсбергом: ячейка таблицы, отметка в стаканах,
        # линия на графике, уведомление.
        multiplier, visible_lots, hold_sec = iceberg_core.settings(cfg)   # множитель по умолчанию 5 (с 2.0.51, было 3)
        announced = state.setdefault("iceberg_announced", {})  # (сторона, цена) -> monotonic последнего уведомления
        mono = time.monotonic()
        for hit in self._ice_for(symbol, state).book(mono, state["bids"], state["asks"], multiplier, visible_lots,
                                                     hold_sec):
            key = (hit["side"], hit["price"])
            hits, visible, executed, held = hit["hits"], hit["visible"], hit["executed"], hit["held"]
            side_name = "BUY" if hit["side"] == "B" else "SELL"
            details = {"price": hit["price"], "hits": hits, "visible": visible, "executed": executed, "time": now}
            self.rows.setdefault(symbol, {})["iceberg"] = details
            self._update_iceberg_cell(symbol)
            # Подтверждённый айсберг — в стаканы этого инструмента (голубая полоса; у стакана должно быть
            # включено «Определять айсберг-заявки»). От настроек «на графике» / «в историю» не зависит.
            mm_marks.board().set(symbol, mm_marks.iceberg_key(side_name, hit["price"]),
                                 mm_marks.iceberg_mark(side_name, hit["price"], hit["max_visible"],
                                                       executed, hits, time.time()))
            if cfg.get("chart") or cfg.get("history"):      # линия нужна и графику, и истории
                # first / last — биржевое время сделок (по нему линия встаёт на свечу; при отставании ленты часы
                # терминала сдвигали её вправо); удержание held — по часам терминала
                self._emit_iceberg_line(symbol, side_name, hit["price"], hit["last"] or now,
                                        hits=hits, visible=visible,
                                        executed=executed, source="стакан", first=hit["first"], held=held)
            # «Крупный айсберг, исполнено от»: мелкий — только линия на графике, без уведомления (и в историю не идёт).
            # Проверяется на каждом восстановлении: исполненное доросло до порога — уведомление придёт тогда.
            turnover = float(executed) * float(hit["price"]) * _quotes_lot_size(symbol)
            if float(executed) < float(cfg.get("min_lots", 0) or 0):
                continue
            # Пока айсберг на этой цене держится — уведомление одно; новое — только если он минуту молчал.
            previous = announced.get(key)
            announced[key] = mono
            if previous is not None and mono - previous < ICEBERG_REANNOUNCE_SEC:
                continue
            def lots(value):
                return f"{value:,.0f}".replace(",", " ")
            text = (f"Цена {hit['price']:.8g}, держится {held:.0f} с, восстановлений: {hits}, "
                    f"видимый объём: {lots(visible)} лотов, исполнено: {lots(executed)} лотов")
            # Биржевой айсберг или робот-доливщик: у айсберга Мосбиржи видимая часть не меньше биржевого
            # минимума (Si — 500 контрактов…), а детектор часто ловит доливки по 10–50 лотов (iceberg_kind)
            ice_name, ice_note = iceberg_kind.classify(symbol, hit["max_visible"])
            if ice_note:
                text += f"; {ice_note}"
            self._notify(symbol, "🧊 Iceberg", text, notify=True,
                         title=f"{ice_name}: {'продажа (ask)' if hit['side'] == 'S' else 'покупка (bid)'}",
                         extra={"price": float(hit["price"]), "executed": float(executed), "hold": float(held),
                                "turnover": turnover})
        if len(announced) > 300:
            for old in sorted(announced, key=announced.get)[:150]:
                announced.pop(old, None)

    def _ice_for(self, symbol, state) -> "iceberg_rust.IcebergTracker":
        """Расчёт айсбергов инструмента по стакану (Rust; модуля нет — выключен, айсбергов нет). Живёт вместе
        с состоянием стакана: поток стакана остановили — счёт исполненного и кандидаты забыты, как и раньше."""
        ice = state.get("ice")
        if ice is None:
            ice = state["ice"] = iceberg_rust.tracker(symbol)
        return ice

    def _stop_trade_stream(self, symbol):
        sub = self.trade_threads.pop(symbol, None)
        if sub is not None:
            sub.close()

    def start(self):
        self._retries.clear()   # новое подключение — счётчики автоперезапуска с нуля
        self._robot_timer.start()
        self._start_streams()

    def stop(self):
        """Остановить всё: закрыть подписки в хабе (ждать нечего — потоки держит шлюз); дописать журнал."""
        self._save_events(now=True)
        try:
            self._flush_iceberg_history()
        except Exception:
            traceback.print_exc()
        self._robot_timer.stop()
        self._queue_timer.stop()
        self._start_queue.clear()
        for threads in (self.trade_threads, self.book_threads):
            for sub in threads.values():
                sub.close()
            threads.clear()
        self._stop_quote_stream()
        self._link.clear()
        for symbol in self.symbols:
            self._update_link_cell(symbol)

    def _on_quote(self, quote):
        symbol = str(quote.get("symbol", ""))
        if not symbol or symbol not in self.symbols:
            return
        self._retries.pop(("quote", ""), None)
        if self._link.get(("quote", ""), ("",))[0] != "ok":
            self._set_link("quote", "", "ok", "данные идут")
        self._ensure_row(symbol)
        state = self.rows[symbol]
        previous = state.get("price")

        # Апдейт может прийти без last (или с last=0, пока нет сделок): тогда остаёмся на
        # прежней цене, затем берём close. Раньше подставлялся 0 -> «цена 0, −100 %».
        price = _positive_decimal(quote.get("last"))
        if price is None:
            price = state.get("price")
        if price is None:
            price = _positive_decimal(quote.get("close"))
        open_price = _positive_decimal(quote.get("open")) or state.get("open") or price
        turnover = _quotes_decimal(quote.get("turnover"), state.get("turnover", 0))
        unchanged = (previous, state.get("open"), state.get("turnover")) == (price, open_price, turnover)
        state.update({"price": price, "open": open_price, "turnover": turnover})

        if not unchanged:                 # котировка без изменений цены / оборота (bid, ask) — строку не трогаем
            self._render_row(symbol)
        if previous and price and price != previous:
            self._flash_price(symbol, price > previous)
        self._check_price_notification(symbol, price)

    def _on_trade(self, symbol, trade):
        if symbol not in self.symbols:
            return
        self._retries.pop(("trade", symbol), None)
        if self._link.get(("trade", symbol), ("",))[0] != "ok":
            self._set_link("trade", symbol, "ok", "данные идут")
        price = _quotes_decimal(trade.get("price"))
        size = _quotes_decimal(trade.get("size"))
        if price <= 0 or size <= 0:
            return
        ts_text = str(trade.get("timestamp", ""))
        try:
            ts = pd.Timestamp(ts_text)
            if ts.tzinfo is None:
                ts = ts.tz_localize("UTC")
            ts = ts.tz_convert("UTC")
        except Exception:
            ts = pd.Timestamp.now(tz="UTC")
        side = str(trade.get("side", ""))
        turnover = price * size * _quotes_lot_size(symbol)
        state = self.rows.get(symbol)
        if state is None:
            state = self.rows[symbol] = self._new_row_state()
        # Хвост сделок инструмента — для запасного поиска айсберга «по сделкам» (пока стакана нет): последние
        # iceberg_core.TRADES_MAX сделок не старше TRADES_SEC; ведёт Rust (iceberg_rust.TradeTail).
        tail = state.get("ice_trades")
        if tail is None:
            tail = state["ice_trades"] = iceberg_rust.trade_tail(symbol)
        tail.add(ts, price, size, turnover)
        # Айсберги — по отдельным сделкам (важна каждая цена), роботы и крупные сделки — по заявкам.
        self._check_turnover_notification(symbol, state, ts, size, side, turnover)
        self._register_iceberg_trade(symbol, ts, price, side, size)
        self._detect_iceberg(symbol, ts)
        self._add_to_order(symbol, ts, price, size, side, turnover)

    # ---- сделки -> агрессивные заявки (Rust: robot_rust.OrderAssembler; эталон — robot_core) ----
    def _orders_of(self, symbol) -> "robot_rust.OrderAssembler":
        """Сборка заявок инструмента. С 2.1.52 считает Rust (robot_rust.order_assembler; модуля нет — эталон на
        Python). pending_orders в состоянии инструмента — какие заявки сейчас собираются (по сторонам)."""
        state = self.rows[symbol]
        asm = state.get("order_assembler")
        if asm is None:
            asm = state["order_assembler"] = robot_rust.order_assembler(state.setdefault("pending_orders", {}), symbol)
        return asm

    def _add_to_order(self, symbol, ts, price, size, side, turnover):
        asm = self._orders_of(symbol)
        for order in asm.add(ts, price, size, side, turnover, time.monotonic()):   # закончились этой сделкой
            self._finish_order(symbol, order)
        if asm.pending and not self._order_timer.isActive():
            self._order_timer.start()

    def _finish_order(self, symbol, order):
        price = robot_core.order_price(order)               # средняя цена заявки (VWAP её кусков)
        size = order["size"]
        self._detect_robot(symbol, order["ts"], price, size, order["side"], order["turnover"])
        self._detect_escalation(symbol, order["ts"], price, size, order["side"])
        self._check_trade_notification(symbol, order["turnover"], order["ts"], price, size, order["side"])

    def _detect_escalation(self, symbol, ts, price, size, side) -> None:
        """«Наращивание» (escalation_detector.py) по склеенным рыночным заявкам: журнал, график и стакан (_mm_events)."""
        cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        if not cfg.get("esc_enabled", True):
            return
        dets = self.__dict__.setdefault("_esc", {})
        det = dets.get(symbol)
        if det is None:
            det = dets[symbol] = algo_shadow.escalation_detector(symbol)   # считает Rust (2.1.23, services/algo_shadow)
        det.configure(cfg.get("esc_min_links", 4), cfg.get("esc_growth", 1.3),
                      float(cfg.get("esc_tolerance", 30.0) or 30.0) / 100.0,
                      cfg.get("esc_min_first", 10), cfg.get("esc_min_total", 0))
        try:
            seconds = pd.Timestamp(ts).timestamp()
        except Exception:
            seconds = time.time()
        events = det.on_order(seconds, "B" if str(side).upper().endswith("BUY") else "S", float(size), float(price))
        self._mm_events(symbol, events, tag="нр")

    def _flush_orders(self) -> None:
        """Раз в 0,2 с: заявки, к которым давно не приходили куски, — закончены (последняя заявка перед паузой)."""
        now = time.monotonic()
        busy = False
        for symbol in list(self.symbols):
            state = self.rows.get(symbol)
            if not state or not state.get("pending_orders"):
                continue
            asm = self._orders_of(symbol)
            for order in asm.flush(now, ORDER_FLUSH_SEC):
                self._finish_order(symbol, order)
            busy = busy or bool(asm.pending)
        if not busy:
            self._order_timer.stop()

    # Пороги робота — в robot_core (там же — что они значат); здесь — те же имена для вкладки и проверок.
    ROBOT_MIN_GAP_SEC = robot_core.ROBOT_MIN_GAP_SEC
    ROBOT_FORGET_SEC = robot_core.ROBOT_FORGET_SEC
    ROBOT_PAUSE_SEC = robot_core.ROBOT_PAUSE_SEC
    ROBOT_REANNOUNCE_SEC = robot_core.ROBOT_REANNOUNCE_SEC

    def _robot_pause_sec(self, cfg: dict | None) -> float:
        return robot_core.pause_sec(cfg)

    def _robot_alive_sec(self, chain: dict, max_gap: float, cfg: dict | None = None) -> float:
        """Сколько молчания серия ещё «работает» (robot_core.alive_sec)."""
        return robot_core.alive_sec(chain, max_gap, cfg)

    def _robot_tracker(self, symbol) -> "robot_rust.RobotTracker":
        """Серии роботов инструмента. С 2.1.52 считает Rust (robot_rust.robot_tracker; модуля нет — эталон
        robot_core.RobotTracker); серии — словари того же вида в состоянии инструмента, как и раньше."""
        state = self.rows[symbol]
        tracker = state.get("robot_tracker")
        if tracker is None:
            tracker = state["robot_tracker"] = robot_rust.robot_tracker(
                self._robot_uids, state.setdefault("robot_chains", []), state.setdefault("robot_announced", {}),
                symbol)
        return tracker

    def _detect_robot(self, symbol, ts, price, size, side, turnover):
        """Заявка -> серии роботов (расчёт — Rust, robot_rust.RobotTracker.on_order; что считается роботом —
        описано у эталона robot_core.RobotTracker.on_order);
        здесь — что из этого следует: график, заметки, уведомление, действующий робот в таблице."""
        state = self.rows[symbol]
        cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        if not cfg.get("enabled", False):
            for chain in self._robot_tracker(symbol).clear():       # ждущие заметки — с тем, что успели собрать
                self._finish_robot_note(symbol, chain, robot_notes.REASON_DISABLED)
                self._log_robot_series(symbol, chain)
            state["robot"] = None
            self._update_robot_cell(symbol)
            return
        events, counted = self._robot_tracker(symbol).on_order(ts, price, size, side, turnover, time.monotonic(), cfg)
        for event in events:
            kind, chain = event[0], event[1]
            if kind == "gone":
                self._close_robot_track(symbol, chain)
                self._report_robot_stop(symbol, chain)        # если таймер остановку ещё не заметил
                self._finish_robot_note(symbol, chain)
                self._log_robot_series(symbol, chain)
            elif kind == "grew":
                self._emit_robot_track(symbol, chain)     # робот на графике растёт вместе с серией
            elif kind == "announce":
                notify = event[2]
                # Заметка о таком роботе — один раз на серию: в уведомление и в закреплённую строку (note_hint);
                # счётчик встреч у заметки растёт, только когда робот объявлен уведомлением
                # объём — этой заявки (при «Допуске по объёму» он может отличаться от первого объёма серии)
                chain["note_hint"] = self._robot_note_reminder(symbol, "BUY" if chain["is_buy"] else "SELL",
                                                               float(size),
                                                               self._robot_info(chain).get("interval"), mark=notify)
                if notify:
                    chain["notified"] = True                    # остановку этой серии — со звуком (2.1.77)
                    self._check_robot_notification(symbol, self._robot_info(chain))
                if cfg.get("chart"):
                    # На графике — каждый робот, набравший порог (уведомление — не чаще раза в 5 минут
                    # на тот же объём, а прямоугольник серии рисуется всегда).
                    chain["on_chart"] = True
                    self._emit_robot_track(symbol, chain)
        if counted:
            self._refresh_robot(symbol)

    _robot_info = staticmethod(robot_core.robot_info)   # сводка серии (robot_core.robot_info)

    def _log_robot_series(self, symbol: str, chain: dict) -> None:
        """Закончившийся робот — в logs/robots_ДАТА.csv (регулярность при объявлении и итоговая, 2.1.40).
        Журнал нужен для подбора порогов, поэтому пишется только при запуске со всеми журналами (с 2.1.65:
        FX_LOGS=1 или --logs, services/log_mode.py); в обычном, тихом, режиме — нет."""
        if log_mode.full():
            robot_core.append_series(MM_LOG_DIR, symbol, chain, f"{datetime.now():%Y-%m-%d}")

    def _refresh_robot(self, symbol):
        """Выбирает действующего робота (самый крупный по обороту) и обновляет кнопку и «Реализацию»."""
        state = self.rows.get(symbol)
        if state is None:
            return
        cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        if not cfg.get("enabled", False):
            return
        best = self._robot_tracker(symbol).best(time.monotonic(), cfg)
        if best is not None:
            info = self._robot_info(best)
            state["robot"], state["robot_last"] = info, info
            state["realization"] = info["volume"]
        else:
            state["robot"] = None
        self._update_robot_cell(symbol)
        self._update_realization_cell(symbol)

    def active_robots(self) -> list[dict]:
        """Все работающие сейчас роботы по всем инструментам (для закреплённого блока в окне
        уведомлений): серия набрала «Минимум сделок» и оборот, и пауза ещё не превысила допустимую.
        Самые крупные по обороту — сверху."""
        result = []
        now = time.monotonic()
        for symbol in self.symbols:
            state = self.rows.get(symbol) or {}
            cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
            if not cfg.get("enabled", False) or not state:
                continue
            max_gap = robot_core.max_gap_of(cfg)
            for chain in self._robot_tracker(symbol).working(now, cfg, check_interval=False):
                info = self._robot_info(chain)
                info["symbol"] = symbol
                silent = now - chain["seen"]
                info["paused_sec"] = silent if silent > max_gap + 1.0 else 0.0   # на паузе — строка остаётся
                result.append(info)
        result.sort(key=lambda r: r.get("turnover", 0), reverse=True)
        return result

    def _update_feed_lag(self) -> None:
        """Раз в секунду: инструменты, у которых последняя живая сделка пришла позже биржи на FEED_LAG_WARN_SEC+."""
        hub = getattr(self.host, "md_hub", None)
        if hub is None or not hasattr(hub, "trade_feed_lag"):
            return
        from core.models import InstrumentId
        now = float(self._now_utc().timestamp())
        late = []
        for symbol in self.trade_threads:
            try:
                lag = hub.trade_feed_lag(InstrumentId.parse(symbol), now)
            except Exception:
                continue
            if lag is not None and lag >= FEED_LAG_WARN_SEC:
                late.append((lag, symbol))
        if not late:
            if self.lag_label.isVisible():
                self.lag_label.hide()
            return
        late.sort(reverse=True)
        parts = [f"{to_friendly_symbol(sym)} {lag:.0f} с" for lag, sym in late[:3]]
        more = f" и ещё {len(late) - 3}" if len(late) > 3 else ""
        text = "⚠ Лента сделок Finam отстаёт: " + ", ".join(parts) + more
        if self.lag_label.text() != text:
            self.lag_label.setText(text)
        if not self.lag_label.isVisible():
            self.lag_label.show()

    def _tick_robots(self):
        self._update_feed_lag()
        now = time.monotonic()
        for symbol in list(self.symbols):
            self._close_iceberg_lines(symbol)
            self._expire_spreads(symbol)
            state = self.rows.get(symbol)
            if state and (state.get("robot") or state.get("robot_chains")):
                self._refresh_robot(symbol)
                cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
                for chain in self._robot_tracker(symbol).stopped(now, cfg):   # замолчали дольше допустимого
                    if chain.get("on_chart") and not chain.get("chart_closed"):
                        self._close_robot_track(symbol, chain)      # серия кончилась — на графике «остановился»
                    self._report_robot_stop(symbol, chain)          # звук и «· остановился» в уведомлениях
                    self._finish_robot_note(symbol, chain)          # и заметка, ждавшая остановки, — в «Заметки»

    def _report_robot_stop(self, symbol: str, chain: dict) -> None:
        """Робот, о котором было уведомление (chain["notified"]), остановился: молчит дольше «Пауза робота, не
        дольше». Один раз на серию: строка робота в «Уведомлениях» получает «· остановился» и поднимается наверх
        (как при склейке), сигнал robot_stopped — звук FX Robot End. Серии, о которых уведомления не было
        (не набрали порог или повтор того же робота в течение 5 минут), — молча."""
        if not chain.get("notified") or chain.get("stop_reported"):
            return
        chain["stop_reported"] = True
        info = self._robot_info(chain)
        try:
            worked = (pd.Timestamp(info["last"]) - pd.Timestamp(info["started"])).total_seconds()
        except Exception:
            worked = None
        try:
            self._mark_robot_row_stopped(symbol, "BUY" if chain.get("is_buy") else "SELL", worked)
        except Exception:
            traceback.print_exc()
        print(f"[Алгоритмы] {_friendly_symbol(symbol)}: робот остановился "
              f"({'покупка' if chain.get('is_buy') else 'продажа'}, {info.get('count')} × {info.get('size', 0):g})",
              file=sys.stderr)
        self.robot_stopped.emit(symbol, info)

    def _mark_robot_row_stopped(self, symbol: str, side: str, worked: float | None) -> None:
        """Строка робота (инструмент, сторона) в ленте уведомлений — «· остановился», время — сейчас. Новая
        серия того же робота (notify_merge.merge_robot) заголовок пересобирает — пометка уходит сама."""
        groups = self.__dict__.get("_event_groups") or {}
        held = groups.get(("robot", symbol, side))
        if held is None or not any(e is held[0] for e in self.events[-200:]):
            return
        event = held[0]
        if STOPPED_MARK not in str(event.get("title", "")):
            event["title"] = f"{event.get('title', '')}{STOPPED_MARK}"
            if worked is not None:
                event["details"] = f"{event.get('details', '')}; работал {notify_merge.fmt_span(worked)}"
        stamp = self._now_utc()
        event["ts"], event["time"] = stamp.isoformat(), stamp.strftime("%H:%M:%S")
        self.events.remove(event)                 # как склеенная строка — наверх ленты
        self.events.append(event)
        self._events_unsaved.append(dict(event))  # в журнал — новая версия с тем же id
        dialog = self._live_notifications()
        if dialog is not None:
            dialog.upsert_event(event)
        self._save_events()

    # ---- роботы на графике -----------------------------------------------------------
    def _emit_robot_track(self, symbol: str, chain: dict, active: bool = True) -> None:
        if "chart_id" not in chain:
            chain["chart_id"] = f"robot-{next(self._chart_ids)}"
        info = self._robot_info(chain)
        info.update(id=chain["chart_id"], pmin=chain["pmin"], pmax=chain["pmax"], active=active)
        self._emit_chart_event(symbol, "robot", chain["started"], chain["price"], info, event_id=chain["chart_id"])

    def _close_robot_track(self, symbol: str, chain: dict) -> None:
        if chain.get("on_chart") and not chain.get("chart_closed"):
            chain["chart_closed"] = True
            self._emit_robot_track(symbol, chain, active=False)

    # ---- заметка о роботе после его остановки (окно уведомлений → «В заметки») ----------------
    def robot_uids(self, symbol: str, side: str | None = None) -> list[int]:
        """Серии роботов инструмента (и стороны BUY / SELL), которые работают сейчас (см. active_robots)."""
        return [r["uid"] for r in self.active_robots()
                if r.get("symbol") == symbol and r.get("uid") is not None and (side is None or r.get("side") == side)]

    def wait_robot_note(self, symbol: str, uid) -> bool:
        """Заметку о работающем роботе записать, когда он остановится. False — такой серии уже нет."""
        if uid is None or uid not in self.robot_uids(symbol):
            return False
        self._robot_note_wait[uid] = symbol
        return True

    def robot_note_waiting(self, uid) -> bool:
        return uid is not None and uid in self._robot_note_wait

    def _finish_robot_note(self, symbol: str, chain: dict, reason: str = robot_notes.REASON_STOPPED) -> None:
        """Серия кончилась (или терминал закрывают): ждавшая её заметка уходит в «Заметки» со всей серией."""
        uid = chain.get("uid")
        if uid is None or self._robot_note_wait.pop(uid, None) is None:
            return
        store = getattr(self.host, "notes_store", None)
        if store is None:
            return
        tz_name = getattr(self.host, "display_tz", "Europe/Moscow")

        def fmt(ts):
            try:
                stamp = pd.Timestamp(ts)
                stamp = stamp.tz_localize("UTC") if stamp.tzinfo is None else stamp
                return stamp.tz_convert(tz_name).strftime("%d.%m %H:%M:%S")
            except Exception:
                return str(ts)

        try:
            note = robot_notes.compose(self._robot_info(chain), _friendly_symbol(symbol), fmt, reason)
            # reveal=False: заметка приходит сама, когда робот остановился, — окно «Заметки» к ней не
            # перематывается (в нём в это время могут листать список или писать комментарий к другой заметке)
            store.add(symbol=_friendly_symbol(symbol), kind=note["kind"], title=note["title"],
                      details=note["details"], event_time=note["event_time"], comment=note["comment"],
                      fields={"chart_symbol": symbol}, reveal=False)
            print(f"[Алгоритмы] {_friendly_symbol(symbol)}: заметка о роботе ({note['title']}) — {reason}",
                  file=sys.stderr)
        except Exception:
            traceback.print_exc()

    # ---- айсберги на графике: линия уровня, пока айсберг работает ----------------------------
    ICEBERG_LINE_TTL_SEC = 60.0      # айсберг молчит столько — линия «закрывается» (становится бледной)

    def _emit_iceberg_line(self, symbol: str, side: str, price: float, ts, hits: int = 0,
                           visible: float = 0.0, executed: float = 0.0, source: str = "",
                           first=None, held: float = 0.0) -> None:
        lines = self.rows.setdefault(symbol, {}).setdefault("iceberg_lines", {})
        key = (side, round(float(price), 8))
        line = lines.get(key)
        if line is None:
            line = lines[key] = {"id": f"ice-{next(self._chart_ids)}", "side": side, "price": float(price),
                                 "first": first if first is not None else ts, "max_hits": 0}
        line.update(last=ts, hits=hits, visible=visible, executed=executed, source=source, held=held,
                    mono=time.monotonic(), max_hits=max(line.get("max_hits", 0), hits))
        self._send_iceberg_line(symbol, line, active=True)

    def _send_iceberg_line(self, symbol: str, line: dict, active: bool) -> None:
        """Состояние линии — графику (если «Показывать айсберги на графике»). keep в подробностях — айсберг
        крупный (исполнено не меньше «Крупный айсберг, исполнено от»): закончившись, он остаётся на графике бледным
        (и попадает в историю); мелкий виден, только пока держится, — закончился, и линия убирается (с 2.0.83;
        раньше при включённой истории оставались все — 03.11 график CNYRUB_TOM пестрел айсбергами по 2–3 тыс.
        лотов при пороге 100 тыс.)."""
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg.get("chart"):
            return
        details = {k: line.get(k) for k in ("id", "side", "price", "first", "last", "hits", "max_hits",
                                            "visible", "executed", "source", "held", "broken")}
        details["active"] = active
        details["history"] = bool(cfg.get("history"))
        details["keep"] = float(line.get("executed") or 0) >= float(cfg.get("min_lots", 0) or 0)
        if not active:
            details["session"] = self._ice_session
        self._emit_chart_event(symbol, "iceberg", line["first"], line["price"], details, event_id=line["id"])

    def _break_iceberg_line(self, symbol: str, side: str, price: float, ts) -> None:
        mm_marks.board().drop(symbol, mm_marks.iceberg_key(side, price))      # и из стаканов
        lines = (self.rows.get(symbol) or {}).get("iceberg_lines") or {}
        line = lines.pop((side, round(float(price), 8)), None)
        if line is not None:
            line.update(broken=True, last=ts)
            self._send_iceberg_line(symbol, line, active=False)
            self._save_iceberg_history(symbol, [line])

    def _close_iceberg_lines(self, symbol: str) -> None:
        lines = (self.rows.get(symbol) or {}).get("iceberg_lines")
        if not lines:
            return
        now = time.monotonic()
        closed = []
        for key, line in list(lines.items()):
            if now - line.get("mono", now) > self.ICEBERG_LINE_TTL_SEC:
                lines.pop(key, None)
                self._send_iceberg_line(symbol, line, active=False)
                closed.append(line)
        if closed:
            self._save_iceberg_history(symbol, closed)

    # ---- история айсбергов для графика (iceberg_kind.history_*) -------------------------------
    def _iceberg_history(self) -> list[dict]:
        """Все записи истории (файл читается один раз, при первой надобности)."""
        if self._ice_history is None:
            try:
                self._ice_history = self._ice_journal.load() or []
            except Exception:
                traceback.print_exc()
                self._ice_history = []
        return self._ice_history

    def _save_iceberg_history(self, symbol: str, lines: list[dict]) -> None:
        """Закончившиеся линии, где исполнено не меньше «Крупный айсберг, исполнено от» (лоты), — дозаписью в файл."""
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg.get("history"):
            return
        min_lots = float(cfg.get("min_lots", 0) or 0)
        lot = _quotes_lot_size(symbol)
        records = [r for r in (iceberg_kind.history_record(symbol, line, lot, min_lots, self._ice_session)
                               for line in lines) if r is not None]
        if not records:
            return
        history = self._iceberg_history()
        history.extend(records)
        try:
            self._ice_journal.append(records, current=history)
            if len(history) > iceberg_kind.HISTORY_MAX * 1.5:
                self._ice_history = trim_events(history, iceberg_kind.HISTORY_KEEP_DAYS, iceberg_kind.HISTORY_MAX)
        except Exception:
            traceback.print_exc()

    def iceberg_history_count(self, symbol: str) -> int:
        return sum(1 for r in self._iceberg_history() if r.get("symbol") == symbol)

    def clear_iceberg_history(self, symbol: str) -> int:
        """Очистить историю айсбергов инструмента: записи из файла (переписывается без них), закончившиеся линии —
        из памяти и с открытых графиков (идущие остаются). Возвращает, сколько записей удалено."""
        history = self._iceberg_history()
        removed = [r for r in history if r.get("symbol") == symbol]
        kept = [r for r in history if r.get("symbol") != symbol]
        self._ice_history = kept
        try:
            self._ice_journal.rewrite(kept)
        except Exception:
            traceback.print_exc()
        gone = [iceberg_kind.history_event(r)["id"] for r in removed]
        store = self.chart_events.get(symbol) or {}
        for event_id, event in list(store.items()):
            d = event.get("details") or {}
            if event.get("type") == "iceberg" and not d.get("active", True):
                store.pop(event_id, None)
                gone.append(str(d.get("id") or event_id))
        for line_id in gone:                      # график убирает закончившуюся линию без keep / saved
            try:
                self.host.add_quote_event_to_chart({"id": line_id, "type": "iceberg", "symbol": symbol,
                                                    "time": None, "price": 0.0,
                                                    "details": {"id": line_id, "active": False, "keep": False}})
            except Exception:
                traceback.print_exc()
        print(f"[Алгоритмы] {_friendly_symbol(symbol)}: история айсбергов очищена — {len(removed)} записей",
              file=sys.stderr)
        return len(removed)

    def _flush_iceberg_history(self) -> None:
        """Терминал закрывается: ещё держащиеся айсберги — тоже в историю (с их последним временем)."""
        for symbol in list(self.rows):
            lines = (self.rows.get(symbol) or {}).get("iceberg_lines")
            if lines:
                self._save_iceberg_history(symbol, list(lines.values()))
                lines.clear()

    # ---- спредовый робот ---------------------------------------------------------------------
    def _detect_spread(self, symbol: str, state: dict, now) -> None:
        cfg = self._settings_for(self.spread_settings, symbol, self.DEFAULT_SPREAD)
        if not cfg.get("enabled", False):
            return
        tracker = state.get("spread_tracker")
        if tracker is None:                    # считает Rust (spread_rust.tracker); эталон — spread_core
            tracker = state["spread_tracker"] = spread_rust.tracker(symbol)
        for robot, new in tracker.update(state["bids"], state["asks"], time.monotonic(), now, cfg):
            robot.setdefault("id", f"spread-{next(self._chart_ids)}")
            if new:
                side = "покупка (bid)" if robot["side"] == "BUY" else "продажа (ask)"
                self._notify(symbol, "Спред",
                             f"~{robot['size']:,.0f} лотов, цена {robot['price']:.8g}, "
                             f"перестановок {len(robot['events'])} за минуту".replace(",", " "),
                             notify=True, title=f"Спредовый робот: {side}",
                             extra={"size": float(robot["size"]), "price": float(robot["price"]),
                                    "per_minute": len(robot["events"])})
            if cfg.get("chart", False):
                self._send_spread(symbol, robot)

    def _send_spread(self, symbol: str, robot: dict) -> None:
        details = {k: robot.get(k) for k in ("id", "side", "size", "price", "from_price", "requotes", "started", "last")}
        details["per_minute"] = len(robot.get("events", []))
        details["active"] = bool(robot.get("active", True))
        self._emit_chart_event(symbol, "spread", robot.get("last"), robot.get("price") or 0.0, details,
                               event_id=robot["id"])

    def _expire_spreads(self, symbol: str) -> None:
        state = self.orderbook_state.get(symbol) or {}
        tracker = state.get("spread_tracker")
        if tracker is None:
            return
        cfg = self._settings_for(self.spread_settings, symbol, self.DEFAULT_SPREAD)
        for robot in tracker.expire(time.monotonic()):
            if cfg.get("chart", False) and robot.get("id"):
                self._send_spread(symbol, robot)

    def active_spreads(self) -> list[dict]:
        result = []
        for symbol in self.symbols:
            tracker = (self.orderbook_state.get(symbol) or {}).get("spread_tracker")
            if tracker is None:
                continue
            for robot in tracker.active():
                info = dict(robot)
                info["symbol"] = symbol
                info["kind"] = "spread"
                info["per_minute"] = len(robot.get("events", []))
                result.append(info)
        # На инструмент и сторону — один, самый активный (по числу перестановок за минуту, затем по объёму).
        best: dict[tuple[str, str], dict] = {}
        for info in result:
            key = (info["symbol"], info.get("side"))
            rank = (info["per_minute"], float(info.get("size", 0) or 0))
            if key not in best or rank > (best[key]["per_minute"], float(best[key].get("size", 0) or 0)):
                best[key] = info
        result = sorted(best.values(), key=lambda r: -float(r.get("size", 0) or 0))
        return result

    def chart_events_for(self, symbol: str, saved: bool = True) -> list[dict]:
        """События для графика инструмента (последнее состояние каждого) — история для только что открытого графика.
        «Показывать айсберги на графике» — впереди сохранённые айсберги прошлых сеансов (и этого, если живое
        событие уже вытеснено из памяти). Показ и сохранение — разные галочки: история копится и без показа,
        а выключенный показ не рисует ни живых, ни сохранённых.
        saved=False — только события этого сеанса: так спрашивает стакан для своих значков (раз в секунду на
        каждое окно; сохранённые айсберги в столбик значков не попадают, а отбор их из истории — лишняя работа)."""
        live = list((self.chart_events.get(symbol) or {}).values())
        live += list((self.mm_chart_events.get(symbol) or {}).values())      # ММ и «Наращивание» (2.1.2)
        if not saved:
            return live
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg.get("chart"):
            return live
        skip = [(self._ice_session, e.get("id")) for e in live if e.get("type") == "iceberg"]
        try:
            saved = iceberg_kind.history_for_chart(self._iceberg_history(), symbol, skip)
        except Exception:
            traceback.print_exc()
            saved = []
        return saved + live

    def _update_realization_cell(self, symbol):
        row = self._row_for(symbol)
        item = self.table.item(row, 4) if row >= 0 else None
        if item is not None:
            item.setText(f"{self.rows[symbol].get('realization', 0):,.0f}".replace(",", " "))

    def _register_iceberg_trade(self, symbol, ts, price, side, size=0.0):
        """Сделка — в расчёт айсбергов по стакану (iceberg_rust.IcebergTracker.trade): он стирает кандидатов, сквозь
        которых прошла цена, копит исполненное на цене и ставит ожидание восстановления объёма. Линии айсбергов
        на графике, пробитые этой сделкой, закрывает вкладка (_check_iceberg_breaks) — до расчёта: итог линии
        берётся из счёта исполненного, каким он был перед сделкой."""
        state = self.orderbook_state.get(symbol)
        if not state:
            return
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg.get("enabled", False):
            return
        consumed_side = iceberg_core.consumed_side(side)
        ice = self._ice_for(symbol, state)
        self._check_iceberg_breaks(symbol, ice, ts, price)
        visible = (state["asks"] if consumed_side == "S" else state["bids"]).get(price, 0.0)
        # срок ожидания восстановления — от прихода сделки в терминал (iceberg_core.RESTORE_SEC по time.monotonic)
        ice.trade(ts, time.monotonic(), price, consumed_side, size, visible, float(cfg.get("visible_lots", 0) or 0))

    def _check_iceberg_breaks(self, symbol, ice, ts, price) -> None:
        """Цена прошла по ту сторону уровня — айсберга там больше нет: на продажу (ask) — сделка выше
        его цены, на покупку (bid) — ниже. Его скрытый объём выбрали (или заявку сняли) — айсберг
        закончился. Неподтверждённого кандидата молча стирает сам расчёт (ice — iceberg_rust.IcebergTracker, при
        следующем вызове trade); здесь — подтверждённый, с линией на графике: «закончился» с итогом: сколько
        исполнено на цене (это и есть размер съеденной скрытой заявки), оборот, восстановлений. Уведомление —
        если исполнено не меньше «Крупный айсберг, исполнено от» (как и у объявления айсберга).
        Удержание — по часам терминала (time.monotonic: удержание на последнем подтверждении + сколько прошло
        с него), а конец линии — биржевое время пробившей сделки, как и начало (линия встаёт на свои свечи)."""
        mono_now = time.monotonic()
        cfg = None
        # 1. Линии на графике — проверяем по их собственной цене. Уровень-кандидат мог уже смениться
        #    (айсберг молчал дольше iceberg_core.LEVEL_TTL_SEC и счёт начался заново), а линия ещё «держится» —
        #    раньше такая линия оставалась на графике, хотя цена ушла за уровень.
        lines = (self.rows.get(symbol) or {}).get("iceberg_lines") or {}
        for (side_name, level_price), line in list(lines.items()):
            passed = price > level_price if side_name == "SELL" else price < level_price
            if not passed:
                continue
            consumed = "B" if side_name == "BUY" else "S"
            # Итог: исполнено на цене — последнее подтверждённое или накопленное с тех пор, что больше.
            executed = max(float(line.get("executed") or 0), ice.executed(consumed, level_price))
            line["executed"] = executed
            held = float(line.get("held") or 0) + max(0.0, mono_now - float(line.get("mono") or mono_now))
            line["held"] = held
            self._break_iceberg_line(symbol, side_name, level_price, ts)
            turnover = executed * float(level_price) * _quotes_lot_size(symbol)
            if cfg is None:
                cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
            if executed >= float(cfg.get("min_lots", 0) or 0):
                lots = f"{executed:,.0f}".replace(",", " ")
                hits = int(line.get("max_hits") or line.get("hits") or 0)
                self._notify(symbol, "🧊 Iceberg",
                             f"Цена {level_price:.8g}: прошла сделка по {price:.8g}, айсберг держался {held:.0f} с; "
                             f"итог: исполнено {lots} лотов ({_quotes_money(turnover)}), восстановлений {hits}",
                             notify=True,
                             title=f"Айсберг закончился: {'покупка (bid)' if side_name == 'BUY' else 'продажа (ask)'}",
                             extra={"price": float(level_price), "hold": float(held), "executed": executed,
                                    "turnover": turnover})
            ice.drop_level(consumed, level_price)

    def _detect_iceberg(self, symbol, ts):
        """Запасной поиск «по сделкам», пока стакана инструмента нет: последние сделки (числом «Множитель») прошли
        на одной цене. ts — биржевое время последней сделки. Считает Rust (iceberg_rust.TradeTail.candidate)."""
        if symbol in self.orderbook_state:
            return
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        if not cfg["enabled"]:
            return
        tail = self.rows[symbol].get("ice_trades")
        if tail is None:
            return
        # Стакана нет, видимую часть не знаем — «Видимый объём» проверяется по исполненному; порог «Крупный
        # айсберг, исполнено от» без стакана — порог самого поиска (лоты пачки сделок на цене).
        found = tail.candidate(iceberg_core.settings(cfg)[0], float(cfg.get("visible_lots", 0) or 0),
                               float(cfg.get("min_lots", 0) or 0))
        if found is None:
            return
        price, hits, turnover = found["price"], found["hits"], found["turnover"]
        self.rows[symbol]["iceberg"] = {"hits": hits, "turnover": turnover, "price": price, "time": ts}
        self._update_iceberg_cell(symbol)
        # Линию на графике по одним сделкам не рисуем: без стакана не проверить, что это «стена».
        # Это именно эвристический кандидат: без полного Level-2 потока
        # нельзя доказать скрытый остаток заявки. Одна цена — одно уведомление в минуту
        # (раньше флаги были перепутаны: уведомление шло только при «на графике», а маркер — всегда).
        announced = self.rows[symbol].setdefault("iceberg_announced", {})
        now = time.monotonic()
        if now - announced.get(round(price, 8), -1e9) >= ICEBERG_REANNOUNCE_SEC:
            announced[round(price, 8)] = now
            self._notify(symbol, "🧊 Iceberg",
                         f"{hits} {_plural(hits, 'исполнение', 'исполнения', 'исполнений')} на цене {price:.8g}, "
                         f"оборот {_quotes_money(turnover)}",
                         notify=True, title="Айсберг: кандидат (по сделкам)")

    def _emit_chart_event(self, symbol, event_type, ts, price, details, event_id: str | None = None):
        event_id = event_id or f"{event_type}-{next(self._chart_ids)}"
        event = {"id": event_id, "type": event_type, "symbol": symbol, "time": ts, "price": float(price), "details": details}
        store = self.chart_events.setdefault(symbol, OrderedDict())
        store[event_id] = event
        store.move_to_end(event_id)
        while len(store) > CHART_EVENTS_PER_SYMBOL:
            store.popitem(last=False)
        try:
            self.host.add_quote_event_to_chart(event)
        except Exception:
            traceback.print_exc()

    def _update_robot_cell(self, symbol):
        row = self._row_for(symbol)
        item = self.table.item(row, self.COL_ROBOT) if row >= 0 else None
        state = self.rows.get(symbol)
        if item is None or state is None:
            return
        robot = state.get("robot")

        def hms(seconds):
            h, rem = divmod(max(0, int(seconds)), 3600)
            m, sec = divmod(rem, 60)
            return f"{h:02d}:{m:02d}:{sec:02d}"

        if robot:
            started = robot.get("started")
            elapsed = (pd.Timestamp.now(tz="UTC") - started).total_seconds() if started is not None else 0
            is_buy = robot.get("side") == "BUY"
            item.setText(f"🤖 {hms(elapsed)} · {'покупка' if is_buy else 'продажа'}")
            item.setForeground(QtGui.QBrush(QtGui.QColor(BULL_COLOR if is_buy else BEAR_COLOR)))
            item.setToolTip((
                f"Робот ({'покупка' if is_buy else 'продажа'})\nОбъём: {robot['volume']:,.0f} лотов "
                f"({robot['count']} × {robot.get('size', 0):g})\n"
                f"Оборот: {_quotes_money(robot['turnover'])}\n"
                f"Интервал: {robot['interval']:.1f} сек\nРабота: {hms(elapsed)}\n\nЩелчок — настройки робота"
            ).replace(",", " "))
            return
        item.setForeground(QtGui.QBrush())
        last = state.get("robot_last")
        if last:
            side = "покупка" if last.get("side") == "BUY" else "продажа"
            worked = (last["last"] - last["started"]).total_seconds()
            item.setText(f"🤖 остановился · {self._local_time(last.get('last'))}")
            item.setToolTip((
                f"Робот остановился\nПоследний ({side}): {last['count']} × {last.get('size', 0):g} лотов, "
                f"всего {last['volume']:,.0f} лотов\nОборот: {_quotes_money(last['turnover'])}\n"
                f"Работал {hms(worked)}\n\nЩелчок — настройки робота"
            ).replace(",", " "))
        else:
            cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
            item.setText("—" if cfg.get("enabled", False) else "выключен")
            item.setToolTip("Робот — щелчок открывает его настройки")

    def _local_time(self, ts) -> str:
        """Время в часовом поясе терминала, ЧЧ:ММ:СС."""
        if ts is None:
            return ""
        try:
            stamp = pd.Timestamp(ts)
            stamp = stamp.tz_localize("UTC") if stamp.tzinfo is None else stamp
            return stamp.tz_convert(getattr(self.host, "display_tz", "Europe/Moscow")).strftime("%H:%M:%S")
        except Exception:
            return ""

    def _update_iceberg_cell(self, symbol):
        row = self._row_for(symbol)
        item = self.table.item(row, self.COL_ICEBERG) if row >= 0 else None
        state = self.rows.get(symbol)
        if item is None or state is None:
            return
        cfg = self._settings_for(self.iceberg_settings, symbol, self.DEFAULT_ICEBERG)
        ice = state.get("iceberg") or {}
        if not cfg.get("enabled", False):
            item.setText("выключен")
            item.setToolTip("Поиск айсбергов выключен — щелчок открывает настройки")
        elif ice.get("price"):
            item.setText(f"🧊 {float(ice['price']):.8g} · {self._local_time(ice.get('time'))}")
            source = "по стакану" if symbol in self.orderbook_state else "по сделкам (кандидат)"
            item.setToolTip(
                f"Последний айсберг {source}\nЦена: {float(ice['price']):.8g}\n"
                f"Исполнений / восстановлений: {ice.get('hits', 0)}\n\nЩелчок — настройки айсберга"
            )
        else:
            item.setText("—")
            item.setToolTip("Айсберг — щелчок открывает его настройки")

    def _check_price_notification(self, symbol, price):
        """
        «Цена»: резкое движение — изменение не меньше price_pct % за price_window секунд
        (по умолчанию 1 % за 15 с). Считается от минимума (рост) или максимума (падение)
        цены внутри скользящего окна до текущей цены. После срабатывания окно
        начинается заново, поэтому одно движение даёт одно уведомление, а не по
        уведомлению на каждый тик (раньше сравнивали с ценой открытия — и при
        старте сыпались десятки одинаковых событий).
        """
        state = self.rows.get(symbol)
        if state is None or not price:
            return
        cfg = self._settings_for(self.notify_settings, symbol, self.DEFAULT_NOTIFY)
        if not cfg.get("price_enabled", False):
            state.pop("price_move", None)
            return
        window = max(1.0, float(cfg.get("price_window", 15)))
        # Окно и решение — PriceMoveDetector: с 2.1.23 считает Rust (services/algo_shadow; эталон — algo_core); здесь — текст.
        moves = state.get("price_move")
        if moves is None:
            moves = state["price_move"] = algo_shadow.price_move_detector(symbol)
        now = time.monotonic()
        hit = moves.on_price(now, float(price), window, float(cfg.get("price_pct", 1.0)))
        if hit is None:
            return
        move, ref, ref_time = hit                  # изменение в % со знаком, цена и время отсчёта
        elapsed = max(1, int(round(now - ref_time)))
        self._notify(
            symbol,
            "Цена",
            f"{move:+.2f}% за {elapsed} с ({ref:.8g} → {price:.8g})",
        )
        state["last_price_alert"] = now

    def _check_trade_notification(self, symbol, turnover, ts=None, price=0.0, size=0.0, side=""):
        """«Сделка»: одна исполненная рыночная заявка (склеенные куски) не меньше «Порога сделки» в лотах."""
        cfg = self._settings_for(self.notify_settings, symbol, self.DEFAULT_NOTIFY)
        if cfg["trade_enabled"] and size >= float(cfg.get("trade_lots", 500) or 500):
            is_buy = str(side).upper().endswith("BUY")
            title = "Крупная сделка: покупка" if is_buy else "Крупная сделка: продажа"
            details = (f"{size:g} {_plural(size, 'лот', 'лота', 'лотов') if float(size).is_integer() else 'лота'}"
                       f" × {price:.8g} = {_quotes_money(turnover)}")
            count_before = len(self.events)
            self._notify(symbol, "Сделка", details, title=title, ts=ts, extra={"turnover": float(turnover or 0)})
            if len(self.events) > count_before:          # не дубль — закрепляем на несколько секунд
                self._big_trades.append({"kind": "big", "symbol": symbol, "side": "BUY" if is_buy else "SELL",
                                         "title": title, "details": details, "turnover": turnover,
                                         "time": self.events[-1].get("ts"), "mono": time.monotonic()})
                dialog = self._live_notifications()
                if dialog is not None:
                    dialog.refresh_robots()              # сразу, не дожидаясь секундного обновления

    def active_big_trades(self) -> list[dict]:
        """Крупные сделки последних BIG_TRADE_PIN_SEC секунд — новые первыми."""
        now = time.monotonic()
        self._big_trades = [t for t in self._big_trades if now - t["mono"] <= BIG_TRADE_PIN_SEC]
        return list(reversed(self._big_trades))

    def _notify_settings_for_dialog(self, symbol: str) -> dict:
        """Настройки уведомлений для вкладки: порог «Роста оборота» из настроек до 2.0.72 (₽, turnover_delta) —
        в лоты по последней цене инструмента, чтобы поле показало его, а не умолчание."""
        cfg = self._settings_for(self.notify_settings, symbol, self.DEFAULT_NOTIFY)
        saved = self.notify_settings.get(symbol) or {}
        price = (self.rows.get(symbol) or {}).get("price")
        if "volume_lots" not in saved and float(saved.get("turnover_delta", 0) or 0) > 0 and price:
            cfg["volume_lots"] = int(round(float(saved["turnover_delta"]) / (float(price) * _quotes_lot_size(symbol))))
        return cfg

    def _check_turnover_notification(self, symbol, state, ts, size, side, turnover) -> None:
        """«Рост оборота»: сделка — в VolumeSurge инструмента; всплеск — уведомление «Оборот» с объёмом за период,
        оборотом, перевесом стороны и (если уже есть база) сравнением с обычным объёмом."""
        cfg = self._settings_for(self.notify_settings, symbol, self.DEFAULT_NOTIFY)
        if not cfg.get("turnover_enabled", False):
            state.pop("volume_surge", None)
            return
        period = max(1, int(cfg.get("turnover_period", 60) or 60))
        surge = state.get("volume_surge")
        if surge is None:
            surge = state["volume_surge"] = algo_shadow.volume_surge(symbol)     # считает Rust (эталон — algo_core.VolumeSurge)
        try:
            sec = int(ts.timestamp())
        except Exception:
            sec = int(time.time())
        is_buy = str(side).upper().endswith("BUY")
        surge.add(sec, float(size), is_buy, float(turnover or 0), period)
        min_lots = float(cfg.get("volume_lots", 0) or 0)
        saved = self.notify_settings.get(symbol) or {}
        if "volume_lots" not in saved and float(saved.get("turnover_delta", 0) or 0) > 0 and size > 0:
            # Настройки до 2.0.72: порог в ₽ («Прирост оборота») — в лоты по текущей цене, пока его не зададут
            # в лотах (иначе включённая проверка сработала бы от умолчания DEFAULT_LOTS).
            min_lots = float(saved["turnover_delta"]) / (float(turnover) / float(size))
        hit = surge.check(min_lots, float(cfg.get("volume_ratio", 0) or 0))
        if hit is None:
            return
        share = hit["buy_share"]
        side_text = "покупки" if share >= 0.6 else ("продажи" if share <= 0.4 else "обе стороны")
        lots = f"{hit['lots']:,.0f}".replace(",", " ")
        text = (f"За {period} с: {lots} лотов ({_quotes_money(hit['turnover'])}), "
                f"покупки {share * 100:.0f} % / продажи {(1 - share) * 100:.0f} %")
        if hit.get("usual"):
            usual = f"{hit['usual']:,.0f}".replace(",", " ")
            text += f"; обычно ≈ {usual} лотов за {period} с (×{hit['ratio']:.1f})"
        self._notify(symbol, "Оборот", text, notify=True, title=f"Рост оборота: {side_text}", ts=ts,
                     extra={"turnover": float(hit["turnover"]), "lots": float(hit["lots"])})

    def _check_robot_notification(self, symbol, robot=None):
        """Один раз на серию — когда набралось «Минимум сделок» (раньше слало на каждую сделку)."""
        robot = robot or self.rows[symbol].get("robot")
        if not robot:
            return
        side = "покупка" if robot.get("side") == "BUY" else "продажа"
        count, size = int(robot["count"]), robot.get("size", 0)
        self._notify(
            symbol,
            "Robot",
            f"{count} {_plural(count, 'сделка', 'сделки', 'сделок')} × {size:g} "
            f"{_plural(size, 'лот', 'лота', 'лотов') if float(size).is_integer() else 'лота'}, "
            f"интервал ≈ {robot['interval']:.1f} с, оборот {_quotes_money(robot['turnover'])}"
            + (f", {robot_notes.tempo_text(robot.get('cv'))}" if robot.get("cv") is not None else "")
            + (f", регулярность {robot['regularity'] * 100:.0f} %" if robot.get("regularity") is not None else "")
            + (robot["note_hint"] if robot.get("note_hint") is not None
               else self._robot_note_reminder(symbol, robot.get("side"), float(size), robot.get("interval"))),
            title=f"Робот: {side}",
            ts=robot.get("last"),
            extra={"size": float(size or 0), "interval": float(robot.get("interval") or 0),
                   "turnover": float(robot.get("turnover") or 0), "cv": robot.get("cv")},
        )

    def _robot_note_reminder(self, symbol: str, side, size: float, interval=None, mark: bool = True) -> str:
        """Хвост уведомления о роботе, если о таком роботе (инструмент, сторона, объём ± «Допуск объёма»,
        похожий интервал)
        есть заметка с напоминанием: « · 📝 заметка от 28.10: „комментарий“». У заметок растёт счётчик встреч."""
        store = getattr(self.host, "notes_store", None)
        if store is None or not hasattr(store, "find_robot_notes"):
            return ""
        cfg = self._settings_for(self.robot_settings, symbol, self.DEFAULT_ROBOT)
        tol = max(0.0, float(cfg.get("size_tolerance", 0.0) or 0.0)) / 100.0
        try:
            notes = store.find_robot_notes({symbol, symbol.split("@")[0], _friendly_symbol(symbol)},
                                           "BUY" if side == "BUY" else "SELL", size, tol, interval)
        except Exception:
            return ""
        if not notes:
            return ""
        if mark:
            for note in notes:
                store.mark_seen(note.get("id"))
        note = notes[0]
        when = str(note.get("event_time") or note.get("created") or "")
        try:
            day = datetime.fromisoformat(when.replace("Z", "+00:00")).strftime("%d.%m")
        except ValueError:
            day = when[:5]
        # «Выводы» автора, а не заголовок отчёта (robot_notes.note_summary)
        text = robot_notes.note_summary(note.get("comment") or "") or "без выводов"
        more = f" (и ещё {len(notes) - 1})" if len(notes) > 1 else ""
        return f" · 📝 заметка от {day}: «{text}»{more}"

    def _notify(self, symbol, typ, details, notify=True, title=None, ts=None, extra=None):
        """
        Время события у ВСЕХ уведомлений — момент срабатывания (по часам сервера Finam, если они
        синхронизированы, иначе по часам ПК), поэтому лента идёт строго по порядку. Биржевое время
        самой сделки (ts), если оно есть, сохраняется отдельно — видно в подсказке ячейки «Время».
        Поле time (HH:MM:SS UTC) оставлено для старых записей.
        extra — числа события (у робота size / interval / turnover, у крупной сделки turnover): для склейки
        и фильтра «оборот от» окна уведомлений.

        Склейка (notify_merge.py): серии одного робота (инструмент + сторона) подряд и начало / конец одного
        айсберга — одна строка, обновляется на месте и поднимается наверх; непрочитанным это не считается
        и звук не повторяется. Кандидаты айсбергов «по сделкам» — только в журнал терминала.
        """
        if title == notify_merge.CANDIDATE_TITLE:
            print(f"[Алгоритмы] {_friendly_symbol(symbol)}: {title} — {details}", file=sys.stderr)
            return
        stamp = self._now_utc()
        exchange = None
        if ts is not None:
            try:
                exchange = pd.Timestamp(ts)
                exchange = exchange.tz_localize("UTC") if exchange.tzinfo is None else exchange.tz_convert("UTC")
            except Exception:
                exchange = None
        event = {
            "time": stamp.strftime("%H:%M:%S"),
            "ts": stamp.isoformat(),
            "type": typ,
            "symbol": symbol,
            "title": title or typ,
            "details": details,
        }
        if exchange is not None:
            event["exchange_ts"] = exchange.isoformat()
        event["id"] = notify_merge.new_id()
        for k, v in (extra or {}).items():
            if v is not None:
                event[k] = v
        # Защита от спама: то же событие (инструмент, тип, заголовок, текст) чаще 5 секунд — отбрасываем,
        # даже если между повторами были другие уведомления (раньше сравнивалось только с последним).
        key = (symbol, typ, event["title"], details)
        now = time.monotonic()
        last = self._recent_events.get(key)
        if last is not None and now - last < DUPLICATE_EVENT_SEC:
            return
        self._recent_events[key] = now
        if len(self._recent_events) > 500:
            cutoff = now - DUPLICATE_EVENT_SEC
            self._recent_events = {k: t for k, t in self._recent_events.items() if t >= cutoff}
        group = notify_merge.group_key(event)
        groups = self.__dict__.setdefault("_event_groups", {})     # ключ -> (событие, когда обновлено)
        if group is not None:
            held = groups.get(group)
            if (held is not None and now - held[1] <= notify_merge.merge_window(group)
                    and any(e is held[0] for e in self.events[-200:])):
                old = held[0]
                if group[0] == "robot":
                    notify_merge.merge_robot(old, event, now, _quotes_money)
                elif group[0] == "spread":
                    notify_merge.merge_spread(old, event, now)
                else:
                    notify_merge.merge_iceberg(old, event, _quotes_money)
                old["ts"], old["time"] = event["ts"], event["time"]
                self.events.remove(old)                  # склеенная строка — наверх ленты
                self.events.append(old)
                self._events_unsaved.append(dict(old))   # в журнал — новая версия с тем же id
                groups[group] = (old, now)
                dialog = self._live_notifications()
                if dialog is not None:
                    dialog.upsert_event(old)
                self._save_events()
                return
            if group[0] == "robot":
                notify_merge.start_robot(event, now)
            elif group[0] == "spread":
                notify_merge.start_spread(event, now)
            else:
                notify_merge.start_iceberg(event)
            groups[group] = (event, now)
            if len(groups) > 400:
                for k in sorted(groups, key=lambda k: groups[k][1])[:200]:
                    groups.pop(k, None)
        event["sound"] = event_sound(event)
        self.events.append(event)
        self._events_unsaved.append(event)
        if len(self.events) > MAX_EVENTS + MAX_EVENTS // 5:
            del self.events[:-MAX_EVENTS]
        dialog = self._live_notifications()
        if dialog is not None:
            dialog.add_event(event)        # окно на экране — событие видно сразу, непрочитанным не считаем
        elif notify:
            self.unread += 1
            self.unread_level = max(self.unread_level, notify_badge.level_of(event))
            self._update_unread()
        self._save_events()                    # журнал — в свой файл, раз в несколько секунд
        if notify:
            self.event_added.emit(event)

    def _now_utc(self) -> "pd.Timestamp":
        """Сейчас (UTC): часы сервера Finam терминала, если есть, иначе часы ПК."""
        source = getattr(self.host, "finam_clock_source", None)
        if source is not None:
            try:
                return pd.Timestamp(float(source.now()), unit="s", tz="UTC")
            except Exception:
                pass
        return pd.Timestamp.now(tz="UTC")

    def _update_unread(self):
        """Число непрочитанных показывает значок «Уведомления» в строке меню (читает self.unread и
        self.unread_level раз в секунду, main_window._update_quotes_toolbar)."""
        return

    def mark_notifications_read(self) -> None:
        """Окно «Уведомления» показано — непрочитанных нет."""
        self.unread = 0
        self.unread_level = 0
        self._update_unread()

    def _live_notifications(self) -> "QuotesNotificationsPanel | None":
        """Панель «Уведомления», если она сейчас на экране (событие показывается в ней сразу). Создана, но скрыта
        (вкладка за другой, закрыта крестиком) — помечается устаревшей: при показе перечитает список."""
        panel = self._notifications_dialog
        if panel is None:
            return None
        try:
            if panel.isVisible():
                return panel
            panel.mark_stale()
        except RuntimeError:                       # виджет удалён Qt
            self._notifications_dialog = None
        return None

    def notifications_panel(self) -> "QuotesNotificationsPanel":
        """Окно «Уведомления» — одно на терминал: фабрика панели «notifications» (main_window) и отдельного
        окна, если пространств нет. Создаётся без родителя — родителя даёт панель рабочей области."""
        panel = self._notifications_dialog
        if panel is not None:
            try:
                panel.objectName()                 # жив ли C++-объект
                return panel
            except RuntimeError:
                panel = self._notifications_dialog = None
        tz_name = getattr(self.host, "display_tz", "Europe/Moscow")
        panel = QuotesNotificationsPanel(self.events, None, tz_name, sound=getattr(self.host, "sound", None),
                                         robots_source=lambda: (self.active_big_trades() + self.active_spreads()
                                                                + self.active_robots()),
                                         tab=self)
        self._notifications_dialog = panel
        return panel

    def open_notifications(self):
        """Показать окно «Уведомления»: в терминале — панелью (MainWindow.show_notifications_panel: где она
        закреплена, там и показывается; нигде — открывается в текущей области); без пространств — отдельным
        окном (запуск вкладки отдельно, проверки)."""
        opener = getattr(self.host, "show_notifications_panel", None)
        if callable(opener):
            opener()
            return
        panel = self.notifications_panel()
        panel.set_display_tz(getattr(self.host, "display_tz", "Europe/Moscow"))
        panel.setWindowFlag(QtCore.Qt.WindowType.Window, True)
        panel.show()
        panel.raise_()
        panel.activateWindow()
        self.mark_notifications_read()

    def notification_popup_html(self) -> str:
        """Всплывающее окно значка «Уведомления» (notify_badge.popup_html): работающие роботы и последние
        уведомления; новые — с точкой (последние self.unread)."""
        tz_name = getattr(self.host, "display_tz", "Europe/Moscow")
        rows = []
        unread = int(self.unread or 0)
        for i, event in enumerate(reversed(self.events[-notify_badge.POPUP_EVENTS:])):
            typ = str(event.get("type", ""))
            when = QuotesNotificationsPanel._event_time(event, tz_name)
            rows.append({"time": when if when.endswith("UTC") else when[-8:],     # «ЧЧ:ММ:СС»; старые записи — как есть
                         "kind": EVENT_TYPE_LABELS.get(typ, typ), "symbol": _friendly_symbol(event.get("symbol", "")),
                         "title": str(event.get("title", "") if event.get("title") != typ else ""),
                         "details": str(event.get("details", "")), "new": i < unread})
        robots = []
        now = pd.Timestamp.now(tz="UTC")
        for robot in self.active_spreads() + self.active_robots():
            try:
                elapsed = max(0, int((now - pd.Timestamp(robot["started"])).total_seconds()))
            except Exception:
                elapsed = 0
            h, rem = divmod(elapsed, 3600)
            m, sec = divmod(rem, 60)
            side = "покупка" if robot.get("side") == "BUY" else "продажа"
            size = float(robot.get("size", 0) or 0)
            if robot.get("kind") == "spread":
                kind, more = "🔄 Спредовый", f"~{size:,.0f} лотов".replace(",", " ")
            else:
                kind, more = "🤖 Робот", f"{int(robot.get('count', 0))} × {size:g}"
            robots.append({"kind": kind, "symbol": _friendly_symbol(robot.get("symbol", "")),
                           "side": robot.get("side"), "text": f"{side} · {h:02d}:{m:02d}:{sec:02d} · {more}"})
        return notify_badge.popup_html(rows, robots, unread, int(self.unread_level or 0))

    def set_catalog(self):
        pass

    def shutdown(self):
        if self._robot_note_wait:                   # робот ещё работает — заметка с тем, что успели собрать
            for symbol in set(self._robot_note_wait.values()):
                for chain in (self.rows.get(symbol) or {}).get("robot_chains", []):
                    self._finish_robot_note(symbol, chain, robot_notes.REASON_SHUTDOWN)
        for symbol, state in list(self.rows.items()):   # роботы, ещё не забытые, — в журнал серий
            for chain in (state or {}).get("robot_chains", []):
                self._log_robot_series(symbol, chain)
        dialog, self._notifications_dialog = self._notifications_dialog, None
        if dialog is not None:
            try:
                if dialog.parentWidget() is None:  # отдельное окно; панель в области не трогаем — её место в
                    dialog.close()                 # раскладке пространств сохраняется при выходе
            except RuntimeError:
                pass
        self.stop()


# --------------------------------------------------------------------------
# Главное окно
# --------------------------------------------------------------------------

