# -*- coding: utf-8 -*-
"""Пользовательские цвета и шрифты терминала (как «Цвета» и «Шрифты» в настройках скальперских терминалов).

Хранится только то, что пользователь поменял, — отдельно для каждой темы:
    colors/<тема>/<ключ> = "#RRGGBB" или "#AARRGGBB" (с прозрачностью);
    fonts/<параметр>     = значение (общие для обеих тем).
Нет записи — цвет по умолчанию темы, поэтому кнопка «Сброс» просто удаляет записи.

Ключи цветов (COLOR_GROUPS) по областям:
    app.*   — интерфейс: акцент (активная вкладка докинга, выделение), шапка окон, с 2.1.83 — фон окон и текст
              (fx_theme.stylesheet: из них выводятся панели, кнопки, рамки — fx_theme.shades);
    algo.* / oi.* / cny.* / opt.* / atr.* / notes.* / ticks.* / flow.* / balance.* (2.1.83) — свои фон и текст окон
              «Алгоритмы», «Открытый интерес», «CNY Forward», «Опционы», «ATR», «Заметки», «Тики Bid/Ask»,
              «Покупка/Продажа», «Баланс покупок/продаж» (window_qss — правила по objectName окна, WINDOW_SCOPES) и
              цвета их графиков (окна читают color() при создании); не задано — окно как всё приложение;
    dom.*   — стакан, тики, кластеры, лента: ключи словаря CS в scalper_widget.py (dom.bid → CS["bid"]);
    chart.* — графики свечей: свечи, объём, фон и текст (candlestick_item / chart_panel / fx_theme.chart_color).
Стакан перекрашивается сразу (scalper_widget.apply_dom_theme по сигналу NOTIFIER.changed); интерфейс —
частично сразу, полностью после перезапуска; графики берут цвета при запуске терминала.

Модуль без зависимостей от окон терминала: его импортируют fx_theme, candlestick_item и scalper_widget
ещё до создания QApplication (QSettings с явными именами работает и без него).
"""
from __future__ import annotations

import sys
from dataclasses import asdict, dataclass, fields

from PySide6 import QtCore, QtGui

ORG, APP = "MyTradingTools", "FxTerminal"
THEMES = ("dark", "light")

# ---------------------------------------------------------------- цвета

# (ключ, подпись) по группам страницы «Цвета». Порядок — как в окне настроек.
COLOR_GROUPS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Цвета приложения", [
        ("app.accent", "Активная вкладка и выделение"),
        ("app.titlebar", "Шапка окон"),
        ("app.active_frame", "Выделение активного стакана"),
        ("app.bg", "Фон окон"),
        ("app.text", "Текст"),
    ]),
    ("Тики Bid/Ask", [("ticks.bg", "Фон"), ("ticks.text", "Текст"),
                      ("ticks.plot_bg", "Фон графика"), ("ticks.clock", "Часы"),
                      ("ticks.ask", "Бары ASK (покупки)"), ("ticks.bid", "Бары BID (продажи)"),
                      ("ticks.rep_ask", "Повтор ASK"), ("ticks.rep_bid", "Повтор BID"),
                      ("ticks.large", "Крупная сделка")]),
    ("Покупка/Продажа", [("flow.bg", "Фон"), ("flow.text", "Текст")]),
    ("Баланс покупок/продаж", [("balance.bg", "Фон"), ("balance.text", "Текст"),
                               ("balance.plot_bg", "Фон графика"),
                               ("balance.up", "Бары вверх (покупки)"), ("balance.down", "Бары вниз (продажи)")]),
    ("Алгоритмы", [("algo.bg", "Фон"), ("algo.text", "Текст")]),
    ("Открытый интерес", [("oi.bg", "Фон"), ("oi.text", "Текст"),
                          ("oi.plot_bg", "Фон графиков"), ("oi.line", "Линия OI")]),
    ("CNY Forward", [("cny.bg", "Фон"), ("cny.text", "Текст"),
                     ("cny.dash_bg", "Фон дашборда"), ("cny.dash_text", "Текст дашборда")]),
    ("Опционы", [("opt.bg", "Фон окна"), ("opt.text", "Текст"),
                 ("opt.chart_bg", "Фон графиков"), ("opt.card", "Фон карточек"),
                 ("opt.grid", "Сетка"), ("opt.muted", "Подписи"),
                 ("opt.call", "CALL"), ("opt.put", "PUT"),
                 ("opt.price", "Цена базового актива"), ("opt.highlight", "Максимумы OI")]),
    ("ATR", [("atr.bg", "Фон"), ("atr.text", "Текст"), ("atr.line", "Линия и столбики")]),
    ("Заметки", [("notes.bg", "Фон"), ("notes.text", "Текст")]),
    ("Цвета стаканов", [
        ("dom.ask", "Аски"), ("dom.bid", "Биды"),
        ("dom.best_ask", "Лучший аск"), ("dom.best_bid", "Лучший бид"),
        ("dom.gold", "Объем"), ("dom.bar_big", "Крупный объем"), ("dom.bar_big2", "Крупный объем 2"),
        ("dom.bar_ice", "Айсберг-заявки"),
        ("dom.sell_fill", "Тик продажа"), ("dom.buy_fill", "Тик покупка"),
        ("dom.sell_edge", "Обводка тика продажи"), ("dom.buy_edge", "Обводка тика покупки"),
        ("dom.big_edge", "Обводка крупного тика"), ("dom.line", "Линия тиков"),
        ("dom.grid", "Сетка"), ("dom.grid_major", "Уровни"),
        ("dom.pnl_up", "Прибыль"), ("dom.pnl_dn", "Убыток"),
        ("dom.bg", "Фон"), ("dom.separator", "Разделитель справа"), ("dom.frame", "Рамки колонок"),
        ("dom.text", "Текст"), ("dom.vol_text", "Текст объема"),
        ("dom.best_text", "Текст лучших цен"), ("dom.hover", "Курсор"), ("dom.label_bg", "Фон линейки"),
        ("dom.signal", "Сигнальные уровни"), ("dom.btn_sel", "Активная функция"),
    ]),
    ("Цвета кластеров", [
        ("dom.cl_dn_body", "Тело свечи вниз"), ("dom.cl_up_body", "Тело свечи вверх"),
        ("dom.cl_dn_fill", "Кластер Дельта продажи"), ("dom.cl_up_fill", "Кластер Дельта покупки"),
        ("dom.cl_vol_fill", "Кластер Объем"), ("dom.cl_poc", "Максимальный объем"),
        ("dom.cl_cell", "Фон ячейки"), ("dom.cl_text", "Текст кластеров"),
        ("dom.cl_dn_edge", "Рамка свечи вниз"), ("dom.cl_up_edge", "Рамка свечи вверх"),
        ("dom.delta_neg", "Итог дельты −"), ("dom.delta_pos", "Итог дельты +"),
    ]),
    ("Цвета ленты сделок", [
        ("dom.tape_bg", "Фон"), ("dom.tape_price", "Цена"), ("dom.tape_time", "Время"),
        ("dom.tape_buy", "Покупка"), ("dom.tape_sell", "Продажа"), ("dom.tape_big", "Крупная сделка"),
    ]),
    ("Цвета графиков (после перезапуска)", [
        ("chart.up", "Свеча вверх"), ("chart.down", "Свеча вниз"),
        ("chart.vol_up", "Объем если свеча вверх"), ("chart.vol_down", "Объем если свеча вниз"),
        ("chart.bg", "Фон"), ("chart.fg", "Текст и оси"),
    ]),
]
COLOR_TITLES = {key: title for _group, items in COLOR_GROUPS for key, title in items}

# Цвета по умолчанию для app.* и chart.* (dom.* — из CS_DARK / CS_LIGHT в scalper_widget.py).
# app.* повторяют ACCENT и TITLEBAR_COLOR из fx_theme.stylesheet, chart.bg/fg — fx_theme.CHART_COLORS.
_FIXED_DEFAULTS = {
    "dark": {"app.accent": "#3d8bfd", "app.titlebar": "#103638", "app.active_frame": "#65166b",
             "chart.up": "#00d9a3", "chart.down": "#ff4560",
             "chart.vol_up": "#6e00d9a3", "chart.vol_down": "#6eff4560",
             "chart.bg": "#131722", "chart.fg": "#d1d4dc"},
    "light": {"app.accent": "#2878d0", "app.titlebar": "#bcbcbc", "app.active_frame": "#9c4fa6",
              "chart.up": "#00d9a3", "chart.down": "#ff4560",
              "chart.vol_up": "#6e00d9a3", "chart.vol_down": "#6eff4560",
              "chart.bg": "#ffffff", "chart.fg": "#3d434c"},
}


def _settings() -> QtCore.QSettings:
    return QtCore.QSettings(ORG, APP)


def saved_theme(settings: QtCore.QSettings | None = None) -> str:
    try:
        name = str((settings or _settings()).value("appearance/theme", "dark"))
    except Exception:
        name = "dark"
    return "light" if name.lower() == "light" else "dark"


def color_hex(color: QtGui.QColor) -> str:
    """#RRGGBB для непрозрачного цвета, #AARRGGBB — с прозрачностью (формат QColor)."""
    fmt = QtGui.QColor.NameFormat.HexRgb if color.alpha() == 255 else QtGui.QColor.NameFormat.HexArgb
    return color.name(fmt)


def valid(text) -> bool:
    return isinstance(text, str) and QtGui.QColor(text).isValid()


def overrides(theme: str | None = None, settings: QtCore.QSettings | None = None) -> dict[str, str]:
    """Цвета, изменённые пользователем в теме: {ключ: hex}. Битые записи пропускаются."""
    st = settings or _settings()
    theme = theme or saved_theme(st)
    out: dict[str, str] = {}
    st.beginGroup(f"colors/{theme}")
    try:
        for key in st.childKeys():
            value = st.value(key)
            if key in COLOR_TITLES and valid(value):
                out[key] = str(value)
    finally:
        st.endGroup()
    return out


def override(key: str, theme: str | None = None) -> str | None:
    value = _settings().value(f"colors/{theme or saved_theme()}/{key}")
    return str(value) if valid(value) else None


def save_overrides(theme: str, values: dict[str, str], settings: QtCore.QSettings | None = None) -> None:
    """Записать изменённые цвета темы целиком: ключей нет в values — значит, по умолчанию."""
    st = settings or _settings()
    st.remove(f"colors/{theme}")
    for key, value in values.items():
        if key in COLOR_TITLES and valid(value):
            st.setValue(f"colors/{theme}/{key}", value)


# Окна со своими фоном и текстом (2.1.83): префикс ключей -> objectName окна. window_qss пишет правила только
# для заданных цветов — не задано, окно выглядит как всё приложение.
WINDOW_SCOPES = {"algo": "fxAlgo", "oi": "fxOpenInterest", "cny": "fxCnyForward", "opt": "fxOptions",
                 "atr": "fxAtr", "notes": "fxNotes", "ticks": "fxTickWindow", "flow": "fxOrderFlow",
                 "balance": "fxBalance"}
# Окна со своим размером шрифта (FontPrefs, pt; 0 — как весь интерфейс): префикс окна -> поле FontPrefs.
FONT_SCOPES = {"notes": "notes_pt", "ticks": "ticks_pt", "flow": "flow_pt", "balance": "balance_pt"}
# Цвета окон по умолчанию: имя цвета темы (fx_theme.base_colors) или свой (тёмная, светлая тема).
_WINDOW_DEFAULTS = {
    "bg": "BG_WINDOW", "text": "TEXT",
    "oi.plot_bg": ("#131722", "#ffffff"), "oi.line": ("#5fd3b3", "#119c7f"),
    "cny.dash_bg": ("#ffffff", "#ffffff"), "cny.dash_text": ("#000000", "#000000"),   # как рисует matplotlib
    "opt.chart_bg": ("#131722", "#ffffff"), "opt.card": "BG_PANEL", "opt.grid": "BORDER", "opt.muted": "TEXT_DIM",
    "opt.call": ("#2ecc55", "#2ecc55"), "opt.put": ("#e61e1e", "#e61e1e"),
    "opt.price": ("#ffbf4a", "#ffbf4a"), "opt.highlight": ("#f3d36b", "#f3d36b"),
    "atr.line": "ACCENT",
    # «Тики»: как рисует окно (tick_volume_window: ASK_COLOR …, часы — fx_theme.CHART_COLORS["clock"])
    "ticks.plot_bg": ("#131722", "#ffffff"), "ticks.clock": ("#ffe600", "#7b2fbe"),
    "ticks.ask": ("#2ecc55", "#2ecc55"), "ticks.bid": ("#e61e1e", "#e61e1e"),
    "ticks.rep_ask": ("#40dccd", "#40dccd"), "ticks.rep_bid": ("#ff69b4", "#ff69b4"),
    "ticks.large": ("#ff3cc8", "#ff3cc8"),
    # «Баланс покупок/продаж»: цвета свечей графиков (candlestick_item BULL_COLOR / BEAR_COLOR)
    "balance.plot_bg": ("#131722", "#ffffff"), "balance.up": ("#00d9a3", "#00d9a3"),
    "balance.down": ("#ff4560", "#ff4560"),
}


# Цвета графиков окон, которые по умолчанию повторяют «Цвета графиков» (фон, свечи вверх / вниз).
_FOLLOW_CHART = {"oi.plot_bg": "chart.bg", "opt.chart_bg": "chart.bg", "ticks.plot_bg": "chart.bg",
                 "balance.plot_bg": "chart.bg", "balance.up": "chart.up", "balance.down": "chart.down"}


def default_color(key: str, theme: str) -> str:
    """Цвет по умолчанию (для образца в настройках и кнопки «Сброс»)."""
    if key.startswith("dom."):
        import scalper_widget                                      # палитры стакана живут рядом с отрисовкой
        table = scalper_widget.CS_LIGHT if theme == "light" else scalper_widget.CS_DARK
        color = table.get(key[4:])
        return color_hex(color) if color is not None else "#808080"
    light = theme == "light"
    if key in _FOLLOW_CHART:                      # графики окон — по умолчанию как свечные графики терминала
        return override(_FOLLOW_CHART[key], theme) or default_color(_FOLLOW_CHART[key], theme)
    if key in ("app.bg", "app.text") or key.split(".", 1)[0] in WINDOW_SCOPES:
        import fx_theme
        base = fx_theme.base_colors(theme)
        spec = _WINDOW_DEFAULTS.get(key) or _WINDOW_DEFAULTS.get(key.split(".", 1)[1])
        if isinstance(spec, tuple):
            return spec[1] if light else spec[0]
        if key.split(".", 1)[1] in ("bg", "text") and key != "app.bg" and key != "app.text":
            return app_color(key.split(".", 1)[1], theme)                # окно — как всё приложение
        return base.get(spec or "", "#808080")
    return _FIXED_DEFAULTS["light" if light else "dark"].get(key, "#808080")


def app_color(name: str, theme: str | None = None) -> str:
    """Фон («bg») или текст («text») всего приложения: «Фон окон» / «Текст» или цвет темы."""
    theme = theme or saved_theme()
    import fx_theme
    user = override(f"app.{name}", theme)
    return user or fx_theme.base_colors(theme)["BG_WINDOW" if name == "bg" else "TEXT"]


def color(key: str, theme: str | None = None) -> str:
    """Цвет сохранённой темы с учётом пользовательского (окна «Аналитики» и «Заметки» — при создании)."""
    theme = theme or saved_theme()
    return override(key, theme) or default_color(key, theme)


def window_qss(theme: str | None = None, settings: QtCore.QSettings | None = None) -> str:
    """Правила общего стиля для окон со своими фоном и текстом (WINDOW_SCOPES) и размер шрифта окон
    (FONT_SCOPES: «Заметки», «Тики», «Покупка/Продажа», «Баланс покупок/продаж»). Добавляется в конец стиля приложения (app_common.app_stylesheet) — применяется сразу после
    «OK» в «Настройках». Окну нужны objectName из WINDOW_SCOPES и WA_StyledBackground (иначе фон контейнера
    не рисуется). Оттенки (чередование строк таблиц, заголовки, приглушённый текст) — fx_theme.shades."""
    import fx_theme
    st = settings or _settings()
    theme = theme or saved_theme(st)
    user = overrides(theme, st)
    out = []
    for prefix, name in WINDOW_SCOPES.items():
        bg, text = user.get(f"{prefix}.bg"), user.get(f"{prefix}.text")
        if not bg and not text:
            continue
        sh = fx_theme.shades(QtGui.QColor(bg or app_color("bg", theme)).name(),
                             QtGui.QColor(text or app_color("text", theme)).name())
        s = f"#{name}"
        if bg:
            out.append(f"QWidget{s} {{ background-color: {bg}; }}")
            out.append(f"{s} QTableView, {s} QTableWidget, {s} QListView, {s} QListWidget, {s} QTreeView, "
                       f"{s} QPlainTextEdit, {s} QTextEdit, {s} QTextBrowser {{ background-color: {bg}; "
                       f"alternate-background-color: {sh['BG_PANEL']}; }}")
            out.append(f"{s} QHeaderView::section, {s} QTableCornerButton::section {{ "
                       f"background-color: {sh['BG_PANEL']}; }}")
            out.append(f"{s} QTabWidget::pane, {s} QScrollArea, {s} QStackedWidget {{ background-color: {bg}; }}")
        out.append(f"QWidget{s}, {s} QLabel, {s} QCheckBox, {s} QRadioButton, {s} QGroupBox, {s} QTableView, "
                   f"{s} QTableWidget, {s} QListView, {s} QListWidget, {s} QTreeView, {s} QPlainTextEdit, "
                   f"{s} QTextEdit, {s} QTextBrowser {{ color: {sh['TEXT']}; }}")
        out.append(f"{s} QHeaderView::section {{ color: {sh['TEXT_DIM']}; }}")
    prefs = load_fonts(st)
    for prefix, field in FONT_SCOPES.items():
        size = getattr(prefs, field)
        if size > 0:
            name = WINDOW_SCOPES[prefix]
            out.append(f"QWidget#{name}, #{name} QWidget {{ font-size: {size}pt; }}")
    return ("\n/* свои цвета окон (appearance.window_qss) */\n" + "\n".join(out) + "\n") if out else ""


def style_window(widget, prefix: str) -> None:
    """Окно со своими цветами (WINDOW_SCOPES): имя для правил window_qss и фон контейнера из стиля."""
    widget.setObjectName(WINDOW_SCOPES[prefix])
    widget.setAttribute(QtCore.Qt.WidgetAttribute.WA_StyledBackground, True)


def chart_hex(key: str) -> str:
    """Цвет графиков сохранённой темы с учётом пользовательского (chart.up → "#00d9a3")."""
    theme = saved_theme()
    return override(f"chart.{key}", theme) or default_color(f"chart.{key}", theme)


def dom_overrides(theme: str | None = None) -> dict[str, QtGui.QColor]:
    """Изменённые цвета стакана для словаря CS: {"bid": QColor, ...}."""
    return {key[4:]: QtGui.QColor(value) for key, value in overrides(theme).items() if key.startswith("dom.")}


# ---------------------------------------------------------------- шрифты

WEIGHTS = ("Обычное", "Жирное")
DEFAULT_FAMILY = "Verdana"          # как в скальперских терминалах (Verdana 11 при строке 12); есть в любой Windows


@dataclass
class FontPrefs:
    """Шрифты стакана и графиков (страница «Шрифты»).

    dom_size 0 — размер по высоте строки (равен высоте строки, с 2.0.43; меняется вместе с масштабом колесом);
    weight «Обычное» — жирными остаются только лучшие цены и метки, «Жирное» — весь текст области;
    в стакане (dom_weight) по умолчанию «Жирное» (2.1.62): все цены и объёмы — как лучшие цены, иначе тонкие
    цифры рядом с жирными выглядят затемнёнными; в тиках и кластерах — «Обычное»;
    dom_row — высота строки при масштабе 100 % (новые окна стакана и открытые — после OK; Ctrl+колесо — как раньше);
    chart_size 0 — подписи осей графиков как в теме (применяется к новым графикам и после перезапуска);
    dom_price — вид цены в стакане (PRICE_FORMATS): «sep» 82 323, «plain» 82323,
    «last2»…«last4» — только последние цифры (как Price Digits в ATAS / Short price в Quantower);
    dom_price_bold — сколько последних цифр цены жирным (0 — не выделять; как Digits to highlight в CQG).
    tick_px / cluster_px / tape_px (2.1.70) — размер шрифта в тиках (подписи пузырьков), в кластерах (ячейки и
    итоги под ними) и в ленте сделок, px; 0 — «как в стакане» (по умолчанию: все три того же размера, что цифры
    стакана). В тиках размер — наибольший: в мелком пузырьке подпись мельче; пузырьки растут вместе с шрифтом.
    В кластерах — не больше высоты строки стакана. tape_size (pt) — прежняя настройка ленты, с 2.1.70 не
    используется (оставлена, чтобы старые сохранённые настройки читались без ошибок).
    dom_gray — серое сглаживание текста стакана вместо цветного (ClearType): без сине-жёлтой каймы вокруг цифр
    на цветном фоне ячеек (замер 14.11 по скриншоту: у объёмов поверх жёлтой полосы кайма заметная, у Ватаги —
    серое сглаживание и каймы нет). По умолчанию включено (2.1.63; до этого было выключено — проверено на
    жирном шрифте стакана, с ним цифры чище); на части мониторов серое выглядит мягче — тогда галочку снять."""
    dom_family: str = DEFAULT_FAMILY
    dom_size: int = 0
    dom_row: int = 12
    dom_weight: str = "Жирное"
    tick_weight: str = "Обычное"
    cluster_weight: str = "Обычное"
    tape_size: int = 9                  # до 2.1.70 (pt); не используется — см. tape_px
    tick_px: int = 0
    cluster_px: int = 0
    tape_px: int = 0
    chart_size: int = 0
    dom_antialias: bool = True
    dom_gray: bool = True
    dom_price: str = "sep"
    dom_price_bold: int = 0
    notes_pt: int = 0                   # 2.1.83: размер шрифта окна «Заметки», pt; 0 — как весь интерфейс
    ticks_pt: int = 0                   # 2.1.83: окна «Тики» (подписи, шкалы графика), pt; 0 — как интерфейс
    ticks_clock_px: int = 0             # 2.1.83: часы окна «Тики», px; 0 — 15 px, как было
    flow_pt: int = 0                    # 2.1.83: «Покупка/Продажа», pt; 0 — как интерфейс
    balance_pt: int = 0                 # 2.1.83: «Баланс покупок/продаж» (и шкалы графика), pt; 0 — как интерфейс


DOM_SIZES = (0, 8, 9, 10, 11, 12, 13, 14, 16)
ROW_HEIGHTS = tuple(range(10, 31))
TAPE_SIZES = (8, 9, 10, 11, 12)          # прежняя настройка ленты (pt), не используется с 2.1.70
TEXT_SIZES = (0, 8, 9, 10, 11, 12, 13, 14, 16)    # tick_px / cluster_px / tape_px: 0 — как в стакане
CHART_SIZES = (0, 7, 8, 9, 10, 11, 12)
NOTES_SIZES = (0, 8, 9, 10, 11, 12, 13, 14, 16, 18)      # notes_pt, ticks_pt, flow_pt, balance_pt: 0 — как интерфейс
WINDOW_FONT_SIZES = NOTES_SIZES
CLOCK_SIZES = (0, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32)   # ticks_clock_px: 0 — 15 px
PRICE_FORMATS = (("sep", "Полностью, с разделителем: 82 323"), ("plain", "Полностью, без разделителя: 82323"),
                 ("last2", "Последние 2 цифры: 23"), ("last3", "Последние 3 цифры: 323"),
                 ("last4", "Последние 4 цифры: 2 323"))
PRICE_BOLD = (0, 1, 2, 3)


def load_fonts(settings: QtCore.QSettings | None = None) -> FontPrefs:
    st = settings or _settings()
    prefs = FontPrefs()
    for f in fields(FontPrefs):
        raw = st.value(f"fonts/{f.name}")
        if raw is None:
            continue
        default = getattr(prefs, f.name)
        try:
            if isinstance(default, bool):
                value = raw if isinstance(raw, bool) else str(raw).lower() in ("1", "true", "yes")
            elif isinstance(default, int):
                value = int(raw)
            else:
                value = str(raw)
        except (TypeError, ValueError):
            continue
        setattr(prefs, f.name, value)
    if prefs.dom_weight not in WEIGHTS:
        prefs.dom_weight = "Обычное"
    if prefs.tick_weight not in WEIGHTS:
        prefs.tick_weight = "Обычное"
    if prefs.cluster_weight not in WEIGHTS:
        prefs.cluster_weight = "Обычное"
    prefs.dom_row = max(ROW_HEIGHTS[0], min(ROW_HEIGHTS[-1], prefs.dom_row))
    if prefs.dom_price not in dict(PRICE_FORMATS):
        prefs.dom_price = "sep"
    prefs.dom_price_bold = max(0, min(PRICE_BOLD[-1], prefs.dom_price_bold))
    for name in ("tick_px", "cluster_px", "tape_px"):          # 0 — как в стакане; правленное вручную — в пределах
        value = getattr(prefs, name)
        setattr(prefs, name, 0 if value <= 0 else max(6, min(32, value)))
    prefs.dom_family = prefs.dom_family.strip() or DEFAULT_FAMILY
    for name in ("notes_pt", "ticks_pt", "flow_pt", "balance_pt", "ticks_clock_px"):
        value = getattr(prefs, name)
        setattr(prefs, name, 0 if value <= 0 else max(6, min(48, value)))
    return prefs


def save_fonts(prefs: FontPrefs, settings: QtCore.QSettings | None = None) -> None:
    st = settings or _settings()
    for name, value in asdict(prefs).items():
        st.setValue(f"fonts/{name}", value)


FONT_DEFAULTS_KEY = "fonts/defaults_version"    # какие «новые умолчания» уже применены к сохранённым настройкам
FONT_DEFAULTS_VERSION = 3
FONT_MIN_DEFAULT_PX = 12


def upgrade_fonts(settings: QtCore.QSettings | None = None) -> bool:
    """Разовые «новые умолчания» шрифтов стакана для уже сохранённых настроек; каждый шаг — один раз
    (номер последнего сделанного — в FONT_DEFAULTS_KEY). У новой установки всё это уже в FontPrefs.

    Шаг 1 (2.1.56): шрифт по умолчанию — 12 px: строка ниже 12 px — 12 px, заданный размер шрифта меньше
    12 px — «Авто» (по высоте строки). Сравнение со стаканом Ватаги 14.11: там строка 12 px и шрифт около
    11 px, у нас стояла строка 10 px.
    Шаг 2 (2.1.62): начертание в стакане «Обычное» — «Жирное»: все цены и объёмы выглядят как лучшие цены
    (тонкие цифры рядом с жирными казались затемнёнными). Не трогаем, если включено «Последние цифры цены
    жирным»: оно работает только при обычном начертании.
    Шаг 3 (2.1.63): «Серое сглаживание» включается (если сглаживание шрифта вообще включено): без цветной
    каймы вокруг цифр.
    Потом настройки снова полностью в руках пользователя («Настройки» → «Шрифты»): вернул «Обычное» или
    уменьшил строку, снял галочку — больше не трогаем. Возвращает, менялось ли что-то."""
    st = settings or _settings()
    try:
        done = int(st.value(FONT_DEFAULTS_KEY, 0) or 0)
    except (TypeError, ValueError):
        done = 0
    if done >= FONT_DEFAULTS_VERSION:
        return False
    st.setValue(FONT_DEFAULTS_KEY, FONT_DEFAULTS_VERSION)
    prefs = load_fonts(st)
    changed = False
    if done < 1:
        if prefs.dom_row < FONT_MIN_DEFAULT_PX:
            prefs.dom_row, changed = FONT_MIN_DEFAULT_PX, True
        if 0 < prefs.dom_size < FONT_MIN_DEFAULT_PX:
            prefs.dom_size, changed = 0, True
    # «Последние цифры цены жирным» работает только при обычном начертании — у кого выделение включено,
    # тот начертание выбрал сам: не трогаем
    if done < 2 and prefs.dom_weight != "Жирное" and not prefs.dom_price_bold:
        prefs.dom_weight, changed = "Жирное", True
    if done < 3 and prefs.dom_antialias and not prefs.dom_gray:
        prefs.dom_gray, changed = True, True
    if changed:
        save_fonts(prefs, st)
    return changed


# ---------------------------------------------------------------- значки роботов на графике

# Сколько держать в столбике значков графика остановившихся роботов и закончившиеся айсберги («Настройки» →
# «Интерфейс»): минуты; 0 — скрывать сразу, остаются только работающие. По умолчанию 15 (как было).
ICONS_KEEP_KEY = "chart/icons_stopped_keep_min"
ICONS_KEEP_CHOICES = ((0, "Скрывать сразу — только работающие"), (5, "5 минут"), (10, "10 минут"), (15, "15 минут"))
ICONS_KEEP_DEFAULT = 15


def icons_keep_sec(settings: QtCore.QSettings | None = None) -> float:
    try:
        value = int((settings or _settings()).value(ICONS_KEEP_KEY, ICONS_KEEP_DEFAULT))
    except (TypeError, ValueError):
        value = ICONS_KEEP_DEFAULT
    return 60.0 * max(0, value)


# ---------------------------------------------------------------- рамка активного стакана

ACTIVE_FRAME_KEY = "appearance/active_frame"     # «Подсвечивать активный стакан рамкой» (страница «Цвета»)
ACTIVE_FRAME_PX = 2


def active_frame_enabled(settings: QtCore.QSettings | None = None) -> bool:
    raw = (settings or _settings()).value(ACTIVE_FRAME_KEY, True)
    return raw if isinstance(raw, bool) else str(raw).lower() in ("1", "true", "yes")


def active_frame_color(theme: str | None = None) -> str:
    theme = theme or saved_theme()
    return override("app.active_frame", theme) or default_color("app.active_frame", theme)


# ---------------------------------------------------------------- общий размер шрифта интерфейса (2.1.83)

UI_FONT_KEY = "appearance/font_size"       # = app_common.FONT_SIZE_KEY: «Настройки» → «Размер шрифта», pt; 0 — тема
UI_BASE_PT = 9                             # шрифт темы, если приложение его ещё не запомнило (fx_base_font_pt)


def ui_scale(settings: QtCore.QSettings | None = None) -> float:
    """Во сколько раз выбранный в «Настройках» размер шрифта интерфейса больше шрифта темы: 1.0 — «Как в теме».
    Подписи со своим размером (карточки «Открытого интереса», «Опционов» и «ATR», всплывающие «Мировое время»,
    число на значке уведомлений) умножают свой размер на это число — растут и мельчают вместе со всем интерфейсом.
    Шрифт темы — тот, что app_common.apply_app_font_size запомнил до замены (свойство приложения fx_base_font_pt)."""
    try:
        size = int((settings or _settings()).value(UI_FONT_KEY, 0) or 0)
    except (TypeError, ValueError):
        size = 0
    if size <= 0:
        return 1.0
    app = QtCore.QCoreApplication.instance()
    base = app.property("fx_base_font_pt") if app is not None else None
    try:
        base = int(base or 0)
    except (TypeError, ValueError):
        base = 0
    if base <= 0:
        base = UI_BASE_PT
    return min(3.0, max(0.5, size / base))


def ui_px(px: float, settings: QtCore.QSettings | None = None) -> int:
    """Размер в пикселях под общий размер шрифта (ui_scale); не меньше 6."""
    return max(6, round(px * ui_scale(settings)))


def ui_pt(pt: float, settings: QtCore.QSettings | None = None) -> int:
    """Размер в пунктах под общий размер шрифта (ui_scale); не меньше 6."""
    return max(6, round(pt * ui_scale(settings)))


# ---------------------------------------------------------------- оповещение окон

class _Notifier(QtCore.QObject):
    """changed — «Настройки» сохранены (OK): окна стакана перерисовываются, подписи со своим размером
    (ui_px / ui_pt) пересчитывают размер под общий шрифт интерфейса."""
    changed = QtCore.Signal()


NOTIFIER = _Notifier()
