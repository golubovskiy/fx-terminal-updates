# -*- coding: utf-8 -*-
"""Публикация пакетов обновления в github.com/golubovskiy/fx-terminal-updates (2.1.68) — на компьютере автора.

    python tools\\publish_update.py --init               один раз: создать ключ подписи (закрытый — только у вас)
    python tools\\publish_update.py --key                показать открытый ключ (его зашивают в терминал)
    python tools\\publish_update.py                      опубликовать новые fx_update_*.zip из папки «Загрузки»
    python tools\\publish_update.py ПАКЕТ.zip [ПАКЕТ2.zip …]   опубликовать эти пакеты
    python tools\\publish_update.py --withdraw ВЕРСИЯ   снять неудачный пакет (2.1.72): убрать из latest.json и packages/
        [--repo ПАПКА] [--downloads ПАПКА] [--dry-run] [--no-push] [--engine-wheel КОЛЕСО.whl] [--no-engine]

Что делает публикация:
    1. берёт локальную копию репозитория (по умолчанию %USERPROFILE%\\fx-terminal-updates): нет — git clone,
       есть — git pull;
    2. пакеты (новее уже опубликованных) по порядку версий: проверка (manifest.json и суммы файлов — как у
       updater.py), копия в packages/fx_update_<версия>.zip, запись в latest.json (версия, requires, размер, sha256,
       изменения);
    2а. пакет с пересборкой Rust ("build_rust") — добавляет в него готовый модуль (2.1.83, embed_engine): собранной
       программе (exe) нечем собирать Rust, она берёт модуль из пакета. Модуль — fx_engine*.pyd из колеса maturin
       этой папки (fx_engine_rs/target/wheels: самое свежее, если новее исходников Rust; иначе — сборка
       «python -m maturin build --release», несколько минут) или из --engine-wheel. Сначала проверяется, что
       исходники Rust здесь — те же, что в пакете (поставьте пакет у себя: updater тогда и соберёт колесо).
       В пакет: engine/fx_engine.cp313-win_amd64.pyd и manifest "engine"; "build_rust" остаётся — установки из
       исходников по-прежнему пересобирают модуль сами. Модуль собран под ваш Python: exe, собранный из этой же
       папки (тот же Python 3.x), его принимает; под другой версией Python терминал возьмёт модуль из сборки
       программы. --no-engine — публиковать как есть;
    3. подписывает latest.json вашим закрытым ключом (update_online.sign_index, Ed25519);
    4. git add, commit «FX Terminal <версия>: пакет обновления», git push — вашими учётными данными GitHub.
Терминалы находят новую версию при следующей проверке (при запуске и раз в час) и предлагают установить.

Неудачный пакет (не ставится — например, не проходят проверки): --withdraw ВЕРСИЯ убирает его из списка и из
packages/, терминалы его больше не видят. Пакет-замена (следующая версия с requires той же, что у неудачного)
и без снятия перешагивает неудачный — update_online.plan_chain берёт самый новый подходящий пакет.

Ключ: закрытый лежит в %APPDATA%\\FX_Terminal\\update_signing.key (переменная FX_UPDATE_KEY — другой путь) и
не должен попадать ни в один репозиторий — эта программа отказывается хранить его внутри папки с git. Потеряли —
--init заново, новый открытый ключ надо добавить в терминал (update_online.PUBLIC_KEYS) пакетом, поставленным
вручную. Сделайте копию файла ключа (например, на флешку).

Нужен git (тот же, которым вы отправляете код в FX-Terminal). Только стандартная библиотека Python.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import ed25519_lite  # noqa: E402
import update_online  # noqa: E402
import updater  # noqa: E402

REPO_URL = f"https://github.com/{update_online.REPO}.git"
KEY_ENV = "FX_UPDATE_KEY"


class PublishError(Exception):
    pass


def key_path() -> Path:
    if os.environ.get(KEY_ENV):
        return Path(os.environ[KEY_ENV])
    base = os.environ.get("APPDATA") or str(Path.home() / ".config")
    return Path(base) / "FX_Terminal" / "update_signing.key"


def _inside_git(path: Path) -> Path | None:
    for parent in [path.resolve().parent, *path.resolve().parents]:
        if (parent / ".git").exists():
            return parent
    return None


def init_key(path: Path | None = None) -> bytes:
    """Создать закрытый ключ (если его ещё нет) -> открытый ключ."""
    path = path or key_path()
    repo = _inside_git(path)
    if repo is not None:
        raise PublishError(f"ключ нельзя хранить внутри репозитория git ({repo}) — выберите другую папку")
    if path.exists():
        raise PublishError(f"ключ уже есть: {path}. Новый не создаю — иначе терминалы перестанут доверять "
                           "вашим обновлениям. Удалите файл сами, если правда нужен новый ключ")
    path.parent.mkdir(parents=True, exist_ok=True)
    seed = ed25519_lite.new_seed()
    path.write_text("fx-terminal-update-key-v1 " + seed.hex() + "\n", encoding="ascii")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return ed25519_lite.public_key(seed)


def load_key(path: Path | None = None) -> bytes:
    path = path or key_path()
    try:
        tag, hexseed = path.read_text(encoding="ascii").split()
        seed = bytes.fromhex(hexseed)
    except FileNotFoundError:
        raise PublishError(f"ключа нет ({path}) — сначала: python tools\\publish_update.py --init") from None
    except (ValueError, UnicodeDecodeError):
        raise PublishError(f"файл ключа повреждён: {path}") from None
    if tag != "fx-terminal-update-key-v1" or len(seed) != 32:
        raise PublishError(f"файл ключа повреждён: {path}")
    return seed


def public_text(pub: bytes) -> str:
    return base64.b64encode(pub).decode("ascii")


def git(repo: Path, *args: str, check: bool = True) -> str:
    try:
        res = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, encoding="utf-8",
                             errors="replace")
    except FileNotFoundError:
        raise PublishError("git не найден — установите Git for Windows (git-scm.com)") from None
    if check and res.returncode != 0:
        raise PublishError(f"git {' '.join(args)}: {(res.stderr or res.stdout).strip()[-600:]}")
    return res.stdout


def ensure_repo(repo: Path, url: str = REPO_URL, log=print) -> None:
    """Локальная копия репозитория обновлений: нет — склонировать, есть — подтянуть изменения."""
    if not (repo / ".git").exists():
        if repo.exists() and any(repo.iterdir()):
            raise PublishError(f"папка {repo} не пустая и это не копия репозитория — укажите другую (--repo)")
        log(f"Клонирую {url} → {repo}")
        repo.parent.mkdir(parents=True, exist_ok=True)
        try:
            res = subprocess.run(["git", "clone", url, str(repo)], capture_output=True, text=True, encoding="utf-8",
                                 errors="replace")
        except FileNotFoundError:
            raise PublishError("git не найден — установите Git for Windows (git-scm.com)") from None
        if res.returncode != 0:
            raise PublishError(f"git clone: {(res.stderr or res.stdout).strip()[-600:]}")
    elif git(repo, "rev-parse", "--verify", "--quiet", "HEAD", check=False).strip():
        git(repo, "pull", "--ff-only", "--quiet")           # пустой репозиторий (ещё ни одного коммита) — нечего тянуть
    attrs = repo / ".gitattributes"
    if not attrs.exists():                     # файлы как есть: без замены концов строк (подпись — по байтам)
        attrs.write_text("* -text\n", encoding="ascii")


def read_payload(repo: Path, seed: bytes) -> dict:
    """payload из latest.json репозитория (подпись проверяется вашим ключом); файла нет — пустой."""
    path = repo / update_online.INDEX_FILE
    if not path.exists():
        return {"app": "FX Terminal", "latest": None, "packages": []}
    pub = public_text(ed25519_lite.public_key(seed))
    try:
        return update_online.verify_index(path.read_bytes(), keys=(pub,))
    except update_online.OnlineError as exc:
        raise PublishError(f"latest.json в репозитории не проверяется вашим ключом: {exc}") from None


def find_downloads(folder: Path, after: str | None) -> list[Path]:
    """fx_update_*.zip из папки новее версии after; одинаковые версии (скачаны дважды) — самый свежий файл."""
    best: dict[str, Path] = {}
    for path in sorted(Path(folder).glob("fx_update_*.zip"), key=lambda p: p.stat().st_mtime):
        try:
            version = str(updater.read_package(path)["version"])
        except updater.UpdateError:
            continue
        if after is None or updater.parse_version(version) > updater.parse_version(after):
            best[version] = path
    return [best[v] for v in sorted(best, key=updater.parse_version)]


# ------------------------------------------------------------------ готовый модуль Rust в пакете (2.1.83)

RUST_DIR = "fx_engine_rs"
RUST_SOURCES = ("src/**/*.rs", "Cargo.toml", "Cargo.lock", "pyproject.toml")


def wheels_dir(root: Path = ROOT) -> Path:
    return Path(root) / RUST_DIR / "target" / "wheels"


def _newest_wheel(root: Path) -> Path | None:
    wheels = sorted(wheels_dir(root).glob("fx_engine-*.whl"), key=lambda p: p.stat().st_mtime)
    return wheels[-1] if wheels else None


def _sources_mtime(root: Path) -> float:
    base = Path(root) / RUST_DIR
    times = [p.stat().st_mtime for pattern in RUST_SOURCES for p in base.glob(pattern) if p.is_file()]
    return max(times, default=0.0)


def check_rust_sources(manifest: dict, root: Path = ROOT) -> None:
    """Исходники Rust из пакета должны совпадать с этой папкой — иначе модуль собран не из них."""
    version = manifest["version"]
    for rel, info in manifest["files"].items():
        if not rel.startswith(RUST_DIR + "/"):
            continue
        path = Path(root) / rel
        if not path.is_file() or updater.sha256_file(path) != info["sha256"]:
            raise PublishError(f"{rel} здесь не такой, как в пакете {version}: модуль Rust собран бы не из него — "
                               f"поставьте пакет {version} у себя (или укажите --engine-wheel)")


def engine_wheel(root: Path = ROOT, build: bool = True, log=print) -> Path | None:
    """Колесо fx_engine для пакета: свежее колесо maturin (новее исходников Rust) или новая сборка.
    build=False (пробный запуск) — не собирать, None."""
    wheel = _newest_wheel(root)
    if wheel and wheel.stat().st_mtime >= _sources_mtime(root):
        return wheel
    if not build:
        return None
    log("  сборка модуля Rust (python -m maturin build --release, несколько минут)…")
    res = subprocess.run([sys.executable, "-m", "maturin", "build", "--release"], cwd=str(Path(root) / RUST_DIR),
                         capture_output=True, text=True, encoding="utf-8", errors="replace")
    if res.returncode != 0:
        tail = "\n".join((res.stdout + res.stderr).strip().splitlines()[-15:])
        raise PublishError(f"сборка fx_engine не удалась (код {res.returncode}):\n{tail}")
    wheel = _newest_wheel(root)
    if not wheel:
        raise PublishError("сборка fx_engine не дала файла .whl")
    return wheel


def engine_from_wheel(wheel: Path) -> tuple[str, bytes]:
    """Модуль из колеса: (имя файла fx_engine….pyd, содержимое). Колесо maturin кладёт его в fx_engine/."""
    try:
        with zipfile.ZipFile(wheel) as zf:
            names = [n for n in zf.namelist()
                     if PurePosixPath(n).name.startswith(updater.ENGINE_PREFIX + ".") and n.endswith(".pyd")]
            if len(names) != 1:
                raise PublishError(f"в {Path(wheel).name} нет модуля fx_engine….pyd (или их несколько: {names}) — "
                                   "нужно колесо для Windows")
            return PurePosixPath(names[0]).name, zf.read(names[0])
    except (OSError, zipfile.BadZipFile) as exc:
        raise PublishError(f"{wheel}: не колесо Python ({exc})")


def embed_engine(path: Path, out_dir: Path, root: Path = ROOT, wheel: Path | None = None, build: bool = True,
                 log=print) -> Path:
    """Пакет с "build_rust" и без готового модуля -> его копия в out_dir с engine/fx_engine….pyd и manifest
    "engine" (сумма и размер — в "files", как у остальных файлов). Остальные пакеты — как есть (path)."""
    manifest = updater.read_package(path)
    if not manifest.get("build_rust") or manifest.get("engine"):
        return Path(path)
    version = manifest["version"]
    if wheel is None:
        check_rust_sources(manifest, root)
        wheel = engine_wheel(root, build=build, log=log)
        if wheel is None:
            log(f"  {version}: при публикации будет собран модуль Rust и добавлен в пакет")
            return Path(path)
    name, data = engine_from_wheel(Path(wheel))
    rel = f"{updater.ENGINE_DIR}/{name}"
    reason = updater.allowed_path(rel)
    if reason:
        raise PublishError(reason)
    new_manifest = {k: v for k, v in manifest.items() if k != "_zip"}
    new_manifest["files"] = {**manifest["files"], rel: {"sha256": updater.sha256_bytes(data), "size": len(data)}}
    new_manifest["engine"] = rel
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / Path(path).name
    with zipfile.ZipFile(path) as src, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as dst:
        dst.writestr(updater.MANIFEST, json.dumps(new_manifest, ensure_ascii=False, indent=1))
        for item in src.infolist():
            if item.filename not in (updater.MANIFEST, rel):
                dst.writestr(item, src.read(item.filename))
        dst.writestr(rel, data)
    updater.read_package(target)                                       # та же проверка, что при установке
    log(f"  {version}: добавлен готовый модуль Rust {rel} ({len(data) // 1024} КБ, из {Path(wheel).name})")
    return target


def publish(packages: list[Path], repo: Path, seed: bytes, dry_run: bool = False, push: bool = True,
            log=print, root: Path = ROOT, engine: bool = True, wheel: Path | None = None) -> list[str]:
    """Опубликовать пакеты (см. описание файла) -> опубликованные версии.
    engine — добавлять готовый модуль Rust в пакеты с "build_rust" (embed_engine; wheel — своё колесо)."""
    with tempfile.TemporaryDirectory(prefix="fx_publish_") as tmp:
        return _publish(packages, repo, seed, dry_run, push, log, root, engine, wheel, Path(tmp))


def _publish(packages, repo, seed, dry_run, push, log, root, engine, wheel, tmp: Path) -> list[str]:
    payload = read_payload(repo, seed)
    entries = list(payload.get("packages") or [])
    latest = payload.get("latest")
    todo = []
    for path in packages:
        manifest = updater.read_package(path)                       # проверка пакета, как у updater.py
        todo.append((updater.parse_version(manifest["version"]), Path(path), manifest))
    todo.sort(key=lambda item: item[0])
    done = []
    for _key, path, manifest in todo:
        version = str(manifest["version"])
        if latest and updater.parse_version(version) <= updater.parse_version(latest):
            log(f"  {version}: уже опубликована версия {latest} или новее — пропускаю")
            continue
        need = manifest.get("requires")
        if latest and need and updater.parse_version(need) > updater.parse_version(latest):
            log(f"  внимание: {version} требует {need}, а в репозитории последняя {latest} — терминалы со старыми "
                "версиями дальше вручную")
        if engine:
            path = embed_engine(path, tmp, root, wheel=wheel, build=not dry_run, log=log)
        rel = f"{update_online.PACKAGES_DIR}/fx_update_{version}.zip"
        if not dry_run:
            rel = update_online.copy_package(path, repo)
        entry = update_online.entry_for(path, rel)
        entries.append(entry)
        latest = version
        done.append(version)
        log(f"  {version}: {path.name}, {entry['size'] // 1024} КБ" + (f", требует {need}" if need else ""))
    if not done:
        log("Публиковать нечего.")
        return []
    payload = {"app": "FX Terminal", "published": datetime.now().strftime("%Y-%m-%d %H:%M"), "latest": latest,
               "packages": entries}
    index = update_online.sign_index(payload, seed)
    if dry_run:
        log(f"Пробный запуск: опубликовал бы {', '.join(done)}; репозиторий не тронут.")
        return done
    (repo / update_online.INDEX_FILE).write_bytes(update_online.index_bytes(index))
    git(repo, "add", "--", update_online.INDEX_FILE, ".gitattributes",
        *[f"{update_online.PACKAGES_DIR}/fx_update_{v}.zip" for v in done])
    title = f"FX Terminal {done[-1]}: пакет обновления" if len(done) == 1 else \
        f"FX Terminal {done[0]}…{done[-1]}: пакеты обновления"
    git(repo, "commit", "--quiet", "-m", title)
    if push:
        git(repo, "push", "--quiet", "origin", "HEAD")
        log(f"Опубликовано: {', '.join(done)}. Терминалы предложат обновление при следующей проверке.")
    else:
        log(f"Записано в {repo} (без отправки в GitHub): {', '.join(done)}.")
    return done


def withdraw(version: str, repo: Path, seed: bytes, push: bool = True, log=print) -> bool:
    """Снять опубликованный пакет version: убрать запись из latest.json (подписать заново) и файл из packages/,
    git commit и push. False — такой версии в списке нет."""
    payload = read_payload(repo, seed)
    entries = list(payload.get("packages") or [])
    keep = [e for e in entries if str(e.get("version")) != str(version)]
    if len(keep) == len(entries):
        log(f"Версии {version} в списке нет — снимать нечего.")
        return False
    gone = [e for e in entries if str(e.get("version")) == str(version)]
    latest = max((str(e["version"]) for e in keep), key=updater.parse_version, default=None)
    payload = dict(payload, packages=keep, latest=latest, published=datetime.now().strftime("%Y-%m-%d %H:%M"))
    (repo / update_online.INDEX_FILE).write_bytes(update_online.index_bytes(update_online.sign_index(payload, seed)))
    files = [str(e["file"]) for e in gone if e.get("file")]
    for rel in files:
        if (repo / rel).exists():
            git(repo, "rm", "--quiet", "--", rel)
    git(repo, "add", "--", update_online.INDEX_FILE)
    git(repo, "commit", "--quiet", "-m", f"FX Terminal {version}: пакет снят")
    if push:
        git(repo, "push", "--quiet", "origin", "HEAD")
    log(f"Снят пакет {version}; последняя версия в списке — {latest or 'нет'}.")
    return True


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Публикация обновлений FX Terminal в " + update_online.REPO)
    ap.add_argument("packages", nargs="*", help="пакеты fx_update_*.zip; без них — новые из «Загрузок»")
    ap.add_argument("--init", action="store_true", help="создать ключ подписи (один раз)")
    ap.add_argument("--key", action="store_true", help="показать открытый ключ")
    ap.add_argument("--withdraw", metavar="ВЕРСИЯ", help="снять опубликованный пакет этой версии")
    ap.add_argument("--repo", default=str(Path.home() / "fx-terminal-updates"), help="локальная копия репозитория")
    ap.add_argument("--downloads", default=str(Path.home() / "Downloads"), help="где искать пакеты")
    ap.add_argument("--dry-run", action="store_true", help="только показать, что будет опубликовано")
    ap.add_argument("--no-push", action="store_true", help="записать в локальную копию, но не отправлять")
    ap.add_argument("--engine-wheel", metavar="КОЛЕСО", help="готовый модуль Rust для пакетов с пересборкой — "
                    "из этого колеса fx_engine-*.whl (по умолчанию — колесо maturin из fx_engine_rs)")
    ap.add_argument("--no-engine", action="store_true", help="не добавлять готовый модуль Rust в пакеты")
    args = ap.parse_args(argv)
    try:
        if args.init:
            pub = init_key()
            print(f"Ключ подписи создан: {key_path()}\nСделайте его копию (флешка) и никому не отправляйте.\n"
                  f"Открытый ключ (его можно отправить — он нужен терминалу):\n    {public_text(pub)}")
            return 0
        seed = load_key()
        pub = public_text(ed25519_lite.public_key(seed))
        if args.key:
            print(f"Открытый ключ: {pub}\nНомер ключа: {update_online.key_id(ed25519_lite.public_key(seed))}")
            return 0
        if pub not in update_online.PUBLIC_KEYS:
            print("Внимание: этого ключа нет в терминале (update_online.PUBLIC_KEYS) — терминалы не примут "
                  "опубликованное, пока ключ не добавлен пакетом, поставленным вручную.")
        repo = Path(args.repo)
        if args.withdraw:
            ensure_repo(repo)
            return 0 if withdraw(args.withdraw, repo, seed, push=not args.no_push) else 1
        if not args.dry_run:
            ensure_repo(repo)
        elif not (repo / ".git").exists():
            raise PublishError(f"для пробного запуска нужна копия репозитория в {repo}")
        packages = [Path(p) for p in args.packages]
        if not packages:
            latest = read_payload(repo, seed).get("latest")
            packages = find_downloads(Path(args.downloads), latest)
            if not packages:
                print(f"В {args.downloads} нет пакетов новее {latest or 'опубликованных'}.")
                return 0
            print("Нашёл в «Загрузках»: " + ", ".join(p.name for p in packages))
        publish(packages, repo, seed, dry_run=args.dry_run, push=not args.no_push, engine=not args.no_engine,
                wheel=Path(args.engine_wheel) if args.engine_wheel else None)
        return 0
    except (PublishError, updater.UpdateError) as exc:
        print(f"Не опубликовано: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
