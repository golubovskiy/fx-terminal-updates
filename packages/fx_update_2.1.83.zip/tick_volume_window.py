"""
Окно «Тики Bid/Ask» — аналог QUIK-индикатора TICK_BID_ASK_VOLUME.

    ASK (покупки по Ask) — вверх, зелёным
    BID (продажи по Bid) — вниз, красным
    повторы (одинаковые сделки одной стороны) — бирюзовым / розовым
    ★ — крупная сделка (qty >= порога), подсказка при наведении
    Шкала времени с секундными засечками, вертикальная сетка по 5 с.

Источник данных — сделки одного инструмента (Finam SubscribeLatestTrades, сторона
сделки — из поля side) через подписку в MarketDataHub: все окна одного инструмента
и другие вкладки делят один поток у брокера, переподключение и отсев повторов — в шлюзе.
Часы окна сверяются с сервером Finam отдельно (ClockSyncWorker).

Подключение к терминалу — см. gui_app: меню «Окна → Тики Bid/Ask», панели «Тики»
в рабочих пространствах (до 25 окон, tick_volume_manager.MAX_WINDOWS).
"""

from __future__ import annotations

import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
import pyqtgraph as pg
from PySide6 import QtCore, QtGui, QtWidgets

import fx_theme
from tick_bars_item import DOWN, UP, VolumeBarsItem
from tick_volume_core import (
    REPEAT_TAG_TTL_SEC,
    SIDE_BUY,
    SIDE_SELL,
    TickAggregator,
    parse_timestamp,
)

ASK_COLOR = QtGui.QColor(46, 204, 85)        # зелёный — покупки по Ask
BID_COLOR = QtGui.QColor(230, 30, 30)        # красный — продажи по Bid
REP_ASK_COLOR = QtGui.QColor(64, 220, 205)   # бирюзовый — повторяющиеся покупки
REP_BID_COLOR = QtGui.QColor(255, 105, 180)  # розовый — повторяющиеся продажи
LARGE_COLOR = QtGui.QColor(255, 60, 200)
_BASE_COLORS = {"ASK_COLOR": ASK_COLOR, "BID_COLOR": BID_COLOR, "REP_ASK_COLOR": REP_ASK_COLOR,
                "REP_BID_COLOR": REP_BID_COLOR, "LARGE_COLOR": LARGE_COLOR}
CLOCK_PX = 15                   # часы окна по умолчанию, px («Шрифты» → «Часы в окне «Тики»» — свой размер)


def _user_look() -> dict:
    """Свои цвета и шрифты окна (2.1.83): «Настройки» → «Цвета» → «Тики Bid/Ask» и «Шрифты» (appearance).
    Бары (ASK, BID, повторы, крупная сделка) — цвета модуля (ASK_COLOR …): их читают столбцы, легенда, подсказки
    и итоги; фон графика, часы (цвет и размер), текст (подписи шкал) и размер шрифта шкал — в словаре. Читается при
    создании окна: открытые окна получают новые цвета после перезапуска; фон и текст самого окна — сразу, стилем
    (appearance.window_qss)."""
    look = {"plot_bg": fx_theme.chart_color("bg"), "clock": fx_theme.chart_color("clock"), "clock_px": CLOCK_PX,
            "axis_text": None, "axis_pt": 0}
    try:
        import appearance
        user = appearance.overrides()
        prefs = appearance.load_fonts()
    except Exception:
        return look
    for key, name in (("ticks.ask", "ASK_COLOR"), ("ticks.bid", "BID_COLOR"), ("ticks.rep_ask", "REP_ASK_COLOR"),
                      ("ticks.rep_bid", "REP_BID_COLOR"), ("ticks.large", "LARGE_COLOR")):
        globals()[name] = QtGui.QColor(user[key]) if key in user else _BASE_COLORS[name]
    look["plot_bg"] = user.get("ticks.plot_bg") or look["plot_bg"]
    look["clock"] = user.get("ticks.clock") or look["clock"]
    look["clock_px"] = prefs.ticks_clock_px or CLOCK_PX
    look["axis_pt"] = prefs.ticks_pt
    if "ticks.text" in user:
        look["axis_text"] = fx_theme.shades(QtGui.QColor(user.get("ticks.bg") or fx_theme.BG_WINDOW).name(),
                                            QtGui.QColor(user["ticks.text"]).name())["TEXT_DIM"]
    return look


def _style_axes(plot, look: dict) -> None:
    """Подписи шкал графика окна: свой цвет текста и размер шрифта (если заданы)."""
    for name in ("bottom", "right"):
        axis = plot.getAxis(name)
        if look.get("axis_text"):
            axis.setTextPen(pg.mkPen(look["axis_text"]))
        if look.get("axis_pt"):
            font = QtGui.QFont(axis.font() if hasattr(axis, "font") else QtGui.QFont())
            font.setPointSize(int(look["axis_pt"]))
            axis.setStyle(tickFont=font)

BUCKET_CHOICES = [("Тиковый", 0), ("1 с", 1), ("2 с", 2), ("5 с", 5), ("10 с", 10), ("30 с", 30), ("1 мин", 60)]
WINDOW_CHOICES = [("1 мин", 60), ("5 мин", 300), ("15 мин", 900), ("30 мин", 1800), ("1 час", 3600)]
# В тиковом режиме «окно» — число последних сделок на экране.
TICK_WINDOW_CHOICES = [("100 тиков", 100), ("200 тиков", 200), ("500 тиков", 500),
                       ("1000 тиков", 1000), ("2000 тиков", 2000), ("5000 тиков", 5000)]
_TICK_SPACINGS = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000]

# «Лупа»: отдельная панель слева с крупным планом недавнего отрезка и своей шкалой объёма.
LUPA_SPAN_CHOICES = [("30 с", 30), ("1 мин", 60), ("2 мин", 120), ("3 мин", 180), ("5 мин", 300)]
LUPA_TICK_SPAN_CHOICES = [("50 тиков", 50), ("100 тиков", 100), ("200 тиков", 200), ("300 тиков", 300), ("500 тиков", 500)]
LUPA_AUTO_K = 3.0               # автополоса = K × среднее значение столбца за период лупы
# Шкала объёма «липкая» (sticky_limit, с 2.0.80): граница по объёму меняется только когда столбцы в неё не влезают
# или стали заметно ниже (STICKY_SHRINK), и встаёт на круглое число. Раньше она пересчитывалась на каждом кадре
# (×1.15 от наибольшего столбца) — шкалы обоих графиков окна перерисовывались 4 раза в секунду: замер 03.11 —
# два окна «Тики» ≈ 110 мс/с GUI, из них оси ≈ 40 мс/с.
STICKY_SHRINK = 0.7
_NICE_MANTISSAS = (1.0, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0)


def nice_ceil(value: float) -> float:
    """Ближайшее сверху «круглое» число: 1 / 1.2 / 1.5 / 2 / 2.5 / 3 / 4 / 5 / 6 / 8 × 10^k."""
    if value <= 0:
        return 1.0
    exp = 10.0 ** np.floor(np.log10(value))
    for mant in _NICE_MANTISSAS:
        if mant * exp >= value * (1 - 1e-9):
            return float(mant * exp)
    return float(10.0 * exp)


def sticky_limit(current: float | None, need: float) -> float:
    """Граница шкалы: прежняя, пока need в неё влезает и не меньше STICKY_SHRINK от неё, иначе — nice_ceil(need)."""
    if current is not None and current > 0 and STICKY_SHRINK * current <= need <= current:
        return current
    return nice_ceil(need)


IDLE_MARGIN_SEC = 5.0       # запас к ширине окна, после которого последний столбец точно ушёл за левый край


def chart_moves(now: float, last_trade: float | None, span_sec: float, repeats_alive: bool) -> bool:
    """Сдвинется ли что-то на графике «Тики», если перерисовать его по часам: столбцы ещё в окне (span_sec —
    ширина окна по времени, с лупой и «максимумом за минуту»), или горят теги повторов. Нет — ночью и в паузы
    торгов окно не прокручивается вхолостую (замер 07.11: два окна без единой сделки — 4 полные перерисовки
    в секунду каждое, ~35–40 мс GUI в секунду на окно)."""
    if repeats_alive:
        return True
    if last_trade is None:
        return False
    return now - last_trade <= span_sec + IDLE_MARGIN_SEC
MIN_BAR_PX = 1.3                # столбец не тоньше этого числа пикселей (иначе тонкие столбцы «мигают»)
LUPA_WIDTH_FRACTION = 0.30      # доля ширины окна под лупу по умолчанию
LUPA_HANDLE_COLOR = "#7d1f8c"   # фиолетовый разделитель, как на макете
LUPA_HANDLE_WIDTH = 2           # px — тонкая полоса (можно тянуть)
LUPA_AXIS_MIN_WIDTH = 22        # минимальная ширина шкалы лупы, px (дальше подстраивается под цифры)
LUPA_WHEEL_STEP = 1.15          # во сколько раз меняется полоса за один щелчок колеса над шкалой лупы

DEFAULT_SYMBOL = "USDRUBF@RTSX"
# Задержка сделок в строке состояния (раз в секунду): «биржа → окно» по часам сервера и сколько из неё —
# очередь самого терминала (MarketDataHub.trade_queue_lag). Добавлено 29.10: бары отставали от часов
# на минуту, и по снимку было не понять — Finam прислал поздно или терминал не успел разобрать очередь.
LAG_WARN_SEC = 5.0          # задержка больше — строка в журнал (не чаще раза в LAG_LOG_EVERY_SEC)
LAG_LOG_EVERY_SEC = 30.0
NO_TRADES_SEC = 10.0        # дольше без сделок — в строке состояния «сделок нет N с»
FEED_LAG_WARN_SEC = 10.0    # задержка больше — строка состояния жёлтая: «⚠ лента Finam отстаёт на N с»
FEED_LAG_COLOR = "#e0b030"

UI_REFRESH_MS = 250        # перерисовка графика не чаще 4 раз в секунду
MAX_REPEAT_TAGS = 4         # сколько разных объёмов повторов показывать на шкале с каждой стороны
MINUTE_MAX_SEC = 60         # окно «максимум за минуту» (скользящее, по времени сервера)
MARK_GAP_PX = 12            # на сколько пикселей метка ★ выше (ниже) края столбца
MARK_LABEL_DX_PX = 9        # отступ подписи времени от звёздочки
MAX_MARK_LABELS = 80        # ограничение числа подписей на экране
CLOCK_TICK_MS = 100         # обновление часов 10 раз в секунду (миллисекунды видны; при 50 мс
                            # часы давали ~20 перерисовок окна в секунду — ~50 мс ЦП в секунду, замер 27.10)
CLOCK_SYNC_MS = 60_000      # как часто сверяем часы с сервером Finam
CLOCK_FIRST_SYNC_MS = 1500  # первая сверка — после старта стрима, чтобы не толкаться с gRPC
STREAM_START_DELAY_MS = 300  # пауза перед стартом gRPC-стрима (как и в остальном терминале)
STREAM_START_STAGGER_MS = 350  # дополнительная пауза на каждое следующее окно (до 10 копий)

_NICE_SPACINGS = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600, 7200]


class _StreamThreads(QtCore.QObject):
    """Хранитель фоновых потоков стримов «Тики».

    Поток НЕ принадлежит окну: если окно (панель) удаляется, а gRPC-стрим ещё не успел
    остановиться (cancel на Windows бывает небыстрым, а во время открытия стрима отменять
    вообще нечего), Qt уничтожил бы работающий QThread вместе с окном — это аварийное
    завершение всего Python («QThread: Destroyed while thread is still running»).
    Здесь поток доживает сам и удаляется, когда действительно закончился."""

    def __init__(self):
        super().__init__()
        self._items: dict[int, tuple[QtCore.QThread, QtCore.QObject]] = {}

    def add(self, thread: QtCore.QThread, worker: QtCore.QObject) -> None:
        self._items[id(thread)] = (thread, worker)
        thread.finished.connect(self._on_finished)

    @QtCore.Slot()
    def _on_finished(self) -> None:
        thread = self.sender()
        item = self._items.pop(id(thread), None)
        if item is not None:
            item[1].deleteLater()
            item[0].deleteLater()

    def stop_all(self, timeout_ms: int = 3000) -> None:
        """Выход из терминала: остановить все стримы и дождаться потоков (иначе падение при выходе)."""
        deadline = time.monotonic() + timeout_ms / 1000
        items = list(self._items.values())
        for thread, worker in items:
            request_stop = getattr(worker, "request_stop", None)
            if request_stop is not None:
                request_stop()
            thread.quit()
        for thread, _worker in items:
            left = int(max(0.0, deadline - time.monotonic()) * 1000)
            if thread.isRunning() and not thread.wait(max(left, 1)):
                print("[предупреждение] поток «Тики Bid/Ask» не завершился при выходе", file=sys.stderr)


_threads: _StreamThreads | None = None


def stream_threads() -> _StreamThreads:
    """Общий хранитель потоков (создаётся в GUI-потоке при первом стриме)."""
    global _threads
    if _threads is None:
        _threads = _StreamThreads()
    return _threads


class ClockSyncWorker(QtCore.QObject):
    """Одна сверка с AssetsService/Clock в фоне: offset = время сервера - время ПК."""

    done = QtCore.Signal(float, float)   # offset_sec, rtt_sec
    failed = QtCore.Signal(str)
    finished = QtCore.Signal()

    def __init__(self, client):
        super().__init__()
        self.client = client

    @QtCore.Slot()
    def run(self) -> None:
        try:
            t0 = time.time()
            data = self.client.get_server_time()
            t1 = time.time()
            server_ts = parse_timestamp((data or {}).get("timestamp"))
            if server_ts is None:
                raise ValueError(f"в ответе Clock нет timestamp: {data!r}")
            rtt = t1 - t0
            # Серверное время относится к середине запроса.
            self.done.emit(server_ts - (t0 + t1) / 2, rtt)
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()


class SecondsAxis(pg.AxisItem):
    """Ось времени (epoch-секунды) в выбранном часовом поясе, засечки по секундам."""

    def __init__(self, tz_name: str = "Europe/Moscow"):
        super().__init__(orientation="bottom")
        self._tz = ZoneInfo(tz_name)
        self._tick_lookup = None  # функция «номер сделки -> Tick»; не None = тиковый режим

    def set_tick_mode(self, lookup) -> None:
        self._tick_lookup = lookup
        self.picture = None
        self.update()

    def set_timezone(self, tz_name: str) -> None:
        try:
            self._tz = ZoneInfo(tz_name)
        except Exception:
            return
        self.picture = None
        self.update()

    def tickSpacing(self, minVal, maxVal, size):
        span = maxVal - minVal
        if span <= 0 or size <= 0:
            return [(1, 0)]
        if self._tick_lookup is not None:
            px_per_tick = size / span
            major = next((n for n in _TICK_SPACINGS if n * px_per_tick >= 70), _TICK_SPACINGS[-1])
            levels = [(major, 0)]
            minor = next(
                (n for n in _TICK_SPACINGS if n < major and major % n == 0 and n * px_per_tick >= 7),
                None,
            )
            if minor:
                levels.append((minor, 0))
            return levels
        px_per_sec = size / span
        major = next((n for n in _NICE_SPACINGS if n * px_per_sec >= 62), _NICE_SPACINGS[-1])
        levels = [(major, 0)]
        minor = next(
            (n for n in _NICE_SPACINGS if n < major and major % n == 0 and n * px_per_sec >= 6),
            None,
        )
        if minor:
            levels.append((minor, 0))
        return levels

    def tickStrings(self, values, scale, spacing):
        fmt = "%M:%S"  # часы убраны: только минуты и секунды
        out = []
        if self._tick_lookup is not None:
            # Тиковый режим: подпись — время сделки с этим номером.
            for value in values:
                tick = self._tick_lookup(int(round(value)))
                if tick is None:
                    out.append("")
                    continue
                try:
                    out.append(datetime.fromtimestamp(tick[0], self._tz).strftime(fmt))
                except (OverflowError, OSError, ValueError):
                    out.append("")
            return out
        for value in values:
            try:
                out.append(datetime.fromtimestamp(value, self._tz).strftime(fmt))
            except (OverflowError, OSError, ValueError):
                out.append("")
        return out


class AbsAxis(pg.AxisItem):
    """
    Ось объёма: BID лежит в минусе, но подписи — по модулю. Поверх шкалы — «ценники»
    (максимум за минуту и объём повторов). Ширина шкалы подстраивается под содержимое:
    самые длинные подписи делений или самый широкий ряд ценников.
    """

    MIN_WIDTH = 30
    SHRINK_DELAY_SEC = 2.0   # сужаем шкалу не сразу, чтобы график не «дёргался»
    SHRINK_STEP_PX = 8       # и только если запас больше этого

    LABEL_PAD = 8    # запас справа/слева от цифр делений, px

    def __init__(self, *args, min_width: int | None = None, label_pad: int | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        if min_width is not None:
            self.MIN_WIDTH = min_width     # у лупы — уже, чем у основной шкалы
        if label_pad is not None:
            self.LABEL_PAD = label_pad
        self.setStyle(tickTextOffset=3)   # цифры ближе к линии шкалы (по умолчанию 5 px)
        self._tags: list[tuple] = []
        self.wheel_callback = None   # функция(delta) — колесо мыши над шкалой (у лупы меняет «Полосу»)
        self._cur_width = self.MIN_WIDTH
        self._last_grow = 0.0
        self.setWidth(self._cur_width)

    def wheelEvent(self, event) -> None:
        if self.wheel_callback is None:
            super().wheelEvent(event)
            return
        delta = event.delta() if hasattr(event, "delta") else event.angleDelta().y()
        self.wheel_callback(float(delta))
        event.accept()

    def set_tags(self, tags) -> None:
        """
        tags: [(значение_на_оси, текст, цвет_фона[, цвет_текста])] — «ценники» прямо на шкале.
        Теги, попадающие на один уровень, раскладываются в ряд вправо.
        """
        tags = list(tags)
        if tags == self._tags:
            # Те же ценники — шкалу не перерисовываем (при сдвиге графика её перерисует pyqtgraph);
            # ширину всё равно сверяем: у делений могло прибавиться цифр.
            self.fit_width()
            return
        self._tags = tags
        self.fit_width()
        self.update()

    def tickStrings(self, values, scale, spacing):
        return [f"{abs(v):g}" for v in values]

    # ---------------------------------------------------------- раскладка

    def _bold_metrics(self) -> QtGui.QFontMetrics:
        font = QtGui.QFont(self.font())
        font.setBold(True)
        return QtGui.QFontMetrics(font)

    def _layout(self, metrics: QtGui.QFontMetrics):
        """[(tag, rect)] в координатах оси; теги одного уровня сдвигаются вправо."""
        view = self.linkedView()
        result: list[tuple[tuple, QtCore.QRectF]] = []
        if view is None:
            return result
        drawn: list[QtCore.QRectF] = []
        for tag in self._tags:
            value, text = tag[0], tag[1]
            local = self.mapFromScene(view.mapViewToScene(QtCore.QPointF(0.0, value)))
            width = metrics.horizontalAdvance(text) + 8
            height = metrics.height() + 2
            rect = QtCore.QRectF(1.0, local.y() - height / 2, width, height)
            for _ in range(5):  # на том же уровне уже есть тег — сдвигаем вправо
                hit = next((r for r in drawn if r.intersects(rect)), None)
                if hit is None:
                    break
                rect.moveLeft(hit.right() + 2)
            drawn.append(rect)
            result.append((tag, rect))
        return result

    def fit_width(self) -> None:
        """Ширина = max(подписи делений, самый широкий ряд ценников) + небольшой запас."""
        view = self.linkedView()
        if view is None:
            return
        # подписи делений: самое длинное число в видимом диапазоне
        (y0, y1) = view.viewRange()[1]
        digits = len(str(int(max(abs(y0), abs(y1), 1))))
        label_w = QtGui.QFontMetrics(self.font()).horizontalAdvance("0" * digits) + self.LABEL_PAD

        metrics = self._bold_metrics()
        tags_w = max((rect.right() for _tag, rect in self._layout(metrics)), default=0.0) + 2

        need = int(max(self.MIN_WIDTH, label_w, tags_w))
        need = (need + 5) // 6 * 6  # шаг 6 px — меньше мелких подрагиваний
        now = time.monotonic()
        if need > self._cur_width:
            self._cur_width = need
            self._last_grow = now
            self.setWidth(need)
        elif (
            need < self._cur_width - self.SHRINK_STEP_PX
            and now - self._last_grow >= self.SHRINK_DELAY_SEC
        ):
            self._cur_width = need
            self.setWidth(need)

    # ------------------------------------------------------------ рисование

    def paint(self, painter, opt, widget):
        super().paint(painter, opt, widget)
        if not self._tags or self.linkedView() is None:
            return
        painter.save()
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)
        for tag, rect in self._layout(painter.fontMetrics()):
            color = tag[2]
            text_color = tag[3] if len(tag) > 3 else QtGui.QColor("#ffffff")
            painter.fillRect(rect, color)
            painter.setPen(text_color)
            painter.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, tag[1])
        painter.restore()


class DragLabel(QtWidgets.QLabel):
    """Метка, которую можно перетащить мышью в пределах родительского окна (двойной клик — сброс)."""

    moved = QtCore.Signal()
    reset_requested = QtCore.Signal()

    def __init__(self, text: str, parent: QtWidgets.QWidget):
        super().__init__(text, parent)
        self._grab = None
        self.setCursor(QtCore.Qt.CursorShape.SizeAllCursor)

    def mousePressEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self._grab = event.position().toPoint()
        event.accept()

    def mouseMoveEvent(self, event: QtGui.QMouseEvent) -> None:
        parent = self.parentWidget()
        if self._grab is None or parent is None:
            return
        pos = self.mapToParent(event.position().toPoint() - self._grab)
        x = max(0, min(pos.x(), parent.width() - self.width()))
        y = max(0, min(pos.y(), parent.height() - self.height()))
        self.move(x, y)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:
        if self._grab is not None:
            self._grab = None
            self.moved.emit()
        event.accept()

    def mouseDoubleClickEvent(self, event: QtGui.QMouseEvent) -> None:
        self.reset_requested.emit()
        event.accept()


class ClockLabel(DragLabel):
    """Часы сервера поверх окна: рисуют себя сами в прямоугольнике постоянного размера. QLabel.setText
    10 раз в секунду пересчитывал размер и раскладку окна (замер 28.10: плавающее окно «Тиков» ~12
    перерисовок в секунду по 4–5 мс даже без сделок)."""

    SAMPLE = "88:88:88.888"

    def __init__(self, text: str, parent: QtWidgets.QWidget):
        super().__init__("", parent)
        self._clock_text = text

    def set_clock_text(self, text: str) -> None:
        if text != self._clock_text:
            self._clock_text = text
            self.update()

    def clock_text(self) -> str:
        return self._clock_text

    def sizeHint(self) -> QtCore.QSize:
        fm = self.fontMetrics()
        return QtCore.QSize(fm.horizontalAdvance(self.SAMPLE) + 4, fm.height() + 2)

    def minimumSizeHint(self) -> QtCore.QSize:
        return self.sizeHint()

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        painter = QtGui.QPainter(self)
        painter.setFont(self.font())               # шрифт и цвет — из стиля метки (setStyleSheet)
        painter.setPen(self.palette().color(QtGui.QPalette.ColorRole.WindowText))
        painter.drawText(self.rect(), QtCore.Qt.AlignmentFlag.AlignCenter, self._clock_text)
        painter.end()


class TickVolumeWindow(QtWidgets.QWidget):
    SETTINGS_PREFIX = "tick_volume/"   # у окна №1; у остальных — tick_volume/w<N>/
    closed = QtCore.Signal(int)

    def __init__(
        self,
        host,
        picker_cls,
        mic_labels: dict,
        type_labels: dict,
        symbols: list[str],
        friendly_fn,
        index: int = 1,
        clock=None,
        initial_symbol: str = "",
        embedded: bool = False,
    ):
        # embedded=True — окно живёт панелью рабочего пространства (докинг): обычный дочерний
        # виджет без своей рамки; геометрию и положение ведёт докинг, а не окно.
        if embedded:
            super().__init__(None)
        else:
            super().__init__(host, QtCore.Qt.WindowType.Window)
        self._embedded = embedded
        self._look = _user_look()          # свои цвета баров, фон графика, часы, шкалы (2.1.83)
        # Отдельное окно удаляется при закрытии само. Встроенное — НЕТ: оно лежит внутри
        # док-панели QtAds, которая хранит на него обычный указатель; самоудаление оставило бы
        # панели «висячую» ссылку, и следующее обращение к ней роняло Python. Встроенное окно
        # удаляет оболочка вместе с панелью (remover менеджера → discard_dock).
        if not embedded:
            self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.index = index
        # У каждой копии свои настройки (инструмент, параметры, геометрия).
        # Окно №1 использует прежний префикс — настройки одиночного окна сохраняются.
        self.SETTINGS_PREFIX = "tick_volume/" if index == 1 else f"tick_volume/w{index}/"
        self._clock = clock
        self._initial_symbol = initial_symbol
        self.host = host
        self._picker_cls = picker_cls
        self._mic_labels = mic_labels
        self._type_labels = type_labels
        self._friendly = friendly_fn
        self._settings: QtCore.QSettings = host.settings

        self._hub_sub = None              # подписка на сделки в хабе терминала
        self._generation = 0          # отличает актуальный стрим от устаревшего
        self._active_symbol = ""
        self._status_text = ""
        self._dirty = False
        self._link_applying = False   # идёт смена инструмента по команде хаба — обратно хабу не сообщаем
        self._hover_text = ""
        self._clock_last_sec = 0
        self._idle_drawn = False      # сделок в окне нет, последний кадр нарисован — по часам не перерисовываем
        self._lag = None                 # (задержка биржа→окно, очередь терминала, monotonic прихода)
        self._lag_logged = 0.0

        self.aggregator = TickAggregator(
            bucket_sec=self._get_int("bucket", 1),
            min_volume=self._get_int("min_volume", 1),
            large_volume=self._get_int("large_volume", 20),
            repeat_min=self._saved_repeat_min(),
        )

        self._tick_mode = self.aggregator.bucket_sec == 0
        self.setWindowTitle(f"Тики Bid/Ask #{index}")
        if not embedded:
            self.resize(1100, 620)
        self._build_ui(symbols)
        self._restore_state()
        # Оформление берётся из темы приложения (fx_theme.stylesheet, app.setStyleSheet);
        # свойство fxWindow даёт окну фон по текущей теме, objectName «fxTickWindow» — свои фон, текст и шрифт
        # окна из «Настроек» (appearance.window_qss, 2.1.83).
        self.setObjectName("fxTickWindow")
        self.setProperty("fxWindow", True)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_StyledBackground, True)
        self._fit_controls()

        self._refresh_timer = QtCore.QTimer(self)
        self._refresh_timer.timeout.connect(self._redraw_tick)
        self._refresh_timer.start(UI_REFRESH_MS)

        self._clock_timer = QtCore.QTimer(self)
        self._clock_timer.timeout.connect(self._tick_clock)
        self._clock_timer.start(CLOCK_TICK_MS)

        if self._clock is not None:
            self._clock.changed.connect(self._on_clock_changed)
            self._on_clock_changed(self._clock.tooltip)

        # Связь окон по цветным группам: регистрируемся, когда окно полностью построено
        # (инструмент уже выбран) — хаб читает его через link_symbol().
        link_hub = getattr(self.host, "link_hub", None)
        if link_hub is not None:
            link_hub.register(self)

    # ------------------------------------------------------------ настройки

    def _get_int(self, key: str, default: int) -> int:
        try:
            return int(self._settings.value(self.SETTINGS_PREFIX + key, default))
        except (TypeError, ValueError):
            return default

    def _saved_repeat_min(self) -> int:
        on = str(self._settings.value(self.SETTINGS_PREFIX + "repeat_on", "true")).lower() != "false"
        return self._get_int("repeat_min", 3) if on else 0

    def _set(self, key: str, value) -> None:
        self._settings.setValue(self.SETTINGS_PREFIX + key, value)

    # ------------------------------------------------------------------ UI

    def _build_ui(self, symbols: list[str]) -> None:
        # --- строка 1: инструмент ---
        self.symbol_combo = QtWidgets.QComboBox()
        self.symbol_combo.setMinimumWidth(170)
        for symbol in symbols:
            self.symbol_combo.addItem(self._friendly(symbol), userData=symbol)

        self.catalog_btn = QtWidgets.QPushButton("Каталог…")
        self.catalog_btn.setToolTip("Выбрать инструмент из полного каталога брокера")
        self.catalog_btn.clicked.connect(self._open_catalog)

        self.repeat_check = QtWidgets.QCheckBox("Повторы")
        self.repeat_check.setToolTip(
            "Выделять сделки одинакового объёма и стороны, повторяющиеся\n"
            "подряд с интервалом до 5 с: бирюзовым — покупки, розовым — продажи"
        )
        self.repeat_check.setChecked(self.aggregator.repeat_min > 0)
        self.repeat_spin = QtWidgets.QSpinBox()
        self.repeat_spin.setRange(3, 50)
        self.repeat_spin.setPrefix("≥ ")
        self.repeat_spin.setSuffix(" сделок")
        self.repeat_spin.setKeyboardTracking(False)
        self.repeat_spin.setToolTip("Со скольких сделок одного объёма и стороны (интервал между соседними — "
                                    "до 5 с, чужие сделки между ними не мешают) серия считается повтором")
        self.repeat_spin.setValue(self._get_int("repeat_min", 3))
        self.repeat_spin.setEnabled(self.repeat_check.isChecked())

        self.lupa_btn = QtWidgets.QPushButton(" Лупа")
        self.lupa_btn.setIcon(fx_theme.icon("lupa"))
        self.lupa_btn.setIconSize(QtCore.QSize(14, 14))
        self.lupa_btn.setCheckable(True)
        self.lupa_btn.setChecked(str(self._settings.value(self.SETTINGS_PREFIX + "lupa_on", "false")).lower() == "true")
        self.lupa_btn.setToolTip(
            "Панель слева: крупный план недавнего отрезка со своей шкалой объёма.\n"
            "Столбцы выше полосы уходят за границу — средние значения видны лучше.\n"
            "Время синхронизировано с основным графиком."
        )
        self._paused = False
        self._lupa_on = self.lupa_btn.isChecked()
        self._lupa_sized = False
        self._lupa_band_last = 10.0
        self.lupa_cfg_btn = QtWidgets.QPushButton()
        self.lupa_cfg_btn.setIcon(fx_theme.icon("gear"))
        self.lupa_cfg_btn.setIconSize(QtCore.QSize(14, 14))
        self.lupa_cfg_btn.setFixedWidth(28)
        self.lupa_cfg_btn.setToolTip("Настройки лупы: период и полоса")
        self.lupa_cfg_btn.clicked.connect(self._toggle_lupa_settings)

        self.status_label = QtWidgets.QLabel("Не подключено")
        self.status_label.setStyleSheet(f"color: {fx_theme.TEXT_DIM};")

        # Квадрат группы связи окон (как в графике и стакане): окна одного цвета меняют инструмент
        # вместе. Остаётся на месте и при скрытых «Инструмент»/«Каталог…» — это способ сменить
        # инструмент через группу.
        link_hub = getattr(self.host, "link_hub", None)
        self.link_btn = link_hub.make_button(self) if link_hub is not None else None

        self.instr_label = QtWidgets.QLabel("Инструмент:")
        row1 = QtWidgets.QHBoxLayout()
        row1.addWidget(self.instr_label)
        row1.addWidget(self.symbol_combo)
        if self.link_btn is not None:
            row1.addWidget(self.link_btn)
        row1.addWidget(self.catalog_btn)
        row1.addSpacing(12)
        row1.addWidget(self.lupa_btn)
        row1.addWidget(self.lupa_cfg_btn)
        row1.addSpacing(12)
        row1.addWidget(self.status_label, 1)

        # --- строка 2: параметры (те же, что Settings в Lua-скрипте) ---
        self.min_spin = QtWidgets.QSpinBox()
        self.min_spin.setKeyboardTracking(False)  # пересчёт — по Enter/уходу фокуса, не на каждую цифру
        self.min_spin.setRange(0, 10_000_000)
        self.min_spin.setValue(int(self.aggregator.min_volume))
        self.min_spin.setToolTip("MinVolume: сделки меньше этого объёма (лотов) не учитываются")

        self.large_spin = QtWidgets.QSpinBox()
        self.large_spin.setKeyboardTracking(False)
        self.large_spin.setRange(0, 10_000_000)
        self.large_spin.setValue(int(self.aggregator.large_volume))
        self.large_spin.setToolTip("LargeTradeVolume: сделка от этого объёма помечается ★ (0 — выкл.)")

        self.large_check = QtWidgets.QCheckBox("Метки ★")
        self.large_check.setChecked(str(self._settings.value(self.SETTINGS_PREFIX + "large_on", "true")).lower() != "false")

        self.bucket_combo = QtWidgets.QComboBox()
        for label, value in BUCKET_CHOICES:
            self.bucket_combo.addItem(label, userData=value)
        self.bucket_combo.setCurrentIndex(max(0, self.bucket_combo.findData(self.aggregator.bucket_sec)))

        self.window_combo = QtWidgets.QComboBox()
        self._fill_window_combo()

        self.follow_check = QtWidgets.QCheckBox("Автопрокрутка")
        self.follow_check.setChecked(True)
        self.grid_check = QtWidgets.QCheckBox("Сетка")
        self.grid_check.setChecked(True)

        self.pause_btn = QtWidgets.QPushButton("Пауза")
        self.pause_btn.setCheckable(True)
        self.clear_btn = QtWidgets.QPushButton("Очистить")

        # Кнопка «Параметры»: интервал, окно, повторы, метки, автопрокрутка, сетка — в плавающей панели.
        self.clock_check = QtWidgets.QCheckBox("Часы")
        self.clock_check.setChecked(str(self._settings.value(self.SETTINGS_PREFIX + "clock_on", "true")).lower() != "false")
        self.hide_instr_check = QtWidgets.QCheckBox("Скрывать «Инструмент» и «Каталог»")
        self.hide_instr_check.setChecked(
            str(self._settings.value(self.SETTINGS_PREFIX + "hide_instrument", "false")).lower() == "true"
        )
        self.hide_instr_check.setToolTip(
            "Убирает из окна поле выбора инструмента и кнопку «Каталог…».\n"
            "Инструмент виден в заголовке окна и в строке статуса;\n"
            "сменить его можно через цветной квадрат связи окон или сняв галочку."
        )
        self.view_btn = QtWidgets.QPushButton(" Параметры")
        self.view_btn.setIcon(fx_theme.icon("sliders"))
        self.view_btn.setIconSize(QtCore.QSize(14, 14))
        self.view_btn.setToolTip("Интервал и окно, повторы, метки ★, автопрокрутка, сетка, часы, скрытие инструмента")
        self.view_btn.clicked.connect(lambda: self._toggle_panel(self.view_dlg, self.view_btn, align_right=True))
        self.view_dlg = QtWidgets.QDialog(self, QtCore.Qt.WindowType.Tool)
        self.view_dlg.setWindowTitle("Параметры")
        form = QtWidgets.QFormLayout(self.view_dlg)
        form.addRow("Интервал:", self.bucket_combo)
        form.addRow("Окно:", self.window_combo)
        repeat_row = QtWidgets.QHBoxLayout()
        repeat_row.addWidget(self.repeat_check)
        repeat_row.addWidget(self.repeat_spin)
        form.addRow(repeat_row)
        form.addRow(self.large_check)
        form.addRow(self.follow_check)
        form.addRow(self.grid_check)
        form.addRow(self.clock_check)
        form.addRow(self.hide_instr_check)

        row2 = QtWidgets.QHBoxLayout()
        row2.addWidget(QtWidgets.QLabel("Мин. объём:"))
        row2.addWidget(self.min_spin)
        row2.addWidget(QtWidgets.QLabel("Крупная ≥"))
        row2.addWidget(self.large_spin)
        row2.addStretch(1)
        row2.addWidget(self.view_btn)
        row2.addWidget(self.pause_btn)
        row2.addWidget(self.clear_btn)

        # --- график ---
        self.time_axis = SecondsAxis(getattr(self.host, "display_tz", "Europe/Moscow"))
        self.plot = pg.PlotWidget(
            axisItems={"bottom": self.time_axis, "right": AbsAxis(orientation="right")}
        )
        self.time_axis.set_tick_mode(self.aggregator.tick_at if self._tick_mode else None)
        self.plot.setBackground(self._look["plot_bg"])
        _style_axes(self.plot, self._look)
        # Шкала объёма — справа (левая ось скрыта).
        self.plot.hideAxis("left")
        self.plot.showAxis("right")
        # Ширина правой шкалы подстраивается сама (AbsAxis.fit_width) — под подписи и ценники.
        self._apply_grid(True)
        self.plot.setMouseEnabled(x=True, y=False)
        self.plot.setMenuEnabled(False)
        self.plot.setAntialiasing(True)    # тонкие столбцы рисуются полутонами, а не пропадают
        self.plot.addLine(y=0, pen=pg.mkPen("#4a4f5c", width=1))

        # Все столбцы — одним элементом (tick_bars_item.VolumeBarsItem): ASK вверх, BID вниз, поверх —
        # повторы (окрашенная часть столбца = объём повторяющихся сделок).
        self.bars = VolumeBarsItem(self._bar_layers())
        self.plot.addItem(self.bars)

        scatter_kwargs = dict(
            symbol="star", size=15, pen=pg.mkPen("#ffffff", width=0.6), brush=pg.mkBrush(LARGE_COLOR)
        )
        try:
            self.large_scatter = pg.ScatterPlotItem(
                hoverable=True, tip=self._mark_tip, **scatter_kwargs
            )
        except TypeError:  # старый pyqtgraph без hoverable/tip
            self.large_scatter = pg.ScatterPlotItem(**scatter_kwargs)
        self.plot.addItem(self.large_scatter)

        # Лучи от баров с максимальным объёмом за минуту к шкале справа.
        self.max_rays = {}
        for key, color in (("ask", ASK_COLOR), ("bid", BID_COLOR)):
            pen = pg.mkPen(color.lighter(130), width=1, style=QtCore.Qt.PenStyle.DashLine)
            ray = pg.PlotCurveItem(pen=pen)
            dot = pg.ScatterPlotItem(
                size=7, symbol="o", pen=pg.mkPen("#ffffff", width=0.8), brush=pg.mkBrush(color)
            )
            self.plot.addItem(ray, ignoreBounds=True)
            self.plot.addItem(dot, ignoreBounds=True)
            self.max_rays[key] = (ray, dot)

        # Подписи «мм:сс» рядом с метками ★ (пул переиспользуемых TextItem).
        self._mark_labels: list[pg.TextItem] = []

        self.legend_text = pg.TextItem(html=self._legend_html(), anchor=(0, 0))
        self.plot.addItem(self.legend_text, ignoreBounds=True)
        self.plot.getViewBox().sigRangeChanged.connect(lambda *_: self._place_legend())

        # Часы сервера Finam — плавающая метка поверх окна: по умолчанию в правом верхнем
        # углу чуть выше первой строки; перетаскивается мышью, двойной клик — на место.
        self.clock_label = ClockLabel("--:--:--.---", self)
        self.clock_label.setStyleSheet(
            f"color: {self._look['clock']}; background: transparent;"
            f"font-family: Consolas, 'Courier New', monospace; font-size: {self._look['clock_px']}px; font-weight: bold;"
        )
        self.clock_label.setToolTip("Время сервера Finam (ещё не синхронизировано)")
        self.clock_label.adjustSize()
        self.clock_label.moved.connect(self._on_clock_moved)
        self.clock_label.reset_requested.connect(self._reset_clock_pos)

        self.plot.scene().sigMouseMoved.connect(self._on_mouse_moved)
        self.plot.getViewBox().sigRangeChangedManually.connect(self._on_manual_range)

        self._build_lupa()

        # --- нижняя строка: итоги и подсказка под курсором ---
        self.summary_label = QtWidgets.QLabel("")
        self.hover_label = QtWidgets.QLabel("")
        self.hover_label.setStyleSheet(f"color: {fx_theme.TEXT_DIM};")
        bottom = QtWidgets.QHBoxLayout()
        bottom.addWidget(self.summary_label, 1)
        bottom.addWidget(self.hover_label)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(row1)
        layout.addLayout(row2)
        layout.addWidget(self.splitter, 1)
        layout.addLayout(bottom)

        # --- сигналы ---
        self.symbol_combo.currentIndexChanged.connect(self._on_symbol_changed)
        self.min_spin.valueChanged.connect(self._on_params_changed)
        self.large_spin.valueChanged.connect(self._on_params_changed)
        self.large_check.toggled.connect(self._on_params_changed)
        self.repeat_check.toggled.connect(self._on_params_changed)
        self.repeat_spin.valueChanged.connect(self._on_params_changed)
        self.bucket_combo.currentIndexChanged.connect(self._on_params_changed)
        self.window_combo.currentIndexChanged.connect(self._on_window_changed)
        self.follow_check.toggled.connect(lambda _on: self._mark_dirty())
        self.grid_check.toggled.connect(self._on_grid_toggled)
        self.pause_btn.toggled.connect(self._on_pause_toggled)
        self.clear_btn.clicked.connect(self._on_clear)
        self.clock_check.toggled.connect(self._on_clock_toggled)
        self.clock_label.setVisible(self.clock_check.isChecked())
        self.hide_instr_check.toggled.connect(self._on_hide_instrument_toggled)
        self._apply_hide_instrument(self.hide_instr_check.isChecked())
        self.lupa_btn.toggled.connect(self._on_lupa_toggled)
        self.lupa_span_combo.currentIndexChanged.connect(self._on_lupa_changed)
        self.lupa_band_spin.valueChanged.connect(self._on_lupa_changed)
        self.splitter.splitterMoved.connect(lambda *_: self._on_splitter_moved())
        self._apply_lupa_visibility()

    # ------------------------------------------------------------- лупа

    def _build_lupa(self) -> None:
        """Левая панель «Лупа» + фиолетовый разделитель; основной график — справа."""
        # строка настроек лупы (показывается только когда лупа включена)
        self.lupa_span_combo = QtWidgets.QComboBox()
        self.lupa_span_combo.setToolTip("За какой последний отрезок времени показывать лупу (правый край — как у основного графика)")
        self._fill_lupa_span_combo()
        self.lupa_band_spin = QtWidgets.QSpinBox()
        self.lupa_band_spin.setKeyboardTracking(False)
        self.lupa_band_spin.setRange(0, 10_000_000)
        self.lupa_band_spin.setSpecialValueText(f"авто ({LUPA_AUTO_K:g}× среднее)")
        self.lupa_band_spin.setSuffix(" лотов")
        self.lupa_band_spin.setValue(self._get_int("lupa_band", 0))
        self.lupa_band_spin.setToolTip(
            "Высота полосы лупы в лотах (вверх для ASK и вниз для BID).\n"
            "Столбцы выше уходят за границу. «Авто» — 3 × среднее значение столбца за период."
        )
        # Настройки лупы — в небольшом окне по кнопке ⚙ (применяются сразу), а не отдельной строкой.
        self.lupa_settings_dlg = QtWidgets.QDialog(self, QtCore.Qt.WindowType.Tool)
        self.lupa_settings_dlg.setWindowTitle("Настройки лупы")
        form = QtWidgets.QFormLayout(self.lupa_settings_dlg)
        form.addRow("Период:", self.lupa_span_combo)
        form.addRow("Полоса:", self.lupa_band_spin)
        hint = QtWidgets.QLabel(f"«Авто» — {LUPA_AUTO_K:g} × среднее значение столбца за период.\n"
                                "Столбцы выше полосы уходят за границу панели.\n"
                                "Колесо мыши над шкалой лупы тоже меняет полосу.")
        hint.setStyleSheet(f"color: {fx_theme.TEXT_DIM};")
        form.addRow(hint)

        # график лупы: своя шкала справа и своя ось времени
        self.lupa_time_axis = SecondsAxis(getattr(self.host, "display_tz", "Europe/Moscow"))
        self.lupa_time_axis.set_tick_mode(self.aggregator.tick_at if self._tick_mode else None)
        self.lupa_plot = pg.PlotWidget(
            axisItems={
                "bottom": self.lupa_time_axis,
                # узкая шкала: ширина = только цифры делений (она подстраивается сама)
                "right": AbsAxis(orientation="right", min_width=LUPA_AXIS_MIN_WIDTH, label_pad=6),
            }
        )
        self.lupa_plot.setBackground(self._look["plot_bg"])
        _style_axes(self.lupa_plot, self._look)
        self.lupa_plot.hideAxis("left")
        self.lupa_plot.showAxis("right")
        self.lupa_plot.setMouseEnabled(x=False, y=False)   # положение и масштаб задаются автоматически
        self.lupa_plot.setMenuEnabled(False)
        self.lupa_plot.setAntialiasing(True)
        self.lupa_plot.addLine(y=0, pen=pg.mkPen("#4a4f5c", width=1))
        self.lupa_plot.setMinimumWidth(150)
        self.lupa_plot.getAxis("right").wheel_callback = self._on_lupa_wheel
        self.lupa_plot.setToolTip("Колесо мыши над шкалой справа — менять полосу лупы")
        self.plot.setMinimumWidth(260)

        self.lupa_bars = VolumeBarsItem(self._bar_layers())
        self.lupa_plot.addItem(self.lupa_bars)

        self.lupa_caption = pg.TextItem(anchor=(0, 0))
        self.lupa_plot.addItem(self.lupa_caption, ignoreBounds=True)
        self._apply_grid(self.grid_check.isChecked())

        # сплиттер: слева лупа, справа основной график; разделитель — фиолетовый
        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        self.splitter.setHandleWidth(LUPA_HANDLE_WIDTH)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {LUPA_HANDLE_COLOR}; }}")
        self.splitter.addWidget(self.lupa_plot)
        self.splitter.addWidget(self.plot)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)

    # ------------------------------------------- ширина по содержимому

    def _fit_combo(self, combo: QtWidgets.QComboBox) -> None:
        """Ширина выпадающего списка = текущий текст (название инструмента) + стрелка."""
        metrics = combo.fontMetrics()
        current = metrics.horizontalAdvance(combo.currentText())
        combo.setFixedWidth(max(56, current + 38))
        widest = max((metrics.horizontalAdvance(combo.itemText(i)) for i in range(combo.count())), default=current)
        combo.view().setMinimumWidth(widest + 28)      # выпадающий список — по самому длинному названию

    def _fit_spin(self, spin: QtWidgets.QAbstractSpinBox) -> None:
        """Ширина счётчика = текст значения (с приставкой/суффиксом), но не уже четырёх цифр."""
        metrics = spin.fontMetrics()
        text = spin.text()
        prefix = getattr(spin, "prefix", lambda: "")()
        suffix = getattr(spin, "suffix", lambda: "")()
        width = max(metrics.horizontalAdvance(text), metrics.horizontalAdvance(f"{prefix}0000{suffix}"))
        special = getattr(spin, "specialValueText", lambda: "")()
        if special and spin.value() == spin.minimum():
            width = max(width, metrics.horizontalAdvance(special))
        spin.setFixedWidth(width + 34)

    # ----------------------------------------- связь окон (window_links.LinkHub)

    def link_symbol(self) -> str:
        return self.current_symbol()

    def link_apply(self, symbol: str) -> None:
        """Сменить инструмент по команде хаба (тот же путь, что и выбор в списке/каталоге)."""
        if not symbol or symbol == self.current_symbol():
            return
        self._link_applying = True
        try:
            self._select_symbol(symbol)
        finally:
            self._link_applying = False

    def link_widget(self) -> QtWidgets.QWidget:
        return self

    def link_set_compact(self, compact: bool) -> None:
        """Общий переключатель хаба не используется: у каждого окна «Тики» своя галочка в «Параметрах»."""

    def _link_notify(self, symbol: str) -> None:
        """Сообщить хабу о выборе инструмента пользователем (не о смене по его же команде)."""
        hub = getattr(self.host, "link_hub", None)
        if hub is None or self._link_applying or "@" not in symbol:
            return
        hub.symbol_changed(self, symbol)

    def _apply_hide_instrument(self, hidden: bool) -> None:
        """Скрыть/показать «Инструмент», поле выбора и «Каталог…». Квадрат связи окон остаётся."""
        for widget in (self.instr_label, self.symbol_combo, self.catalog_btn):
            widget.setVisible(not hidden)

    def _on_hide_instrument_toggled(self, on: bool) -> None:
        self._set("hide_instrument", bool(on))   # у каждого окна «Тики» своё значение
        self._apply_hide_instrument(bool(on))

    def _fit_controls(self) -> None:
        """Подогнать ширину всех списков и счётчиков окна и подписаться на изменения."""
        combos = [self.symbol_combo, self.bucket_combo, self.window_combo, self.lupa_span_combo]
        spins = [self.min_spin, self.large_spin, self.repeat_spin, self.lupa_band_spin]
        for combo in combos:
            self._fit_combo(combo)
            combo.currentTextChanged.connect(lambda _t, c=combo: self._fit_combo(c))
        for spin in spins:
            self._fit_spin(spin)
            spin.valueChanged.connect(lambda _v, sp=spin: self._fit_spin(sp))
        self._fit_widgets = combos + spins   # для повторной подгонки после первого показа (шрифт/тема)

    def _refit_controls(self) -> None:
        for widget in getattr(self, "_fit_widgets", []):
            if isinstance(widget, QtWidgets.QComboBox):
                self._fit_combo(widget)
            else:
                self._fit_spin(widget)

    def _fill_lupa_span_combo(self) -> None:
        """Период лупы: секунды/минуты — во временном режиме, число сделок — в тиковом."""
        combo = self.lupa_span_combo
        combo.blockSignals(True)
        combo.clear()
        if self._tick_mode:
            choices, key, default = LUPA_TICK_SPAN_CHOICES, "lupa_span_ticks", 200
        else:
            choices, key, default = LUPA_SPAN_CHOICES, "lupa_span", 120
        for label, value in choices:
            combo.addItem(label, userData=value)
        combo.setCurrentIndex(max(0, combo.findData(self._get_int(key, default))))
        combo.blockSignals(False)

    def _apply_lupa_visibility(self) -> None:
        on = self._lupa_on
        self.lupa_cfg_btn.setVisible(on)
        if not on:
            self.lupa_settings_dlg.hide()
        self.lupa_plot.setVisible(on)
        if on:
            QtCore.QTimer.singleShot(0, self._apply_lupa_sizes)

    def _on_lupa_wheel(self, delta: float) -> None:
        """Колесо мыши над шкалой лупы: вверх — приблизить (полоса меньше), вниз — шире."""
        steps = delta / 120.0
        if not steps:
            return
        manual = self.lupa_band_spin.value()
        current = float(manual or self._lupa_band_last or 10.0)   # из «авто» стартуем от текущей полосы
        new = int(round(current * (LUPA_WHEEL_STEP ** (-steps))))
        if new == int(round(current)):          # на малых значениях шаг не должен «залипать»
            new += -1 if steps > 0 else 1
        new = max(1, min(new, self.lupa_band_spin.maximum()))
        self.lupa_band_spin.setValue(new)       # сработает _on_lupa_changed: сохранение и перерисовка

    def _toggle_panel(self, dlg: QtWidgets.QDialog, button: QtWidgets.QWidget, align_right: bool = False) -> None:
        """Плавающая панель под кнопкой: клик открывает, повторный клик закрывает."""
        if dlg.isVisible():
            dlg.hide()
            return
        dlg.adjustSize()
        dx = button.width() - dlg.width() if align_right else 0
        dlg.move(button.mapToGlobal(QtCore.QPoint(dx, button.height() + 4)))
        dlg.show()
        dlg.raise_()

    def _toggle_lupa_settings(self) -> None:
        self._toggle_panel(self.lupa_settings_dlg, self.lupa_cfg_btn)

    def _apply_lupa_sizes(self) -> None:
        total = self.splitter.width()
        if total <= 0 or not self._lupa_on:
            return
        width = self._get_int("lupa_w", 0) or int(total * LUPA_WIDTH_FRACTION)
        width = max(150, min(width, total - 280))
        self.splitter.setSizes([width, total - width])
        self._lupa_sized = True

    def _on_splitter_moved(self) -> None:
        if self._lupa_on:
            self._set("lupa_w", self.lupa_plot.width())
        self._mark_dirty()

    def _on_lupa_toggled(self, on: bool) -> None:
        self._lupa_on = on
        self._set("lupa_on", on)
        self._lupa_sized = False
        self._apply_lupa_visibility()
        self._mark_dirty()

    def _on_lupa_changed(self, *_args) -> None:
        self._set("lupa_span_ticks" if self._tick_mode else "lupa_span", self.lupa_span_combo.currentData())
        self._set("lupa_band", self.lupa_band_spin.value())
        self._mark_dirty()

    def _tick_arrays(self, first: int, ticks: list):
        """Тиковый режим: сделки -> массивы для столбцов (X = номер сделки)."""
        ids = self.aggregator.repeat_ids
        xs = [float(first + i) for i in range(len(ticks))]
        asks = [t[2] if t[3] == SIDE_BUY else 0.0 for t in ticks]
        bids = [t[2] if t[3] != SIDE_BUY else 0.0 for t in ticks]
        rep_asks = [a if (first + i) in ids else 0.0 for i, a in enumerate(asks)]
        rep_bids = [b if (first + i) in ids else 0.0 for i, b in enumerate(bids)]
        return xs, asks, bids, rep_asks, rep_bids

    @staticmethod
    def _min_bar_width(plot, width: float, span: float) -> float:
        """Ширина столбца в единицах оси X, но не меньше MIN_BAR_PX пикселей экрана."""
        pixels = max(1.0, float(plot.getViewBox().width()))
        per_unit = pixels / max(1e-9, float(span))      # пикселей на единицу X
        return max(width, MIN_BAR_PX / per_unit)

    @staticmethod
    def _bar_layers() -> list:
        """Слои столбцов по порядку рисования: ASK вверх, BID вниз, поверх — повторы ASK / BID."""
        return [(ASK_COLOR, UP), (BID_COLOR, DOWN), (REP_ASK_COLOR, UP), (REP_BID_COLOR, DOWN)]

    @staticmethod
    def _set_html(item, html: str) -> None:
        """TextItem.setHtml пересобирает документ и раскладку текста; если подпись та же — не трогаем."""
        if getattr(item, "_fx_html", None) != html:
            item._fx_html = html
            item.setHtml(html)

    @staticmethod
    def _fmt_avg(value: float) -> str:
        return f"{value:.1f}".rstrip("0").rstrip(".")

    def _redraw_lupa(self, x_to: float) -> None:
        """
        Панель-лупа: тот же поток данных, но крупным планом за последний период и со своей
        шкалой объёма. Правый край по времени всегда совпадает с основным графиком.
        Всё, что выше полосы, уходит за границу панели (отдельно не помечается — оно
        видно на основном графике). На шкале — средние значения ASK и BID за период.
        """
        if not self._lupa_on or not self.lupa_plot.isVisible():
            return
        agg = self.aggregator
        span = float(self.lupa_span_combo.currentData() or (200 if self._tick_mode else 120))
        x_from = x_to - span

        if self._tick_mode:
            first, ticks = agg.tick_range(x_from, x_to)
            xs, asks, bids, rep_asks, rep_bids = self._tick_arrays(first, ticks)
            width = 0.8
        else:
            xs, asks, bids, _marks, rep_asks, rep_bids = agg.snapshot(x_from, x_to)
            width = (agg.bucket_sec or 1) * 0.8
        width = self._min_bar_width(self.lupa_plot, width, x_to - x_from)

        ask_vals = [v for v in asks if v > 0]
        bid_vals = [v for v in bids if v > 0]
        avg_ask = sum(ask_vals) / len(ask_vals) if ask_vals else 0.0
        avg_bid = sum(bid_vals) / len(bid_vals) if bid_vals else 0.0

        manual = self.lupa_band_spin.value()
        if manual > 0:
            band = float(manual)
        elif avg_ask or avg_bid:
            # авто — «липкая» и круглая (sticky_limit): полоса и шкала лупы не меняются на каждом кадре
            band = sticky_limit(getattr(self, "_lupa_band_auto", None),
                                max(1.0, LUPA_AUTO_K * max(avg_ask, avg_bid)))
            self._lupa_band_auto = band
        else:
            band = 10.0

        self._lupa_band_last = band
        x_arr = np.asarray(xs, dtype=float)
        ask_arr = np.asarray(asks, dtype=float)
        bid_arr = np.asarray(bids, dtype=float)
        rep_a = np.asarray(rep_asks, dtype=float)
        rep_b = np.asarray(rep_bids, dtype=float)
        self.lupa_bars.set_data(x_arr, [ask_arr, bid_arr, rep_a, rep_b], width)   # не изменилось — пропуск

        vb = self.lupa_plot.getViewBox()
        vb.setXRange(x_from, x_to, padding=0)
        vb.setYRange(-band, band, padding=0)

        self.lupa_plot.getAxis("right").set_tags([])   # на шкале лупы только деления; пересчёт её ширины

        span_text = self.lupa_span_combo.currentText()
        self._set_html(
            self.lupa_caption,
            f'<span style="color:{fx_theme.TEXT_DIM};font-size:9pt">'
            f'полоса до {band:g} лотов{" (авто)" if manual == 0 else ""} · среднее за {span_text}</span>'
        )
        self.lupa_caption.setPos(x_from, band)

    def _fill_window_combo(self) -> None:
        """Окно: минуты — для временных корзин, число сделок — для тикового режима."""
        combo = self.window_combo
        combo.blockSignals(True)
        combo.clear()
        if self._tick_mode:
            choices, key, default = TICK_WINDOW_CHOICES, "window_ticks", 500
        else:
            choices, key, default = WINDOW_CHOICES, "window", 300
        for label, value in choices:
            combo.addItem(label, userData=value)
        combo.setCurrentIndex(max(0, combo.findData(self._get_int(key, default))))
        combo.blockSignals(False)

    @staticmethod
    def _legend_html() -> str:
        return (
            f'<span style="color:{ASK_COLOR.name()}">▲ ASK — покупки по Ask</span>'
            f'&nbsp;&nbsp;<span style="color:{BID_COLOR.name()}">▼ BID — продажи по Bid</span>'
            f'&nbsp;&nbsp;<span style="color:{LARGE_COLOR.name()}">★ крупная сделка</span>'
            f'&nbsp;&nbsp;<span style="color:{REP_ASK_COLOR.name()}">▌повтор ASK</span>'
            f'&nbsp;<span style="color:{REP_BID_COLOR.name()}">▌повтор BID</span>'
        )

    def _place_legend(self) -> None:
        vb = self.plot.getViewBox()
        (x0, _x1), (_y0, y1) = vb.viewRange()
        if getattr(self, "_legend_pos", None) != (x0, y1):   # то же место — сцену не трогаем
            self._legend_pos = (x0, y1)
            self.legend_text.setPos(x0, y1)

    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:
        super().resizeEvent(event)
        self._place_legend()
        self._place_clock()

    # -------------------------------------------------------------- часы

    CLOCK_MARGIN = 12      # отступ от правого края по умолчанию
    CLOCK_TOP = 2          # px от верха окна по умолчанию
    CLOCK_DROP_MM = 1.0    # плюс на столько миллиметров ниже (по DPI экрана)

    def _saved_clock_fraction(self):
        try:
            fx = float(self._settings.value(self.SETTINGS_PREFIX + "clock_fx"))
            fy = float(self._settings.value(self.SETTINGS_PREFIX + "clock_fy"))
            return max(0.0, min(fx, 1.0)), max(0.0, min(fy, 1.0))
        except (TypeError, ValueError):
            return None

    def _place_clock(self) -> None:
        label = self.clock_label
        hint = label.sizeHint()
        if hint != label.size():
            label.resize(hint)
        free_w = max(1, self.width() - label.width())
        free_h = max(1, self.height() - label.height())
        saved = self._saved_clock_fraction()
        if saved is None:
            drop = int(round(self.logicalDpiY() / 25.4 * self.CLOCK_DROP_MM))
            x, y = self.width() - label.width() - self.CLOCK_MARGIN, self.CLOCK_TOP + drop
        else:
            x, y = int(saved[0] * free_w), int(saved[1] * free_h)
        label.move(max(0, min(x, free_w)), max(0, min(y, free_h)))
        label.raise_()

    def _on_clock_toggled(self, on: bool) -> None:
        self._set("clock_on", on)
        self.clock_label.setVisible(on)
        if on:
            self._place_clock()

    def _on_clock_moved(self) -> None:
        label = self.clock_label
        free_w = max(1, self.width() - label.width())
        free_h = max(1, self.height() - label.height())
        self._set("clock_fx", label.x() / free_w)
        self._set("clock_fy", label.y() / free_h)

    def _reset_clock_pos(self) -> None:
        self._settings.remove(self.SETTINGS_PREFIX + "clock_fx")
        self._settings.remove(self.SETTINGS_PREFIX + "clock_fy")
        self._place_clock()

    def _now(self) -> float:
        """Текущее время сервера (epoch-сек): общие часы терминала или время ПК."""
        return self._clock.now() if self._clock is not None else time.time()

    def _on_clock_changed(self, tooltip: str) -> None:
        self.clock_label.setToolTip(tooltip + "\n(перетащите мышью; двойной клик — на место)")
        self._dirty = True

    def _tick_clock(self) -> None:
        if not self.isVisible():
            return
        now = self._now()
        if self.clock_label.isVisible():   # часы отключены — текст не обновляем (график едет как раньше)
            self.clock_label.set_clock_text(      # размер постоянный — без пересчёта раскладки окна
                datetime.fromtimestamp(now, self.time_axis._tz).strftime("%H:%M:%S.%f")[:-3]
            )
        # Автопрокрутка идёт и когда сделок нет — раз в секунду просим перерисовку, пока на графике есть что
        # сдвигать (chart_moves). Все столбцы ушли за левый край — рисуем ещё один кадр и ждём сделок: первая
        # же сделка перерисует окно и поставит его на текущее время.
        sec = int(now)
        if sec != self._clock_last_sec:
            self._clock_last_sec = sec
            repeats = bool(self.aggregator.alive_repeats(now))
            if self._tick_mode or self.follow_check.isChecked() or repeats:
                if chart_moves(now, self.aggregator.last_tick[0] if self.aggregator.last_tick else None,
                               self._moving_span(), repeats):
                    self._dirty = True  # прокрутка, «сгорание» максимума за минуту и тегов повторов
                    self._idle_drawn = False
                elif not self._idle_drawn:
                    self._dirty = True  # последний кадр: столбцы ушли за край
                    self._idle_drawn = True
            self._show_lag()

    def _moving_span(self) -> float:
        """Сколько секунд после последней сделки на графике ещё что-то едет по часам: во временном режиме —
        окно (и лупа, если она шире), в тиковом — «максимум за минуту»; плюс два интервала столбца."""
        span = float(MINUTE_MAX_SEC)
        if not self._tick_mode:
            span = max(span, float(self.window_combo.currentData() or 300))
            if self._lupa_on:
                span = max(span, float(self.lupa_span_combo.currentData() or 120))
        return span + 2 * max(1, int(self.aggregator.bucket_sec or 1))

    # -------------------------------------------------------- инструмент

    def current_symbol(self) -> str:
        data = self.symbol_combo.currentData()
        return str(data) if data else ""

    def _select_symbol(self, symbol: str) -> None:
        idx = self.symbol_combo.findData(symbol)
        if idx < 0:
            self.symbol_combo.addItem(self._friendly(symbol), userData=symbol)
            idx = self.symbol_combo.count() - 1
        self.symbol_combo.setCurrentIndex(idx)

    def _restore_state(self) -> None:
        saved = str(self._settings.value(self.SETTINGS_PREFIX + "symbol", "") or "")
        symbol = saved or self._initial_symbol
        if not symbol and self.index == 1:
            try:
                symbol = self.host.current_panel()._current_symbol()
            except Exception:
                symbol = ""
        symbol = symbol or DEFAULT_SYMBOL

        self.symbol_combo.blockSignals(True)
        self._select_symbol(symbol)
        self.symbol_combo.blockSignals(False)
        self._update_title()

        geometry = self._settings.value(self.SETTINGS_PREFIX + "geometry")
        if geometry and not self._embedded:
            self.restoreGeometry(geometry)

    def _open_catalog(self) -> None:
        assets = getattr(self.host, "_active_assets", None)
        if not assets:
            QtWidgets.QMessageBox.information(
                self,
                "Каталог не загружен",
                "Дождитесь загрузки каталога инструментов от брокера "
                "(см. статус-бар основного окна) и попробуйте снова.",
            )
            return
        dlg = self._picker_cls(assets, self._mic_labels, self._type_labels, self._settings, self)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        symbol = dlg.chosen_symbol()
        if symbol:
            self._select_symbol(symbol)

    def _update_title(self) -> None:
        symbol = self.current_symbol()
        label = self._friendly(symbol) if symbol else ""
        self.setWindowTitle(f"Тики Bid/Ask #{self.index} — {label}" if label else f"Тики Bid/Ask #{self.index}")

    def _on_symbol_changed(self, _index: int) -> None:
        symbol = self.current_symbol()
        if not symbol:
            return
        self._update_title()
        self._set("symbol", symbol)
        self.aggregator.clear()
        self._mark_dirty()
        self.start_stream()
        self._link_notify(symbol)

    # ----------------------------------------------------------- параметры

    def _on_params_changed(self, *_args) -> None:
        large = self.large_spin.value() if self.large_check.isChecked() else 0
        self.aggregator.reconfigure(
            bucket_sec=self.bucket_combo.currentData(),
            min_volume=self.min_spin.value(),
            large_volume=large,
            repeat_min=self.repeat_spin.value() if self.repeat_check.isChecked() else 0,
        )
        self._set("repeat_on", self.repeat_check.isChecked())
        self._set("repeat_min", self.repeat_spin.value())
        self.repeat_spin.setEnabled(self.repeat_check.isChecked())
        self._set("min_volume", self.min_spin.value())
        self._set("large_volume", self.large_spin.value())
        self._set("bucket", self.bucket_combo.currentData())
        self._set("large_on", self.large_check.isChecked())

        tick_mode = self.aggregator.bucket_sec == 0
        if tick_mode != self._tick_mode:
            # Переключили «Тиковый» <-> временной интервал: другая ось X и другое окно.
            self._tick_mode = tick_mode
            self._fill_window_combo()
            self.time_axis.set_tick_mode(self.aggregator.tick_at if tick_mode else None)
            self.lupa_time_axis.set_tick_mode(self.aggregator.tick_at if tick_mode else None)
            self._fill_lupa_span_combo()
            self._refit_controls()
            self.follow_check.setChecked(True)  # старый диапазон осей уже не подходит
        self._mark_dirty()

    def _on_window_changed(self, *_args) -> None:
        self._set("window_ticks" if self._tick_mode else "window", self.window_combo.currentData())
        self.follow_check.setChecked(True)
        self._mark_dirty()

    def _apply_grid(self, on: bool) -> None:
        # Горизонтальную сетку рисует видимая ось — теперь это правая.
        for plot in (self.plot, getattr(self, "lupa_plot", None)):
            if plot is None:
                continue
            plot.showGrid(x=on, y=False)
            plot.getAxis("bottom").setGrid(38 if on else False)
            plot.getAxis("right").setGrid(38 if on else False)

    def _on_grid_toggled(self, on: bool) -> None:
        self._apply_grid(on)

    def _redraw_tick(self) -> None:
        """Плановая перерисовка по таймеру; на паузе картинка стоит."""
        if not self._paused:
            self._redraw()

    def _on_pause_toggled(self, paused: bool) -> None:
        """
        Пауза замораживает график, но не отключает поток сделок: данные продолжают
        копиться, и после «Продолжить» в графике нет разрыва. (Раньше пауза останавливала
        поток, а время на графике продолжало идти — картинка «ехала» как будто паузы нет.)
        """
        self._paused = paused
        self.pause_btn.setText("Продолжить" if paused else "Пауза")
        if paused:
            self._set_status("Пауза — график остановлен, данные продолжают поступать")
        else:
            self._status_text = ""          # статус вернётся к «Стрим активен…» с ближайшей сделкой
            self._set_status(f"Стрим активен: {self._friendly(self._active_symbol)}" if self._streaming else "Подключение…")
            self._mark_dirty()

    def _on_clear(self) -> None:
        self.aggregator.clear()
        self._mark_dirty()

    def _on_manual_range(self, *_args) -> None:
        # Пользователь двигает/масштабирует график руками — отключаем автопрокрутку.
        if self.follow_check.isChecked():
            self.follow_check.setChecked(False)

    def set_timezone(self, tz_name: str) -> None:
        self.time_axis.set_timezone(tz_name)
        self.lupa_time_axis.set_timezone(tz_name)
        self._mark_dirty()

    # -------------------------------------------------------------- стрим

    def start_stream(self) -> None:
        """Перезапускает стрим сделок текущего инструмента (с паузой для gRPC)."""
        self.stop_stream()
        self._generation += 1
        generation = self._generation
        QtCore.QTimer.singleShot(
            STREAM_START_DELAY_MS + (self.index - 1) * STREAM_START_STAGGER_MS,
            lambda: self._start_stream_now(generation),
        )

    @property
    def _streaming(self) -> bool:
        """Подписка на сделки в хабе открыта (сделки идут или подключаются)."""
        return getattr(self, "_hub_sub", None) is not None

    def _start_stream_now(self, generation: int) -> None:
        if generation != self._generation or self._streaming:
            return
        hub = getattr(self.host, "md_hub", None)
        symbol = self.current_symbol()
        if hub is None or not symbol:
            self._set_status("Нет подключения к Finam (проверьте токен в «Настройках»)")
            return

        # Сделки из MarketDataHub. Все окна «Тики» одного инструмента и остальные вкладки
        # делят один поток у брокера; переподключение (1 → 60 с) и отсев повторов по trade_id
        # делает FinamGateway.
        self._active_symbol = symbol
        from core.models import InstrumentId
        # replay=True: сразу последние сделки, уже прошедшие через хаб, — поток мог быть открыт раньше
        # стаканом или «Алгоритмами», и окно иначе начинало бы с пустого графика.
        self._hub_sub = hub.subscribe_trades(
            InstrumentId.parse(symbol),
            lambda trade, g=generation: self._on_hub_trade(trade, g),
            replay=True,
        )
        self._set_status(f"Подключение: {self._friendly(symbol)}…")

    def stop_stream(self) -> None:
        """Закрывает подписку на сделки в хабе; запоздавшие сделки старого поколения окно не примет."""
        self._generation += 1  # отложенные старты старого стрима станут неактуальны
        sub = getattr(self, "_hub_sub", None)
        self._hub_sub = None
        if sub is not None:
            sub.close()

    def stop(self) -> None:
        """Вызывается из MainWindow._shutdown_connections()."""
        self.stop_stream()
        self._set_status("Остановлено")

    def resume(self) -> None:
        """Вызывается после переподключения клиента: если окно открыто — поднимаем стрим."""
        if self.isVisible():
            self.start_stream()

    def _on_hub_trade(self, trade, generation: int) -> None:
        """Trade из хаба -> тик (ts, цена, объём, сторона). Для живых сделок (не история) — задержка."""
        if not trade.is_snapshot and generation == self._generation:
            self._note_lag(trade)
        side = SIDE_BUY if trade.side is not None and trade.side.value == "buy" else \
            SIDE_SELL if trade.side is not None else 0
        self._on_ticks([(trade.ts, trade.price, trade.volume, side)], generation)

    def _on_ticks(self, ticks: list, generation: int) -> None:
        if generation != self._generation:
            return
        agg = self.aggregator
        for ts, price, qty, side in ticks:
            if agg.large_volume > 0 and qty >= agg.large_volume and qty >= agg.min_volume:
                print(
                    f"[ТИКИ] крупная сделка: {qty:g} @ {price:g}, "
                    f"{'BUY' if side == SIDE_BUY else 'SELL' if side else 'сторона?'}, "
                    f"{self._fmt_time(ts)}",
                    file=sys.stderr,
                )
        agg.add(ticks)
        self._dirty = True
        if not self._paused and not self._status_text.startswith("Стрим"):
            self._set_status(f"Стрим активен: {self._friendly(self._active_symbol)}")

    def _set_status(self, text: str) -> None:
        self._status_text = text
        self.status_label.setText(text + self._lag_suffix())

    def _note_lag(self, trade) -> None:
        """Запомнить задержку живой сделки; большая — строка в журнал (с разбивкой, где копилась)."""
        hub = getattr(self.host, "md_hub", None)
        queue = hub.trade_queue_lag(trade.instrument) if hub is not None and hasattr(hub, "trade_queue_lag") else None
        total = self._now() - float(trade.ts)
        mono = time.monotonic()
        self._lag = (total, queue, mono)
        if total > LAG_WARN_SEC and mono - self._lag_logged > LAG_LOG_EVERY_SEC:
            self._lag_logged = mono
            where = (f", из них в очереди терминала {queue:.1f} с" if queue is not None else "")
            print(f"[ТИКИ] {self._friendly(self._active_symbol)}: сделка пришла через {total:.1f} с после биржи{where}",
                  file=sys.stderr)

    def _lag_suffix(self) -> str:
        """« · задержка 0.4 с (терминал 0.1)» / « · сделок нет 25 с» — для строки состояния."""
        if not self._status_text.startswith("Стрим") or self._lag is None:
            return ""
        total, queue, mono = self._lag
        idle = time.monotonic() - mono
        if idle > NO_TRADES_SEC:
            return f"  ·  сделок нет {idle:.0f} с"
        if total >= FEED_LAG_WARN_SEC:
            text = f"  ·  ⚠ лента Finam отстаёт на {total:.0f} с"
        else:
            text = f"  ·  задержка {max(total, 0.0):.1f} с"
        if queue is not None and queue >= 0.05:
            text += f" (терминал {queue:.1f})"
        return text

    def _lag_warning(self) -> bool:
        lag = self._lag
        return (lag is not None and self._status_text.startswith("Стрим") and lag[0] >= FEED_LAG_WARN_SEC
                and time.monotonic() - lag[2] <= NO_TRADES_SEC)

    def _show_lag(self) -> None:
        """Раз в секунду: обновить задержку в строке состояния (текст меняется — setText); большая — жёлтым."""
        text = self._status_text + self._lag_suffix()
        if self.status_label.text() != text:
            self.status_label.setText(text)
        warn = self._lag_warning()
        if warn != getattr(self, "_lag_warn_shown", False):
            self._lag_warn_shown = warn
            color = FEED_LAG_COLOR if warn else fx_theme.TEXT_DIM
            self.status_label.setStyleSheet(f"color: {color};" + (" font-weight: 600;" if warn else ""))

    # ------------------------------------------------------------ рисование

    def _mark_dirty(self) -> None:
        self._dirty = True
        self._redraw()

    def _redraw(self) -> None:
        if not self._dirty or not self.isVisible():
            return
        self._dirty = False

        agg = self.aggregator
        if self._tick_mode:
            t_from, t_to, xs, asks, bids, marks, rep_asks, rep_bids = self._collect_ticks()
            width = 0.8
        else:
            window_sec = int(self.window_combo.currentData() or 300)
            last_ts = max(self._now(), agg.last_tick[0] if agg.last_tick else 0.0)

            if self.follow_check.isChecked():
                step = max(1, agg.bucket_sec)
                # Раньше правый край = текущее время (дробное): каждую секунду сетка столбцов
                # сдвигалась на случайную долю пикселя, и тонкие столбцы (меньше пикселя)
                # то попадали в пиксельную колонку, то нет — «мигали». Теперь край — на границе
                # интервала, и график едет ровно на столбец.
                t_to = (int(last_ts // step) + 1) * step + max(2, step)
                t_from = t_to - window_sec
            else:
                (t_from, t_to), _ = self.plot.getViewBox().viewRange()

            xs, asks, bids, marks, rep_asks, rep_bids = agg.snapshot(t_from, t_to)
            width = agg.bucket_sec * 0.8

        width = self._min_bar_width(self.plot, width, t_to - t_from)

        x_arr = np.asarray(xs, dtype=float)
        ask_arr = np.asarray(asks, dtype=float)
        bid_arr = np.asarray(bids, dtype=float)

        rep_ask_arr = np.asarray(rep_asks, dtype=float)
        rep_bid_arr = np.asarray(rep_bids, dtype=float)
        self.bars.set_data(x_arr, [ask_arr, bid_arr, rep_ask_arr, rep_bid_arr], width)   # не изменилось — пропуск

        vb = self.plot.getViewBox()
        top = float(max(ask_arr.max() if ask_arr.size else 0, 1))
        bottom = float(max(bid_arr.max() if bid_arr.size else 0, 1))
        mm_ask, mm_bid = self._minute_max()
        if mm_ask:
            top = max(top, mm_ask[0])
        if mm_bid:
            bottom = max(bottom, mm_bid[0])
        # «Липкие» границы (sticky_limit): шкала не перерисовывается на каждом кадре
        self._y_top = sticky_limit(getattr(self, "_y_top", None), top * 1.15)
        self._y_bottom = sticky_limit(getattr(self, "_y_bottom", None), bottom * 1.15)
        y_min, y_max = -self._y_bottom, self._y_top
        # sigRangeChangedManually приходит только от мыши, поэтому программная
        # смена диапазона автопрокрутку не выключает.
        if self.follow_check.isChecked():
            vb.setXRange(t_from, t_to, padding=0)
        vb.setYRange(y_min, y_max, padding=0)

        # Метки ставим ПОСЛЕ диапазона: отступ от края столбца считается в пикселях.
        self._draw_marks(marks, t_from, t_to, y_min, y_max)
        max_tags = self._draw_minute_max(mm_ask, mm_bid, t_to)
        self.plot.getAxis("right").set_tags(max_tags + self._repeat_tags(rep_asks, rep_bids))
        self._place_legend()
        self._redraw_lupa(t_to)

        self._update_summary(xs, asks, bids, marks, rep_asks, rep_bids)

    def _minute_max(self):
        """
        Максимум объёма ASK и BID за последние 60 с (по времени сервера).

        Возвращает ((значение, x), (значение, x)) — для ASK и BID, x в координатах
        графика (центр корзины или номер сделки); None, если за минуту данных нет.
        В тиковом режиме — самая крупная одиночная сделка, во временном — самая
        крупная корзина (сумма за интервал).
        """
        agg = self.aggregator
        now = self._now()
        t0 = now - MINUTE_MAX_SEC
        best_ask = best_bid = None

        if self._tick_mode:
            idx = agg.accepted_total
            for ts, _price, qty, side in reversed(agg.accepted):
                idx -= 1
                if ts < t0:
                    break
                if side == SIDE_BUY:
                    if best_ask is None or qty > best_ask[0]:
                        best_ask = (qty, float(idx))
                elif best_bid is None or qty > best_bid[0]:
                    best_bid = (qty, float(idx))
        else:
            step = agg.bucket_sec or 1
            key = int(t0 // step) * step
            half = step / 2
            while key <= now:
                cell = agg.buckets.get(key)
                if cell:
                    if cell[0] > 0 and (best_ask is None or cell[0] >= best_ask[0]):
                        best_ask = (cell[0], key + half)
                    if cell[1] > 0 and (best_bid is None or cell[1] >= best_bid[0]):
                        best_bid = (cell[1], key + half)
                key += step
        return best_ask, best_bid

    @staticmethod
    def _fmt_volume(value: float) -> str:
        return f"{int(value)}" if float(value).is_integer() else f"{value:g}"

    def _draw_minute_max(self, mm_ask, mm_bid, x_right: float) -> list:
        """Пунктирные лучи от бара-максимума к правой шкале; возвращает «ценники» максимума."""
        tags = []
        for key, found, sign, color in (
            ("ask", mm_ask, 1, ASK_COLOR.darker(115)),
            ("bid", mm_bid, -1, BID_COLOR.darker(115)),
        ):
            ray, dot = self.max_rays[key]
            state = None if not found else (found[1], sign * found[0], x_right)
            if getattr(ray, "_fx_state", "-") == state:      # то же — setData не зовём (он дорогой)
                if found:
                    tags.append((state[1], self._fmt_volume(found[0]), color))
                continue
            ray._fx_state = state
            if not found:
                ray.setData([], [])
                dot.setData([], [])
                continue
            value, x = found
            y = sign * value
            ray.setData([x, x_right], [y, y])
            dot.setData([x], [y])
            tags.append((y, self._fmt_volume(value), color))
        return tags

    def _repeat_tags(self, rep_asks, rep_bids) -> list:
        """
        Точный объём повторяющихся сделок прямо на шкале: бирюзовый тег — повторяются
        покупки (ASK, вверх), розовый — продажи (BID, вниз).

        Тег показывается, пока серия идёт: последний повтор не старше REPEAT_TAG_TTL_SEC
        (6 с). Серия закончилась — тег со шкалы убирается; окрашенные столбцы на графике
        остаются как история.
        """
        agg = self.aggregator
        if agg.repeat_min <= 0 or not agg.active_repeats:
            return []
        dark = QtGui.QColor("#10131a")

        alive = agg.alive_repeats(self._now())    # самые свежие серии — первыми; закончившиеся забыты

        tags = []
        per_side = {SIDE_BUY: 0, -SIDE_BUY: 0}
        for ts, side, qty in alive:
            key = SIDE_BUY if side == SIDE_BUY else -SIDE_BUY
            if per_side[key] >= MAX_REPEAT_TAGS:
                continue
            per_side[key] += 1
            color = REP_ASK_COLOR if side == SIDE_BUY else REP_BID_COLOR
            sign = 1 if side == SIDE_BUY else -1
            tags.append((sign * qty, self._fmt_volume(qty), color, dark))
        return tags

    def _draw_marks(self, marks, x_from, x_to, y_min, y_max) -> None:
        """Звёздочки чуть выше (ASK) / ниже (BID) края столбца + подпись мм:сс рядом."""
        shown = marks if (self.large_check.isChecked() and marks) else []

        vb = self.plot.getViewBox()
        h_px = max(float(vb.height()), 100.0)
        w_px = max(float(vb.width()), 100.0)
        y_per_px = (y_max - y_min) / h_px
        x_per_px = (x_to - x_from) / w_px
        gap = MARK_GAP_PX * y_per_px

        xs, ys = [], []
        for m in shown:
            xs.append(m["x"])
            ys.append(m["y"] + (gap if m["side"] == SIDE_BUY else -gap))

        # Звёздочки пересобираются только при изменении (ScatterPlotItem.setData дорогой); подсказки
        # берут data — сравниваем и содержимое меток, не только координаты.
        key = (tuple(xs), tuple(ys), tuple((m["qty"], m["count"], m["ts"]) for m in shown))
        if key != getattr(self, "_scatter_key", None):
            self._scatter_key = key
            if shown:
                self.large_scatter.setData(x=xs, y=ys, data=shown)
            else:
                self.large_scatter.setData(x=[], y=[])

        # Подписи: только последние MAX_MARK_LABELS, чтобы не перегружать график.
        labelled = list(zip(xs, ys, shown))[-MAX_MARK_LABELS:]
        while len(self._mark_labels) < len(labelled):
            item = pg.TextItem(anchor=(0, 0.5))
            self.plot.addItem(item, ignoreBounds=True)
            self._mark_labels.append(item)

        # Раскладка в пикселях без наложений: сначала все звёздочки — препятствия,
        # затем подписи от новых к старым. Если место справа занято — сдвигаем
        # подпись на строку вверх (ASK) / вниз (BID), потом пробуем слева от звезды.
        def to_px(x, y):
            return (x - x_from) / x_per_px, (y_max - y) / y_per_px

        obstacles = []
        for x, y in zip(xs, ys):
            px, py = to_px(x, y)
            obstacles.append((px - 7, py - 7, px + 7, py + 7))

        def free(rect):
            x0, y0, x1, y1 = rect
            if x0 < 0 or x1 > w_px or y0 < 0 or y1 > h_px:
                return False
            return not any(x0 < ox1 and x1 > ox0 and y0 < oy1 and y1 > oy0
                           for ox0, oy0, ox1, oy1 in obstacles)

        used = 0
        for item, (x, y, m) in zip(self._mark_labels, reversed(labelled)):
            self._set_html(
                item,
                f'<span style="color:{fx_theme.chart_color("label")};'
                f'font-size:9pt;font-weight:bold">{self._fmt_ms(m["ts"])}</span>'
            )
            rect_w = item.boundingRect().width() or 40.0
            rect_h = item.boundingRect().height() or 16.0
            px, py = to_px(x, y)
            step = rect_h * (-1 if m["side"] == SIDE_BUY else 1)  # вверх для ASK, вниз для BID

            placed = None
            for side_right in (True, False):
                for k in range(0, 5):
                    cy = py + step * k
                    if side_right:
                        rect = (px + MARK_LABEL_DX_PX, cy - rect_h / 2,
                                px + MARK_LABEL_DX_PX + rect_w, cy + rect_h / 2)
                    else:
                        rect = (px - MARK_LABEL_DX_PX - rect_w, cy - rect_h / 2,
                                px - MARK_LABEL_DX_PX, cy + rect_h / 2)
                    if free(rect):
                        placed = (side_right, step * k, rect)
                        break
                if placed:
                    break

            if placed is None:
                item.setVisible(False)  # места нет — звезда остаётся, подпись скрываем
                continue
            side_right, dy_px, rect = placed
            obstacles.append(rect)
            anchor = (0, 0.5) if side_right else (1, 0.5)
            if getattr(item, "_fx_anchor", None) == anchor:
                pass                      # якорь тот же — пересчёт положения текста не нужен
            elif hasattr(item, "setAnchor"):
                item.setAnchor(anchor)
            else:  # старый pyqtgraph
                item.anchor = pg.Point(*anchor)
                item.updateTextPos()
            item._fx_anchor = anchor
            dx = MARK_LABEL_DX_PX * x_per_px * (1 if side_right else -1)
            item.setPos(x + dx, y - dy_px * y_per_px)
            item.setVisible(True)
            used += 1
        for item in self._mark_labels[len(labelled):]:
            item.setVisible(False)

    def _fmt_ms(self, ts: float) -> str:
        """Минуты:секунды (без часов) — как на оси времени."""
        try:
            return datetime.fromtimestamp(ts, self.time_axis._tz).strftime("%M:%S")
        except (OverflowError, OSError, ValueError):
            return ""

    def _collect_ticks(self):
        """Тиковый режим: каждая принятая сделка — свой столбец, X = номер сделки."""
        agg = self.aggregator
        total = agg.accepted_total
        if self.follow_check.isChecked():
            n = int(self.window_combo.currentData() or 500)
            x_to = total + max(2.0, n * 0.03)
            x_from = x_to - n - max(2.0, n * 0.03)
        else:
            (x_from, x_to), _ = self.plot.getViewBox().viewRange()

        first, ticks = agg.tick_range(x_from, x_to)
        xs = [float(first + i) for i in range(len(ticks))]
        asks = [t[2] if t[3] == SIDE_BUY else 0.0 for t in ticks]
        bids = [t[2] if t[3] != SIDE_BUY else 0.0 for t in ticks]
        ids = agg.repeat_ids
        rep_asks = [a if (first + i) in ids else 0.0 for i, a in enumerate(asks)]
        rep_bids = [b if (first + i) in ids else 0.0 for i, b in enumerate(bids)]

        marks = []
        if agg.large_volume > 0:
            for x, (ts, price, qty, side) in zip(xs, ticks):
                if qty >= agg.large_volume:
                    marks.append({
                        "x": x, "y": qty if side == SIDE_BUY else -qty,
                        "side": side, "qty": qty, "price": price, "ts": ts, "count": 1,
                    })
        return x_from, x_to, xs, asks, bids, marks, rep_asks, rep_bids

    def _update_summary(self, xs, asks, bids, marks, rep_asks=(), rep_bids=()) -> None:
        agg = self.aggregator
        ask_sum, bid_sum = sum(asks), sum(bids)
        delta = ask_sum - bid_sum
        delta_color = ASK_COLOR.name() if delta >= 0 else BID_COLOR.name()
        parts = [
            f'<span style="color:{ASK_COLOR.name()}">ASK {ask_sum:g}</span>',
            f'<span style="color:{BID_COLOR.name()}">BID {bid_sum:g}</span>',
            f'Δ <span style="color:{delta_color}">{delta:+g}</span>',
            f"★ {len(marks)}",
        ]
        if agg.repeat_min > 0:
            parts.append(
                f'повторы: <span style="color:{REP_ASK_COLOR.name()}">{sum(rep_asks):g}</span> / '
                f'<span style="color:{REP_BID_COLOR.name()}">{sum(rep_bids):g}</span>'
            )
        if agg.max_trade:
            max_qty = agg.max_trade[2]
            threshold = agg.large_volume
            if threshold > 0 and max_qty < threshold:
                parts.append(f"макс. сделка {max_qty:g} < порога {threshold:g}")
            else:
                parts.append(f"макс. сделка {max_qty:g}")
        if agg.last_tick:
            ts, price, qty, side = agg.last_tick
            side_txt = "BUY" if side == SIDE_BUY else ("SELL" if side else "?")
            parts.append(f"последняя: {price:g} × {qty:g} {side_txt}")
        if agg.unknown_side:
            parts.append(f"без стороны: {agg.unknown_side}")
        self.summary_label.setText("  ·  ".join(parts))

    # ----------------------------------------------------------- подсказки

    def _fmt_time(self, ts: float) -> str:
        try:
            return datetime.fromtimestamp(ts, self.time_axis._tz).strftime("%H:%M:%S")
        except (OverflowError, OSError, ValueError):
            return ""

    def _mark_tip(self, x, y, data) -> str:
        if not isinstance(data, dict):
            return ""
        side = "покупка (ASK)" if data.get("side") == SIDE_BUY else "продажа (BID)"
        extra = f", всего крупных в корзине: {data['count']}" if data.get("count", 1) > 1 else ""
        return (
            f"Крупная сделка: {data['qty']:g} лот(ов), {side}\n"
            f"цена {data['price']:g}, {self._fmt_time(data['ts'])}{extra}"
        )

    def _on_mouse_moved(self, pos) -> None:
        vb = self.plot.getViewBox()
        if not vb.sceneBoundingRect().contains(pos):
            return
        x = vb.mapSceneToView(pos).x()
        agg = self.aggregator
        if self._tick_mode:
            idx = int(round(x))
            tick = agg.tick_at(idx)
            if tick is None:
                self.hover_label.setText("")
                return
            ts, price, qty, side = tick
            side_txt = "BUY (ASK)" if side == SIDE_BUY else "SELL (BID)"
            rep_txt = "  (повтор)" if idx in agg.repeat_ids else ""
            self.hover_label.setText(
                f"#{idx}  {self._fmt_time(ts)}  {price:g} × {qty:g}  {side_txt}{rep_txt}"
            )
            return
        key = int(x // agg.bucket_sec) * agg.bucket_sec
        cell = agg.buckets.get(key)
        if cell is None:
            self.hover_label.setText(self._fmt_time(x))
            return
        rep_cell = agg.rep_buckets.get(key)
        rep_txt = f"  повтор: ASK {rep_cell[0]:g} / BID {rep_cell[1]:g}" if rep_cell else ""
        self.hover_label.setText(
            f"{self._fmt_time(key)}  ASK {cell[0]:g}  BID {cell[1]:g}  Δ {cell[0] - cell[1]:+g}{rep_txt}"
        )

    # --------------------------------------------------------- жизненный цикл

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        super().showEvent(event)
        self._dirty = True
        self._refit_controls()     # шрифт и тема применены — пересчитать ширины
        self._place_clock()
        if self._lupa_on and not self._lupa_sized:
            QtCore.QTimer.singleShot(0, self._apply_lupa_sizes)
        if not self._streaming:
            self.start_stream()

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        # Окно закрывается совсем (WA_DeleteOnClose): останавливаем стрим и
        # таймеры, запоминаем геометрию, сообщаем менеджеру.
        link_hub = getattr(self.host, "link_hub", None)
        if link_hub is not None:
            try:
                link_hub.unregister(self)
            except Exception:
                pass
        self.stop_stream()
        self._refresh_timer.stop()
        self._clock_timer.stop()
        self._set_status("Закрыто")
        if not self._embedded:
            self._settings.setValue(self.SETTINGS_PREFIX + "geometry", self.saveGeometry())
        self.closed.emit(self.index)
        super().closeEvent(event)
