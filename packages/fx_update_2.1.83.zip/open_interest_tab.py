# -*- coding: utf-8 -*-
"""Вкладка «Открытый интерес» для FX Terminal: квартальные (Si, CR) и вечные (CNYRUBF, USDRUBF) фьючерсы.

Это окно finam_open_interest.py, встроенное в терминал:
  * котировки (OI и цена) — подписки в MarketDataHub терминала: одна подписка у брокера
    на инструмент, переподключение делает шлюз Finam;
  * текущие квартальные контракты — по единому правилу терминала (contracts.py через
    options_common), ролловер сам; имена вида Si-12.26 / CNY-12.26;
  * шкала значений (OI / цена) — справа, как на графиках терминала;
  * жизненный цикл как у вкладки CNY Forward: start(client, hub) после подключения,
    stop() из _shutdown_connections(); графики и накопленные точки при
    переподключении сохраняются, пока контракты те же;
  * оформление берётся из темы FX Terminal (fx_theme.py), если она рядом.

Две внутренние вкладки: «Квартальные» (ближайшие Si и CR, ролловер по дате) и «Вечные»
(CNYRUBF, USDRUBF — без экспирации, ролловера нет). Подписка в хабе — на каждый инструмент
(эти же потоки делят другие окна терминала).

Для каждого фьючерса: текущий OI, изменение за запуск и за минуту, последняя цена
и график OI по каждому изменению. История на диск не пишется.

Кнопка «Заметка» (справа от внутренних вкладок): итоги за последний час по всем фьючерсам
окна — OI сейчас, изменение, минимум / максимум, цена и её изменение — в окно «Заметки»
(hour_notes.py).
"""
from __future__ import annotations

import math
import time
from collections import deque

import pyqtgraph as pg
from PySide6 import QtCore, QtWidgets

import hour_notes
from options_common import contract_title, front_quarterly_symbol

try:
    import fx_theme
except Exception:                     # нет файла — запасная палитра
    fx_theme = None


# ============================================================
# НАСТРОЙКИ
# ============================================================

PREFIXES = ("Si", "CR")        # какие квартальные фьючерсы показываем (USD/RUB, CNY/RUB)
PERPETUALS = (                 # вечные фьючерсы: тикер API -> подпись
    ("CNYRUBF@RTSX", "CNYRUBF"),
    ("USDRUBF@RTSX", "USDRUBF"),
)
MAX_POINTS = 50_000            # длина буфера графика на инструмент
REFRESH_MS = 250               # как часто перерисовывать графики
ROLLOVER_CHECK_MS = 10 * 60 * 1000   # как часто проверять, не пора ли на следующий контракт


def _palette() -> dict:
    p = {
        "panel": "#232427", "border": "#34363b", "text": "#d7dae0", "muted": "#8b9098",
        "line": "#5fd3b3", "up": "#4cc9a6", "down": "#f0707f",
        "hover": "#4a4d54", "checked": "#34363b", "plot_bg": "#232427",
    }
    if fx_theme is not None:
        p.update(
            panel=fx_theme.BG_PANEL, border=fx_theme.BORDER, text=fx_theme.TEXT,
            muted=fx_theme.TEXT_DIM, up=fx_theme.BUY, down=fx_theme.SELL,
            hover=fx_theme.BORDER_STRONG, checked=fx_theme.BG_PRESSED,
        )
    try:
        background = pg.getConfigOption("background")
        if isinstance(background, str) and background.startswith("#"):
            p["plot_bg"] = background     # тот же фон, что у свечных графиков терминала
            if background.lower() in ("#ffffff", "#fff"):
                p["line"] = "#119c7f"         # на белом фоне светлая бирюза почти не видна
    except Exception:
        pass
    _user_colors(p)
    return p


def _user_colors(p: dict) -> None:
    """Свои цвета окна из «Настройки» → «Цвета» → «Открытый интерес» (appearance, 2.1.83) поверх темы: фон и
    текст — карточки, рамки и приглушённый текст выводятся из них (fx_theme.shades); фон графиков и линия OI —
    как заданы. Не задано — как было. Читаются при создании окна (меняются после перезапуска)."""
    try:
        import appearance
        bg, text = appearance.override("oi.bg"), appearance.override("oi.text")
        plot_bg, line = appearance.override("oi.plot_bg"), appearance.override("oi.line")
    except Exception:
        return
    if (bg or text) and fx_theme is not None:
        sh = fx_theme.shades(fx_theme.QtGui.QColor(bg or fx_theme.BG_WINDOW).name(),
                             fx_theme.QtGui.QColor(text or p["text"]).name())
        p.update(text=sh["TEXT"], muted=sh["TEXT_DIM"])
        if bg:
            p.update(panel=sh["BG_PANEL"], border=sh["BORDER"], hover=sh["BORDER_STRONG"], checked=sh["BG_PRESSED"])
    if plot_bg:
        p["plot_bg"] = plot_bg
    if line:
        p["line"] = line
    p["user_text"] = bool(text)


# ============================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================

def fmt_int(value):
    return f"{value:,.0f}".replace(",", "\u00a0")


def fmt_delta_int(value):
    return f"{value:+,.0f}".replace(",", "\u00a0")


def fmt_price(value):
    return f"{value:.10g}"


def fmt_delta_price(value):
    return f"{round(value, 6):+g}"


class PlainAxis(pg.AxisItem):
    """Ось без научной записи: 8 902 500 вместо 8.9025e+06."""

    def tickStrings(self, values, scale, spacing):
        if spacing and spacing > 0:
            digits = 0 if spacing >= 1 else max(0, -int(math.floor(math.log10(spacing))))
        else:
            digits = 0
        return [f"{v:,.{digits}f}".replace(",", "\u00a0") for v in values]


# ============================================================
# ПАНЕЛЬ ИНСТРУМЕНТА
# ============================================================

class InstrumentPanel(QtWidgets.QFrame):
    def __init__(self, symbol, title, kind, pal):
        super().__init__()
        self.symbol = symbol
        self.kind = kind  # "oi" | "price"
        self._pal = pal
        self.data = deque(maxlen=MAX_POINTS)  # (ts, значение: OI или цена)
        self.prices = deque(maxlen=MAX_POINTS)  # (ts, последняя цена) — для итогов за час
        self.title = title
        self.first_value = None
        self.bid = None
        self.ask = None
        self.dirty = False

        self.setObjectName("panel")

        main_caption = "открытый интерес" if kind == "oi" else "цена"
        side_caption = "цена" if kind == "oi" else "bid / ask"

        self.name_lbl = QtWidgets.QLabel(title)          # Si-12.26 / CNY-12.26, без «@RTSX»
        self.name_lbl.setObjectName("name")
        self.title_lbl = QtWidgets.QLabel("")
        self.title_lbl.setObjectName("muted")

        self.main_lbl = QtWidgets.QLabel("—")
        self.main_lbl.setObjectName("oi")
        self.side_lbl = QtWidgets.QLabel("—")
        self.side_lbl.setObjectName("value")
        self.d_run_lbl = QtWidgets.QLabel("—")
        self.d_run_lbl.setObjectName("value")
        self.d_min_lbl = QtWidgets.QLabel("—")
        self.d_min_lbl.setObjectName("value")

        def caption(text):
            lbl = QtWidgets.QLabel(text)
            lbl.setObjectName("muted")
            return lbl

        header = QtWidgets.QGridLayout()
        header.setHorizontalSpacing(28)
        header.setVerticalSpacing(0)
        header.addWidget(self.name_lbl, 0, 0)
        header.addWidget(self.title_lbl, 1, 0)
        for col, (val, cap) in enumerate(
            [
                (self.main_lbl, caption(main_caption)),
                (self.side_lbl, caption(side_caption)),
                (self.d_run_lbl, caption("за запуск")),
                (self.d_min_lbl, caption("за 1 мин")),
            ],
            start=1,
        ):
            header.addWidget(val, 0, col)
            header.addWidget(cap, 1, col)
        header.setColumnStretch(5, 1)

        # Шкала значений — справа (как на графиках терминала), слева оси нет.
        right_axis = PlainAxis(orientation="right")
        right_axis.enableAutoSIPrefix(False)
        self.plot = pg.PlotWidget(
            axisItems={
                "bottom": pg.DateAxisItem(orientation="bottom"),
                "right": right_axis,
            },
            background=pal["plot_bg"],
        )
        if pal.get("user_text"):              # свой «Текст» окна (2.1.83) — и подписи осей графика
            for name in ("bottom", "right"):
                self.plot.getAxis(name).setTextPen(pg.mkPen(pal["muted"]))
        self.plot.hideAxis("left")
        self.plot.showAxis("right")
        right_axis.setStyle(showValues=True)
        self.plot.setMinimumHeight(140)
        self.plot.showGrid(x=True, y=True, alpha=0.12)
        self.plot.setMenuEnabled(True)
        self.curve = self.plot.plot(pen=pg.mkPen(pal["line"], width=1.5))

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(6)
        layout.addLayout(header)
        layout.addWidget(self.plot, 1)

    # --------------------------------------------------------

    def on_tick(self, ts, oi, last, bid, ask):
        if last is not None and (not self.prices or self.prices[-1][1] != last):
            self.prices.append((ts, last))
        if self.kind == "oi":
            if last is not None:
                self.side_lbl.setText(fmt_price(last))
            value = oi
        else:
            if bid is not None:
                self.bid = bid
            if ask is not None:
                self.ask = ask
            if self.bid is not None and self.ask is not None:
                self.side_lbl.setText(f"{fmt_price(self.bid)} / {fmt_price(self.ask)}")
            value = last

        if value is None:
            return
        if self.data and self.data[-1][1] == value:
            return  # значение не изменилось

        if self.first_value is None:
            self.first_value = value
        self.data.append((ts, value))
        self.dirty = True

        self.main_lbl.setText(fmt_int(value) if self.kind == "oi" else fmt_price(value))
        self._set_delta(self.d_run_lbl, value - self.first_value)
        self._set_delta(self.d_min_lbl, self._delta_last_minute(ts, value))

    def _delta_last_minute(self, ts, value):
        """Изменение за последние 60 с (None, если данных меньше минуты)."""
        for t, v in reversed(self.data):
            if t <= ts - 60:
                return value - v
        return None

    def _set_delta(self, label, delta):
        if delta is None:
            label.setText("—")
            color = self._pal["muted"]
        else:
            label.setText(fmt_delta_int(delta) if self.kind == "oi" else fmt_delta_price(delta))
            color = (self._pal["up"] if delta > 0
                     else self._pal["down"] if delta < 0 else self._pal["muted"])
        label.setStyleSheet(f"color: {color};")

    def hour_summary(self, now: float) -> str | None:
        """Строка итогов за час: «Si-12.26: OI 1 234 567, за час +12 345 (+1,01 %), мин … / макс …;
        цена 81 600, за час −250». None — данных ещё нет."""
        if not self.data:
            return None
        oi_now = self.data[-1][1]
        oi_then, since = hour_notes.value_hour_ago(list(self.data), now)
        recent = [v for t, v in self.data if t >= now - hour_notes.HOUR_SEC] or [oi_now]
        line = (f"{self.title}: OI {hour_notes.fmt_int(oi_now)}, {hour_notes.span_text(since, now)} "
                f"{hour_notes.fmt_delta(oi_now - oi_then)}{hour_notes.fmt_pct(oi_now, oi_then)}; "
                f"мин {hour_notes.fmt_int(min(recent))} / макс {hour_notes.fmt_int(max(recent))}")
        if self.prices:
            price_now = self.prices[-1][1]
            price_then, p_since = hour_notes.value_hour_ago(list(self.prices), now)
            line += (f"; цена {fmt_price(price_now)}, {hour_notes.span_text(p_since, now)} "
                     f"{fmt_delta_price(price_now - price_then)}")
        return line

    def refresh(self):
        if not self.dirty:
            return
        self.dirty = False
        self.curve.setData([t for t, _ in self.data], [v for _, v in self.data])


# ============================================================
# ВКЛАДКА
# ============================================================

class OpenInterestTab(QtWidgets.QWidget):
    """Вкладка терминала. Подключение: start(client) после создания клиента,
    stop() из _shutdown_connections() (см. gui_app.py)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        try:                                          # свои фон и текст окна (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "oi")
        except Exception:
            pass
        self._pal = _palette()
        self._client = None
        self._hub = None
        self._hub_subs = []                             # подписки на котировки в хабе
        self._quarterly: list[str] = []                 # текущие квартальные контракты
        self._panels: dict[str, InstrumentPanel] = {}   # ВСЕ панели: квартальные + вечные

        self._apply_style()
        try:                                          # OK в «Настройках» — размеры под новый шрифт (2.1.83)
            import appearance
            appearance.NOTIFIER.changed.connect(self._apply_style)
        except Exception:
            pass

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 0)
        layout.setSpacing(6)

        # Внутренние вкладки: квартальные / вечные фьючерсы
        self._tabs = QtWidgets.QTabWidget(self)
        self._tabs.setDocumentMode(True)
        self._quarterly_page, self._quarterly_layout = self._make_page()
        self._perpetual_page, self._perpetual_layout = self._make_page()
        self._tabs.addTab(self._quarterly_page, "Квартальные")
        self._tabs.addTab(self._perpetual_page, "Вечные")
        self._tabs.currentChanged.connect(self._on_page_changed)
        self.note_btn = QtWidgets.QPushButton("Заметка")
        self.note_btn.setToolTip("Итоги за последний час по всем фьючерсам окна — в «Заметки»")
        self.note_btn.setAutoDefault(False)
        self.note_btn.clicked.connect(self._add_hour_note)
        self._tabs.setCornerWidget(self.note_btn, QtCore.Qt.Corner.TopRightCorner)
        layout.addWidget(self._tabs, 1)

        # Вечные фьючерсы не экспирируются — их панели создаются один раз.
        for symbol, title in PERPETUALS:
            panel = InstrumentPanel(symbol, title, "oi", self._pal)
            self._panels[symbol.upper()] = panel
            self._perpetual_layout.addWidget(panel, 1)

        self.status_lbl = QtWidgets.QLabel("Не подключено")
        self.status_lbl.setObjectName("status")
        layout.addWidget(self.status_lbl)

        self._refresh_timer = QtCore.QTimer(self)
        self._refresh_timer.timeout.connect(self._refresh)
        self._refresh_timer.start(REFRESH_MS)

        self._rollover_timer = QtCore.QTimer(self)
        self._rollover_timer.timeout.connect(self._check_rollover)
        self._rollover_timer.start(ROLLOVER_CHECK_MS)

    def _apply_style(self) -> None:
        """Стиль карточек. Размеры подписей (название 14, ОИ 20, значения 14, подписи 11 px при шрифте темы) —
        под общий размер шрифта интерфейса («Настройки» → «Размер шрифта», appearance.ui_px, 2.1.83)."""
        try:
            import appearance
            px = appearance.ui_px
        except Exception:                             # noqa: BLE001 — без настроек: размеры темы
            px = round
        p = self._pal
        self.setStyleSheet(f"""
            QFrame#panel {{ background: {p['panel']}; border: 1px solid {p['border']}; border-radius: 4px; }}
            QLabel {{ background: transparent; }}
            QLabel#name {{ font-size: {px(14)}px; font-weight: 600; }}
            QLabel#muted {{ color: {p['muted']}; font-size: {px(11)}px; }}
            QLabel#oi {{ font-size: {px(20)}px; font-weight: 600; }}
            QLabel#value {{ font-size: {px(14)}px; }}
            QLabel#status {{ color: {p['muted']}; padding: 4px 14px; }}
        """)

    @staticmethod
    def _make_page():
        page = QtWidgets.QWidget()
        page_layout = QtWidgets.QVBoxLayout(page)
        page_layout.setContentsMargins(0, 8, 0, 0)
        page_layout.setSpacing(10)
        return page, page_layout

    # ---- вызывается терминалом ----------------------------------------------
    def start(self, client, hub=None) -> None:
        """(Пере)запуск: подписки на котировки в MarketDataHub. Панели с накопленными точками
        сохраняются; после ролловера пересоздаются только квартальные."""
        self.stop()
        if hub is None:
            return                          # шлюз не запустился — данных нет
        self._client = client
        self._hub = hub
        quarterly = self._desired_quarterly()
        if quarterly != self._quarterly:
            self._rebuild_quarterly(quarterly)
        symbols = quarterly + [symbol for symbol, _ in PERPETUALS]
        from core.models import InstrumentId
        self._hub_subs = [
            hub.subscribe_quotes(InstrumentId.parse(symbol),
                                 lambda q, s=symbol: self._on_hub_quote(s, q))
            for symbol in symbols
        ]
        self.status_lbl.setText("Подключение...")

    def stop(self) -> None:
        """Закрыть подписки в хабе."""
        for sub in self._hub_subs:
            sub.close()
        self._hub_subs = []
        self._hub = None
        self._client = None
        self.status_lbl.setText("Не подключено")

    # ---- внутреннее -----------------------------------------------------------
    @staticmethod
    def _desired_quarterly() -> list[str]:
        return [front_quarterly_symbol(prefix) for prefix in PREFIXES]

    def _on_hub_quote(self, symbol: str, quote) -> None:
        """Quote из хаба (поля из прошлых сообщений уже подставлены) -> панель инструмента."""
        if quote.open_interest is None and quote.last is None and quote.bid is None and quote.ask is None:
            return
        if not self.status_lbl.text().startswith("Поток"):
            self.status_lbl.setText("Поток подключён")
        self._on_tick(symbol, time.time(), quote.open_interest, quote.last, quote.bid, quote.ask)

    def _rebuild_quarterly(self, symbols: list[str]) -> None:
        for symbol in self._quarterly:
            panel = self._panels.pop(symbol.upper(), None)
            if panel is not None:
                self._quarterly_layout.removeWidget(panel)
                panel.hide()
                panel.deleteLater()
        self._quarterly = list(symbols)
        for symbol in symbols:
            panel = InstrumentPanel(symbol, contract_title(symbol), "oi", self._pal)
            self._panels[symbol.upper()] = panel
            self._quarterly_layout.addWidget(panel, 1)

    def _check_rollover(self) -> None:
        """Долгая сессия через ролловер: контракты сменились — переподписываемся на новые."""
        client, hub = self._client, self._hub
        if hub is not None and self._desired_quarterly() != self._quarterly:
            self.start(client, hub)

    def _on_tick(self, symbol, ts, oi, last, bid, ask) -> None:
        panel = self._panels.get(symbol.upper())
        if panel is not None:
            panel.on_tick(ts, oi, last, bid, ask)

    def _visible_panels(self):
        page = self._tabs.currentWidget()
        return [panel for panel in self._panels.values() if panel.parentWidget() is page]

    def _on_page_changed(self, _index: int) -> None:
        for panel in self._visible_panels():
            panel.dirty = True       # точки копились, пока страница была скрыта
            panel.refresh()

    def _refresh(self) -> None:
        if not self.isVisible():
            return          # скрытую вкладку не перерисовываем (экономим CPU)
        for panel in self._visible_panels():
            panel.refresh()

    def _add_hour_note(self) -> None:
        now = time.time()
        lines = [line for panel in self._panels.values() if (line := panel.hour_summary(now))]
        if not lines:
            self.status_lbl.setText("Для заметки пока нет данных")
            return
        quarterly = [self._panels[s.upper()].title for s in self._quarterly if s.upper() in self._panels]
        self.status_lbl.setText(hour_notes.add_hour_note(
            self, "Открытый интерес", ", ".join(quarterly) or "фьючерсы",
            lines[0].split(";")[0], "\n".join(lines)))

    def showEvent(self, event) -> None:
        for panel in self._panels.values():
            panel.dirty = True       # за время «скрытости» накопились точки — перерисовать
        super().showEvent(event)
