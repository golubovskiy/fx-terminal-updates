# -*- coding: utf-8 -*-
"""
CNY Forward — Qt-вкладка для FX Terminal.

v2.6

Главные изменения:
- котировки из хаба подписок терминала (MarketDataHub): без своего потока у брокера,
  переподключение и переподписку делает шлюз;
- одновременно текущий и следующий CNY-фьючерс;
- переключение фьючерса без перезапуска подписки;
- собственная история/dashboard для каждого контракта;
- справочник (экспирации) — через уже существующий FinamStreamClient;
- расчёт делегируется cny_forward_monitor_v2_5.py;
- кнопка «Заметка»: итоги за последний час по выбранному контракту (TOM, фьючерс, базис,
  справедливый базис, отклонение от справедливой цены — сейчас, изменение, мин / макс)
  в окно «Заметки» (hour_notes.py). Час берётся из записей этого запуска, а если запуск
  короче — из истории cny_forward_history.csv. К заметке прикладывается копия дашборда (PNG — картинкой
  заметки, note_images), а в комментарий после итогов за час — текущий текстовый отчёт окна.
"""

from __future__ import annotations

import csv
import re
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Any

import matplotlib.dates as mdates
# Dashboard рисуется в фоновом потоке, поэтому НЕ через pyplot: pyplot держит глобальное
# состояние и GUI-бэкенд (в терминале это Qt), а работа с ним вне главного потока даёт
# «Starting a Matplotlib GUI outside of the main thread will likely fail» и может уронить Qt.
# Figure + холст Agg рисуют в память, без окон и без общего состояния — это потокобезопасно.
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from PySide6 import QtCore, QtGui, QtWidgets

from finam_sdk_client import FinamStreamClient
from finam_terminal import display_name
import contracts
import hour_notes

from cny_forward_monitor_v2_5 import (
    BASE_DIR,
    CSV_PATH,
    FUTURE_MIC,
    INITIAL_WAIT_SECONDS,
    RUSFAR_3M_SYMBOL,
    RUSFAR_SYMBOL,
    RUSFARCNY_SYMBOL,
    TOM_SYMBOL,
    QuoteManager,
    append_csv,
    candidate_symbols,
    days_to_expiry,
    get_asset_name,
    get_asset_symbol,
    get_expiration,
    make_record,
    now_local,
)


# ============================================================================
# ЧАСОВОЙ ПОЯС ОТОБРАЖЕНИЯ
# ============================================================================

_display_tz: ZoneInfo | None = None  # None — показывать как записано в данных


def set_display_timezone(name: str | None) -> bool:
    """
    Задаёт часовой пояс для графика и текстового отчёта (вызывается из gui_app
    при старте и после изменения настроек). Данные в CSV не меняются.
    """
    global _display_tz
    if not name:
        _display_tz = None
        return True
    try:
        _display_tz = ZoneInfo(name)
    except Exception:
        return False
    return True


def _convert_dt(dt: datetime) -> datetime:
    """
    Переводит datetime в выбранный пояс. Время без пояса считается
    системным локальным (now_local() в мониторе).
    """
    if _display_tz is None:
        return dt
    if dt.tzinfo is None:
        dt = dt.astimezone()  # naive -> системный локальный пояс
    return dt.astimezone(_display_tz)


def to_display_naive(dt: datetime) -> datetime:
    """Для matplotlib: локальное время выбранного пояса без tzinfo."""
    return _convert_dt(dt).replace(tzinfo=None)


def format_timestamp_display(value: Any) -> str:
    """Строку timestamp из записи -> 'YYYY-MM-DD HH:MM:SS' в выбранном поясе."""
    if _display_tz is None:
        return str(value)
    try:
        dt = datetime.fromisoformat(str(value))
    except Exception:
        return str(value)
    return _convert_dt(dt).strftime("%Y-%m-%d %H:%M:%S")


def _short_error(exc) -> str:
    """Из ошибки gRPC — одна строка: «UNAVAILABLE: Stream removed (End of TCP stream)»."""
    text = str(exc)
    code = re.search(r"StatusCode\.(\w+)", text)
    details = re.search(r'details = "([^"\n]+)', text)
    if details:
        return f"{code.group(1)}: {details.group(1)[:140]}" if code else details.group(1)[:140]
    return text.strip().splitlines()[0][:160] if text.strip() else type(exc).__name__


RESTART_BASE_SEC = 5      # после обрыва — повтор через 5, 10, 20, 40, 60 … с
RESTART_MAX_SEC = 60


# ============================================================================
# DASHBOARD
# ============================================================================

DASHBOARD_DIR = BASE_DIR / "cny_forward_dashboards"


def dashboard_path_for(symbol: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", symbol)
    return DASHBOARD_DIR / f"cny_forward_dashboard_{safe}.png"


CSV_NUMERIC_FIELDS = (
    "days_to_expiry",
    "tom",
    "future",
    "future_bid",
    "future_ask",
    "rusfar",
    "rusfar_3m",
    "rusfarcny",
    "fair_forward_on_on",
    "market_basis",
    "fair_basis_on_on",
    "market_residual_on_on",
    "fair_forward_3m",
    "fair_basis_3m",
    "market_residual_3m",
)


def load_history_for_symbol(symbol: str) -> list[dict[str, Any]]:
    """
    Читает общий CSV, но оставляет только выбранный контракт.
    """

    if not CSV_PATH.exists():
        return []

    result: list[dict[str, Any]] = []

    try:
        with CSV_PATH.open(
            "r",
            newline="",
            encoding="utf-8-sig",
        ) as file:

            for row in csv.DictReader(file):

                if row.get("future_symbol") != symbol:
                    continue

                try:
                    row["timestamp_dt"] = datetime.fromisoformat(
                        row["timestamp"]
                    )
                except Exception:
                    continue

                for field in CSV_NUMERIC_FIELDS:
                    try:
                        row[field] = float(row[field])
                    except (TypeError, ValueError):
                        row[field] = None

                result.append(row)

    except Exception as exc:
        print(
            f"[CNY Forward] Ошибка чтения CSV: {exc}"
        )

    result.sort(
        key=lambda x: x["timestamp_dt"]
    )

    return result


def _apply_dashboard_colors(fig, axes) -> None:
    """Фон и текст дашборда из «Настройки» → «Цвета» → «CNY Forward» (appearance, 2.1.83): фон рисунка и графиков,
    заголовки, подписи, деления, рамки и легенды. Не задано — как рисует matplotlib (белый фон, чёрный текст).
    Линии данных остаются своих цветов. Вызывается и из фонового потока: QSettings читать там можно."""
    try:
        import appearance
        bg, text = appearance.override("cny.dash_bg"), appearance.override("cny.dash_text")
    except Exception:
        return
    if not bg and not text:
        return
    if bg:
        fig.set_facecolor(bg)
    if text and fig._suptitle is not None:
        fig._suptitle.set_color(text)
    for ax in axes:
        if bg:
            ax.set_facecolor(bg)
        if text:
            ax.tick_params(colors=text, which="both")
            ax.xaxis.label.set_color(text)
            ax.yaxis.label.set_color(text)
            ax.title.set_color(text)
            for name in ("_left_title", "_right_title"):        # заголовки с loc="left" / "right"
                title = getattr(ax, name, None)
                if title is not None:
                    title.set_color(text)
            for spine in ax.spines.values():
                spine.set_edgecolor(text)
        legend = ax.get_legend()
        if legend is not None:
            if bg:
                legend.get_frame().set_facecolor(bg)
            if text:
                for item in legend.get_texts():
                    item.set_color(text)


def draw_dashboard_for_symbol(
    symbol: str,
) -> Path | None:
    """
    Dashboard только для одного фьючерса.
    """

    rows = load_history_for_symbol(symbol)

    if not rows:
        return None

    rows = rows[-1000:]

    times = [
        to_display_naive(row["timestamp_dt"])
        for row in rows
    ]

    def kop(field: str):
        return [
            None
            if row.get(field) is None
            else row[field] * 100
            for row in rows
        ]

    fig = Figure(figsize=(16, 12))
    FigureCanvasAgg(fig)          # холст в памяти (PNG), без GUI
    axes = fig.subplots(
        4,
        1,
        sharex=True,
        gridspec_kw={
            "height_ratios": [
                1.25,
                1.35,
                1.0,
                0.75,
            ]
        },
    )

    # ------------------------------------------------------------------
    # 1. Базис
    # ------------------------------------------------------------------

    axes[0].plot(
        times,
        kop("market_basis"),
        label="Future − TOM",
        linewidth=2,
    )

    axes[0].plot(
        times,
        kop("fair_basis_on_on"),
        label="Fair Forward − TOM",
    )

    axes[0].plot(
        times,
        kop("market_residual_on_on"),
        label="Future − Fair Forward",
    )

    axes[0].axhline(
        0,
        linewidth=0.8,
    )

    axes[0].set_ylabel("коп.")
    axes[0].set_title(
        f"СТРУКТУРА БАЗИСА — {display_name(symbol)}",
        loc="left",
    )

    axes[0].legend(
        loc="upper left",
        frameon=False,
    )

    # ------------------------------------------------------------------
    # 2. Цены
    # ------------------------------------------------------------------

    axes[1].plot(
        times,
        [row["tom"] for row in rows],
        label="CNY TOM",
    )

    axes[1].plot(
        times,
        [row["fair_forward_on_on"] for row in rows],
        label="Fair Forward",
    )

    axes[1].plot(
        times,
        [row["future"] for row in rows],
        label="CNY Future",
        linewidth=2,
    )

    axes[1].set_ylabel("RUB")
    axes[1].set_title(
        "ЦЕНЫ",
        loc="left",
    )

    axes[1].legend(
        loc="upper left",
        frameon=False,
    )

    # ------------------------------------------------------------------
    # 3. Ставки
    # ------------------------------------------------------------------

    axes[2].plot(
        times,
        [row["rusfar"] for row in rows],
        label="RUSFAR",
    )

    axes[2].plot(
        times,
        [row["rusfar_3m"] for row in rows],
        label="RUSFAR 3M",
    )

    axes[2].plot(
        times,
        [row["rusfarcny"] for row in rows],
        label="RUSFARCNY",
    )

    axes[2].set_ylabel("%")
    axes[2].set_title(
        "СТАВКИ",
        loc="left",
    )

    axes[2].legend(
        loc="upper left",
        frameon=False,
    )

    # ------------------------------------------------------------------
    # 4. Срок
    # ------------------------------------------------------------------

    axes[3].plot(
        times,
        [row["days_to_expiry"] for row in rows],
        label="Дней до экспирации",
    )

    axes[3].set_ylabel("дни")
    axes[3].set_title(
        "СРОК ДО ЭКСПИРАЦИИ",
        loc="left",
    )

    axes[3].legend(
        loc="upper right",
        frameon=False,
    )

    for ax in axes:
        ax.grid(
            True,
            alpha=0.18,
        )

    axes[-1].xaxis.set_major_formatter(
        mdates.DateFormatter(
            "%d.%m\n%H:%M"
        )
    )

    fig.suptitle(
        f"FINAM — CNY/RUB FORWARD — {display_name(symbol)}",
        fontsize=14,
        fontweight="bold",
    )

    _apply_dashboard_colors(fig, axes)

    fig.tight_layout(
        rect=(0, 0, 1, 0.975),
        h_pad=1.4,
    )

    DASHBOARD_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    path = dashboard_path_for(symbol)

    fig.savefig(
        path,
        dpi=150,
        bbox_inches="tight",
    )

    return path


# ============================================================================
# ОТЧЁТ
# ============================================================================


def format_record_report(
    record: dict[str, Any],
) -> str:

    market = float(
        record["market_basis"]
    )

    def share(
        part: float,
        total: float,
    ) -> float | None:

        if abs(total) < 1e-12:
            return None

        return part / total * 100

    rate_share = share(
        record["fair_basis_on_on"],
        market,
    )

    residual_share = share(
        record["market_residual_on_on"],
        market,
    )

    lines = []

    lines.append("=" * 66)
    lines.append("CNY / RUB FORWARD")
    lines.append("=" * 66)

    lines.append("")
    lines.append("КОНТРАКТ")
    lines.append(
        f"  Название       : {record['future_name']}"
    )
    lines.append(
        f"  Символ         : {display_name(record['future_symbol'])}"
    )
    lines.append(
        f"  Экспирация     : {record['expiration']}"
    )
    lines.append(
        f"  До экспирации  : "
        f"{record['days_to_expiry']:.2f} дней"
    )
    lines.append(
        f"  Время          : {format_timestamp_display(record['timestamp'])}"
    )

    lines.append("")
    lines.append("КОТИРОВКИ")

    lines.append(
        f"  CNY TOM        : {record['tom']:.4f}"
    )

    lines.append(
        f"  CNY Future     : {record['future']:.4f}"
    )

    if record.get("future_bid") is not None:
        lines.append(
            f"  Future Bid     : "
            f"{record['future_bid']:.4f}"
        )

    if record.get("future_ask") is not None:
        lines.append(
            f"  Future Ask     : "
            f"{record['future_ask']:.4f}"
        )

    lines.append("")
    lines.append("СТАВКИ")

    lines.append(
        f"  RUSFAR         : "
        f"{record['rusfar']:.2f}%"
    )

    lines.append(
        f"  RUSFAR 3M      : "
        f"{record['rusfar_3m']:.2f}%"
    )

    lines.append(
        f"  RUSFARCNY      : "
        f"{record['rusfarcny']:.2f}%"
    )

    lines.append("")
    lines.append("РАЗЛОЖЕНИЕ БАЗИСА — ON/ON")
    lines.append("-" * 66)

    lines.append(
        f"  Future − TOM               : "
        f"{market:+.6f} ₽ "
        f"({market * 100:+.2f} коп.)"
    )

    lines.append(
        f"  Fair Forward               : "
        f"{record['fair_forward_on_on']:.6f}"
    )

    lines.append(
        f"  Процентная часть           : "
        f"{record['fair_basis_on_on']:+.6f} ₽ "
        f"({record['fair_basis_on_on'] * 100:+.2f} коп.)"
    )

    lines.append(
        f"  Рыночная премия / дисконт  : "
        f"{record['market_residual_on_on']:+.6f} ₽ "
        f"({record['market_residual_on_on'] * 100:+.2f} коп.)"
    )

    if rate_share is not None:
        lines.append(
            f"  Доля процентной части      : "
            f"{rate_share:+.2f}%"
        )

    if residual_share is not None:
        lines.append(
            f"  Доля рыночного отклонения   : "
            f"{residual_share:+.2f}%"
        )

    lines.append("")
    lines.append("РАЗЛОЖЕНИЕ БАЗИСА — 3M/CNY")
    lines.append("-" * 66)

    lines.append(
        f"  Fair Forward               : "
        f"{record['fair_forward_3m']:.6f}"
    )

    lines.append(
        f"  Процентная часть           : "
        f"{record['fair_basis_3m']:+.6f} ₽ "
        f"({record['fair_basis_3m'] * 100:+.2f} коп.)"
    )

    lines.append(
        f"  Рыночная премия / дисконт  : "
        f"{record['market_residual_3m']:+.6f} ₽ "
        f"({record['market_residual_3m'] * 100:+.2f} коп.)"
    )

    lines.append("")
    lines.append("STREAM")
    lines.append(
        f"  Сообщений stream            : "
        f"{record['updates_count']}"
    )

    lines.append("")
    lines.append(
        f"  CSV                         : {CSV_PATH}"
    )

    lines.append(
        f"  Dashboard                   : "
        f"{dashboard_path_for(record['future_symbol'])}"
    )

    lines.append("=" * 66)

    return "\n".join(lines)


# ============================================================================
# ПОИСК ФЬЮЧЕРСОВ
# ============================================================================


def list_active_futures(
    client: FinamStreamClient,
    stop_event: threading.Event | None = None,
) -> list[tuple[datetime, str, dict[str, Any]]]:

    now = datetime.now(timezone.utc)

    found = []
    seen = set()

    for symbol in candidate_symbols():

        if (
            stop_event is not None
            and stop_event.is_set()
        ):
            break

        try:
            asset = client.get_asset(symbol)
        except Exception:
            continue

        expiration = get_expiration(asset)

        if (
            expiration is None
            or expiration <= now
        ):
            continue

        asset_symbol = (
            get_asset_symbol(asset)
            or symbol
        )

        if "@" not in asset_symbol:
            asset_symbol = (
                f"{asset_symbol}@{FUTURE_MIC}"
            )

        # Настоящая дата экспирации — в общий справочник; «текущий» контракт выбираем
        # по единому правилу терминала (переход за contracts.ROLL_DAYS дня до экспирации).
        contracts.register_expiration(asset_symbol, expiration)
        if not contracts.is_current(asset_symbol):
            continue

        if asset_symbol in seen:
            continue

        seen.add(asset_symbol)

        found.append(
            (
                expiration,
                asset_symbol,
                asset,
            )
        )

    found.sort(
        key=lambda item: item[0]
    )

    # Нам нужны именно ближайший и следующий.
    return found[:2]


# ============================================================================
# SIGNALS
# ============================================================================


# ============================================================================
# КОТИРОВКИ ИЗ ХАБА ТЕРМИНАЛА
# ============================================================================


class HubQuoteFeed:
    """Котировки для CnyMonitorWorker из MarketDataHub.

    Для worker'а выглядит как QuoteManager + reader из cny_forward_monitor_v2_5:
    manager (последние котировки по символу, поля склеены), updates_count, error
    (у хаба всегда None — обрывы он переживает сам) и stop().

    Quote хаба переводится в словарь того же вида, что даёт поток Finam
    ({"symbol": …, "last": …, "bid": …, …}; только присланные поля), поэтому make_record
    и остальной расчёт не меняются.

    Потоки: open() / close() — из GUI-потока (так требует хаб); колбэки хаба — тоже в GUI;
    worker читает manager из своего потока (QuoteManager потокобезопасен).
    """

    FIELDS = ("last", "bid", "ask", "close", "open", "high", "low", "volume")

    def __init__(self, hub, symbols: list[str]) -> None:
        from core.models import InstrumentId

        self.manager = QuoteManager()
        self.updates_count = 0
        self.error: Exception | None = None
        self.symbols = list(symbols)
        self._stopped = False
        self._subs = [
            hub.subscribe_quotes(InstrumentId.parse(symbol), self._handler(symbol))
            for symbol in self.symbols
        ]

    def _handler(self, symbol: str):
        def on_quote(quote) -> None:
            if self._stopped:
                return
            row: dict[str, Any] = {"symbol": symbol}
            for field in self.FIELDS:
                value = getattr(quote, field, None)
                if value is not None:
                    row[field] = value
            self.manager.update({"quote": [row]})
            self.updates_count += 1
        return on_quote

    def stop(self) -> None:
        """Перестать принимать котировки (можно из любого потока; подписки закрывает close())."""
        self._stopped = True

    def close(self) -> None:
        """Закрыть подписки хаба — только из GUI-потока."""
        self._stopped = True
        subs, self._subs = self._subs, []
        for sub in subs:
            try:
                sub.close()
            except Exception:
                traceback.print_exc()


class _CnyMonitorSignals(QtCore.QObject):

    status = QtCore.Signal(str)

    record_ready = QtCore.Signal(
        dict,
        str,
    )

    error = QtCore.Signal(str)

    futures_ready = QtCore.Signal(list)


# ============================================================================
# ПОИСК КОНТРАКТОВ
# ============================================================================


class FutureListWorker(threading.Thread):

    def __init__(
        self,
        client: FinamStreamClient,
        signals: _CnyMonitorSignals,
    ) -> None:

        super().__init__(
            name="CnyFutureList",
            daemon=True,
        )

        self.client = client
        self.signals = signals

        self.stop_event = threading.Event()

    def stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:

        try:

            self.signals.status.emit(
                "Поиск текущего и следующего "
                "CNY-фьючерса…"
            )

            futures = list_active_futures(
                self.client,
                self.stop_event,
            )

            if self.stop_event.is_set():
                return

            if not futures:
                self.signals.error.emit(
                    "Активные CNY-фьючерсы не найдены."
                )
                return

            self.signals.futures_ready.emit(
                futures
            )

        except Exception as exc:

            if not self.stop_event.is_set():

                traceback.print_exc()

                self.signals.error.emit(
                    str(exc)
                )


# ============================================================================
# ОСНОВНОЙ WORKER
# ============================================================================


class CnyMonitorWorker(threading.Thread):
    """
    ОДИН worker и ОДИН QuoteStream.

    В stream:
        CNYRUB_TOM
        RUSFAR
        RUSFAR3M
        RUSFARCNY
        текущий future
        следующий future

    При переключении future stream не перезапускается.

    feed — HubQuoteFeed (котировки из хаба терминала, подписки открывает вкладка).
    """

    def __init__(
        self,
        client: FinamStreamClient,
        signals: _CnyMonitorSignals,
        futures: list[
            tuple[
                datetime,
                str,
                dict[str, Any],
            ]
        ],
        selected_index: int = 0,
        feed: HubQuoteFeed | None = None,
    ) -> None:
        if feed is None:
            raise ValueError("CnyMonitorWorker: нужны котировки из хаба терминала (feed)")

        super().__init__(
            name="CnyForwardMonitor",
            daemon=True,
        )

        self.client = client
        self.feed = feed
        self.signals = signals
        self.futures = futures

        self.selected_lock = threading.Lock()

        self.selected_index = max(
            0,
            min(
                selected_index,
                len(futures) - 1,
            ),
        )

        self.stop_event = threading.Event()
        self.update_event = threading.Event()

        self.reader: HubQuoteFeed | None = None
        self.manager: QuoteManager | None = None

    # ------------------------------------------------------------------

    def stop(self) -> None:

        self.stop_event.set()
        self.update_event.set()

        if self.reader is not None:
            self.reader.stop()

    def request_update(self) -> None:
        self.update_event.set()

    def select_future(
        self,
        index: int,
    ) -> None:

        if (
            index < 0
            or index >= len(self.futures)
        ):
            return

        with self.selected_lock:
            self.selected_index = index

        # Разбудить worker.
        self.update_event.set()

    def selected_future(
        self,
    ) -> tuple[
        datetime,
        str,
        dict[str, Any],
    ]:

        with self.selected_lock:
            return self.futures[
                self.selected_index
            ]

    # ------------------------------------------------------------------

    def stream_symbols(self) -> list[str]:

        symbols = [
            TOM_SYMBOL,
            RUSFAR_SYMBOL,
            RUSFAR_3M_SYMBOL,
            RUSFARCNY_SYMBOL,
        ]

        for _, symbol, _ in self.futures:

            if symbol not in symbols:
                symbols.append(symbol)

        return symbols

    # ------------------------------------------------------------------

    def common_quotes_ready(self) -> bool:

        if self.manager is None:
            return False

        symbols = [
            TOM_SYMBOL,
            RUSFAR_SYMBOL,
            RUSFAR_3M_SYMBOL,
            RUSFARCNY_SYMBOL,
        ]

        return all(
            self.manager.has(symbol)
            for symbol in symbols
        )

    # ------------------------------------------------------------------

    def calculate(self) -> None:

        if (
            self.manager is None
            or self.reader is None
        ):
            return

        expiration, symbol, asset = (
            self.selected_future()
        )

        name = (
            get_asset_name(asset)
            or symbol
        )

        if not self.common_quotes_ready():

            self.signals.status.emit(
                "Ждём TOM / RUSFAR / "
                "RUSFARCNY…"
            )

            return

        future_quote = (
            self.manager.get(symbol)
        )

        if not future_quote:

            self.signals.status.emit(
                f"{display_name(symbol)}: "
                "ждём котировку…"
            )

            return

        record = make_record(
            timestamp=now_local(),
            future_symbol=symbol,
            future_name=name,
            expiration=expiration,

            tom_quote=(
                self.manager.get(
                    TOM_SYMBOL
                ) or {}
            ),

            future_quote=future_quote,

            rusfar_quote=(
                self.manager.get(
                    RUSFAR_SYMBOL
                ) or {}
            ),

            rusfar_3m_quote=(
                self.manager.get(
                    RUSFAR_3M_SYMBOL
                ) or {}
            ),

            rusfarcny_quote=(
                self.manager.get(
                    RUSFARCNY_SYMBOL
                ) or {}
            ),

            updates_count=(
                self.reader.updates_count
            ),
        )

        if record is None:

            self.signals.status.emit(
                "Недостаточно данных "
                "для расчёта."
            )

            return

        append_csv(record)

        dashboard = (
            draw_dashboard_for_symbol(
                symbol
            )
        )

        self.signals.record_ready.emit(
            record,
            str(dashboard)
            if dashboard
            else "",
        )

    # ------------------------------------------------------------------

    def run(self) -> None:

        try:
            self._run()

        except Exception as exc:

            if not self.stop_event.is_set():

                print(f"[CNY Forward] {_short_error(exc)}", file=sys.stderr)

                self.signals.error.emit(
                    _short_error(exc)
                )

        finally:

            if self.reader is not None:
                self.reader.stop()

    # ------------------------------------------------------------------

    def _run(self) -> None:

        symbols = self.stream_symbols()

        # Подписки в хабе уже открыты вкладкой (GUI-поток); здесь — только чтение.
        self.signals.status.emit(
            "Котировки из хаба терминала: "
            + ", ".join(symbols)
        )
        self.manager = self.feed.manager
        self.reader = self.feed

        self.signals.status.emit(
            "Ждём первый snapshot…"
        )

        deadline = (
            time.time()
            + INITIAL_WAIT_SECONDS
        )

        while (
            time.time() < deadline
            and not self.stop_event.is_set()
        ):

            _, selected_symbol, _ = (
                self.selected_future()
            )

            if (
                self.common_quotes_ready()
                and self.manager.has(
                    selected_symbol
                )
            ):
                break

            if self.reader.error:
                raise RuntimeError(
                    "Ошибка stream reader: "
                    f"{self.reader.error}"
                )

            time.sleep(0.2)

        if self.stop_event.is_set():
            return

        expiration, symbol, asset = (
            self.selected_future()
        )

        name = (
            get_asset_name(asset)
            or symbol
        )

        missing = []

        required = [
            TOM_SYMBOL,
            symbol,
            RUSFAR_SYMBOL,
            RUSFAR_3M_SYMBOL,
            RUSFARCNY_SYMBOL,
        ]

        for item in required:

            if not self.manager.has(item):
                missing.append(item)

        if missing:

            raise RuntimeError(
                "Не получены snapshot для: "
                + ", ".join(missing)
            )

        self.signals.status.emit(
            f"Хаб OK — {display_name(symbol)}, "
            f"экспирация {expiration.date()}"
        )

        # Первый расчёт.
        self.calculate()

        # --------------------------------------------------------------
        # Постоянно живущий stream.
        #
        # update_event вызывается:
        #   - кнопкой «Обновить»;
        #   - при переключении контракта.
        # --------------------------------------------------------------

        while not self.stop_event.is_set():

            if self.reader.error:

                raise RuntimeError(
                    "Ошибка stream reader: "
                    f"{self.reader.error}"
                )

            if self.update_event.wait(
                timeout=0.5
            ):

                self.update_event.clear()

                if self.stop_event.is_set():
                    break

                self.calculate()


# ============================================================================
# IMAGE LABEL
# ============================================================================


class _ScaledImageLabel(QtWidgets.QLabel):

    def __init__(
        self,
        *args,
        **kwargs,
    ) -> None:

        super().__init__(
            *args,
            **kwargs
        )

        self.original: (
            QtGui.QPixmap | None
        ) = None

        self.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignCenter
        )

        self.setMinimumSize(
            200,
            150,
        )

    def set_original_pixmap(
        self,
        pixmap: QtGui.QPixmap,
    ) -> None:

        self.original = pixmap

        self.rescale()

    def resizeEvent(
        self,
        event,
    ) -> None:

        super().resizeEvent(event)

        self.rescale()

    def rescale(self) -> None:

        if (
            self.original is None
            or self.original.isNull()
        ):
            return

        pixmap = self.original.scaled(
            self.size(),
            QtCore.Qt.AspectRatioMode.KeepAspectRatio,
            QtCore.Qt.TransformationMode.SmoothTransformation,
        )

        self.setPixmap(pixmap)


# ============================================================================
# TAB
# ============================================================================


class CnyForwardMonitorTab(
    QtWidgets.QWidget
):

    def __init__(
        self,
        parent=None,
    ) -> None:

        super().__init__(parent)
        try:                                          # свои фон и текст окна (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "cny")
        except Exception:
            pass

        self.client: (
            FinamStreamClient | None
        ) = None

        # Хаб подписок терминала (MarketDataHub) и открытые в нём котировки.
        self.hub = None
        self.feed: HubQuoteFeed | None = None

        self.list_worker: (
            FutureListWorker | None
        ) = None

        self.worker: (
            CnyMonitorWorker | None
        ) = None

        self.futures = []

        self.signals = _CnyMonitorSignals()

        self.signals.status.connect(
            self.on_status
        )

        self.signals.record_ready.connect(
            self.on_record_ready
        )

        self.signals.error.connect(
            self.on_error
        )

        self.signals.futures_ready.connect(
            self.on_futures_ready
        )

        # ==============================================================
        # Верхняя строка
        # ==============================================================

        top = QtWidgets.QHBoxLayout()

        top.setContentsMargins(
            0,
            0,
            0,
            0,
        )

        top.addWidget(
            QtWidgets.QLabel(
                "Фьючерс:"
            )
        )

        self.future_combo = (
            QtWidgets.QComboBox()
        )

        # Узкий список: ширина по самому длинному пункту (раньше — минимум 400 px и растяжение
        # на всю строку).
        self.future_combo.setSizeAdjustPolicy(
            QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToContents
        )

        self.future_combo.setToolTip(
            "Переключение текущего/следующего "
            "фьючерса не перезапускает stream."
        )

        self.future_combo.currentIndexChanged.connect(
            self.on_future_selected
        )

        top.addWidget(
            self.future_combo,
        )
        top.addStretch(1)

        self.refresh_btn = (
            QtWidgets.QPushButton(
                "Обновить"
            )
        )

        self.refresh_btn.clicked.connect(
            self.on_refresh
        )

        top.addWidget(
            self.refresh_btn
        )

        self.rescan_btn = (
            QtWidgets.QPushButton(
                "↻ Контракты"
            )
        )

        self.rescan_btn.setToolTip(
            "Заново найти текущий и следующий "
            "активные контракты."
        )

        self.rescan_btn.clicked.connect(
            self.on_rescan
        )

        top.addWidget(
            self.rescan_btn
        )

        self.note_btn = QtWidgets.QPushButton("Заметка")
        self.note_btn.setToolTip("Итоги за последний час по выбранному контракту — в «Заметки»:\n"
                                 "картинка дашборда и текстовый отчёт окна — тоже в заметку")
        self.note_btn.clicked.connect(self._add_hour_note)
        top.addWidget(self.note_btn)
        self._hour_records: dict[str, list[tuple[float, dict]]] = {}   # контракт -> [(ts, запись)] за ~час
        self._last_record: dict | None = None

        # ==============================================================
        # Status
        # ==============================================================

        self.status_label = (
            QtWidgets.QLabel(
                "Не запущено"
            )
        )

        self.status_label.setStyleSheet(
            "padding: 4px; font-weight: bold;"
        )

        self.status_label.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Preferred,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )

        # ==============================================================
        # Dashboard
        # ==============================================================

        self.image_label = (
            _ScaledImageLabel(
                "Dashboard появится после "
                "первого расчёта."
            )
        )

        self.image_label.setWordWrap(
            True
        )

        # ==============================================================
        # Report
        # ==============================================================

        self.report_text = (
            QtWidgets.QPlainTextEdit()
        )

        self.report_text.setReadOnly(
            True
        )

        self.report_text.setFont(
            QtGui.QFont(
                "Consolas",
                9,
            )
        )

        self.report_text.setMinimumWidth(
            400
        )

        self.report_text.setLineWrapMode(
            QtWidgets.QPlainTextEdit
            .LineWrapMode
            .NoWrap
        )

        # ==============================================================
        # Splitter
        # ==============================================================

        splitter = QtWidgets.QSplitter(
            QtCore.Qt.Orientation.Horizontal
        )

        splitter.addWidget(
            self.image_label
        )

        splitter.addWidget(
            self.report_text
        )

        splitter.setStretchFactor(
            0,
            3,
        )

        splitter.setStretchFactor(
            1,
            2,
        )

        # ==============================================================
        # Layout
        # ==============================================================

        layout = QtWidgets.QVBoxLayout(
            self
        )

        layout.setContentsMargins(
            4,
            4,
            4,
            4,
        )

        layout.setSpacing(4)

        layout.addLayout(
            top
        )

        layout.addWidget(
            self.status_label
        )

        layout.addWidget(
            splitter,
            1,
        )

    # ==================================================================
    # START / STOP
    # ==================================================================

    def start(
        self,
        client: FinamStreamClient,
        hub=None,
    ) -> None:
        """client — справочник (экспирации); hub — MarketDataHub терминала: котировки."""

        if (
            self.list_worker is not None
            and self.list_worker.is_alive()
        ):
            return

        if (
            self.worker is not None
            and self.worker.is_alive()
        ):
            return

        self.client = client
        self.hub = hub

        self.status_label.setText(
            "Поиск текущего и следующего "
            "CNY-фьючерса…"
        )

        self.list_worker = (
            FutureListWorker(
                client,
                self.signals,
            )
        )

        self.list_worker.start()

    def stop(self) -> None:

        timer = getattr(self, "_restart_timer", None)
        if timer is not None:
            timer.stop()
        self._restart_attempt = 0

        if self.list_worker is not None:

            self.list_worker.stop()

            if self.list_worker.is_alive():

                self.list_worker.join(
                    timeout=2
                )

            self.list_worker = None

        if self.worker is not None:

            self.worker.stop()

            if self.worker.is_alive():

                self.worker.join(
                    timeout=3
                )

            self.worker = None

        self._close_feed()

    def _close_feed(self) -> None:
        if self.feed is not None:
            self.feed.close()
            self.feed = None

    # ==================================================================
    # FUTURES FOUND
    # ==================================================================

    def on_futures_ready(
        self,
        futures,
    ) -> None:

        self.futures = list(
            futures
        )

        self.future_combo.blockSignals(
            True
        )

        self.future_combo.clear()

        for index, (
            expiration,
            symbol,
            asset,
        ) in enumerate(
            self.futures
        ):

            name = (
                get_asset_name(asset)
                or symbol
            )

            role = (
                "Текущий"
                if index == 0
                else "Следующий"
            )

            label = (
                f"{role}: {display_name(symbol)} · "
                f"эксп. "
                f"{expiration:%d.%m.%Y}"
            )

            self.future_combo.addItem(
                label,
                (
                    symbol,
                    asset,
                    expiration,
                ),
            )

        self.future_combo.blockSignals(
            False
        )

        if not self.futures:
            return

        self.future_combo.setCurrentIndex(
            0
        )

        self.status_label.setText(
            "Запускаем единый stream…"
        )

        self.start_monitor(
            selected_index=0
        )

    # ==================================================================
    # MONITOR
    # ==================================================================

    def start_monitor(
        self,
        selected_index=0,
    ) -> None:

        if self.client is None:
            return

        if self.worker is not None:

            self.worker.stop()

            if self.worker.is_alive():

                self.worker.join(
                    timeout=3
                )

        # Подписки в хабе открываем здесь, в GUI-потоке (так требует хаб); worker только читает.
        # Новые — до закрытия прежних: иначе хаб остановил бы поток у брокера и тут же открыл снова.
        old_feed, self.feed = self.feed, None
        if self.hub is None:
            if old_feed is not None:
                old_feed.close()
            self.status_label.setText("Нет подключения к Finam: котировки берутся из хаба терминала")
            self.worker = None
            return
        symbols = [TOM_SYMBOL, RUSFAR_SYMBOL, RUSFAR_3M_SYMBOL, RUSFARCNY_SYMBOL]
        for _, symbol, _ in self.futures:
            if symbol not in symbols:
                symbols.append(symbol)
        self.feed = HubQuoteFeed(self.hub, symbols)
        if old_feed is not None:
            old_feed.close()

        self.worker = (
            CnyMonitorWorker(
                self.client,
                self.signals,
                self.futures,
                selected_index,
                feed=self.feed,
            )
        )

        self.worker.start()

    # ==================================================================
    # FUTURE SELECTION
    # ==================================================================

    def on_future_selected(
        self,
        index: int,
    ) -> None:

        if index < 0:
            return

        data = (
            self.future_combo.itemData(
                index
            )
        )

        if not data:
            return

        symbol, asset, expiration = data

        name = (
            get_asset_name(asset)
            or symbol
        )

        self.status_label.setText(
            f"Выбран {name} ({symbol}), "
            f"экспирация {expiration.date()}"
        )

        # --------------------------------------------------------------
        # ВАЖНО:
        #
        # Здесь НЕТ создания нового worker.
        # Только переключаем контракт внутри существующего stream.
        # --------------------------------------------------------------

        if (
            self.worker is not None
            and self.worker.is_alive()
        ):

            self.worker.select_future(
                index
            )

        elif self.futures:

            self.start_monitor(
                selected_index=index
            )

    # ==================================================================
    # REFRESH
    # ==================================================================

    def on_refresh(self) -> None:

        if (
            self.worker is not None
            and self.worker.is_alive()
        ):

            self.worker.request_update()

        else:

            self.status_label.setText(
                "Мониторинг ещё не запущен."
            )

    # ==================================================================
    # RESCAN
    # ==================================================================

    def on_rescan(self) -> None:

        if self.client is None:
            return

        if self.worker is not None:

            self.worker.stop()

            if self.worker.is_alive():

                self.worker.join(
                    timeout=3
                )

            self.worker = None

        self._close_feed()                 # контракты могут смениться — подписки откроем заново

        if (
            self.list_worker is not None
            and self.list_worker.is_alive()
        ):
            return

        self.future_combo.clear()

        self.status_label.setText(
            "Повторный поиск контрактов…"
        )

        self.list_worker = (
            FutureListWorker(
                self.client,
                self.signals,
            )
        )

        self.list_worker.start()

    # ==================================================================
    # SIGNALS
    # ==================================================================

    def on_status(
        self,
        text: str,
    ) -> None:

        self.status_label.setText(
            text
        )

    def on_error(
        self,
        text: str,
    ) -> None:
        """Ошибка (обычно обрыв связи с Finam): поток мониторинга завершился — поднимаем его снова
        с растущей паузой. Раньше вкладка после обрыва просто останавливалась до перезапуска терминала."""
        attempt = getattr(self, "_restart_attempt", 0) + 1
        self._restart_attempt = attempt
        delay = min(RESTART_BASE_SEC * 2 ** (attempt - 1), RESTART_MAX_SEC)
        self.status_label.setText(f"Ошибка: {text} — повтор через {delay} с")
        if self.client is None:
            return
        timer = getattr(self, "_restart_timer", None)
        if timer is None:
            timer = self._restart_timer = QtCore.QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._restart_after_error)
        timer.start(delay * 1000)

    def _restart_after_error(self) -> None:
        if self.client is None:
            return
        if self.list_worker is not None and self.list_worker.is_alive():
            return
        if self.worker is not None and self.worker.is_alive():
            return
        if self.futures:
            index = max(0, self.future_combo.currentIndex())
            self.status_label.setText("Переподключение…")
            self.start_monitor(selected_index=index)
        else:
            self.start(self.client, self.hub)

    # ---- итоги за час (кнопка «Заметка») -----------------------------------------------
    NOTE_FIELDS = (
        ("tom", "CNY TOM", 4),
        ("future", "Фьючерс", 4),
        ("market_basis", "Базис рынка (фьючерс − TOM)", 4),
        ("fair_basis_on_on", "Справедливый базис (O/N)", 4),
        ("market_residual_on_on", "Отклонение от справедливой (O/N)", 4),
        ("market_residual_3m", "Отклонение от справедливой (3M)", 4),
    )

    @staticmethod
    def _record_ts(record: dict) -> float | None:
        try:
            dt = datetime.fromisoformat(str(record.get("timestamp")))
            if dt.tzinfo is None:
                dt = dt.astimezone()             # без пояса — местное время ПК
            return dt.timestamp()
        except Exception:
            return None

    def _remember_record(self, record: dict) -> None:
        ts = self._record_ts(record)
        if ts is None:
            return
        self._last_record = record
        rows = self._hour_records.setdefault(str(record.get("future_symbol")), [])
        rows.append((ts, record))
        cutoff = ts - hour_notes.HOUR_SEC - 600
        while rows and rows[0][0] < cutoff:
            rows.pop(0)

    def _csv_hour(self, future_symbol: str, since: float) -> list[tuple[float, dict]]:
        """Записи контракта из cny_forward_history.csv с момента since (если запуск короче часа)."""
        out = []
        try:
            with open(CSV_PATH, newline="", encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    if row.get("future_symbol") != future_symbol:
                        continue
                    ts = self._record_ts(row)
                    if ts is None or ts < since:
                        continue
                    rec = {}
                    for key, _title, _d in self.NOTE_FIELDS:
                        try:
                            rec[key] = float(row.get(key))
                        except (TypeError, ValueError):
                            rec[key] = None
                    out.append((ts, rec))
        except OSError:
            return []
        return out

    def _add_hour_note(self) -> None:
        last = self._last_record
        if last is None:
            self.status_label.setText("Для заметки пока нет расчёта")
            return
        symbol = str(last.get("future_symbol"))
        now = time.time()
        since = now - hour_notes.HOUR_SEC
        rows = self._hour_records.get(symbol, [])
        if not rows or rows[0][0] > since + 60:
            history = self._csv_hour(symbol, since - 300)
            if history and (not rows or history[0][0] < rows[0][0]):
                rows = [r for r in history if not rows or r[0] < rows[0][0]] + rows
        lines = [f"{display_name(symbol)}, дней до экспирации {last.get('days_to_expiry', '—')}"]
        for key, title, digits in self.NOTE_FIELDS:
            series = [(ts, rec.get(key)) for ts, rec in rows if rec.get(key) is not None]
            value = last.get(key)
            if value is None or not series:
                continue
            then, t0 = hour_notes.value_hour_ago(series, now)
            recent = [v for t, v in series if t >= since] or [value]
            lines.append(f"{title}: {hour_notes.fmt_num(value, digits)}, {hour_notes.span_text(t0, now)} "
                         f"{hour_notes.fmt_delta(value - then, digits)}; мин {hour_notes.fmt_num(min(recent), digits)}"
                         f" / макс {hour_notes.fmt_num(max(recent), digits)}")
        report = self.report_text.toPlainText().strip()
        if report:
            lines += ["", "Отчёт окна:", report]
        images = []
        try:                                           # дашборд — копией: файл окна перезаписывается каждый расчёт
            import note_images
            png = dashboard_path_for(symbol)
            if png.is_file():
                images.append(note_images.save_bytes(png.read_bytes()))
        except OSError as exc:
            print(f"[cny-forward] дашборд в заметку не попал: {exc}", file=sys.stderr)
        self.status_label.setText(hour_notes.add_hour_note(
            self, "CNY Forward", display_name(symbol), lines[3] if len(lines) > 3 else lines[-1], "\n".join(lines),
            images=images))

    def on_record_ready(
        self,
        record: dict,
        png_path: str,
    ) -> None:

        self._restart_attempt = 0          # данные пошли — счётчик повторов с нуля
        self._remember_record(record)

        self.status_label.setText(
            f"{display_name(record['future_symbol'])} "
            f"— обновлено "
            f"{format_timestamp_display(record['timestamp'])}"
        )

        self.report_text.setPlainText(
            format_record_report(
                record
            )
        )

        if png_path:

            pixmap = QtGui.QPixmap(
                png_path
            )

            if not pixmap.isNull():

                self.image_label.set_original_pixmap(
                    pixmap
                )