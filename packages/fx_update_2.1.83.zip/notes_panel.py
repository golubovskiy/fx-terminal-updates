# -*- coding: utf-8 -*-
"""FX Terminal — окно «Заметки».

Заметка — событие (из окна «Уведомления»: робот, айсберг, спредовый робот, крупная сделка…)
или просто текст, плюс ваш комментарий. Хранятся в настройках терминала (QSettings, notes/items),
переживают перезапуск. Одна общая копия (NotesStore) на весь терминал: окно «Заметки» и кнопка
«В заметки» в уведомлениях работают с ней.

Напоминания о роботах: заметка о роботе («Робот: покупка … × 124 лота, интервал ≈ 1.0 с») запоминает
инструмент, сторону, объём и темп (robot_signature / robot_interval — из текста, поэтому работают и старые
заметки). Когда «Алгоритмы» находят робота с тем же инструментом, стороной, объёмом и похожим интервалом
(от половины до двойного), уведомление о нём дополняется ссылкой на заметку, а у заметки
растёт счётчик «встречался». Напоминание выключается у заметки (правая кнопка → «Напоминать…»).

Синхронизация между терминалами (notes_sync.py, WebDAV): каждое изменение заметки ставит ей «updated»
(время, ISO UTC, с миллисекундами) и подаёт сигнал edited; удалённые заметки запоминаются «надгробиями»
(notes/deleted: {id: когда удалена}), чтобы удаление дошло до других терминалов. snapshot() — набор для
обмена, merge_remote() — принять объединённый набор с сервера.

Картинки (note_images.py): note["images"] — имена PNG в папке notes_images (снимок графика — кнопка-камера
на графике; «Вставить картинку» / Ctrl+V в комментарии — из буфера обмена). Миниатюры — под комментарием,
двойной щелчок открывает картинку в программе просмотра Windows. Удалили заметку или картинку — файл
удаляется, имя запоминается (notes/images_deleted), чтобы обмен удалил его и на сервере; отправленные на
сервер картинки помнятся в notes/images_uploaded.

Теги, закрепление, цвет (notes_meta.py): «#тег» в тексте заметки — фильтр в панели тегов слева; правая кнопка
по заметке — «Закрепить» (всегда сверху, 📌) и «Цвет» (цветная метка строки); «Показать на графике» (и двойной
щелчок по строке) — график инструмента заметки на её моменте (MainWindow.open_chart_at).

Вид «Список / Карточки» (как сетка Google Keep, notes/view): карточка — цвет, 📌, тип и время, заголовок,
инструмент, первая картинка крупно (иначе подробности и начало комментария), теги. Фильтры, выделение,
меню и двойной щелчок — те же, что у списка.

«Дневник дня» (как daily notes в Obsidian и дневник сессии в Edgewonk): одна заметка на день (поле day);
кнопка создаёт её или обновляет сводку — сделки дня со счёта (day_trades_fn — назначает главное окно),
заметки, теги и снимки дня; сводка — блоком в начале комментария, ниже — ваши выводы (их кнопка не трогает).
«Статистика по тегам» — по заметкам-сделкам, которые сейчас показаны (фильтр дат / типа / поиска действует):
сделок, прибыльных, итог, средний, лучшая, худшая; двойной щелчок по тегу — фильтр по нему.
"""
from __future__ import annotations

import json
import sys
import time

import note_images
import notes_meta
import uuid
import re
from datetime import date, datetime, timezone

from PySide6 import QtCore, QtGui, QtWidgets

try:
    import fx_theme
except Exception:
    fx_theme = None

MAX_NOTES = 2000
SETTINGS_KEY = "notes/items"
DELETED_KEY = "notes/deleted"     # надгробия удалённых заметок {id: когда} — для синхронизации (notes_sync.py)
IMAGES_UPLOADED_KEY = "notes/images_uploaded"   # картинки, уже отправленные на сервер
IMAGES_DELETED_KEY = "notes/images_deleted"     # удалённые здесь картинки — удалить и на сервере
THUMB_H = 96                      # высота миниатюры под комментарием
VIEW_KEY = "notes/view"           # «list» / «cards»
CARD_W, CARD_H = 272, 236         # карточка (с промежутком сетки)
CARD_IMG_H = 112                  # высота картинки в карточке
_ROBOT_SIZE_RE = re.compile(r"×\s*([\d\s\u00a0]+(?:[.,]\d+)?)\s*лот")
_ROBOT_INTERVAL_RE = re.compile(r"интервал\s*≈\s*(\d+(?:[.,]\d+)?)\s*с")
INTERVAL_MATCH = 2.0          # интервал нового робота — от половины до двойного интервала из заметки


def robot_interval(note: dict) -> float | None:
    """Интервал между сделками робота из текста заметки («интервал ≈ 1.0 с») или None."""
    match = _ROBOT_INTERVAL_RE.search(str(note.get("details", "")))
    try:
        return float(match.group(1).replace(",", ".")) if match else None
    except ValueError:
        return None


def robot_signature(note: dict) -> tuple[str, float] | None:
    """(сторона BUY/SELL, объём сделки в лотах) заметки о роботе или None. Берётся из текста уведомления —
    «Робот: покупка» и «… × 124 лота …», — поэтому работает и для заметок, сохранённых до напоминаний."""
    title = str(note.get("title", "")).lower()
    if not title.startswith("робот"):
        return None
    side = "BUY" if "покупка" in title else "SELL" if "продажа" in title else None
    match = _ROBOT_SIZE_RE.search(str(note.get("details", "")))
    if side is None or match is None:
        return None
    try:
        size = float(re.sub(r"[\s\u00a0]", "", match.group(1)).replace(",", "."))
    except ValueError:
        return None
    return side, size


def _norm_symbol(text: str) -> str:
    return str(text or "").strip().upper()


_USER_SHADES: dict | None = None      # свои цвета «Заметок» (оттенки fx_theme.shades); {} — не заданы
_HOOKED = False                        # подписка на appearance.NOTIFIER.changed сделана


def _user_shades() -> dict:
    """«Настройки» → «Цвета» → «Заметки» (appearance, 2.1.83): фон и текст окна, из них — фон карточек, рамки и
    приглушённый текст. Считается один раз (карточки рисуются часто) и заново после «OK» в настройках
    (appearance.NOTIFIER.changed)."""
    global _USER_SHADES
    if _USER_SHADES is None:
        _USER_SHADES = {}
        try:
            import appearance
            bg, text = appearance.override("notes.bg"), appearance.override("notes.text")
            if (bg or text) and fx_theme is not None:
                sh = fx_theme.shades(QtGui.QColor(bg or fx_theme.BG_WINDOW).name(),
                                     QtGui.QColor(text or fx_theme.TEXT).name())
                keys = ("TEXT", "TEXT_DIM") + (("BG_WINDOW", "BG_PANEL", "BORDER", "BORDER_STRONG") if bg else ())
                _USER_SHADES = {k: sh[k] for k in keys}
            global _HOOKED
            if not _HOOKED:
                appearance.NOTIFIER.changed.connect(_forget_user_shades)
                _HOOKED = True
        except Exception:
            pass
    return _USER_SHADES


def _forget_user_shades() -> None:
    global _USER_SHADES
    _USER_SHADES = None


def _c(name: str, default: str) -> str:
    user = _user_shades().get(name)
    if user:
        return user
    return str(getattr(fx_theme, name, default)) if fx_theme is not None else default


_TRASH_PIXMAPS: tuple | None = None


def _trash_icon() -> QtGui.QIcon:
    """Корзина: приглушённая в покое, красноватая при наведении."""
    global _TRASH_PIXMAPS
    if _TRASH_PIXMAPS is None:
        def draw(color: str) -> QtGui.QPixmap:
            dpr = 2.0
            pm = QtGui.QPixmap(int(14 * dpr), int(14 * dpr))
            pm.setDevicePixelRatio(dpr)
            pm.fill(QtCore.Qt.GlobalColor.transparent)
            p = QtGui.QPainter(pm)
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            pen = QtGui.QPen(QtGui.QColor(color), 1.2)
            pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            P = QtCore.QPointF
            p.drawLine(P(2.5, 3.5), P(11.5, 3.5))                     # крышка
            p.drawLine(P(5.5, 3.5), P(5.5, 2.0)); p.drawLine(P(5.5, 2.0), P(8.5, 2.0)); p.drawLine(P(8.5, 2.0), P(8.5, 3.5))
            p.drawRoundedRect(QtCore.QRectF(3.5, 3.5, 7, 8.5), 1.2, 1.2)  # корпус
            p.drawLine(P(6, 5.5), P(6, 10)); p.drawLine(P(8, 5.5), P(8, 10))
            p.end()
            return pm
        _TRASH_PIXMAPS = (draw(_c("TEXT_DIM", "#8b9098")), draw("#f0707f"))
    icon = QtGui.QIcon()
    icon.addPixmap(_TRASH_PIXMAPS[0], QtGui.QIcon.Mode.Normal)
    icon.addPixmap(_TRASH_PIXMAPS[1], QtGui.QIcon.Mode.Active)
    return icon



def _color_bar(color: str, square: bool = False) -> QtGui.QPixmap:
    """Цветная метка заметки: вертикальная полоска у времени (или квадратик — для меню)."""
    w, h = (12, 12) if square else (5, 16)
    pm = QtGui.QPixmap(w, h)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    p.setPen(QtCore.Qt.PenStyle.NoPen)
    p.setBrush(QtGui.QColor(color))
    p.drawRoundedRect(QtCore.QRectF(0, 0, w, h), 2, 2)
    p.end()
    return pm


class _CardDelegate(QtWidgets.QStyledItemDelegate):
    """Карточка заметки (вид «Карточки»): рисуется целиком здесь, данные — из NotesStore по id."""

    def __init__(self, panel: "NotesPanel"):
        super().__init__(panel)
        self.panel = panel

    def sizeHint(self, option, index):                                         # noqa: N802 (Qt)
        return QtCore.QSize(CARD_W, CARD_H)

    def paint(self, p: QtGui.QPainter, option, index) -> None:
        note = self.panel.store.get(index.data(self.panel.ID_ROLE))
        if note is None:
            return
        p.save()
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        r = QtCore.QRectF(option.rect).adjusted(5, 5, -5, -5)
        selected = bool(option.state & QtWidgets.QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QtWidgets.QStyle.StateFlag.State_MouseOver)
        bg = QtGui.QColor(_c("BG_PANEL", "#232529"))
        color = notes_meta.valid_color(note.get("color"))
        if color:                                            # цвет заметки — лёгкий оттенок фона
            tint = QtGui.QColor(color)
            bg = QtGui.QColor((bg.red() * 5 + tint.red()) // 6, (bg.green() * 5 + tint.green()) // 6,
                              (bg.blue() * 5 + tint.blue()) // 6)
        border = QtGui.QColor(_c("ACCENT", "#3d8bfd") if selected else _c("BORDER_STRONG" if hover else "BORDER",
                                                                          "#383b41"))
        p.setPen(QtGui.QPen(border, 1.6 if selected else 1.0))
        p.setBrush(bg)
        p.drawRoundedRect(r, 7, 7)
        if color:                                            # полоска цвета слева
            p.setPen(QtCore.Qt.PenStyle.NoPen)
            p.setBrush(QtGui.QColor(color))
            p.drawRoundedRect(QtCore.QRectF(r.left(), r.top() + 8, 4, r.height() - 16), 2, 2)
        dim, text = QtGui.QColor(_c("TEXT_DIM", "#8b9098")), QtGui.QColor(_c("TEXT", "#d7dae0"))
        x, w = r.left() + 12, r.width() - 22
        y = r.top() + 8
        small = QtGui.QFont(option.font)
        small.setPointSizeF(max(7.0, option.font.pointSizeF() - 1))
        bold = QtGui.QFont(option.font)
        bold.setBold(True)
        fm_small, fm_bold, fm = QtGui.QFontMetrics(small), QtGui.QFontMetrics(bold), QtGui.QFontMetrics(option.font)
        # строка 1: 📌 тип · время
        when = note.get("event_time") or note.get("created", "")
        head = ("📌 " if note.get("pinned") else "") + (note.get("kind") or "📝 Заметка")
        p.setFont(small)
        p.setPen(dim)
        when_text = self.panel._fmt_time(when) if when else ""
        p.drawText(QtCore.QRectF(x, y, w, fm_small.height()), QtCore.Qt.AlignmentFlag.AlignRight, when_text)
        p.drawText(QtCore.QRectF(x, y, w - fm_small.horizontalAdvance(when_text) - 8, fm_small.height()),
                   QtCore.Qt.AlignmentFlag.AlignLeft,
                   fm_small.elidedText(head, QtCore.Qt.TextElideMode.ElideRight,
                                       int(w - fm_small.horizontalAdvance(when_text) - 8)))
        y += fm_small.height() + 4
        # строка 2: заголовок (жирный), строка 3: инструмент
        title = note.get("title") or (str(note.get("comment") or "").splitlines() or [""])[0] or "Без заголовка"
        p.setFont(bold)
        p.setPen(text)
        p.drawText(QtCore.QRectF(x, y, w, fm_bold.height()), QtCore.Qt.AlignmentFlag.AlignLeft,
                   fm_bold.elidedText(title, QtCore.Qt.TextElideMode.ElideRight, int(w)))
        y += fm_bold.height() + 1
        if note.get("symbol"):
            p.setFont(small)
            p.setPen(dim)
            p.drawText(QtCore.QRectF(x, y, w, fm_small.height()), QtCore.Qt.AlignmentFlag.AlignLeft,
                       fm_small.elidedText(str(note["symbol"]), QtCore.Qt.TextElideMode.ElideRight, int(w)))
            y += fm_small.height() + 4
        bottom = r.bottom() - 8 - fm_small.height()          # место под теги
        images = note_images.images_of(note)
        pix = self.panel.thumb(images[0]) if images else None
        if pix is not None:                                  # первая картинка — крупно
            box = QtCore.QRectF(x, y, w, min(CARD_IMG_H, bottom - y - 4))
            scaled = pix.scaled(int(box.width() * 2), int(box.height() * 2),
                                QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                                QtCore.Qt.TransformationMode.SmoothTransformation)
            sw, sh = scaled.width() / 2.0, scaled.height() / 2.0
            target = QtCore.QRectF(box.left() + (box.width() - sw) / 2, box.top(), sw, sh)
            clip = QtGui.QPainterPath()
            clip.addRoundedRect(target, 4, 4)
            p.save()
            p.setClipPath(clip)
            p.drawPixmap(target, scaled, QtCore.QRectF(scaled.rect()))
            p.restore()
            if len(images) > 1:
                p.setFont(small)
                p.setPen(QtGui.QColor("#ffffff"))
                p.setBrush(QtGui.QColor(0, 0, 0, 150))
                badge = QtCore.QRectF(target.right() - 30, target.top() + 4, 26, fm_small.height() + 2)
                p.drawRoundedRect(badge, 3, 3)
                p.drawText(badge, QtCore.Qt.AlignmentFlag.AlignCenter, f"🖼{len(images)}")
            y = target.bottom() + 4
        # подробности и начало комментария — сколько поместится
        body = " · ".join(t for t in (str(note.get("details") or ""), ) if t)
        comment = " ".join(str(note.get("comment") or "").split())
        if comment:
            body = (body + "\n" if body else "") + "💬 " + comment
        if body and bottom - y > fm.height():
            p.setFont(option.font)
            p.setPen(text if pix is None else dim)
            lines = max(1, int((bottom - y) // fm.height()))
            rect = QtCore.QRectF(x, y, w, lines * fm.height())
            doc_text = fm.elidedText(body.replace("\n", "  "), QtCore.Qt.TextElideMode.ElideRight, int(w * lines - 20))
            p.drawText(rect, int(QtCore.Qt.AlignmentFlag.AlignLeft.value) | int(QtCore.Qt.TextFlag.TextWordWrap.value),
                       doc_text)
        # теги внизу
        tags = notes_meta.tags_of(note)
        if tags:
            p.setFont(small)
            p.setPen(QtGui.QColor(_c("ACCENT", "#3d8bfd")))
            p.drawText(QtCore.QRectF(x, bottom, w, fm_small.height()), QtCore.Qt.AlignmentFlag.AlignLeft,
                       fm_small.elidedText("  ".join("#" + t for t in tags), QtCore.Qt.TextElideMode.ElideRight, int(w)))
        p.restore()


def _hover_tint() -> str:
    """rgb для полупрозрачной подсветки при наведении: светлая на тёмной теме, тёмная на светлой."""
    try:
        import fx_theme
        return str(getattr(fx_theme, "HOVER_TINT", "255, 255, 255"))
    except Exception:
        return "255, 255, 255"

class NotesStore(QtCore.QObject):
    """Список заметок + сохранение. changed — список изменился (окно перерисуется); edited — заметки изменили
    на этом терминале (синхронизация обменяется через несколько секунд)."""

    changed = QtCore.Signal()
    added = QtCore.Signal(str)      # id новой заметки — окно её выделит
    edited = QtCore.Signal()

    def __init__(self, settings: QtCore.QSettings, parent=None):
        super().__init__(parent)
        self._settings = settings
        self.notes: list[dict] = []
        raw = settings.value(SETTINGS_KEY, "")
        if raw:
            try:
                self.notes = list(json.loads(str(raw)))[-MAX_NOTES:]
            except Exception:
                self.notes = []
        self.deleted: dict[str, str] = {}
        raw = settings.value(DELETED_KEY, "")
        if raw:
            try:
                self.deleted = {str(k): str(v) for k, v in dict(json.loads(str(raw))).items()}
            except Exception:
                self.deleted = {}
        self.images_uploaded: set[str] = set(self._json_list(settings, IMAGES_UPLOADED_KEY))
        self.images_deleted: list[str] = self._json_list(settings, IMAGES_DELETED_KEY)
        self._save_timer = QtCore.QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(600)          # набор комментария не пишет настройки на каждую букву
        self._save_timer.timeout.connect(self.save)

    @staticmethod
    def _json_list(settings, key: str) -> list[str]:
        try:
            raw = settings.value(key, "")
            return [str(x) for x in json.loads(str(raw)) if note_images.valid_name(x)] if raw else []
        except Exception:
            return []

    def save(self) -> None:
        self._save_timer.stop()
        self._settings.setValue(SETTINGS_KEY, json.dumps(self.notes[-MAX_NOTES:], ensure_ascii=False))
        self._settings.setValue(DELETED_KEY, json.dumps(self.deleted, ensure_ascii=False))
        self._settings.setValue(IMAGES_UPLOADED_KEY, json.dumps(sorted(self.images_uploaded)))
        self._settings.setValue(IMAGES_DELETED_KEY, json.dumps(self.images_deleted))

    # ---- картинки (note_images.py) -------------------------------------------------------

    def all_images(self) -> set[str]:
        return {name for n in self.notes for name in note_images.images_of(n)}

    def add_images(self, note_id: str, names: list[str]) -> None:
        note = self.get(note_id)
        names = [x for x in names if note_images.valid_name(x)]
        if note is None or not names:
            return
        note["images"] = note_images.images_of(note) + [x for x in names if x not in note_images.images_of(note)]
        note["updated"] = self._now()
        self._touch()

    def remove_image(self, note_id: str, name: str) -> None:
        note = self.get(note_id)
        if note is None or name not in note_images.images_of(note):
            return
        note["images"] = [x for x in note_images.images_of(note) if x != name]
        note["updated"] = self._now()
        self._forget_images([name])
        self._touch()

    def _forget_images(self, names) -> None:
        """Картинки больше не нужны здесь: файл удалить; отправленную на сервер — удалить и там при обмене."""
        still = self.all_images()
        gone = [x for x in names if x not in still]
        note_images.delete(gone)
        for name in gone:
            if name in self.images_uploaded and name not in self.images_deleted:
                self.images_deleted.append(name)
            self.images_uploaded.discard(name)

    def images_synced(self, uploaded, deleted, downloaded=()) -> None:
        """Итог обмена картинками: что отправлено на сервер, что там удалено, что пришло с сервера
        (пришедшие — уже на сервере; окно перерисует миниатюры)."""
        self.images_uploaded |= {x for x in list(uploaded) + list(downloaded) if note_images.valid_name(x)}
        self.images_deleted = [x for x in self.images_deleted if x not in set(deleted)]
        self.save()
        if downloaded:
            self.changed.emit()

    def _touch(self, immediate: bool = True) -> None:
        if immediate:
            self.save()
        else:
            self._save_timer.start()
        self.changed.emit()
        self.edited.emit()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds")

    # ---- синхронизация (notes_sync.py) ----------------------------------------------------

    def snapshot(self) -> dict:
        """Копия для фонового обмена: {"notes": [...], "deleted": {id: когда}}."""
        return {"notes": [dict(n) for n in self.notes], "deleted": dict(self.deleted)}

    def merge_remote(self, merged: dict) -> int:
        """Принять объединённый набор с сервера. Возвращает, сколько заметок появилось, изменилось или исчезло.
        Заметки, изменённые здесь, пока шёл обмен, не теряются: они снова объединяются с пришедшими."""
        import notes_sync
        merged = notes_sync.merge(self.snapshot(), merged)
        old = {n.get("id"): n for n in self.notes}
        new = {n.get("id"): n for n in merged["notes"]}
        changed = sum(1 for nid, n in new.items() if old.get(nid) != n) + sum(1 for nid in old if nid not in new)
        self.deleted = merged["deleted"]
        if not changed and [n.get("id") for n in self.notes] == [n.get("id") for n in merged["notes"]]:
            self.save()                                  # надгробия могли постареть и уйти
            return 0
        before = self.all_images()
        self.notes = merged["notes"]
        gone = before - self.all_images()                # заметку / картинку удалили на другом терминале
        note_images.delete(gone)
        self.images_uploaded -= gone
        self.save()
        self.changed.emit()                              # без edited: это не правка здесь
        return changed

    def add(self, *, symbol: str = "", kind: str = "", title: str = "", details: str = "",
            event_time: str = "", comment: str = "", images: list[str] | None = None,
            fields: dict | None = None, reveal: bool = True) -> str:
        """Новая заметка. fields — дополнительные поля (например, chart_symbol — тикер для «Показать на графике»).
        Заметке терминала (айсберг, робот, крупная сделка, итоги, снимок графика …) первой строкой комментария
        дописывается тег её вида — notes_meta.with_auto_tag (2.1.54); заметки руками и дневник — без тега.
        reveal — окно «Заметки» переходит к новой заметке (сигнал added): так у всех заметок, созданных
        нажатием. False — заметка появляется молча: её добавил сам терминал позже (заметка о роботе, ждавшая
        его остановки), и список не должен уезжать из-под рук."""
        comment = notes_meta.with_auto_tag(kind, title, details, comment)
        note = {
            "id": uuid.uuid4().hex[:12],
            "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "updated": self._now(),
            "event_time": event_time,
            "symbol": symbol,
            "kind": kind,
            "title": title,
            "details": details,
            "comment": comment,
        }
        if images:
            note["images"] = [x for x in images if note_images.valid_name(x)]
        for key, value in (fields or {}).items():
            if key not in note and value not in (None, ""):
                note[key] = value
        self.notes.append(note)
        del self.notes[:-MAX_NOTES]
        self._touch()
        if reveal:
            self.added.emit(note["id"])
        return note["id"]

    def add_event(self, event: dict, type_label: str = "", symbol_label: str = "", time_label: str = "") -> str:
        """Заметка из уведомления (или закреплённой строки действующего робота)."""
        return self.add(
            symbol=symbol_label or str(event.get("symbol", "")),
            kind=type_label or str(event.get("type", "")),
            title=str(event.get("title", "")),
            details=str(event.get("details", "")),
            event_time=time_label or str(event.get("ts") or event.get("time") or ""),
        )

    def get(self, note_id: str) -> dict | None:
        return next((n for n in self.notes if n.get("id") == note_id), None)

    def set_comment(self, note_id: str, text: str) -> None:
        note = self.get(note_id)
        if note is not None and note.get("comment") != text:
            note["comment"] = text
            note["edited"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
            note["updated"] = self._now()
            self._save_timer.start()             # без changed: таблица не мигает при наборе
            self.edited.emit()

    def older_than(self, days: int = 30) -> list[str]:
        """id заметок, созданных раньше, чем days дней назад."""
        cutoff = datetime.now(timezone.utc).timestamp() - days * 86400
        ids = []
        for note in self.notes:
            try:
                created = datetime.fromisoformat(str(note.get("created", "")).replace("Z", "+00:00"))
                if created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
                if created.timestamp() < cutoff:
                    ids.append(note.get("id"))
            except Exception:
                continue
        return ids

    # ---- напоминания о роботах ----------------------------------------------------------

    def find_robot_notes(self, symbols, side: str, size: float, tolerance: float = 0.0,
                         interval: float | None = None) -> list[dict]:
        """Заметки о роботе того же инструмента (symbols — его написания: «SiZ6@RTSX», «Si-12.26»…), той же
        стороны, того же объёма (± tolerance в долях) и похожего темпа (интервал — в пределах ×2 от заметки,
        если он известен и там, и там), с включённым напоминанием. Новые — первыми."""
        names = {_norm_symbol(s) for s in symbols if s}
        found = []
        for note in reversed(self.notes):
            if note.get("remind") is False or _norm_symbol(note.get("symbol")) not in names:
                continue
            sig = robot_signature(note)
            if sig is None or sig[0] != side:
                continue
            if abs(sig[1] - float(size)) > max(1e-9, sig[1] * max(0.0, tolerance)):
                continue
            noted = robot_interval(note)
            if interval and noted and not (noted / INTERVAL_MATCH <= float(interval) <= noted * INTERVAL_MATCH):
                continue                         # тот же объём, но темп другой (раз в секунду против раза в 20 с)
            found.append(note)
        return found

    def mark_seen(self, note_id: str) -> None:
        """Робот из заметки появился снова: счётчик и время последнего раза."""
        note = self.get(note_id)
        if note is None:
            return
        note["seen_count"] = int(note.get("seen_count", 0) or 0) + 1
        note["last_seen"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self._touch(immediate=False)             # «updated» не ставим: счётчик при обмене берётся наибольший

    def update_fields(self, note_id: str, **fields) -> None:
        """Поменять поля заметки (дневник дня: сводка, картинки) — с отметкой правки для синхронизации."""
        note = self.get(note_id)
        if note is None:
            return
        before = note_images.images_of(note)
        note.update(fields)
        note["updated"] = self._now()
        self._forget_images([x for x in before if x not in note_images.images_of(note)])
        self._touch()

    def set_pinned(self, note_id: str, on: bool) -> None:
        note = self.get(note_id)
        if note is not None and bool(note.get("pinned")) != bool(on):
            if on:
                note["pinned"] = True
            else:
                note.pop("pinned", None)
            note["updated"] = self._now()
            self._touch()

    def set_color(self, note_id: str, color: str | None) -> None:
        note = self.get(note_id)
        color = notes_meta.valid_color(color)
        if note is not None and note.get("color") != color:
            if color:
                note["color"] = color
            else:
                note.pop("color", None)
            note["updated"] = self._now()
            self._touch()

    def set_remind(self, note_id: str, on: bool) -> None:
        note = self.get(note_id)
        if note is not None and note.get("remind", True) != bool(on):
            note["remind"] = bool(on)
            note["updated"] = self._now()
            self._touch()

    def remove(self, note_ids: list[str]) -> None:
        ids = set(note_ids)
        before = len(self.notes)
        dropped = [x for n in self.notes if n.get("id") in ids for x in note_images.images_of(n)]
        self.notes = [n for n in self.notes if n.get("id") not in ids]
        if len(self.notes) != before:
            self._forget_images(dropped)
            now = self._now()
            for nid in ids:
                if nid:
                    self.deleted[str(nid)] = now     # надгробие: удаление дойдёт до других терминалов
            self._touch()


MONTHS_RU = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август",
             "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]
WEEKDAYS_RU = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]


class RangeCalendar(QtWidgets.QWidget):
    """Календарь выбора периода в стиле терминала (рисуется сам, без QCalendarWidget):
    месяц со стрелками, дни недели, сетка 6 × 7. Первый щелчок — начало периода, второй — конец
    (тот же день дважды — один день). Выбранные дни — плашка цвета акцента, концы периода — яркие
    со свечением; дни, за которые есть заметки, подчёркнуты; сегодня — в рамке. Колесо — листать месяцы."""

    rangeSelected = QtCore.Signal(object, object)       # date, date

    HEADER_H, WEEK_H, CELL_W, CELL_H, PAD = 44, 26, 40, 36, 12

    def __init__(self, parent=None):
        super().__init__(parent)
        today = date.today()
        self.year, self.month = today.year, today.month
        self.start: date | None = None
        self.end: date | None = None
        self.marked: set[date] = set()
        self._hover: date | None = None
        self._pending: date | None = None              # первый щелчок уже сделан, ждём второй
        self.setMouseTracking(True)
        self.setFixedSize(self.PAD * 2 + 7 * self.CELL_W, self.HEADER_H + self.WEEK_H + 6 * self.CELL_H + self.PAD)

    # ---- данные -------------------------------------------------------------------------
    def set_range(self, start: date | None, end: date | None) -> None:
        self.start, self.end, self._pending = start, end, None
        if start is not None:
            self.year, self.month = start.year, start.month
        self.update()

    def _days(self) -> list[date]:
        first = date(self.year, self.month, 1)
        begin = first.toordinal() - first.weekday()       # понедельник первой недели
        return [date.fromordinal(begin + i) for i in range(42)]

    def _shift_month(self, step: int) -> None:
        m = self.month - 1 + step
        self.year, self.month = self.year + m // 12, m % 12 + 1
        self.update()

    # ---- геометрия ---------------------------------------------------------------------------
    def _cell_rect(self, index: int) -> QtCore.QRectF:
        row, col = divmod(index, 7)
        return QtCore.QRectF(self.PAD + col * self.CELL_W, self.HEADER_H + self.WEEK_H + row * self.CELL_H,
                             self.CELL_W, self.CELL_H)

    def _arrow_rects(self):
        y = (self.HEADER_H - 24) / 2
        return QtCore.QRectF(self.PAD, y, 24, 24), QtCore.QRectF(self.width() - self.PAD - 24, y, 24, 24)

    def _day_at(self, pos) -> date | None:
        for i, d in enumerate(self._days()):
            if self._cell_rect(i).contains(QtCore.QPointF(pos)):
                return d
        return None

    # ---- мышь ---------------------------------------------------------------------------------
    def mouseMoveEvent(self, e):
        d = self._day_at(e.position())
        if d != self._hover:
            self._hover = d
            self.update()

    def leaveEvent(self, e):
        self._hover = None
        self.update()

    def wheelEvent(self, e):
        self._shift_month(-1 if e.angleDelta().y() > 0 else 1)

    def mousePressEvent(self, e):
        if e.button() != QtCore.Qt.MouseButton.LeftButton:
            return
        left, right = self._arrow_rects()
        pos = QtCore.QPointF(e.position())
        if left.contains(pos):
            self._shift_month(-1)
            return
        if right.contains(pos):
            self._shift_month(1)
            return
        d = self._day_at(e.position())
        if d is None:
            return
        if self._pending is None:
            self._pending = d
            self.start, self.end = d, None
            self.update()
            return
        a, b = sorted((self._pending, d))
        self._pending = None
        self.start, self.end = a, b
        self.update()
        self.rangeSelected.emit(a, b)

    # ---- рисование ------------------------------------------------------------------------------
    def _in_range(self, d: date) -> bool:
        if self.start is None:
            return False
        end = self.end
        if end is None and self._pending is not None and self._hover is not None:
            end = self._hover                              # предпросмотр периода, пока выбираете конец
        if end is None:
            return d == self.start
        a, b = sorted((self.start, end))
        return a <= d <= b

    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        text = QtGui.QColor(_c("TEXT", "#d7dae0"))
        dim = QtGui.QColor(_c("TEXT_DIM", "#8b9098"))
        accent = QtGui.QColor(_c("ACCENT", "#5b8def"))
        panel = QtGui.QColor(_c("BG_PANEL", "#232427"))
        border = QtGui.QColor(_c("BORDER", "#34363b"))

        p.setPen(QtGui.QPen(border, 1))
        p.setBrush(panel)
        p.drawRoundedRect(QtCore.QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 10, 10)

        # заголовок: ◂ Октябрь 2026 ▸
        font = QtGui.QFont(self.font())
        font.setPixelSize(14)
        font.setWeight(QtGui.QFont.Weight.DemiBold)
        p.setFont(font)
        p.setPen(text)
        p.drawText(QtCore.QRectF(0, 0, self.width(), self.HEADER_H), QtCore.Qt.AlignmentFlag.AlignCenter,
                   f"{MONTHS_RU[self.month - 1]} {self.year}")
        p.setBrush(dim)
        p.setPen(QtCore.Qt.PenStyle.NoPen)
        for rect, left in zip(self._arrow_rects(), (True, False)):
            c = rect.center()
            pts = ([QtCore.QPointF(c.x() + 3, c.y() - 5), QtCore.QPointF(c.x() - 3, c.y()), QtCore.QPointF(c.x() + 3, c.y() + 5)]
                   if left else
                   [QtCore.QPointF(c.x() - 3, c.y() - 5), QtCore.QPointF(c.x() + 3, c.y()), QtCore.QPointF(c.x() - 3, c.y() + 5)])
            p.drawPolygon(QtGui.QPolygonF(pts))

        # дни недели
        small = QtGui.QFont(self.font())
        small.setPixelSize(10)
        small.setWeight(QtGui.QFont.Weight.DemiBold)
        p.setFont(small)
        for col, name in enumerate(WEEKDAYS_RU):
            p.setPen(dim if col < 5 else QtGui.QColor(240, 112, 127, 190))
            p.drawText(QtCore.QRectF(self.PAD + col * self.CELL_W, self.HEADER_H, self.CELL_W, self.WEEK_H),
                       QtCore.Qt.AlignmentFlag.AlignCenter, name)

        # сетка дней
        day_font = QtGui.QFont(self.font())
        day_font.setPixelSize(12)
        bold = QtGui.QFont(day_font)
        bold.setPixelSize(14)
        bold.setWeight(QtGui.QFont.Weight.Bold)
        today = date.today()
        a, b = (self.start, self.end) if self.end else (self.start, self.start)
        for i, d in enumerate(self._days()):
            rect = self._cell_rect(i)
            inner = rect.adjusted(3, 3, -3, -3)
            other = d.month != self.month
            selected_end = d in (a, b) and self.start is not None
            in_range = self._in_range(d)
            if in_range and not selected_end:
                fill = QtGui.QColor(accent)
                fill.setAlpha(55)
                p.setPen(QtCore.Qt.PenStyle.NoPen)
                p.setBrush(fill)
                p.drawRoundedRect(inner, 6, 6)
            if selected_end:
                glow = QtGui.QColor(accent)
                for k, alpha in ((5, 25), (3, 45)):           # мягкое свечение вокруг плашки
                    glow.setAlpha(alpha)
                    p.setPen(QtCore.Qt.PenStyle.NoPen)
                    p.setBrush(glow)
                    p.drawRoundedRect(inner.adjusted(-k, -k, k, k), 8 + k, 8 + k)
                p.setBrush(accent)
                p.drawRoundedRect(inner, 6, 6)
            elif d == self._hover:
                p.setPen(QtCore.Qt.PenStyle.NoPen)
                p.setBrush(QtGui.QColor(255, 255, 255, 22))
                p.drawRoundedRect(inner, 6, 6)
            if d == today and not selected_end:
                p.setPen(QtGui.QPen(QtGui.QColor(accent.red(), accent.green(), accent.blue(), 200), 1.2))
                p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
                p.drawRoundedRect(inner, 6, 6)
            # число
            if selected_end:
                p.setFont(bold)
                p.setPen(QtGui.QColor("#ffffff"))
            else:
                p.setFont(day_font)
                color = QtGui.QColor(text if not other else dim)
                if other:
                    color.setAlpha(110)
                p.setPen(color)
            p.drawText(inner.adjusted(0, -3, 0, -3), QtCore.Qt.AlignmentFlag.AlignCenter, str(d.day))
            # есть заметки за день — подчёркивание
            if d in self.marked:
                bar_color = QtGui.QColor("#ffffff") if selected_end else QtGui.QColor(accent)
                if other and not selected_end:
                    bar_color.setAlpha(110)
                p.setPen(QtCore.Qt.PenStyle.NoPen)
                p.setBrush(bar_color)
                w = inner.width() * 0.5
                p.drawRoundedRect(QtCore.QRectF(inner.center().x() - w / 2, inner.bottom() - 6, w, 2.4), 1.2, 1.2)
        p.end()


class RangeCalendarPopup(QtWidgets.QFrame):
    """Всплывающий календарь под кнопкой дат."""

    def __init__(self, parent=None):
        super().__init__(parent, QtCore.Qt.WindowType.Popup | QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)   # скруглённые углы
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.calendar = RangeCalendar(self)
        layout.addWidget(self.calendar)
        self.calendar.rangeSelected.connect(lambda *_: QtCore.QTimer.singleShot(180, self.close))

    def show_below(self, widget: QtWidgets.QWidget) -> None:
        pos = widget.mapToGlobal(QtCore.QPoint(0, widget.height() + 4))
        screen = QtGui.QGuiApplication.screenAt(pos) or QtGui.QGuiApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            pos.setX(max(area.left(), min(pos.x(), area.right() - self.sizeHint().width())))
            if pos.y() + self.sizeHint().height() > area.bottom():
                pos.setY(widget.mapToGlobal(QtCore.QPoint(0, 0)).y() - self.sizeHint().height() - 4)
        self.move(pos)
        self.show()


class NotesPanel(QtWidgets.QWidget):
    """Окно «Заметки»: список сверху (новые — первыми), комментарий выбранной заметки снизу."""

    COLUMNS = ["Время", "Тип", "Инструмент", "Событие", "Детали", ""]
    COL_DELETE = 5
    ID_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 11

    def __init__(self, store: NotesStore, display_tz_fn=None, parent=None):
        super().__init__(parent)
        try:                                          # свои фон, текст и шрифт окна (appearance.window_qss, 2.1.83)
            import appearance
            appearance.style_window(self, "notes")
        except Exception:
            pass
        self.store = store
        self._display_tz_fn = display_tz_fn or (lambda: "Europe/Moscow")
        self._current_id: str | None = None
        self._loading = False
        self._scroll_pending: tuple | None = None    # прокрутка списков, которую reload ещё должен вернуть

        dim, text = _c("TEXT_DIM", "#8b9098"), _c("TEXT", "#d7dae0")
        tint = _hover_tint()
        self.setStyleSheet(f"""
            QPushButton#pill {{ background: transparent; color: {text}; border: 1px solid {dim};
                                border-radius: 10px; padding: 2px 12px; min-height: 14px; }}
            QPushButton#pill:hover {{ border-color: {text}; background: rgba({tint}, 0.06); }}
            QPushButton#pill:disabled {{ color: {dim}; border-color: rgba(139, 144, 152, 0.4); }}
            QPushButton#pill:checked {{ border-color: {_c("ACCENT", "#3d8bfd")}; color: {text};
                                        background: rgba(61, 139, 253, 0.16); }}
        """)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)
        top = QtWidgets.QHBoxLayout()
        top.setSpacing(6)                 # кнопки-«пилюли» чуть меньше (03.11): поле 2×12 px вместо 3×16, промежуток 6
        self.new_btn = QtWidgets.QPushButton("Новая заметка")
        self.new_btn.setObjectName("pill")
        self.new_btn.clicked.connect(self._new_note)
        self.purge_btn = QtWidgets.QPushButton("Удалить старше месяца")
        self.purge_btn.setObjectName("pill")
        self.purge_btn.setToolTip("Удалить все заметки, созданные больше 30 дней назад")
        self.purge_btn.clicked.connect(self._purge_old)
        top.addWidget(self.new_btn)
        top.addWidget(self.purge_btn)
        self.diary_btn = QtWidgets.QPushButton("Дневник дня")
        self.diary_btn.setObjectName("pill")
        self.diary_btn.setToolTip("Заметка за сегодня: сделки, заметки, теги и снимки дня собираются сами,\n"
                                  "ниже — ваши выводы. Повторный щелчок обновляет сводку, выводы не трогает.")
        self.diary_btn.clicked.connect(self._diary)
        self.stats_btn = QtWidgets.QPushButton("Статистика по тегам")
        self.stats_btn.setObjectName("pill")
        self.stats_btn.setToolTip("Итоги заметок-сделок по тегам (#пробой, #ошибка…) — по заметкам, которые\n"
                                  "сейчас показаны: выберите даты, чтобы посчитать за период")
        self.stats_btn.clicked.connect(self._tag_stats)
        top.addWidget(self.diary_btn)
        top.addWidget(self.stats_btn)
        self.day_trades_fn = None               # (date) -> [ClosedTrade] сделок дня со счёта; назначает главное окно
        top.addSpacing(10)
        self.view_list_btn = QtWidgets.QPushButton("Список")
        self.view_cards_btn = QtWidgets.QPushButton("Карточки")
        view_group = QtWidgets.QButtonGroup(self)
        for btn in (self.view_list_btn, self.view_cards_btn):
            btn.setObjectName("pill")
            btn.setCheckable(True)
            view_group.addButton(btn)
            top.addWidget(btn)
        self.view_cards_btn.setToolTip("Заметки карточками: картинки крупно, цвет, теги — как в Google Keep")
        self.view_list_btn.clicked.connect(lambda: self._set_view("list"))
        self.view_cards_btn.clicked.connect(lambda: self._set_view("cards"))
        top.addStretch(1)
        self.filter_edit = QtWidgets.QLineEdit()
        self.filter_edit.setPlaceholderText("Поиск по заметкам…")
        self.filter_edit.setClearButtonEnabled(True)
        self.filter_edit.setFixedWidth(220)
        self.filter_edit.textChanged.connect(self._apply_filter)
        top.addWidget(self.filter_edit)
        self.count_label = QtWidgets.QLabel("")
        self.count_label.setStyleSheet(f"color:{dim};")
        top.addWidget(self.count_label)
        root.addLayout(top)

        # Фильтры: тип и даты (с календариком; дни, где есть заметки, выделены жирным)
        filters = QtWidgets.QHBoxLayout()
        filters.setSpacing(6)
        type_caption = QtWidgets.QLabel("Тип:")
        type_caption.setStyleSheet(f"color:{dim};")
        filters.addWidget(type_caption)
        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.type_combo.currentIndexChanged.connect(lambda _i: self._apply_filter())
        filters.addWidget(self.type_combo)
        filters.addSpacing(14)
        date_caption = QtWidgets.QLabel("Даты:")
        date_caption.setStyleSheet(f"color:{dim};")
        filters.addWidget(date_caption)
        self._range: tuple[date, date] | None = None
        self.date_btn = QtWidgets.QPushButton("Все даты  ▾")
        self.date_btn.setObjectName("pill")
        self.date_btn.setToolTip("Открыть календарь: щёлкните начало периода, затем конец (или тот же день дважды)")
        self.date_btn.clicked.connect(self._open_calendar)
        filters.addWidget(self.date_btn)
        self._calendar_popup = RangeCalendarPopup(self)
        self._calendar_popup.calendar.rangeSelected.connect(lambda a, b: self._set_range(a, b))
        self.today_btn = QtWidgets.QPushButton("Сегодня")
        self.today_btn.setObjectName("pill")
        self.today_btn.clicked.connect(lambda: self._set_range(date.today(), date.today()))
        self.week_btn = QtWidgets.QPushButton("7 дней")
        self.week_btn.setObjectName("pill")
        self.week_btn.clicked.connect(lambda: self._set_range(date.fromordinal(date.today().toordinal() - 6), date.today()))
        filters.addWidget(self.today_btn)
        filters.addWidget(self.week_btn)
        self.reset_btn = QtWidgets.QPushButton("Сбросить")
        self.reset_btn.setObjectName("pill")
        self.reset_btn.setToolTip("Показать все заметки")
        self.reset_btn.clicked.connect(self._reset_filters)
        filters.addWidget(self.reset_btn)
        filters.addStretch(1)
        root.addLayout(filters)

        self.table = QtWidgets.QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeMode.Stretch)      # «Детали» — вся ширина
        header.setSectionResizeMode(self.COL_DELETE, QtWidgets.QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(self.COL_DELETE, 34)
        self.table.setWordWrap(False)
        for col, width in enumerate((120, 120, 110, 230)):
            self.table.setColumnWidth(col, width)
        self.table.itemSelectionChanged.connect(self._on_selection)
        self.table.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._table_menu)
        QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.Key.Key_Delete), self.table,
                        activated=self._delete_selected, context=QtCore.Qt.ShortcutContext.WidgetShortcut)

        editor_box = QtWidgets.QWidget()
        editor_layout = QtWidgets.QVBoxLayout(editor_box)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.setSpacing(4)
        self.editor_title = QtWidgets.QLabel("Комментарий")
        self.editor_title.setStyleSheet(f"color:{dim};")
        editor_layout.addWidget(self.editor_title)
        self.editor = QtWidgets.QPlainTextEdit()
        self.editor.setPlaceholderText("Выберите заметку и напишите комментарий: почему это важно, что сделали…\n"
                                       "Теги — слово с # (#пробой, #ошибка): по ним фильтр слева; после # — подсказка "
                                       "из ваших тегов.\n"
                                       "Ctrl+V с картинкой в буфере — картинка добавится к заметке.")
        # Подсказка тегов: набрали «#» (или «#про») — список уже использованных тегов; Enter / щелчок — вставить
        self._tag_model = QtCore.QStringListModel(self)
        self._tag_completer = QtWidgets.QCompleter(self._tag_model, self)
        self._tag_completer.setWidget(self.editor)
        self._tag_completer.setCaseSensitivity(QtCore.Qt.CaseSensitivity.CaseInsensitive)
        self._tag_completer.setCompletionMode(QtWidgets.QCompleter.CompletionMode.PopupCompletion)
        self._tag_completer.activated[str].connect(self._insert_tag)
        self.editor.textChanged.connect(self._on_comment_changed)
        self.editor.installEventFilter(self)              # Ctrl+V с картинкой — в картинки заметки
        editor_layout.addWidget(self.editor)
        # Картинки заметки: миниатюры (снимки графика, вставленные из буфера)
        images_row = QtWidgets.QHBoxLayout()
        images_row.setSpacing(6)
        self.images_list = QtWidgets.QListWidget()
        self.images_list.setViewMode(QtWidgets.QListView.ViewMode.IconMode)
        self.images_list.setFlow(QtWidgets.QListView.Flow.LeftToRight)
        self.images_list.setWrapping(False)
        self.images_list.setMovement(QtWidgets.QListView.Movement.Static)
        self.images_list.setIconSize(QtCore.QSize(int(THUMB_H * 16 / 9), THUMB_H))
        self.images_list.setFixedHeight(THUMB_H + 26)
        self.images_list.setSpacing(4)
        self.images_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.images_list.setToolTip("Двойной щелчок — открыть картинку; правая кнопка — сохранить, копировать, удалить")
        self.images_list.itemDoubleClicked.connect(lambda item: self._open_image(item.data(self.ID_ROLE)))
        self.images_list.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.images_list.customContextMenuRequested.connect(self._image_menu)
        self.images_list.hide()
        images_row.addWidget(self.images_list, 1)
        self.paste_btn = QtWidgets.QPushButton("Вставить картинку")
        self.paste_btn.setObjectName("pill")
        self.paste_btn.setToolTip("Добавить к заметке картинку из буфера обмена (скриншот, Ctrl+V в комментарии — то же)")
        self.paste_btn.clicked.connect(self._paste_image)
        self.paste_btn.setEnabled(False)
        # по ширине текста, а не на всю строку (пока картинок нет, список скрыт — кнопка растягивалась)
        self.paste_btn.setSizePolicy(QtWidgets.QSizePolicy.Policy.Maximum, QtWidgets.QSizePolicy.Policy.Fixed)
        images_row.addSpacing(30)                    # отступ кнопки от левого края (и от миниатюр)
        images_row.addWidget(self.paste_btn, 0, QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignBottom)
        images_row.addStretch(0)
        editor_layout.addLayout(images_row)

        # Панель тегов слева (как в Bear): все заметки, закреплённые, затем #теги по частоте
        self.tags_list = QtWidgets.QListWidget()
        self.tags_list.setMinimumWidth(130)
        self.tags_list.setMaximumWidth(220)
        self.tags_list.setToolTip("Теги — слова с «#» в тексте заметки (#пробой, #ошибка). Щелчок — показать заметки с тегом")
        self.tags_list.currentItemChanged.connect(lambda *_a: self._apply_filter())
        self.table.itemDoubleClicked.connect(lambda item: self._show_on_chart(item.data(self.ID_ROLE)))
        top_split = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        top_split.setChildrenCollapsible(False)
        self.cards = QtWidgets.QListWidget()
        self.cards.setViewMode(QtWidgets.QListView.ViewMode.IconMode)
        self.cards.setResizeMode(QtWidgets.QListView.ResizeMode.Adjust)
        self.cards.setMovement(QtWidgets.QListView.Movement.Static)
        self.cards.setUniformItemSizes(True)
        self.cards.setGridSize(QtCore.QSize(CARD_W, CARD_H))
        self.cards.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.cards.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.cards.setItemDelegate(_CardDelegate(self))
        self.cards.itemSelectionChanged.connect(self._on_card_selection)
        self.cards.itemDoubleClicked.connect(lambda item: self._show_on_chart(item.data(self.ID_ROLE)))
        self.cards.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.cards.customContextMenuRequested.connect(
            lambda pos: self._note_menu(self._card_id_at(pos), self.cards.viewport().mapToGlobal(pos)))
        QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.Key.Key_Delete), self.cards,
                        activated=self._delete_selected, context=QtCore.Qt.ShortcutContext.WidgetShortcut)
        self._thumbs: dict[str, QtGui.QPixmap] = {}
        self.views = QtWidgets.QStackedWidget()
        self.views.addWidget(self.table)
        self.views.addWidget(self.cards)
        top_split.addWidget(self.tags_list)
        top_split.addWidget(self.views)
        top_split.setStretchFactor(0, 0)
        top_split.setStretchFactor(1, 1)
        top_split.setSizes([150, 900])
        self.open_chart_at = None               # (тикер, момент epoch) -> None; назначает главное окно

        splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Vertical)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(top_split)
        splitter.addWidget(editor_box)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        root.addWidget(splitter, 1)

        # Размер полосы прокрутки списки пересчитывают отложенно — прежнее место возвращаем, когда он известен
        # (reload / _restore_scroll).
        for view in (self.table, self.cards):
            view.verticalScrollBar().rangeChanged.connect(lambda *_: self._restore_scroll(self._scroll_pending))
        store.changed.connect(self.reload)
        store.added.connect(self._select_note)
        self.reload()
        try:
            view = str(store._settings.value(VIEW_KEY, "list"))
        except Exception:
            view = "list"
        self._set_view(view)

    # ---- данные ---------------------------------------------------------------------
    def _fmt_time(self, iso: str) -> str:
        if not iso:
            return ""
        try:
            from zoneinfo import ZoneInfo
            dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(ZoneInfo(self._display_tz_fn())).strftime("%d.%m %H:%M:%S")
        except Exception:
            return str(iso)

    def reload(self) -> None:
        """Перечитать заметки в таблицу и карточки (после любого изменения в хранилище). Список остаётся на
        том же месте: таблица и карточки собираются заново, и без этого прокрутка каждый раз возвращалась
        наверх — после удаления заметки внизу приходилось листать обратно (14.11). Выделенная заметка
        остаётся выделенной, но список к ней не перематывается: перечитывание — не переход к заметке.
        Новая заметка — другое дело: хранилище сообщает о ней отдельно (added), и список переходит к ней."""
        keep = self._current_id
        scroll = self._scroll_state()
        self._loading = True
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        for note in notes_meta.display_order(self.store.notes):    # закреплённые — сверху
            row = self.table.rowCount()
            self.table.insertRow(row)
            when = note.get("event_time") or note.get("created", "")
            title = note.get("title", "") or (note.get("comment", "").splitlines() or [""])[0]
            robot = robot_signature(note) is not None
            if robot:                               # 🔔 — напомнит, когда робот появится снова; 🔕 — выключено
                title = ("🔕 " if note.get("remind") is False else "🔔 ") + title
            pics = len(note_images.images_of(note))
            if pics:                                # 🖼 — у заметки есть картинки (снимки графика)
                title = f"🖼{pics if pics > 1 else ''} " + title
            if note.get("pinned"):                  # 📌 — закреплена, всегда сверху
                title = "📌 " + title
            color = notes_meta.valid_color(note.get("color"))
            values = [
                self._fmt_time(when) if "T" in str(when) or "-" in str(when)[:5] else str(when),
                note.get("kind", "") or "📝 Заметка",
                note.get("symbol", ""),
                title,
                note.get("details", ""),
            ]
            self.table.setCellWidget(row, self.COL_DELETE, self._delete_button(note.get("id")))
            for col, value in enumerate(values):
                item = QtWidgets.QTableWidgetItem(str(value))
                item.setData(self.ID_ROLE, note.get("id"))
                if col == len(values) - 1 and value:
                    item.setToolTip(str(value))
                if note.get("comment"):
                    item.setToolTip((item.toolTip() + "\n\n" if item.toolTip() else "") + "💬 " + note["comment"])
                if color:                           # цвет заметки: полоска у времени и лёгкий фон строки
                    tint = QtGui.QColor(color)
                    tint.setAlpha(34)
                    item.setBackground(tint)
                    if col == 0:
                        item.setData(QtCore.Qt.ItemDataRole.DecorationRole, _color_bar(color))
                if robot and col == 3:
                    seen = int(note.get("seen_count", 0) or 0)
                    tip = ("Напоминание выключено" if note.get("remind") is False
                           else "Напомню, когда робот с тем же объёмом и стороной появится снова")
                    if seen:
                        tip += f"\nВстречался снова: {seen} раз, последний — {self._fmt_time(note.get('last_seen', ''))}"
                    item.setToolTip(tip + "\nПравая кнопка мыши — включить / выключить напоминание")
                self.table.setItem(row, col, item)
        self.table.setUpdatesEnabled(True)
        self.cards.clear()
        for note in notes_meta.display_order(self.store.notes):
            item = QtWidgets.QListWidgetItem()
            item.setData(self.ID_ROLE, note.get("id"))
            item.setSizeHint(QtCore.QSize(CARD_W, CARD_H))
            self.cards.addItem(item)
        self._loading = False
        self._refresh_types()
        self._refresh_tags()
        self._mark_calendar_days()
        self._apply_filter()
        if keep and self.store.get(keep) is not None:
            self._select_note(keep, scroll=False)
        else:
            self._show_note(None)                # в том числе заметку удалили на другом терминале
        # Вернуть прокрутку: сразу, после раскладки (размер полосы прокрутки списки пересчитывают отложенно —
        # тогда придёт rangeChanged, см. __init__; выделение строки тоже подвигает список) и напоследок через
        # SCROLL_KEEP_MS, после чего место больше не удерживается. Переход к заметке (_select_note) отменяет возврат.
        self._scroll_pending = scroll
        self._restore_scroll(scroll)
        QtCore.QTimer.singleShot(0, lambda: self._restore_scroll(scroll))
        QtCore.QTimer.singleShot(self.SCROLL_KEEP_MS, lambda: self._restore_scroll(scroll, last=True))

    SCROLL_KEEP_MS = 250       # столько после перечитывания список удерживается на прежнем месте

    def _scroll_state(self) -> tuple[int, int]:
        """Положение прокрутки таблицы и карточек."""
        return (self.table.verticalScrollBar().value(), self.cards.verticalScrollBar().value())

    def _restore_scroll(self, state: tuple | None, last: bool = False) -> None:
        """Вернуть прокрутку, запомненную перед перечитыванием (если её с тех пор не отменил переход к заметке
        и не сменило следующее перечитывание). Список стал короче — встаём в конец. last — последний возврат:
        дальше место не удерживается (иначе список прыгал бы назад при каждом изменении размера окна)."""
        if state is None or state is not getattr(self, "_scroll_pending", None):
            return
        if last:
            self._scroll_pending = None
        try:
            for view, value in ((self.table, state[0]), (self.cards, state[1])):
                bar = view.verticalScrollBar()
                if bar.value() != min(value, bar.maximum()):
                    bar.setValue(min(value, bar.maximum()))
        except RuntimeError:                         # окно заметок уже закрыто
            pass

    def _row_of(self, note_id: str) -> int:
        for r in range(self.table.rowCount()):
            item = self.table.item(r, 0)
            if item is not None and item.data(self.ID_ROLE) == note_id:
                return r
        return -1

    def _select_note(self, note_id: str, scroll: bool = True) -> None:
        """Выделить заметку в таблице и в карточках и показать её комментарий. scroll — перемотать списки к
        ней (переход к заметке: новая, найденная, из «Статистики по тегам»); False — только выделить
        (перечитывание списка, reload)."""
        if scroll:
            self._scroll_pending = None              # переход к заметке важнее возврата прежней прокрутки
        row = self._row_of(note_id)
        if row >= 0:
            self.table.setRowHidden(row, False)
            self.table.selectRow(row)
            if scroll:
                self.table.scrollToItem(self.table.item(row, 0))
        for r in range(self.cards.count()):
            card = self.cards.item(r)
            if card.data(self.ID_ROLE) == note_id:
                card.setHidden(False)
                self.cards.blockSignals(True)
                self.cards.setCurrentItem(card)
                self.cards.blockSignals(False)
                if scroll:
                    self.cards.scrollToItem(card)
                break
        if not self._loading and self.store.get(note_id) is not None:
            self._show_note(note_id)               # комментарий — этой заметки, какой бы вид ни был открыт

    def _card_id_at(self, pos) -> str | None:
        item = self.cards.itemAt(pos)
        return item.data(self.ID_ROLE) if item is not None else None

    def _on_card_selection(self) -> None:
        if self._loading:
            return
        ids = [i.data(self.ID_ROLE) for i in self.cards.selectedItems()]
        self._show_note(ids[0] if len(ids) == 1 else None)

    def _set_view(self, view: str) -> None:
        view = "cards" if view == "cards" else "list"
        self.views.setCurrentIndex(1 if view == "cards" else 0)
        self.view_cards_btn.setChecked(view == "cards")
        self.view_list_btn.setChecked(view == "list")
        try:
            self.store._settings.setValue(VIEW_KEY, view)
        except Exception:
            pass
        if self._current_id:
            self._select_note(self._current_id)

    def thumb(self, name: str) -> QtGui.QPixmap | None:
        """Картинка для карточки (кэш по имени: файл не меняется)."""
        pix = self._thumbs.get(name)
        if pix is None and note_images.exists(name):
            src = QtGui.QPixmap(str(note_images.path_of(name)))
            if not src.isNull():
                pix = src.scaled(CARD_W * 2, CARD_IMG_H * 2, QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                                 QtCore.Qt.TransformationMode.SmoothTransformation)
                self._thumbs[name] = pix
        return pix

    def _selected_ids(self) -> list[str]:
        """Выделенные заметки в открытом виде (список или карточки) — для Delete."""
        if self.views.currentIndex() == 1:
            return [i.data(self.ID_ROLE) for i in self.cards.selectedItems()]
        return self._table_ids()

    def _table_ids(self) -> list[str]:
        ids = []
        for index in self.table.selectionModel().selectedRows():
            item = self.table.item(index.row(), 0)
            if item is not None:
                ids.append(item.data(self.ID_ROLE))
        return ids

    def _on_selection(self) -> None:
        """Выделение в списке (таблице) — его заметка в комментарии. Своё выделение, а не открытого вида:
        _select_note выделяет и в списке, и в карточках, и при открытых карточках брал бы их прежнее выделение."""
        if self._loading:
            return
        ids = self._table_ids()
        self._show_note(ids[0] if len(ids) == 1 else None)

    def _show_note(self, note_id: str | None) -> None:
        same = note_id is not None and note_id == self._current_id
        self._current_id = note_id
        note = self.store.get(note_id) if note_id else None
        text = note.get("comment", "") if note else ""
        if not (same and self.editor.toPlainText() == text):   # обмен перерисовал таблицу — курсор не сбиваем
            self.editor.blockSignals(True)
            self.editor.setPlainText(text)
            self.editor.blockSignals(False)
        self.editor.setEnabled(note is not None)
        self.paste_btn.setEnabled(note is not None)
        self._show_images(note)
        if note is None:
            self.editor_title.setText("Комментарий")
        else:
            head = " · ".join(x for x in (note.get("symbol"), note.get("title")) if x)
            self.editor_title.setText(f"Комментарий — {head}" if head else "Комментарий")

    def _table_menu(self, pos) -> None:
        item = self.table.itemAt(pos)
        self._note_menu(item.data(self.ID_ROLE) if item is not None else None,
                        self.table.viewport().mapToGlobal(pos))

    def _note_menu(self, note_id: str | None, global_pos) -> None:
        """Меню заметки (список и карточки): график, закрепить, цвет, напоминание о роботе, удалить."""
        note = self.store.get(note_id) if note_id else None
        if note is None:
            return
        nid = note.get("id")
        menu = QtWidgets.QMenu(self)
        chart = menu.addAction("Показать на графике")
        chart.setEnabled(self._chart_target(note) is not None and callable(self.open_chart_at))
        chart.triggered.connect(lambda _c=False: self._show_on_chart(nid))
        menu.addSeparator()
        pinned = bool(note.get("pinned"))
        menu.addAction("Открепить" if pinned else "📌 Закрепить сверху").triggered.connect(
            lambda _c=False: self.store.set_pinned(nid, not pinned))
        colors = menu.addMenu("Цвет")
        current = notes_meta.valid_color(note.get("color"))
        for color, name in notes_meta.NOTE_COLORS:
            act = colors.addAction(QtGui.QIcon(_color_bar(color, square=True)), name)
            act.setCheckable(True)
            act.setChecked(color == current)
            act.triggered.connect(lambda _c=False, c=color: self.store.set_color(nid, c))
        colors.addSeparator()
        colors.addAction("Без цвета").triggered.connect(lambda _c=False: self.store.set_color(nid, None))
        if robot_signature(note) is not None:
            menu.addSeparator()
            action = menu.addAction("Напоминать, когда этот робот появится снова")
            action.setCheckable(True)
            action.setChecked(note.get("remind") is not False)
            action.toggled.connect(lambda on: self.store.set_remind(nid, on))
        menu.addSeparator()
        menu.addAction(_trash_icon(), "Удалить").triggered.connect(lambda _c=False: self._delete_one(nid))
        menu.exec(global_pos)

    def _chart_target(self, note: dict) -> tuple[str, float] | None:
        """(тикер, момент) для «Показать на графике» или None."""
        try:
            from app_common import _from_friendly_symbol
        except Exception:
            _from_friendly_symbol = str
        symbol = notes_meta.chart_symbol(note, _from_friendly_symbol)
        moment = notes_meta.moment_of(note)
        return (symbol, moment) if symbol and moment else None

    def _show_on_chart(self, note_id: str | None) -> None:
        note = self.store.get(note_id) if note_id else None
        target = self._chart_target(note) if note else None
        if target is None or not callable(self.open_chart_at):
            return
        self.open_chart_at(*target)

    # ---- картинки -------------------------------------------------------------------
    def _show_images(self, note: dict | None) -> None:
        names = note_images.images_of(note) if note else []
        shown = [self.images_list.item(i).data(self.ID_ROLE) for i in range(self.images_list.count())]
        if names == shown and all(self.images_list.item(i).data(self.ID_ROLE + 1) for i in range(len(names))):
            return                                   # те же картинки и все уже загружены — не мигаем
        self.images_list.clear()
        for name in names:
            item = QtWidgets.QListWidgetItem()
            item.setData(self.ID_ROLE, name)
            pix = QtGui.QPixmap(str(note_images.path_of(name))) if note_images.exists(name) else QtGui.QPixmap()
            if pix.isNull():
                item.setText("загружается…")         # ещё не пришла с сервера (синхронизация заметок)
                item.setData(self.ID_ROLE + 1, False)
            else:
                item.setIcon(QtGui.QIcon(pix.scaledToHeight(THUMB_H * 2, QtCore.Qt.TransformationMode.SmoothTransformation)))
                item.setToolTip(f"{pix.width()} × {pix.height()} — двойной щелчок: открыть")
                item.setData(self.ID_ROLE + 1, True)
            self.images_list.addItem(item)
        self.images_list.setVisible(bool(names))

    def _open_image(self, name: str | None) -> None:
        if name and note_images.exists(name):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(note_images.path_of(name))))

    def _image_menu(self, pos) -> None:
        item = self.images_list.itemAt(pos)
        name = item.data(self.ID_ROLE) if item is not None else None
        if not name or not self._current_id:
            return
        menu = QtWidgets.QMenu(self)
        have = note_images.exists(name)
        menu.addAction("Открыть", lambda: self._open_image(name)).setEnabled(have)
        menu.addAction("Сохранить как…", lambda: self._save_image_as(name)).setEnabled(have)
        menu.addAction("Копировать", lambda: QtWidgets.QApplication.clipboard().setPixmap(
            QtGui.QPixmap(str(note_images.path_of(name))))).setEnabled(have)
        menu.addSeparator()
        menu.addAction("Удалить картинку", lambda nid=self._current_id: self.store.remove_image(nid, name))
        menu.exec(self.images_list.viewport().mapToGlobal(pos))

    def _save_image_as(self, name: str) -> None:
        path, _f = QtWidgets.QFileDialog.getSaveFileName(self, "Сохранить картинку", name, "PNG (*.png)")
        if path:
            try:
                import shutil
                shutil.copyfile(note_images.path_of(name), path)
            except OSError as exc:
                QtWidgets.QMessageBox.warning(self, "Заметки", f"Не удалось сохранить: {exc}")

    def _paste_image(self) -> bool:
        """Картинка из буфера обмена -> к выбранной заметке. False — в буфере нет картинки."""
        if not self._current_id:
            return False
        image = QtWidgets.QApplication.clipboard().image()
        if image.isNull():
            return False
        name = note_images.save_image(image)
        if name:
            self.store.add_images(self._current_id, [name])
        return True

    def eventFilter(self, obj, event) -> bool:                                # noqa: N802 (Qt)
        if (obj is self.editor and event.type() == QtCore.QEvent.Type.KeyPress
                and event.matches(QtGui.QKeySequence.StandardKey.Paste)
                and QtWidgets.QApplication.clipboard().mimeData().hasImage()
                and not QtWidgets.QApplication.clipboard().mimeData().hasText()):   # Excel кладёт и то и то — текст
            if self._paste_image():
                return True
        return super().eventFilter(obj, event)

    # ---- дневник дня и статистика по тегам (notes_meta) ----------------------------------------
    def _diary(self) -> None:
        today = date.today()
        day_notes = [n for n in self.store.notes if self._note_date(n) == today
                     and n.get("kind") != notes_meta.DIARY_KIND]
        closed = []
        if callable(self.day_trades_fn):
            try:
                closed = list(self.day_trades_fn(today) or [])
            except Exception as exc:                 # счёт недоступен — дневник без сделок
                print(f"[заметки] сделки дня для дневника: {exc}", file=sys.stderr)
        short, full = notes_meta.day_summary(day_notes, closed)
        images: list[str] = []
        for n in day_notes:
            for name in note_images.images_of(n):
                if name not in images and len(images) < notes_meta.DIARY_MAX_IMAGES:
                    images.append(name)
        diary = next((n for n in self.store.notes if n.get("kind") == notes_meta.DIARY_KIND
                      and n.get("day") == today.isoformat()), None)
        if diary is None:
            nid = self.store.add(kind=notes_meta.DIARY_KIND, title=f"Дневник {today:%d.%m.%Y}", details=short,
                                 comment=notes_meta.with_summary("", full), images=images,
                                 event_time=datetime.now().astimezone().isoformat(timespec="seconds"),
                                 fields={"day": today.isoformat()})
        else:
            nid = diary["id"]
            self.store.update_fields(nid, details=short, images=images,
                                     comment=notes_meta.with_summary(diary.get("comment", ""), full))
        self._select_note(nid)
        self.focus_comment(after="Выводы дня:")

    def _tag_stats(self) -> None:
        shown = []
        for r in range(self.table.rowCount()):
            item = self.table.item(r, 0)
            if item is not None and not self.table.isRowHidden(r):
                note = self.store.get(item.data(self.ID_ROLE))
                if note is not None:
                    shown.append(note)
        rows = notes_meta.tag_stats(shown)
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Статистика по тегам")
        dlg.resize(760, 420)
        lay = QtWidgets.QVBoxLayout(dlg)
        period = self.date_btn.text().replace("▾", "").strip()
        info = QtWidgets.QLabel(
            f"Заметки-сделки ({period}; учтены показанные сейчас заметки). Итог — в пунктах × объём, как в "
            "«Сделках» → «Закрытые». Двойной щелчок по тегу — показать его заметки."
            if rows else
            "Заметок-сделок с результатом пока нет. Добавьте сделку в «Заметки» («Сделки» → правая кнопка → "
            "«В заметки», или правая кнопка по метке сделки на графике) и поставьте тег сетапа: «Сетап: #пробой».")
        info.setWordWrap(True)
        lay.addWidget(info)
        headers = ["Тег", "Сделок", "Прибыльных", "% прибыльных", "Итог", "Средний", "Лучшая", "Худшая"]
        table = QtWidgets.QTableWidget(len(rows), len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        green, red = QtGui.QColor("#2ecc55"), QtGui.QColor("#e5484d")
        for r, row in enumerate(rows):
            tag = row["tag"]
            cells = [("#" + tag) if not tag.startswith(("(", "все")) else tag, str(row["trades"]), str(row["wins"]),
                     f"{row['win_pct']:.0f} %", notes_meta.fmt_signed(row["total"]), notes_meta.fmt_signed(row["avg"]),
                     notes_meta.fmt_signed(row["best"]), notes_meta.fmt_signed(row["worst"])]
            for c, text in enumerate(cells):
                item = QtWidgets.QTableWidgetItem(text)
                item.setData(self.ID_ROLE, tag)
                if c >= 1:
                    item.setTextAlignment(int(QtCore.Qt.AlignmentFlag.AlignRight.value)
                                          | int(QtCore.Qt.AlignmentFlag.AlignVCenter.value))
                if c >= 4:
                    value = row[("total", "avg", "best", "worst")[c - 4]]
                    if value:
                        item.setForeground(green if value > 0 else red)
                if tag == "все сделки":
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                table.setItem(r, c, item)
        table.resizeColumnsToContents()
        table.horizontalHeader().setStretchLastSection(True)

        def pick(item) -> None:
            tag = item.data(self.ID_ROLE)
            for i in range(self.tags_list.count()):
                if self.tags_list.item(i).data(self.ID_ROLE) == tag:
                    self.tags_list.setCurrentRow(i)
                    dlg.accept()
                    return
        table.itemDoubleClicked.connect(pick)
        lay.addWidget(table, 1)
        close = QtWidgets.QPushButton("Закрыть")
        close.clicked.connect(dlg.accept)
        lay.addWidget(close, 0, QtCore.Qt.AlignmentFlag.AlignRight)
        dlg.exec()

    def focus_comment(self, after: str | None = None) -> None:
        """Курсор — в комментарий выбранной заметки: в конец строки, начинающейся с after (у дневника —
        «Выводы дня:»), иначе в конец первой строки (у шаблона сделки — после «Сетап: #»)."""
        if not self._current_id:
            return
        self.editor.setFocus(QtCore.Qt.FocusReason.OtherFocusReason)
        doc = self.editor.document()
        block = doc.firstBlock()
        if after:
            b = doc.firstBlock()
            while b.isValid():
                if b.text().startswith(after):
                    block = b
                    break
                b = b.next()
        cur = QtGui.QTextCursor(block)
        cur.movePosition(QtGui.QTextCursor.MoveOperation.EndOfBlock)
        self.editor.setTextCursor(cur)
        self.editor.ensureCursorVisible()

    def _on_comment_changed(self) -> None:
        if self._current_id:
            self.store.set_comment(self._current_id, self.editor.toPlainText())
            self._suggest_tags()

    def _tag_prefix(self) -> str | None:
        """Набираемый тег перед курсором: «#про» -> «про», только «#» -> «»; не тег — None."""
        cur = self.editor.textCursor()
        before = cur.block().text()[:cur.positionInBlock()]
        m = re.search(r"(?:^|[^\w#])#([\w-]*)$", before)
        return m.group(1) if m else None

    def _suggest_tags(self) -> None:
        popup = self._tag_completer.popup()
        prefix = self._tag_prefix()
        if prefix is None or not self.editor.hasFocus():
            popup.hide()
            return
        low = prefix.lower()
        tags = [t for t, _n in notes_meta.tag_counts(self.store.notes) if t.startswith(low) and t != low]
        if not tags:
            popup.hide()
            return
        self._tag_model.setStringList(tags)
        self._tag_completer.setCompletionPrefix("")
        rect = self.editor.cursorRect()
        rect.setWidth(max(160, popup.sizeHintForColumn(0) + 24))
        self._tag_completer.complete(rect)

    def _insert_tag(self, tag: str) -> None:
        prefix = self._tag_prefix()
        if prefix is None:
            return
        cur = self.editor.textCursor()
        cur.movePosition(QtGui.QTextCursor.MoveOperation.Left, QtGui.QTextCursor.MoveMode.KeepAnchor, len(prefix))
        cur.insertText(tag + " ")
        self.editor.setTextCursor(cur)

    # ---- действия -------------------------------------------------------------------
    def _new_note(self) -> None:
        note_id = self.store.add(kind="📝 Заметка", title="", comment="")
        self._select_note(note_id)
        self.editor.setFocus()

    def _delete_button(self, note_id: str) -> QtWidgets.QWidget:
        """Кнопка «удалить» прямо в строке заметки."""
        btn = QtWidgets.QToolButton()
        btn.setAutoRaise(True)
        btn.setIcon(_trash_icon())
        btn.setIconSize(QtCore.QSize(14, 14))
        btn.setToolTip("Удалить заметку")
        btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet("QToolButton { border: none; border-radius: 3px; padding: 2px; }"
                          "QToolButton:hover { background: rgba(240, 112, 127, 0.22); }")
        btn.clicked.connect(lambda _=False, nid=note_id: self._delete_one(nid))
        holder = QtWidgets.QWidget()
        lay = QtWidgets.QHBoxLayout(holder)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(btn, 0, QtCore.Qt.AlignmentFlag.AlignCenter)
        return holder

    def _delete_one(self, note_id: str) -> None:
        if self._current_id == note_id:
            self._current_id = None
        self.store.remove([note_id])

    def _delete_selected(self) -> None:
        ids = self._selected_ids()
        if not ids:
            return
        if len(ids) > 1:
            answer = QtWidgets.QMessageBox.question(self, "Заметки", f"Удалить заметки ({len(ids)})?")
            if answer != QtWidgets.QMessageBox.StandardButton.Yes:
                return
        self._current_id = None
        self.store.remove(ids)

    def _purge_old(self) -> None:
        ids = self.store.older_than(30)
        if not ids:
            QtWidgets.QMessageBox.information(self, "Заметки", "Заметок старше месяца нет.")
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Заметки", f"Удалить заметки старше месяца ({len(ids)})? Отменить это нельзя.")
        if answer != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        if self._current_id in ids:
            self._current_id = None
        self.store.remove(ids)

    # ---- фильтры ------------------------------------------------------------------------
    def _open_calendar(self) -> None:
        cal = self._calendar_popup.calendar
        cal.set_range(*(self._range or (None, None)))
        self._calendar_popup.adjustSize()
        self._calendar_popup.show_below(self.date_btn)

    def _set_range(self, start: date | None, end: date | None) -> None:
        if start is None:
            self._range = None
            self.date_btn.setText("Все даты  ▾")
        else:
            a, b = sorted((start, end or start))
            self._range = (a, b)
            if a == b:
                label = a.strftime("%d.%m.%Y")
            elif a.year == b.year:
                label = f"{a:%d.%m} — {b:%d.%m.%Y}"
            else:
                label = f"{a:%d.%m.%Y} — {b:%d.%m.%Y}"
            self.date_btn.setText(f"{label}  ▾")
        self._apply_filter()

    def _reset_filters(self) -> None:
        self.filter_edit.clear()
        self.type_combo.setCurrentIndex(0)
        self._set_range(None, None)

    @staticmethod
    def _note_date(note: dict) -> date | None:
        """День заметки: дата самого события (если есть), иначе — день, когда заметку создали."""
        created = None
        try:
            created = datetime.fromisoformat(str(note.get("created", "")).replace("Z", "+00:00")).astimezone()
        except Exception:
            pass
        when = str(note.get("event_time") or "")
        m = re.match(r"^(\d{2})\.(\d{2})\b", when)        # «20.10 13:41:24» из окна уведомлений
        if m:
            year = created.year if created else datetime.now().year
            try:
                return date(year, int(m.group(2)), int(m.group(1)))
            except ValueError:
                pass
        if when:
            try:
                return datetime.fromisoformat(when.replace("Z", "+00:00")).astimezone().date()
            except Exception:
                pass
        return created.date() if created else None

    def _refresh_types(self) -> None:
        current = self.type_combo.currentData()
        kinds = sorted({n.get("kind") or "📝 Заметка" for n in self.store.notes})
        self.type_combo.blockSignals(True)
        self.type_combo.clear()
        self.type_combo.addItem("Все типы", None)
        for kind in kinds:
            count = sum(1 for n in self.store.notes if (n.get("kind") or "📝 Заметка") == kind)
            self.type_combo.addItem(f"{kind} ({count})", kind)
        index = self.type_combo.findData(current)
        self.type_combo.setCurrentIndex(index if index >= 0 else 0)
        self.type_combo.blockSignals(False)

    def _refresh_tags(self) -> None:
        """Панель тегов: «Все заметки», «📌 Закреплённые», затем теги по частоте; выбранный — сохраняется."""
        cur = self.tags_list.currentItem()
        keep = cur.data(self.ID_ROLE) if cur is not None else None
        self.tags_list.blockSignals(True)
        self.tags_list.clear()
        entries = [(None, f"Все заметки ({len(self.store.notes)})")]
        pinned = sum(1 for n in self.store.notes if n.get("pinned"))
        if pinned:
            entries.append(("📌", f"📌 Закреплённые ({pinned})"))
        tags = notes_meta.tag_counts(self.store.notes)
        entries += [(tag, f"#{tag}  ({count})") for tag, count in tags]
        select = 0
        for i, (key, text) in enumerate(entries):
            item = QtWidgets.QListWidgetItem(text)
            item.setData(self.ID_ROLE, key)
            self.tags_list.addItem(item)
            if key == keep:
                select = i
        if not tags:                                # подсказка, пока тегов нет
            hint = QtWidgets.QListWidgetItem("Тегов пока нет.\nНапишите в комментарии\nслово с #, например\n#пробой "
                                             "или #ошибка —\nздесь появится фильтр.")
            hint.setFlags(QtCore.Qt.ItemFlag.NoItemFlags)
            hint.setForeground(QtGui.QColor(_c("TEXT_DIM", "#8b9098")))
            self.tags_list.addItem(hint)
        self.tags_list.setCurrentRow(select)
        self.tags_list.blockSignals(False)

    def _mark_calendar_days(self) -> None:
        """В календаре дни, за которые есть заметки, — подчёркнуты."""
        days = {d for d in (self._note_date(n) for n in self.store.notes) if d}
        self._calendar_popup.calendar.marked = days
        self._calendar_popup.calendar.update()

    def _apply_filter(self, *_args) -> None:
        needle = self.filter_edit.text().strip().lower()
        kind = self.type_combo.currentData() if hasattr(self, "type_combo") else None
        cur_tag = self.tags_list.currentItem() if hasattr(self, "tags_list") else None
        tag_filter = cur_tag.data(self.ID_ROLE) if cur_tag is not None else None
        hidden: dict = {}
        use_dates = getattr(self, "_range", None) is not None
        if use_dates:
            d0, d1 = self._range
        shown = 0
        for r in range(self.table.rowCount()):
            item = self.table.item(r, 0)
            note = self.store.get(item.data(self.ID_ROLE)) if item is not None else None
            visible = note is not None
            if visible and needle:
                hay = " ".join(str(note.get(k, "")) for k in ("symbol", "kind", "title", "details", "comment")).lower()
                visible = needle in hay
            if visible and kind:
                visible = (note.get("kind") or "📝 Заметка") == kind
            if visible and use_dates:
                day = self._note_date(note)
                visible = day is not None and d0 <= day <= d1
            if visible and tag_filter == "📌":
                visible = bool(note.get("pinned"))
            elif visible and tag_filter:
                visible = tag_filter in notes_meta.tags_of(note)
            self.table.setRowHidden(r, not visible)
            hidden[item.data(self.ID_ROLE) if item is not None else None] = not visible
            shown += visible
        for r in range(self.cards.count()):
            card = self.cards.item(r)
            card.setHidden(hidden.get(card.data(self.ID_ROLE), True))
        total = len(self.store.notes)
        self.count_label.setText(f"Заметок: {total}" if shown == total else f"Показано {shown} из {total}")
