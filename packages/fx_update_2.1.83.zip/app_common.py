# -*- coding: utf-8 -*-
"""Общие константы и функции терминала: инструменты по умолчанию и квартальные фьючерсы,
дружественные имена символов, таймфреймы и периоды истории, площадки, часовые пояса,
размер шрифта и стиль приложения. Здесь же — настройка pyqtgraph под тему (до создания графиков).

Часть gui_app.py, вынесенная в отдельный модуль; запуск терминала — по-прежнему python gui_app.py.
"""
from __future__ import annotations

import faulthandler
import json
import os
import re
import ssl
import sys
import traceback
from datetime import date, timedelta
from pathlib import Path
from zoneinfo import available_timezones

import pandas as pd
import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6
import pyqtgraph as pg
import fx_theme

from candlestick_item import CandlestickItem, TimeAxisItem, BULL_COLOR, BEAR_COLOR
from finam_terminal import (
    FinamClient,
    enrich_with_indicators,
    INSTRUMENTS,
    to_friendly_symbol,
    from_friendly_symbol,
    register_symbols,
    sma,
    vwap,
)
from finam_sdk_client import FinamStreamClient
from quotes_tab import QuotesTab, QuotesEventMarker
from instrument_picker import InstrumentPickerDialog
from tick_volume_manager import TickVolumeManager
from window_links import LinkHub, install_link_titlebar
from order_flow import (
    OrderFlowController,
    OrderFlowTab,
    ORDER_FLOW_SYMBOLS,
    resolve_quarterly_symbols,
)
from connection_diagnostics import ConnectionDiagnosticsDialog
from cny_forward_tab import CnyForwardMonitorTab, set_display_timezone as set_cny_display_timezone
import docking
from open_interest_tab import OpenInterestTab
from options_tab import OptionsTab
from status_clock import StatusClock, FinamClockSource
from notes_panel import NotesStore, NotesPanel
from sound_notifier import SoundNotifier, PULSE, SIGNAL, ALERT, TITLES as SOUND_TITLES
from workspace_shell import PanelSpec, ShellGroup, WorkspaceShell
import candle_cache


# Фон графиков — по теме: тёмная — графитово-синий, светлая — белый (как и окна вокруг).
pg.setConfigOptions(
    antialias=True,
    background=fx_theme.chart_color("bg", fx_theme.saved_theme()),
    foreground=fx_theme.chart_color("fg", fx_theme.saved_theme()),
)
# Подпись оси записывается, только когда её текст изменился (а не при каждой смене диапазона).
try:
    from services import pg_tweaks
    pg_tweaks.quiet_axis_labels()
except Exception:                                    # noqa: BLE001 — без правки графики работают как раньше
    traceback.print_exc()

# Мгновенный fallback-список валютных инструментов при старте, пока не
# подгрузится полный каталог от брокера через gRPC (после чего «Каталог»
# заполнится настоящими площадками, и можно будет выбрать любую из них).
# Фильтр по конкретным кодам валют, а не по подстроке "RUB" в тикере —
# иначе туда попадают и металлы (GLDRUBF, SLVRUBF), тоже котируемые в RUB.
_CURRENCY_CODES = ("USD", "EUR", "CNY")
DEFAULT_SYMBOLS = [s for s in INSTRUMENTS if s.startswith(_CURRENCY_CODES)]

# ---------------------------------------------------------------------------
# Квартальные фьючерсы ФОРТС: Si (USD/RUB), Eu (EUR/RUB), CR (CNY/RUB,
# на бирже называется CNY-<мес>.<год>). Код месяца: H=март, M=июнь,
# U=сентябрь, Z=декабрь; последняя цифра — год (SiZ6 = Si-12.26).
# Список строится по единому правилу терминала (contracts.py): текущий контракт
# и следующий за ним; на следующий переходим за 3 дня до экспирации. Дата
# экспирации — из Finam GetAsset, пока её нет — третий четверг месяца.
# ---------------------------------------------------------------------------
QUARTERLY_FUTURES_BASES = ("Si", "Eu", "CR")
QUARTERLY_FUTURES_COUNT = 2  # сколько ближайших контрактов на каждый базовый актив
_QUARTER_MONTH_CODES = {3: "H", 6: "M", 9: "U", 12: "Z"}


def _dialog_buttons_qss() -> str:
    """Кнопки диалогов в духе Photoshop: текст в скруглённой («таблетка») тонкой рамке без заливки;
    кнопка по умолчанию (OK) — рамка ярче и толще. Цвета — из текущей палитры fx_theme.
    Размер — как у кнопок-«пилюль» «Заметок» и «Алгоритмов» (03.11): поля 2×12 px, скругление 10 px."""
    text = str(getattr(fx_theme, "TEXT", "#d7dae0"))
    dim = str(getattr(fx_theme, "TEXT_DIM", "#8b9098"))
    tint = str(getattr(fx_theme, "HOVER_TINT", "255, 255, 255"))
    return f"""
        QDialog QPushButton, QMessageBox QPushButton {{
            background: transparent; color: {text};
            border: 1px solid {dim}; border-radius: 10px;
            padding: 2px 12px; min-width: 64px; min-height: 14px;
        }}
        QDialog QPushButton:hover, QMessageBox QPushButton:hover {{
            border-color: {text}; background: rgba({tint}, 0.06);
        }}
        QDialog QPushButton:pressed, QMessageBox QPushButton:pressed {{
            background: rgba({tint}, 0.12);   /* сам отклик на нажатие — заливка акцентом (button_feedback) */
        }}
        QDialog QPushButton:default, QMessageBox QPushButton:default {{
            border: 2px solid {text}; padding: 1px 11px;
        }}
        QDialog QPushButton:disabled, QMessageBox QPushButton:disabled {{
            color: {dim}; border-color: rgba(139, 144, 152, 0.4);
        }}
        QDialog QPushButton:focus, QMessageBox QPushButton:focus {{ outline: none; }}
    """


def app_stylesheet(theme_name: str) -> str:
    """Тема терминала + оформление кнопок диалогов + размер шрифта из «Настроек → Интерфейс» + свои фон, текст
    и шрифт окон «Аналитики» и «Заметок» (appearance.window_qss, 2.1.83 — после общего размера: он их перекрывает)."""
    qss = fx_theme.stylesheet(theme_name) + _dialog_buttons_qss()
    size = _saved_font_size()
    if size > 0:
        # в конце — перекрывает размер из темы; у виджетов со своим стилем размер остаётся их
        qss += f"\nQWidget {{ font-size: {size}pt; }}\n"
    try:
        import appearance
        qss += appearance.window_qss(theme_name)
    except Exception as exc:                                         # оформление — не повод не запуститься
        print(f"[тема] цвета окон: {type(exc).__name__}: {exc}", file=sys.stderr)
    return qss


def apply_app_font_size(app: QtWidgets.QApplication) -> None:
    """Шрифт приложения под выбранный размер (для того, что не задано стилем)."""
    base = app.property("fx_base_font_pt")
    if base is None:                              # исходный размер — чтобы «Как в теме» его вернул
        base = app.font().pointSize()
        app.setProperty("fx_base_font_pt", base)
    size = _saved_font_size()
    font = app.font()
    font.setPointSize(size if size > 0 else int(base))
    app.setFont(font)


def _install_russian_qt(app: QtWidgets.QApplication) -> None:
    """Перевод стандартных кнопок Qt (Cancel → «Отмена», Yes/No → «Да»/«Нет» и т. д.)."""
    try:
        translations = QtCore.QLibraryInfo.path(QtCore.QLibraryInfo.LibraryPath.TranslationsPath)
        translator = QtCore.QTranslator(app)
        if translator.load(QtCore.QLocale(QtCore.QLocale.Language.Russian), "qtbase", "_", translations):
            app.installTranslator(translator)
        else:
            print("[gui] перевод qtbase_ru не найден — стандартные кнопки останутся на английском", file=sys.stderr)
    except Exception as exc:
        print(f"[gui] перевод Qt: {type(exc).__name__}: {exc}", file=sys.stderr)


def _third_thursday(year: int, month: int) -> date:
    first = date(year, month, 1)
    first_thursday = first + timedelta(days=(3 - first.weekday()) % 7)
    return first_thursday + timedelta(days=14)


def quarterly_futures_symbols(
    today: date | None = None,
    bases: tuple[str, ...] = QUARTERLY_FUTURES_BASES,
    count: int = QUARTERLY_FUTURES_COUNT,
) -> list[str]:
    # Единое правило терминала (contracts.py) — то же, что у «Открытого интереса»,
    # «Опционов», «Покупки/Продажи» и CNY Forward, поэтому все окна на одном контракте.
    import contracts
    return [
        symbol
        for base in bases
        for symbol in contracts.quarterly_contracts(base, count, today)
    ]


QUARTERLY_SYMBOLS = quarterly_futures_symbols()
DEFAULT_SYMBOLS = DEFAULT_SYMBOLS + [
    s for s in QUARTERLY_SYMBOLS if s not in DEFAULT_SYMBOLS
]

_CR_SYMBOL_RE = re.compile(r"^CR([HMUZ])(\d)@RTSX$")
_CR_CODE_TO_MONTH = {v: k for k, v in _QUARTER_MONTH_CODES.items()}
# Ввод руками: «CNY-12.26» (правильное имя) или «CR-12.26» (старое, тоже
# принимаем). Год — 2 цифры (12.26) или 4 (12.2026).
_CNY_FRIENDLY_RE = re.compile(r"^(?:CNY|CR)-(\d{1,2})\.(?:20)?(\d{2})$", re.IGNORECASE)


def _friendly_symbol(symbol: str) -> str:
    """
    Дружественное имя для списка: Si/Eu — через to_friendly_symbol (Si-12.26).
    Юаневые квартальные фьючерсы (тикер CRZ6@RTSX) на бирже называются
    «CNY-12.26», а не «CR-12.26», поэтому их разбираем ДО to_friendly_symbol
    (он мог бы превратить CRZ6 в «CR-12.26»).
    """
    m = _CR_SYMBOL_RE.match(symbol)
    if m:
        return f"CNY-{_CR_CODE_TO_MONTH[m.group(1)]}.2{m.group(2)}"
    return to_friendly_symbol(symbol)


def _from_friendly_symbol(text: str) -> str:
    """Обратное преобразование: «CNY-12.26» -> «CRZ6@RTSX», остальное — как раньше."""
    m = _CNY_FRIENDLY_RE.match(text.strip())
    if m:
        month, year = int(m.group(1)), int(m.group(2))
        code = _QUARTER_MONTH_CODES.get(month)
        if code:
            return f"CR{code}{year % 10}@RTSX"
    return from_friendly_symbol(text)


TIMEFRAMES = ["M1", "M5", "M15", "H1", "D1"]

# Скользящие средние в меню «Индикаторы»: период -> цвет линии.
SMA_COLORS = {
    20: "#7e57ff",
    30: "#2196f3",
    50: "#cddc39",
    100: "#26c6da",
    200: "#ec407a",
}
# Лучи «максимум/минимум за N дней»: цвета линий.
EXTREME_MAX_COLOR = "#ffa726"
EXTREME_MIN_COLOR = "#42a5f5"

# ---------------------------------------------------------------------------
# Период загрузки исторических свечей (настройка в «Настройки…»)
# ---------------------------------------------------------------------------
# (подпись в списке, ключ в QSettings, смещение назад от «сейчас»)
HISTORY_PERIODS = [
    ("2 недели", "2w", pd.DateOffset(weeks=2)),
    ("Месяц", "1m", pd.DateOffset(months=1)),
    ("3 месяца", "3m", pd.DateOffset(months=3)),
    ("6 месяцев", "6m", pd.DateOffset(months=6)),
    ("1 год", "1y", pd.DateOffset(years=1)),
]
DEFAULT_HISTORY_PERIOD = "1m"
_HISTORY_SETTINGS_KEY = "data/history_period"

# Глубина истории, которую отдаёт Finam Trade API (документация, «Рыночные
# данные → TimeFrame»), в днях. Запрос глубже этого смысла не имеет, поэтому
# выбранный период ограничивается глубиной для конкретного таймфрейма.
FINAM_HISTORY_DEPTH_DAYS = {
    "M1": 7,
    "M5": 30,
    "M15": 30,
    "M30": 30,
    "H1": 30,
    "D1": 365,
}


def history_start(end: pd.Timestamp, period_key: str, timeframe: str) -> pd.Timestamp:
    """Начало загружаемого периода: выбранный период, но не глубже лимита Finam."""
    offset = next(
        (o for _label, key, o in HISTORY_PERIODS if key == period_key),
        pd.DateOffset(months=1),
    )
    start = end - offset
    depth_days = FINAM_HISTORY_DEPTH_DAYS.get(str(timeframe).upper())
    if depth_days:
        start = max(start, end - pd.Timedelta(days=depth_days))
    return start

# Человекочитаемые названия площадок для выпадающего списка «Каталог».
# Список MIC-кодов взят из ответа TokenDetails (md_permissions) — если
# каталог содержит код не из этого словаря, показываем сырой MIC как есть.
MIC_LABELS = {
    "MISX": "Мосбиржа",
    "RTSX": "ФОРТС",
    "XNAS": "NASDAQ",
    "XNYS": "NYSE",
    "XASE": "NYSE American",
    "ARCX": "NYSE Arca",
    "BATS": "Cboe BZX",
    "OPRA": "Опционы (OPRA)",
    "XLON": "London Stock Exchange",
    "XETR": "Deutsche Börse Xetra",
    "XFRA": "Frankfurt",
    "XPAR": "Euronext Paris",
    "XAMS": "Euronext Amsterdam",
    "XHKG": "Hong Kong Stock Exchange",
    "XSHG": "Shanghai Stock Exchange",
    "XSHE": "Shenzhen Stock Exchange",
    "XTKS": "Tokyo Stock Exchange",
}

# Человекочитаемые названия типов инструментов — поле "type" в ответе
# каталога брокера (см. диагностику "Примеры по каждому значению 'type'").
TYPE_LABELS = {
    "EQUITIES": "Акции",
    "BONDS": "Облигации",
    "FUTURES": "Фьючерсы",
    "CURRENCIES": "Валюта",
    "FUNDS": "Фонды/ETF",
    "INDICES": "Индексы",
    "OTHER": "Прочее",
}


# --------------------------------------------------------------------------
# Часовой пояс отображения
# --------------------------------------------------------------------------

DEFAULT_DISPLAY_TZ = "Europe/Moscow"
_TZ_SETTINGS_KEY = "display/timezone"


def _list_timezones() -> list[str]:
    """Список IANA-поясов для выпадающего списка (с запасным вариантом)."""
    try:
        names = sorted(available_timezones())
    except Exception:
        names = []
    if not names:
        try:
            import pytz
            names = list(pytz.all_timezones)
        except Exception:
            names = [DEFAULT_DISPLAY_TZ, "UTC", "Europe/London", "America/New_York"]
    if "UTC" not in names:
        names.insert(0, "UTC")
    return names


def _is_valid_timezone(name: str) -> bool:
    try:
        pd.Timestamp("2020-01-01", tz="UTC").tz_convert(name)
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
# Диалог настроек
# --------------------------------------------------------------------------

# Старая общая настройка «скрывать инструмент и каталог в окнах» из «Настроек» убрана: теперь это кнопка на
# панели инструментов графика (и пункт в «Параметрах» окна «Тики»). Ключ остаётся только как значение
# по умолчанию для тех, у кого опция уже была включена.
_HIDE_INSTRUMENT_KEY = "ui/hide_instrument_controls"
_CHART_HIDE_INSTRUMENT_KEY = "chart/hide_instrument"    # общее для графиков, как chart/show_percent


FONT_SIZE_KEY = "appearance/font_size"     # 0 — как в теме; иначе размер шрифта интерфейса, pt
FONT_SIZES = (0, 8, 9, 10, 11, 12, 13, 14)


def _saved_font_size() -> int:
    try:
        return int(QtCore.QSettings("MyTradingTools", "FxTerminal").value(FONT_SIZE_KEY, 0) or 0)
    except (TypeError, ValueError):
        return 0


APP_ICON_NAME = "fx_terminal.ico"
# Произвольный, но стабильный идентификатор приложения для Windows. Он нужен,
# чтобы значок на панели задач и группировка окон принадлежали FX Terminal,
# а не python.exe (иначе Windows показывает иконку интерпретатора Python).
APP_USER_MODEL_ID = "MyTradingTools.FxTerminal"


def _resource_path(name: str) -> Path:
    """Путь к ресурсу рядом со скриптом; работает и в сборке PyInstaller."""
    candidates = []
    bundle_dir = getattr(sys, "_MEIPASS", None)  # распаковка onefile-сборки
    if bundle_dir:
        candidates.append(Path(bundle_dir) / name)
    if getattr(sys, "frozen", False):
        candidates.append(Path(sys.executable).parent / name)
    candidates.append(Path(__file__).resolve().parent / name)
    for path in candidates:
        if path.is_file():
            return path
    return candidates[-1]


def _sound_dir() -> Path:
    """Папка Sound с фирменными сигналами — рядом со скриптом (или в сборке PyInstaller)."""
    candidates = []
    bundle_dir = getattr(sys, "_MEIPASS", None)
    if bundle_dir:
        candidates.append(Path(bundle_dir) / "Sound")
    if getattr(sys, "frozen", False):
        candidates.append(Path(sys.executable).parent / "Sound")
    candidates.append(Path(__file__).resolve().parent / "Sound")
    for path in candidates:
        if path.is_dir():
            return path
    return candidates[-1]
