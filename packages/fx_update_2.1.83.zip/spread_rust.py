# -*- coding: utf-8 -*-
"""Спредовый робот по стакану — на Rust (этап 3 переноса «Алгоритмов», 2.1.58) — без Qt.

Расчёт — fx_engine.SpreadTracker (fx_engine_rs/src/algo/spread.rs, модуль 0.6.0 и новее): пропажи и появления
объёма у лучших цен, сопоставление в перестановки, кандидаты по объёму, признание роботом, «ушёл». Этот модуль —
обёртка с API эталона (spread_core.SpreadRobotTracker): вкладка «Алгоритмы» создаёт её через tracker().

Сверки «в тени» не было (как у роботов, решение 14.11): вместо неё tests/test_spread_rust.py — случайные потоки
стакана через Rust и через эталон, ответы и состояние роботов должны совпасть точно; идёт при каждой установке.

Что остаётся в Python: признанный робот для вкладки — словарь того же вида, что у эталона (side, size, events,
prices, requotes, started, recognized, active, price, from_price, last, last_mono); вкладка дописывает в него id
значка на графике. Биржевое время (started, last) Rust не нужно — его ведёт обёртка.

Запасного расчёта на Python нет (как у роботов с 2.1.57): модуля нет или он старый — спредовые роботы НЕ РАБОТАЮТ,
в журнале строка при запуске; ошибка Rust — строка в журнал, расчёт инструмента создаётся заново (работавшие
роботы «уходят» при ближайшей проверке expire — значки на графике закрываются); robot_rust.MAX_ERRORS ошибок —
расчёт этого инструмента выключен до перезапуска.
"""
from __future__ import annotations

import sys

import robot_rust

NEEDED = ("SpreadTracker",)      # fx_engine 0.6.0 и новее
STARTED_KEEP = 400               # столько кандидатов помним «когда появился» (их время начала — для словаря робота)

_engine_module = None            # None — ещё не пробовали; False — класса нет; иначе fx_engine


def engine():
    """Модуль fx_engine со спредовым роботом; None — модуля нет или он старый (строка в журнал — один раз)."""
    global _engine_module
    if _engine_module is None:
        _engine_module = False
        try:
            import app_paths  # noqa: F401  — готовый fx_engine из обновления (2.1.83)
            import fx_engine
            if not all(hasattr(fx_engine, name) for name in NEEDED):
                print(f"[rust-алгоритмы] в fx_engine {getattr(fx_engine, '__version__', '?')} нет SpreadTracker — "
                      "спредовые роботы НЕ РАБОТАЮТ: нужен модуль 0.6.0 или новее (обновление с пересборкой Rust)",
                      file=sys.stderr)
            else:
                _engine_module = fx_engine
                print(f"[rust-алгоритмы] спредовых роботов считает Rust (fx_engine {fx_engine.__version__})")
        except Exception as exc:
            print(f"[rust-алгоритмы] модуль fx_engine не загружен ({type(exc).__name__}: {exc}) — спредовые роботы "
                  "НЕ РАБОТАЮТ: модуль нужно собрать (обновление с пересборкой Rust)", file=sys.stderr)
    return _engine_module or None


def config(cfg: dict) -> tuple[float, float, int]:
    """Настройки спредового робота -> (мин. лотов, допуск по объёму долей, перестановок за минуту) — теми же
    правилами, что у эталона (spread_core.SpreadRobotTracker.update)."""
    return (float(cfg.get("min_lots", 300) or 300),
            max(0.0, float(cfg.get("tolerance", 3) or 0)) / 100.0,
            int(cfg.get("min_requotes", 10) or 10))


class SpreadRobotTracker(robot_rust._Rust):
    """Спредовые роботы инструмента на Rust с API spread_core.SpreadRobotTracker."""
    WHAT = "спредовый робот"

    def __init__(self, make, symbol: str = ""):
        self._by_id: dict[int, dict] = {}            # номер кандидата у Rust -> словарь признанного робота
        self._started: dict[int, object] = {}        # номер кандидата -> биржевое время его первой перестановки
        self._orphans: list[dict] = []               # роботы, которых Rust уже не знает: «ушли» при ближайшем expire
        super().__init__(make, symbol)

    def _reset(self) -> None:
        self._orphans.extend(robot for robot in self._by_id.values() if robot.get("active"))
        self._by_id.clear()
        self._started.clear()

    def update(self, bids: dict, asks: dict, mono: float, ts, cfg: dict) -> list[tuple[dict, bool]]:
        """Обновление стакана (цена -> лоты). -> [(робот, впервые признан?)] для роботов с перестановкой сейчас."""
        if self._rs is None:
            return []
        try:
            min_lots, tolerance, need = config(cfg)
            rows = self._rs.update(list(bids.items()), list(asks.items()), float(mono), min_lots, tolerance, need)
        except Exception as exc:
            self._failed("update", exc)
            return []
        result = []
        for cid, is_buy, size, requotes, price, from_price, events, prices, created, status in rows:
            if created:
                if len(self._started) > STARTED_KEEP:
                    for old in list(self._started)[:STARTED_KEEP // 2]:
                        if old not in self._by_id:
                            del self._started[old]
                self._started[cid] = ts
            if status == 0:                          # кандидат ещё не робот — вкладке не показываем
                continue
            robot = self._by_id.get(cid)
            if robot is None:
                robot = self._by_id[cid] = {"side": "BUY" if is_buy else "SELL", "started": self._started.get(cid),
                                            "recognized": True}
            robot.update(size=size, events=list(events), prices=list(prices), requotes=requotes, price=price,
                         from_price=from_price, last=ts, last_mono=mono, active=True)
            if status == 1:
                robot["started"] = robot.get("started") or ts
            result.append((robot, status == 1))
        return result

    def expire(self, mono: float) -> list[dict]:
        """Роботы без перестановок дольше EXPIRE_SEC — «ушли» (отдаются один раз), и те, что потеряны при сбое."""
        gone, self._orphans = self._orphans, []
        if self._rs is not None:
            try:
                for cid in self._rs.expire(float(mono)):
                    robot = self._by_id.pop(cid, None)
                    self._started.pop(cid, None)
                    if robot is not None:
                        gone.append(robot)
            except Exception as exc:
                self._failed("expire", exc)
                gone, self._orphans = gone + self._orphans, []
        for robot in gone:
            robot["active"] = False
        return gone

    def active(self) -> list[dict]:
        """Работающие роботы: сначала сторона покупки, внутри — по порядку появления."""
        if self._rs is None:
            return []
        try:
            return [self._by_id[cid] for cid in self._rs.active() if cid in self._by_id]
        except Exception as exc:
            self._failed("active", exc)
            return []


def tracker(symbol: str = "") -> SpreadRobotTracker:
    """Спредовые роботы инструмента на Rust; модуля нет — выключены (роботов нет)."""
    mod = engine()
    return SpreadRobotTracker(None if mod is None else mod.SpreadTracker, symbol)
