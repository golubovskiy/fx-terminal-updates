# -*- coding: utf-8 -*-
"""Айсберги — на Rust (этап 3 переноса «Алгоритмов», 2.1.64) — без Qt.

Расчёт — fx_engine.IcebergTracker и fx_engine.IcebergTrades (fx_engine_rs/src/algo/iceberg.rs, модуль 0.7.0 и
новее): счёт исполненного на цене, ожидание восстановления объёма после сделки, кандидаты и подтверждение
айсберга по стакану; запасной поиск «по сделкам», пока стакана нет. Этот модуль — обёртки с API эталонов
(iceberg_core.IcebergTracker и TradeTail): вкладка «Алгоритмы» создаёт их через tracker() и trade_tail().

Сверки «в тени» не было (как у роботов, решение 14.11): вместо неё tests/test_iceberg_rust.py — случайные потоки
сделок и стакана через Rust и через эталон, ответы и состояние должны совпасть точно; идёт при каждой установке.

Что остаётся в Python: стакан (цена -> лоты) — у вкладки, поэтому обновление стакана идёт в два шага: Rust
называет цены, на которых ждёт восстановления объёма (wants), обёртка находит объёмы и отдаёт их обратно
(restore). Обычно ожиданий нет, и это один короткий вызов. Биржевое время уходит в Rust наносекундами и
возвращается pd.Timestamp в UTC. Линии на графике, отметки в стаканах, уведомления и история — у вкладки.

Запасного расчёта на Python нет (как у роботов с 2.1.57): модуля нет или он старый — айсберги НЕ РАБОТАЮТ,
в журнале строка при запуске; ошибка Rust — строка в журнал, расчёт инструмента создаётся заново (кандидаты и
счёт исполненного теряются, линии на графике остаются у вкладки и закроются сами); robot_rust.MAX_ERRORS ошибок —
расчёт этого инструмента выключен до перезапуска.
"""
from __future__ import annotations

import sys

import pandas as pd

import robot_rust

NEEDED = ("IcebergTracker", "IcebergTrades")      # fx_engine 0.7.0 и новее

_engine_module = None            # None — ещё не пробовали; False — классов нет; иначе fx_engine


def engine():
    """Модуль fx_engine с айсбергами; None — модуля нет или он старый (строка в журнал — один раз)."""
    global _engine_module
    if _engine_module is None:
        _engine_module = False
        try:
            import app_paths  # noqa: F401  — готовый fx_engine из обновления (2.1.83)
            import fx_engine
            missing = [name for name in NEEDED if not hasattr(fx_engine, name)]
            if missing:
                print(f"[rust-алгоритмы] в fx_engine {getattr(fx_engine, '__version__', '?')} нет {', '.join(missing)} — "
                      "айсберги НЕ РАБОТАЮТ: нужен модуль 0.7.0 или новее (обновление с пересборкой Rust)",
                      file=sys.stderr)
            else:
                _engine_module = fx_engine
                print(f"[rust-алгоритмы] айсберги считает Rust (fx_engine {fx_engine.__version__})")
        except Exception as exc:
            print(f"[rust-алгоритмы] модуль fx_engine не загружен ({type(exc).__name__}: {exc}) — айсберги "
                  "НЕ РАБОТАЮТ: модуль нужно собрать (обновление с пересборкой Rust)", file=sys.stderr)
    return _engine_module or None


def _ts(ns: int) -> pd.Timestamp:
    """Наносекунды epoch -> биржевое время в UTC (то же, что вкладка отдала в trade)."""
    return pd.Timestamp(int(ns), unit="ns", tz="UTC")


def _side(is_ask) -> str:
    return "S" if is_ask else "B"


class IcebergTracker(robot_rust._Rust):
    """Айсберги инструмента по стакану на Rust с API iceberg_core.IcebergTracker. Стороны — «S» (ask) / «B» (bid)."""
    WHAT = "айсберг"

    def clear_pending(self) -> None:
        """Поиск выключен: ожидания восстановления забываем."""
        if self._rs is None:
            return
        try:
            self._rs.clear_pending()
        except Exception as exc:
            self._failed("clear_pending", exc)

    def executed(self, side: str, price: float) -> float:
        """Сколько лотов исполнено на цене подряд (0 — счёта нет)."""
        if self._rs is None:
            return 0.0
        try:
            return float(self._rs.executed(side == "S", float(price)))
        except Exception as exc:
            self._failed("executed", exc)
            return 0.0

    def drop_level(self, side: str, price: float) -> None:
        """Кандидата на цене больше нет (линия айсберга на графике пробита)."""
        if self._rs is None:
            return
        try:
            self._rs.drop_level(side == "S", float(price))
        except Exception as exc:
            self._failed("drop_level", exc)

    def trade(self, ts, mono: float, price: float, side: str, size: float, visible: float,
              visible_lots: float) -> None:
        """Сделка: ts — биржевое время, mono — часы терминала, side — съеденная сторона («S» / «B»),
        visible — объём в стакане на цене сделки сейчас, visible_lots — настройка «Видимый объём» (0 — любой)."""
        if self._rs is None:
            return
        try:
            self._rs.trade(robot_rust._ns(ts), float(mono), float(price), side == "S", float(size or 0),
                           float(visible or 0), float(visible_lots or 0))
        except Exception as exc:
            self._failed("trade", exc)

    def book(self, mono: float, bids: dict, asks: dict, multiplier: int, visible_lots: float,
             hold_sec: float) -> list[dict]:
        """Стакан обновился (цена -> лоты). -> подтверждённые сейчас айсберги, по порядку:
        {side, price, hits, visible, executed, max_visible, held, first, last}."""
        if self._rs is None:
            return []
        try:
            wants = self._rs.wants(float(mono))
            if not wants:
                return []
            visibles = [float((asks if is_ask else bids).get(price, 0.0) or 0) for is_ask, price in wants]
            rows = self._rs.restore(float(mono), visibles, int(multiplier), float(visible_lots), float(hold_sec))
        except Exception as exc:
            self._failed("book", exc)
            return []
        return [{"side": _side(is_ask), "price": price, "hits": hits, "visible": visible, "executed": executed,
                 "max_visible": max_visible, "held": held, "first": _ts(first_ns), "last": _ts(last_ns)}
                for is_ask, price, hits, visible, executed, max_visible, held, first_ns, last_ns in rows]

    def snapshot(self) -> tuple[list, list, list]:
        """Состояние для сверки с эталоном — тем же видом, что iceberg_core.IcebergTracker.snapshot."""
        if self._rs is None:
            return [], [], []
        pending, executed, levels = self._rs.state()
        return ([(_side(a), price, before, traded, deadline, _ts(last)) for a, price, before, traded, deadline, last in pending],
                [(_side(a), price, qty, _ts(ts)) for a, price, qty, ts in executed],
                [(_side(a), price, hits, top, first_mono, last_mono, _ts(first), bool(confirmed))
                 for a, price, hits, top, first_mono, last_mono, first, confirmed in levels])


class TradeTail(robot_rust._Rust):
    """Хвост сделок и поиск айсберга «по сделкам» на Rust с API iceberg_core.TradeTail."""
    WHAT = "айсберг по сделкам"

    def add(self, ts, price: float, size: float, turnover: float) -> None:
        if self._rs is None:
            return
        try:
            self._rs.add(robot_rust._ns(ts), float(price), float(size), float(turnover))
        except Exception as exc:
            self._failed("add", exc)

    def candidate(self, count: int, visible_lots: float, min_lots: float) -> dict | None:
        """Последние count сделок — на одной цене? -> {hits, turnover, price} или None."""
        if self._rs is None:
            return None
        try:
            found = self._rs.candidate(int(count), float(visible_lots), float(min_lots))
        except Exception as exc:
            self._failed("candidate", exc)
            return None
        if found is None:
            return None
        hits, turnover, price = found
        return {"hits": int(hits), "turnover": turnover, "price": price}


def tracker(symbol: str = "") -> IcebergTracker:
    """Айсберги инструмента по стакану на Rust; модуля нет — выключены (айсбергов нет)."""
    mod = engine()
    return IcebergTracker(None if mod is None else mod.IcebergTracker, symbol)


def trade_tail(symbol: str = "") -> TradeTail:
    """Хвост сделок инструмента на Rust; модуля нет — выключен (кандидатов «по сделкам» нет)."""
    mod = engine()
    return TradeTail(None if mod is None else mod.IcebergTrades, symbol)
