# -*- coding: utf-8 -*-
"""Оформление окон опционов: палитра темы FX Terminal (fx_theme.py), если она рядом.

Без fx_theme (например, модуль скопирован отдельно) используется собственная тёмная палитра.
"""
from __future__ import annotations

try:
    import fx_theme
except Exception:          # нет файла или PySide6 — работаем с запасной палитрой
    fx_theme = None

_FALLBACK = {
    "bg": "#111620",        # фон графиков
    "card": "#111620",      # фон карточек
    "grid": "#252d3a",
    "text": "#d8dee9",
    "muted": "#8994a7",
    "call": "#35c98b",
    "put": "#ed5b68",
    "price": "#ffbf4a",     # линия цены базового актива
    "highlight": "#f3d36b", # максимумы OI
    "themed": False,
    "chart_text": "#d8dee9",   # подписи на графиках (графики тёмные в обеих темах)
    "chart_muted": "#8994a7",
    "chart_grid": "#252d3a",
}


def palette() -> dict:
    """Цвета для графиков и карточек. Вызывать при создании окна: тема читается в этот момент."""
    result = dict(_FALLBACK)
    if fx_theme is None:
        _user_colors(result)
        return result
    result.update(
        themed=True,
        bg=fx_theme.BG_INPUT,
        card=fx_theme.BG_PANEL,
        grid=fx_theme.BORDER,
        text=fx_theme.TEXT,
        muted=fx_theme.TEXT_DIM,
        call=fx_theme.BUY,      # цвета данных (покупка/продажа) — по правилам темы
        put=fx_theme.SELL,
    )
    try:
        import pyqtgraph as pg
        background = pg.getConfigOption("background")
        if isinstance(background, str) and background.startswith("#"):
            result["bg"] = background      # тот же фон, что у свечных графиков терминала
    except Exception:
        pass
    if _is_dark(result["bg"]) and not _is_dark(fx_theme.BG_WINDOW):
        # Светлая тема интерфейса, но графики тёмные (как свечные) — подписи и сетка
        # графиков берутся тёмной палитры, иначе тёмный текст терялся на тёмном фоне.
        result.update(chart_text=_FALLBACK["text"], chart_muted=_FALLBACK["muted"], chart_grid=_FALLBACK["grid"])
    else:
        result.update(chart_text=result["text"], chart_muted=result["muted"], chart_grid=result["grid"])
    _user_colors(result)
    return result


# «Настройки» → «Цвета» → «Опционы» (appearance, 2.1.83): ключ -> поля палитры, которые он задаёт.
_USER_KEYS = {
    "opt.chart_bg": ("bg",), "opt.card": ("card",), "opt.grid": ("grid", "chart_grid"),
    "opt.text": ("text", "chart_text"), "opt.muted": ("muted", "chart_muted"),
    "opt.call": ("call",), "opt.put": ("put",), "opt.price": ("price",), "opt.highlight": ("highlight",),
}


def _user_colors(result: dict) -> None:
    """Свои цвета окна «Опционы» поверх темы. Палитра читается при создании окна — меняются после перезапуска;
    фон и текст самого окна (opt.bg / opt.text) — ещё и общим стилем сразу (appearance.window_qss)."""
    try:
        import appearance
        user = {key: appearance.override(key) for key in _USER_KEYS}
    except Exception:
        return
    for key, value in user.items():
        if value:
            for field in _USER_KEYS[key]:
                result[field] = value


def _is_dark(color: str) -> bool:
    try:
        value = str(color).lstrip("#")[:6]
        r, g, b = (int(value[i:i + 2], 16) for i in (0, 2, 4))
        return (0.299 * r + 0.587 * g + 0.114 * b) < 128
    except Exception:
        return True


def apply_app_theme(app) -> bool:
    """Для запуска окна отдельно: та же тема и шапка, что у терминала. True — тема применена."""
    if fx_theme is None:
        return False
    try:
        from PySide6.QtCore import QSettings
        name = str(QSettings("MyTradingTools", "FxTerminal").value("appearance/theme", "dark"))
        app.setStyle("Fusion")
        app.setStyleSheet(fx_theme.stylesheet(name))
        fx_theme.install_windows_titlebar_color(app)
        return True
    except Exception:
        return False
