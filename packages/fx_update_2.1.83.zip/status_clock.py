# -*- coding: utf-8 -*-
"""FX Terminal — индикатор состояния соединения и часы.

Основной источник времени — Finam gRPC AssetsService.Clock. FinamClockSource
опрашивает сервер в фоновом потоке и между опросами продвигает время по
monotonic clock. Если Finam недоступен, используется локальное время ПК до
успешной синхронизации. Часовой пояс отображения настраивается отдельно.

Пинг до Finam — время ответа того же вызова Clock (как «пинг» в стакане скальперских терминалов): последние PING_KEEP
замеров, ping_stats() — последний, средний, лучший и худший; показывается в подсказке индикатора потока
стакана. Время сервера учитывает половину пинга (ответ сформирован примерно в середине вызова).
"""
from __future__ import annotations

import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Callable, Any

import shiboken6
from PySide6 import QtCore, QtGui, QtWidgets

try:
    from google.protobuf.empty_pb2 import Empty
except Exception:
    Empty = None

try:
    import fx_theme
except Exception:
    fx_theme = None

_STATE_COLORS = {
    "connected": ("BUY", "#2ecc55"),
    "connecting": ("TEXT_DIM", "#8b9098"),
    "partial": ("WARN", "#e0b030"),        # связь есть, но часть потоков переподключается
    "disconnected": ("SELL", "#e61e1e"),
}


def _tzinfo(name: str | None):
    if not name:
        return None
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:
        # Windows может не иметь базы IANA time zones.
        return timezone(timedelta(hours=3)) if name == "Europe/Moscow" else None


PING_KEEP = 30                       # замеров пинга в истории (при опросе раз в 10 с — 5 минут)
_CURRENT: "FinamClockSource | None" = None


def ping_stats() -> dict | None:
    """Пинг до Finam по последнему источнику времени терминала: {"last", "avg", "min", "max", "n", "age",
    "error"} (мс, age — секунд с последнего замера) или None, если замеров ещё нет."""
    source = _CURRENT
    return source.ping_stats() if source is not None else None


class FinamClockSource:
    """Кэш времени Finam; сетевой вызов выполняется в отдельном daemon-потоке.

    clock_rpc — сгенерированный gRPC-метод AssetsService.Clock.
    Ответ должен содержать timestamp.seconds и, опционально, timestamp.nanos.
    """

    def __init__(self, clock_rpc: Callable[..., Any], sync_interval: float = 30.0):
        self._clock_rpc = clock_rpc
        self._sync_interval = max(5.0, float(sync_interval))
        self._lock = threading.Lock()
        self._server_ts: float | None = None
        self._monotonic_at_sync = 0.0
        self._last_error: str | None = None
        self._pings: deque = deque(maxlen=PING_KEEP)      # (monotonic, мс)
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run, name="FinamClockSync", daemon=True
        )
        self._thread.start()
        global _CURRENT
        _CURRENT = self

    def ping_stats(self) -> dict | None:
        with self._lock:
            pings = list(self._pings)
            error = self._last_error
        if not pings:
            return {"error": error} if error else None
        values = [ms for _t, ms in pings]
        return {"last": values[-1], "avg": sum(values) / len(values), "min": min(values), "max": max(values),
                "n": len(values), "age": time.monotonic() - pings[-1][0], "error": error}

    def now(self) -> float:
        """Unix timestamp по серверным часам Finam с локальной интерполяцией."""
        with self._lock:
            server_ts = self._server_ts
            monotonic_at_sync = self._monotonic_at_sync
        if server_ts is None:
            return time.time()
        return server_ts + (time.monotonic() - monotonic_at_sync)

    @property
    def last_error(self) -> str | None:
        with self._lock:
            return self._last_error

    def sync_once(self) -> bool:
        """Синхронизироваться с Finam; удобно также для диагностики."""
        try:
            t0 = time.monotonic()
            if Empty is not None:
                try:
                    response = self._clock_rpc(Empty(), timeout=5.0)
                except TypeError:          # обёртка метода не принимает timeout — вызываем как раньше
                    response = self._clock_rpc(Empty())
            else:
                response = self._clock_rpc()
            stamp = getattr(response, "timestamp", None)
            if stamp is None:
                raise ValueError("Finam Clock не вернул поле timestamp")
            seconds = float(getattr(stamp, "seconds"))
            nanos = float(getattr(stamp, "nanos", 0))
            server_ts = seconds + nanos / 1_000_000_000.0
            if server_ts <= 0:
                raise ValueError(f"Некорректный timestamp от Finam: {server_ts}")
            mono = time.monotonic()
            rtt = mono - t0
            with self._lock:
                self._server_ts = server_ts
                self._monotonic_at_sync = t0 + rtt / 2          # сервер ответил примерно в середине вызова
                self._last_error = None
                self._pings.append((mono, rtt * 1000.0))
            return True
        except Exception as exc:
            with self._lock:
                self._last_error = f"{type(exc).__name__}: {exc}"
            return False

    def _run(self) -> None:
        while not self._stop_event.is_set():
            self.sync_once()
            self._stop_event.wait(self._sync_interval)

    def stop(self, timeout: float = 2.0) -> None:
        global _CURRENT
        if _CURRENT is self:
            _CURRENT = None
        self._stop_event.set()
        if self._thread.is_alive():
            self._thread.join(timeout=max(0.0, timeout))


def _world_time_qss() -> str:
    """Стиль всплывающего «Мирового времени»: заголовок 9 pt и время 10 pt при шрифте темы, с другим размером
    шрифта в «Настройках» — пропорционально (appearance.ui_pt, 2.1.83). Названия городов — шрифтом интерфейса."""
    try:
        import appearance
        title, clock = appearance.ui_pt(9), appearance.ui_pt(10)
    except Exception:                                        # noqa: BLE001
        title, clock = 9, 10
    return f"""
            QFrame#WorldTimePopup {{
                background-color: #151922;
                border: 1px solid #343b49;
                border-radius: 9px;
            }}
            QLabel#WorldTimeTitle {{
                color: #8d99ad;
                font-size: {title}pt;
                font-weight: 700;
                padding-bottom: 5px;
            }}
            QLabel[class="cityName"] {{ color: #cbd3df; padding: 2px 14px 2px 2px; }}
            QLabel[class="cityTime"] {{ color: #f3f6fb; font-family: Consolas, monospace; font-size: {clock}pt; padding: 2px; }}
        """


class StatusClock(QtWidgets.QLabel):
    def __init__(
        self,
        parent: QtWidgets.QWidget | None = None,
        time_source: Callable[[], float] | None = None,
        tz_name: str | None = "Europe/Moscow",
    ):
        super().__init__(parent)
        self._time_source = time_source
        self._tz_name = tz_name
        self._tz = _tzinfo(tz_name)
        self._state = "connecting"
        self._dot_color = QtGui.QColor("#8b9098")
        self._time_text = "--:--:--.---"
        self.setContentsMargins(0, 0, 14, 0)

        # Всплывающая панель мирового времени. Она не перехватывает мышь и
        # обновляется тем же источником времени, что и основные часы (Finam).
        self._world_time_popup = QtWidgets.QFrame(
            self, QtCore.Qt.WindowType.ToolTip | QtCore.Qt.WindowType.FramelessWindowHint
        )
        self._world_time_popup.setObjectName("WorldTimePopup")
        self._world_time_popup.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self._world_time_popup.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._world_time_popup.setStyleSheet(_world_time_qss())
        popup_layout = QtWidgets.QVBoxLayout(self._world_time_popup)
        popup_layout.setContentsMargins(12, 10, 12, 10)
        popup_layout.setSpacing(2)
        title = QtWidgets.QLabel("МИРОВОЕ ВРЕМЯ")
        title.setObjectName("WorldTimeTitle")
        popup_layout.addWidget(title)

        self._world_time_labels: list[tuple[str, QtWidgets.QLabel]] = []
        self._world_cities = (
            ("Владивосток", "Asia/Vladivostok"),
            ("Лондон", "Europe/London"),
            ("Нью-Йорк", "America/New_York"),
            ("Токио", "Asia/Tokyo"),
            ("Гонконг", "Asia/Hong_Kong"),
            ("Шанхай", "Asia/Shanghai"),
        )
        for city, zone_name in self._world_cities:
            row = QtWidgets.QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(14)
            city_label = QtWidgets.QLabel(city)
            city_label.setProperty("class", "cityName")
            time_label = QtWidgets.QLabel("--:--:--")
            time_label.setProperty("class", "cityTime")
            time_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            row.addWidget(city_label, 1)
            row.addWidget(time_label)
            popup_layout.addLayout(row)
            self._world_time_labels.append((zone_name, time_label))

        self._width_fixed = False

        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._refresh)
        # Миллисекунды — 10 обновлений в секунду (глазом не отличить от 20, а перерисовок вдвое меньше).
        self._timer.start(100)
        self._refresh()

    @staticmethod
    def is_valid(widget) -> bool:
        """Проверяет, что underlying C++ QWidget ещё существует."""
        try:
            return widget is not None and shiboken6.isValid(widget)
        except Exception:
            return False

    def set_state(self, state: str, tooltip: str | None = None) -> None:
        """Допустимые состояния: connected, connecting, partial (часть потоков переподключается), disconnected.
        tooltip — подсказка к индикатору (None — не менять)."""
        if not self.is_valid(self):
            return
        if tooltip is not None and tooltip != self.toolTip():
            self.setToolTip(tooltip)
        if state in _STATE_COLORS and state != self._state:
            self._state = state
            self._refresh()

    def set_time_source(self, source: Callable[[], float] | None) -> None:
        if not self.is_valid(self):
            return
        self._time_source = source
        self._refresh()

    def set_timezone(self, tz_name: str | None) -> None:
        if not self.is_valid(self):
            return
        self._tz_name = tz_name
        self._tz = _tzinfo(tz_name)
        self._refresh()

    def _timestamp(self) -> float:
        try:
            ts = float(self._time_source()) if self._time_source is not None else time.time()
            if ts <= 0:
                raise ValueError("Источник времени вернул неположительный timestamp")
            return ts
        except Exception:
            return time.time()

    def _now_text(self) -> str:
        return datetime.fromtimestamp(self._timestamp(), self._tz).strftime("%H:%M:%S")

    @staticmethod
    def _city_time_text(timestamp: float, zone_name: str) -> str:
        """Время города; используем IANA zoneinfo, а на Windows — Qt time zones."""
        try:
            from zoneinfo import ZoneInfo
            return datetime.fromtimestamp(timestamp, ZoneInfo(zone_name)).strftime("%H:%M:%S")
        except Exception:
            try:
                zone = QtCore.QTimeZone(zone_name.encode("ascii"))
                if zone.isValid():
                    dt = QtCore.QDateTime.fromSecsSinceEpoch(
                        int(timestamp), QtCore.QTimeZone.utc()
                    ).toTimeZone(zone)
                    return dt.toString("HH:mm:ss")
            except Exception:
                pass
            return "--:--:--"

    def _refresh(self) -> None:
        # Таймер может попасть в очередь событий одновременно с закрытием окна.
        if not self.is_valid(self):
            return
        attr, default = _STATE_COLORS.get(self._state, _STATE_COLORS["connecting"])
        color = str(getattr(fx_theme, attr, default)) if fx_theme is not None else default
        try:
            timestamp = self._timestamp()
            # %f даёт микросекунды; отображаем три цифры миллисекунд.
            now_text = datetime.fromtimestamp(timestamp, self._tz).strftime("%H:%M:%S.%f")[:-3]
            # Не setText: QLabel на каждый setText пересчитывает размер и раскладку родителя — строка
            # меню главного окна перестраивалась и перерисовывалась целиком 20 раз в секунду (замер 28.10:
            # ~73 мс/с). Часы рисуют себя сами (paintEvent) в прямоугольнике постоянного размера.
            self._dot_color = QtGui.QColor(color)
            self._time_text = now_text
            self.update()
            if self._world_time_popup.isVisible():
                for zone_name, label in self._world_time_labels:
                    label.setText(self._city_time_text(timestamp, zone_name))
        except RuntimeError:
            try:
                self._timer.stop()
                self._world_time_popup.hide()
            except Exception:
                pass

    def sizeHint(self) -> QtCore.QSize:
        m = self.contentsMargins()
        fm = self.fontMetrics()
        return QtCore.QSize(fm.horizontalAdvance("●  88:88:88.888") + m.left() + m.right() + 6,
                            fm.height() + m.top() + m.bottom() + 2)

    def minimumSizeHint(self) -> QtCore.QSize:
        return self.sizeHint()

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        """Точка состояния (цвет по подключению) и время — как прежний текст «●␣␣ЧЧ:ММ:СС.ммм»."""
        painter = QtGui.QPainter(self)
        opt = QtWidgets.QStyleOption()
        opt.initFrom(self)
        self.style().drawPrimitive(QtWidgets.QStyle.PrimitiveElement.PE_Widget, opt, painter, self)  # фон темы
        rect = self.contentsRect()
        fm = self.fontMetrics()
        dot = "●"
        painter.setFont(self.font())
        painter.setPen(self._dot_color)
        align = QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter
        painter.drawText(rect, align, dot)
        painter.setPen(self.palette().color(QtGui.QPalette.ColorRole.WindowText))
        painter.drawText(rect.adjusted(fm.horizontalAdvance(dot + "  "), 0, 0, 0), align, self._time_text)
        painter.end()

    def _fix_width(self) -> None:
        """Фиксирует минимальную ширину по самому широкому тексту: цифры разной ширины не двигают соседей."""
        try:
            sample = "●  88:88:88.888"
            width = self.fontMetrics().horizontalAdvance(sample) + self.contentsMargins().right() + 6
            self.setMinimumWidth(max(self.minimumWidth(), width))
        except Exception:
            pass

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        if not self._width_fixed:
            self._width_fixed = True
            self._fix_width()          # шрифт к этому моменту уже определён темой приложения
        super().showEvent(event)

    def enterEvent(self, event: QtCore.QEvent) -> None:
        """При наведении показываем текущее время шести мировых финансовых центров."""
        try:
            if self.is_valid(self):
                self._refresh()
                if self._world_time_popup.isVisible():
                    self._world_time_popup.hide()
                pos = self.mapToGlobal(QtCore.QPoint(0, self.height() + 5))
                screen = QtGui.QGuiApplication.screenAt(pos)
                if screen is not None:
                    available = screen.availableGeometry()
                    popup_size = self._world_time_popup.sizeHint()
                    x = min(max(pos.x(), available.left() + 6), available.right() - popup_size.width() - 6)
                    y = pos.y()
                    if y + popup_size.height() > available.bottom():
                        y = self.mapToGlobal(QtCore.QPoint(0, -popup_size.height() - 5)).y()
                    self._world_time_popup.move(x, y)
                else:
                    self._world_time_popup.move(pos)
                qss = _world_time_qss()                  # размер — под шрифт интерфейса на момент показа (2.1.83)
                if self._world_time_popup.styleSheet() != qss:
                    self._world_time_popup.setStyleSheet(qss)
                self._world_time_popup.adjustSize()
                self._world_time_popup.show()
                self._world_time_popup.raise_()
        except RuntimeError:
            pass
        super().enterEvent(event)

    def leaveEvent(self, event: QtCore.QEvent) -> None:
        try:
            if self.is_valid(self):
                self._world_time_popup.hide()
        except RuntimeError:
            pass
        super().leaveEvent(event)
