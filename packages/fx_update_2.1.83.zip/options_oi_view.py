# -*- coding: utf-8 -*-
"""Представление «Открытый интерес» для опционной цепочки FX Terminal.

Чистое представление без сети и без файлов: родитель (options_chain_chart_widget)
передаёт строки цепочки, историю итогов, опционные уровни (option_levels.Levels) и изменения OI;
виджет рисует карточки (в т.ч. Max Pain и ожидаемое движение), профиль по страйкам (OI или ΔOI
за час / с начала дня — переключатель над профилем), линии Max Pain и коридор ожидаемого движения,
таблицу и историю OI/PCR.

Зависимости: PySide6, pyqtgraph.
"""
from __future__ import annotations

import math
from typing import Any

import pyqtgraph as pg
from datetime import datetime

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QCursor
from PySide6.QtWidgets import (
    QComboBox, QHBoxLayout, QHeaderView, QLabel, QSplitter,
    QTableWidget, QTableWidgetItem, QToolTip, QVBoxLayout, QWidget,
)

from options_common import short_symbol
from options_theme import palette

# «Фьючерс» / «Спот» -> родительный падеж для подписи «OI фьючерса»
KIND_GENITIVE = {"Фьючерс": "ФЬЮЧЕРСА", "Спот": "СПОТА"}

PANEL = "#111620"     # фон графиков
CARD = "#111620"      # фон карточек
GRID = "#252d3a"
TEXT = "#d8dee9"
MUTED = "#8994a7"
CHART_TEXT = "#d8dee9"   # подписи на графиках: фон графиков тёмный и в светлой теме
CHART_MUTED = "#8994a7"
CALL_COLOR = "#35c98b"
PUT_COLOR = "#ed5b68"
PRICE_COLOR = "#ffbf4a"
HIGHLIGHT = "#f3d36b"
MAX_PAIN_COLOR = "#f3d36b"
EM_COLOR = "#b78cff"
GEX_COLOR = "#4fc3f7"         # как линия Gamma flip (option_levels.LEVEL_COLORS)
PROFILE_MODES = ("Открытый интерес", "Изменение OI за час", "Изменение OI с начала дня")
HISTORY_SYMBOLS_MAX = 60      # кружки на точках истории — только пока точек мало (на 1500 — сплошная «бусина»)


def compact_number(value: float) -> str:
    """Подпись шкалы OI: 1 250 000 → «1,25 млн», 640 000 → «640 тыс» (вместо «1.2e+06» pyqtgraph)."""
    a = abs(value)
    if a >= 1e6:
        text, unit = f"{value / 1e6:.2f}".rstrip("0").rstrip("."), " млн"
    elif a >= 1e3:
        text, unit = f"{value / 1e3:.1f}".rstrip("0").rstrip("."), " тыс"
    else:
        return f"{value:g}"
    return text.replace(".", ",") + unit


class CompactAxis(pg.AxisItem):
    """Шкала значений истории OI: «1,25 млн» / «640 тыс»; малые значения (PCR) — как обычно."""

    def tickStrings(self, values, scale, spacing):
        if values and max(abs(v) for v in values) >= 1e3:
            return [compact_number(v * scale) for v in values]
        return super().tickStrings(values, scale, spacing)


class PointTimeAxis(pg.AxisItem):
    """Ось времени истории OI по НОМЕРУ точки (сжатая): ночь и выходные, когда OI не меняется, не занимают места
    — как пропуск неторгового времени на свечном графике. Подпись — время ближайшей точки."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.times: list[float] = []

    def tickValues(self, minVal, maxVal, size):
        out = []
        for spacing, values in super().tickValues(minVal, maxVal, size):
            ints = [v for v in values if abs(v - round(v)) < 1e-6]
            if ints:
                out.append((max(1.0, spacing), ints))
        return out

    def tickStrings(self, values, scale, spacing):
        times = self.times
        if not times:
            return ["" for _ in values]
        multi_day = times[-1] - times[0] > 20 * 3600
        out = []
        for v in values:
            i = int(round(v))
            if 0 <= i < len(times):
                dt = datetime.fromtimestamp(times[i])
                out.append(f"{dt:%d.%m %H:%M}" if multi_day else f"{dt:%H:%M}")
            else:
                out.append("")
        return out


def apply_palette() -> bool:
    """Подхватывает палитру темы FX Terminal (если есть). True — окно оформляет QSS приложения."""
    global PANEL, CARD, GRID, TEXT, MUTED, CALL_COLOR, PUT_COLOR, PRICE_COLOR, HIGHLIGHT, CHART_TEXT, CHART_MUTED
    p = palette()
    PANEL, CARD, GRID = p["bg"], p["card"], p["grid"]
    TEXT, MUTED = p["text"], p["muted"]
    CHART_TEXT, CHART_MUTED = p.get("chart_text", TEXT), p.get("chart_muted", MUTED)
    CALL_COLOR, PUT_COLOR = p["call"], p["put"]
    PRICE_COLOR, HIGHLIGHT = p["price"], p["highlight"]
    return bool(p["themed"])


def to_float(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def fmt_num(value: Any, digits: int = 0) -> str:
    number = to_float(value)
    if number is None:
        return "—"
    return f"{number:,.{digits}f}".replace(",", " ")


def fmt_strike(value: Any) -> str:
    """85000.0 -> '85 000', 12.5 -> '12.5' (без хвоста нулей)."""
    number = to_float(value)
    if number is None:
        return "—"
    return f"{number:,.4f}".rstrip("0").rstrip(".").replace(",", " ")


def _signed(value: float | None) -> str:
    if not value:
        return "0" if value == 0 else ""
    return ("+" if value > 0 else "−") + fmt_num(abs(value))


def aggregate_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """rows: {'type': CALL|PUT, 'strike', 'symbol', 'oi' (None — неизвестно)}."""
    calls = [r for r in rows if r["type"] == "CALL" and r["oi"] is not None]
    puts = [r for r in rows if r["type"] == "PUT" and r["oi"] is not None]
    call_total = sum(r["oi"] for r in calls) if calls else None
    put_total = sum(r["oi"] for r in puts) if puts else None
    return {
        "call_total": call_total,
        "put_total": put_total,
        "pcr": put_total / call_total if put_total is not None and call_total else None,
        "max_call": max(calls, key=lambda r: r["oi"]) if calls else None,
        "max_put": max(puts, key=lambda r: r["oi"]) if puts else None,
        "with_oi": len(calls) + len(puts),
        "total": len(rows),
    }


def _ui_px(px: float) -> int:
    """Размер под общий шрифт интерфейса («Настройки» → «Размер шрифта», appearance.ui_px, 2.1.83)."""
    try:
        import appearance
        return appearance.ui_px(px)
    except Exception:                                # noqa: BLE001 — без настроек терминала: как задано
        return round(px)


def set_card_value(card: QWidget, color: str, px: float = 15) -> None:
    """Цвет и размер значения карточки (_card); запоминаются — restyle_cards пересчитает размер."""
    card.value_color, card.value_px = color, px
    card.title_label.setStyleSheet(f"color:{MUTED}; font-size:{_ui_px(10)}px; border:none;")
    card.value_label.setStyleSheet(f"color:{color}; font-size:{_ui_px(px)}px; font-weight:700; border:none;")


def restyle_cards(root: QWidget) -> None:
    """OK в «Настройках»: все карточки внутри root — под новый размер шрифта интерфейса."""
    for card in root.findChildren(QWidget):
        if hasattr(card, "value_color") and hasattr(card, "value_label"):
            set_card_value(card, card.value_color, card.value_px)


class OIProfileView(QWidget):
    modeChanged = Signal(int)          # 0 — OI, 1 — ΔOI за час, 2 — ΔOI с начала дня (родитель считает изменения)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._themed = apply_palette()
        try:                                             # карточки — вслед за шрифтом интерфейса (2.1.83)
            import appearance
            appearance.NOTIFIER.changed.connect(self._restyle_cards)
        except Exception:                                # noqa: BLE001
            pass
        # Пока пользователь не двигал график сам, профиль подгоняется под данные при каждом
        # обновлении (OI приходит постепенно, диапазон должен расти вместе с ним).
        # Как только он сделал зум/сдвиг мышью, его вид не трогаем до смены инструмента.
        self._user_zoomed = False
        self._history_reset = True
        self._sig: tuple | None = None
        self._agg: dict[str, Any] | None = None
        self._points: list[tuple] = []
        self._levels = None             # option_levels.Levels выбранной экспирации
        self._changes: dict[float, list[float]] | None = None   # {страйк: [ΔCall, ΔPut]}
        self._changes_caption = ""
        self._build_ui()
        self._hook_hover()

    # ---- UI --------------------------------------------------------------
    @staticmethod
    def _card(caption: str, color: str) -> QWidget:
        """Карточка «подпись / значение» (и у «Гаммы (GEX)»). Размеры (подпись 10, значение 15 px при шрифте
        темы) — под общий размер шрифта интерфейса: set_card_value / restyle_cards (2.1.83)."""
        card = QWidget()
        card.setStyleSheet(f"background:{CARD}; border:1px solid {GRID}; border-radius:6px;")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 7, 10, 7)
        title = QLabel(caption)
        value = QLabel("—")
        layout.addWidget(title)
        layout.addWidget(value)
        card.title_label = title
        card.value_label = value
        set_card_value(card, color)
        return card

    def _restyle_cards(self) -> None:
        restyle_cards(self)

    @staticmethod
    def _style_plot(plot: pg.PlotWidget) -> None:
        """Оформление графиков вкладок опционов («Открытый интерес», «Волатильность», «Гамма (GEX)»): тёмный фон,
        сетка; шкала значений — и слева, и справа (правая — та же ось того же графика, подпись — только слева)."""
        plot.setBackground(PANEL)
        plot.showGrid(x=True, y=True, alpha=0.22)
        plot.showAxis("right")
        plot.getAxis("right").setStyle(showValues=True)
        for side in ("left", "right", "bottom"):
            plot.getAxis(side).setTextPen(CHART_TEXT)
            plot.getAxis(side).setPen(CHART_MUTED)

    def _build_ui(self) -> None:
        qss = f"""
            QTableWidget {{
                background:{PANEL}; alternate-background-color:#151c28;
                gridline-color:{GRID}; selection-background-color:#26374b;
                border:1px solid {GRID};
            }}
            QHeaderView::section {{
                background:#1a2230; color:{TEXT}; border:1px solid {GRID};
                padding:5px; font-weight:600;
            }}
        """
        if not self._themed:           # в терминале таблицы оформляет тема приложения (fx_theme)
            self.setStyleSheet(qss)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 6, 0, 0)
        outer.setSpacing(8)

        self.coverage_label = QLabel("")
        self.coverage_label.setStyleSheet(f"color:{MUTED};")
        self.coverage_label.setWordWrap(True)
        outer.addWidget(self.coverage_label)

        cards = QHBoxLayout()
        self.price_card = self._card("ФЬЮЧЕРС", PRICE_COLOR)
        self.future_oi_card = self._card("OI ФЬЮЧЕРСА", PRICE_COLOR)
        self.call_card = self._card("CALL OI", CALL_COLOR)
        self.put_card = self._card("PUT OI", PUT_COLOR)
        self.pcr_card = self._card("PUT/CALL RATIO", TEXT)
        self.max_call_card = self._card("MAX CALL OI", CALL_COLOR)
        self.max_put_card = self._card("MAX PUT OI", PUT_COLOR)
        self.max_pain_card = self._card("MAX PAIN", MAX_PAIN_COLOR)
        self.max_pain_card.setToolTip("Цена экспирации, при которой покупатели опционов получают меньше всего:\n"
                                      "к экспирации цена часто тянется к ней")
        self.em_card = self._card("ОЖИДАЕМОЕ ДВИЖЕНИЕ", EM_COLOR)
        self.em_card.setToolTip("Сколько рынок закладывает до экспирации: цена ATM-стрэддла\n"
                                "(Call + Put на ближайшем к цене страйке); нет котировок — по IV")
        self.gex_card = self._card("GAMMA FLIP / GEX", GEX_COLOR)
        self.gex_card.setToolTip("Gamma flip — цена, где суммарная гамма-экспозиция опционов меняет знак:\n"
                                 "выше — хеджирование гасит движение, ниже — разгоняет.\n"
                                 "GEX — сколько фьючерсов хеджерам купить / продать при движении на 1% (сейчас);\n"
                                 "«+» — рынок «вязкий», «−» — трендовый.")
        self.cards = (
            self.price_card, self.future_oi_card, self.call_card, self.put_card,
            self.pcr_card, self.max_call_card, self.max_put_card, self.max_pain_card, self.em_card,
            self.gex_card,
        )
        for card in self.cards:
            cards.addWidget(card, 1)
        outer.addLayout(cards)

        vertical = QSplitter(Qt.Orientation.Vertical)
        upper = QSplitter(Qt.Orientation.Horizontal)

        profile_panel = QWidget()
        pl = QVBoxLayout(profile_panel)
        pl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Профиль:"))
        self.profile_mode = QComboBox()
        self.profile_mode.addItems(PROFILE_MODES)
        self.profile_mode.setToolTip("Изменение OI — куда заходят и откуда уходят деньги: вправо — прибыло, влево — убыло")
        self.profile_mode.currentIndexChanged.connect(self._on_profile_mode)
        mode_row.addWidget(self.profile_mode)
        mode_row.addStretch(1)
        pl.addLayout(mode_row)
        self.profile = pg.PlotWidget()
        pl.addWidget(self.profile, 1)
        self._style_plot(self.profile)
        self.profile.setTitle("Профиль OI по страйкам", color=CHART_TEXT, size="12pt")
        self.profile.setLabel("left", "Страйк")
        self.profile.setLabel("bottom", "Put OI  ←     →  Call OI")
        self.profile.getViewBox().setBorder(pg.mkPen(GRID))
        self.profile.getViewBox().sigRangeChangedManually.connect(self._on_profile_manual)
        upper.addWidget(profile_panel)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["Страйк", "Call OI", "Put OI", "Сумма OI", "Δ Call", "Δ Put", "Call тикер", "Put тикер"]
        )
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        header = self.table.horizontalHeader()
        # Ширина числовых колонок — по содержимому, но пересчитывается вручную (_render_table), только когда
        # поменялся набор строк: режим ResizeToContents мерил все ячейки на каждую правку ячейки, и таблица
        # заполнялась заметно позже профиля.
        for col in range(6):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
        for col in (6, 7):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self._table_strikes: list[float] = []
        self.table.setMinimumWidth(420)
        upper.addWidget(self.table)
        upper.setStretchFactor(0, 3)
        upper.setStretchFactor(1, 2)
        vertical.addWidget(upper)

        history_panel = QWidget()
        history_layout = QVBoxLayout(history_panel)
        history_layout.setContentsMargins(0, 0, 0, 0)
        controls = QHBoxLayout()
        controls.addWidget(QLabel("История OI и PCR"))
        controls.addStretch(1)
        self.history_mode = QComboBox()
        self.history_mode.addItems(["Суммарный OI (Call / Put)", "Put/Call Ratio"])
        self.history_mode.currentIndexChanged.connect(self._on_history_mode)
        controls.addWidget(self.history_mode)
        history_layout.addLayout(controls)
        # Ось времени — по номеру точки (PointTimeAxis): ночь и выходные не растягивают график; шкалы значений —
        # «1,25 млн» вместо «1.2e+06» (CompactAxis).
        self._time_axis = PointTimeAxis(orientation="bottom")
        self.history_plot = pg.PlotWidget(
            axisItems={"bottom": self._time_axis, "left": CompactAxis(orientation="left"),
                       "right": CompactAxis(orientation="right")},
        )
        self._style_plot(self.history_plot)
        self.history_plot.setLabel("bottom", "Время")
        history_layout.addWidget(self.history_plot)
        vertical.addWidget(history_panel)
        vertical.setStretchFactor(0, 4)
        vertical.setStretchFactor(1, 2)
        outer.addWidget(vertical, 1)

    # ---- API для родителя -------------------------------------------------
    def profile_mode_index(self) -> int:
        return self.profile_mode.currentIndex()

    def _on_profile_mode(self, index: int) -> None:
        self._user_zoomed = False
        self._sig = None
        self.modeChanged.emit(index)

    def set_levels(self, levels) -> None:
        """Опционные уровни экспирации (option_levels.Levels или None) — карточки и линии на профиле."""
        self._levels = levels
        mp = getattr(levels, "max_pain", None)
        self.max_pain_card.value_label.setText(fmt_strike(mp) if mp is not None else "—")
        em = getattr(levels, "em", None)
        if em:
            pct = f" ({em / levels.price * 100:.2f}%)" if levels.price else ""
            self.em_card.value_label.setText(f"±{fmt_strike(em)}{pct}")
            self.em_card.setToolTip(f"Способ: {levels.em_method}")
        else:
            self.em_card.value_label.setText("—")
        flip, gex = getattr(levels, "gamma_flip", None), getattr(levels, "gex", None)
        parts = [fmt_strike(flip) if flip is not None else "—"]
        if gex is not None:
            parts.append(f"{gex:+,.0f}".replace(",", " "))
        self.gex_card.value_label.setText(" / ".join(parts) if flip is not None or gex is not None else "—")
        self._sig = None

    def set_changes(self, changes: dict[float, list[float]] | None, caption: str = "") -> None:
        """Изменения OI по страйкам для режима «Изменение OI…» и колонок Δ таблицы."""
        self._changes = changes
        self._changes_caption = caption
        self._sig = None

    def _on_profile_manual(self, *_args) -> None:
        self._user_zoomed = True      # сигнал приходит только от мыши, не от setRange

    def reset_view(self) -> None:
        """Следующая отрисовка заново подберёт диапазон осей (смена инструмента/экспирации)."""
        self._user_zoomed = False
        self._history_reset = True
        self._sig = None

    def clear(self) -> None:
        self.profile.clear()
        self.history_plot.clear()
        self.table.setRowCount(0)
        self._table_strikes = []
        for card in self.cards:
            card.value_label.setText("—")
        self.coverage_label.setText("")
        self._sig = None
        self._agg = None
        self._points = []
        self._levels = None
        self._changes = None
        self._tip_strikes, self._tip_price = {}, None
        self.reset_view()

    def set_rows(self, rows: list[dict[str, Any]], price: float | None,
                 future_oi: float | None, title: str, force: bool = False,
                 kind: str = "Фьючерс") -> dict[str, Any] | None:
        """Рисует профиль по строкам выбранной экспирации. Без изменений данных не перерисовывает."""
        rows = [r for r in rows if r.get("strike") is not None and r.get("type") in ("CALL", "PUT")]
        sig = (tuple((r["symbol"], r["oi"]) for r in rows), price, future_oi, title, kind)
        if sig == self._sig and not force:
            return self._agg
        self._sig = sig
        agg = aggregate_rows(rows)
        self._agg = agg

        max_call, max_put = agg["max_call"], agg["max_put"]
        self.price_card.title_label.setText(kind.upper())
        self.future_oi_card.title_label.setText(f"OI {KIND_GENITIVE.get(kind, kind.upper())}")
        self.price_card.value_label.setText(fmt_strike(price) if price is not None else "—")
        self.future_oi_card.value_label.setText(fmt_num(future_oi))
        self.call_card.value_label.setText(fmt_num(agg["call_total"]))
        self.put_card.value_label.setText(fmt_num(agg["put_total"]))
        self.pcr_card.value_label.setText(fmt_num(agg["pcr"], 3))
        self.max_call_card.value_label.setText(
            f'{fmt_strike(max_call["strike"])} / {fmt_num(max_call["oi"])}' if max_call else "—")
        self.max_put_card.value_label.setText(
            f'{fmt_strike(max_put["strike"])} / {fmt_num(max_put["oi"])}' if max_put else "—")

        text = f"OI получен по {agg['with_oi']} из {agg['total']} опционов"
        if agg["total"] and not agg["with_oi"]:
            text += " — пока данных нет: котировки ещё не пришли или Finam не передаёт open_interest по опционам"
        self.coverage_label.setText(text)

        self._render_profile(rows, price, max_call, max_put, title, kind)
        self._render_table(rows)
        return agg

    def set_history(self, points: list[tuple]) -> None:
        """points: (unix_ts, call_oi, put_oi, pcr) по возрастанию времени. Для графика — без одиночных провалов
        (недогруженная цепочка) и повторов одного значения (option_levels.clean_oi_history)."""
        try:
            import option_levels
            points = option_levels.clean_oi_history(list(points))
        except Exception:
            points = list(points)
        self._points = points
        self._render_history()

    # ---- отрисовка ---------------------------------------------------------
    @staticmethod
    def _by_strike(rows: list[dict[str, Any]]) -> dict[float, dict[str, Any]]:
        grouped: dict[float, dict[str, Any]] = {}
        for row in rows:
            group = grouped.setdefault(row["strike"], {"CALL": None, "PUT": None})
            old = group[row["type"]]
            if old is None or (row["oi"] is not None and (old["oi"] is None or row["oi"] > old["oi"])):
                group[row["type"]] = row
        return grouped

    def _render_levels(self, plot, price) -> None:
        """Линия Max Pain и коридор ожидаемого движения поверх профиля."""
        levels = self._levels
        if levels is None:
            return
        if levels.max_pain is not None:
            plot.addItem(pg.InfiniteLine(pos=levels.max_pain, angle=0, pen=pg.mkPen(
                MAX_PAIN_COLOR, width=1.5, style=Qt.PenStyle.DotLine),
                label=f"Max Pain {fmt_strike(levels.max_pain)}",
                labelOpts={"position": 0.92, "color": MAX_PAIN_COLOR, "movable": False}))
        if levels.em and price is not None:
            region = pg.LinearRegionItem(values=(price - levels.em, price + levels.em), orientation="horizontal",
                                         brush=pg.mkBrush(183, 140, 255, 28), pen=pg.mkPen(EM_COLOR, width=1),
                                         movable=False)
            region.setZValue(-10)
            plot.addItem(region)

    def _render_changes(self, plot, strikes, bar_height) -> None:
        """Режим «Изменение OI»: вправо — прибыло, влево — убыло; Call — верхняя половина полосы, Put — нижняя."""
        ch = self._changes or {}
        half = bar_height / 2
        for kind, idx, color, dy in (("CALL", 0, CALL_COLOR, half / 2), ("PUT", 1, PUT_COLOR, -half / 2)):
            ys = [k + dy for k in strikes]
            vals = [ch.get(k, [0.0, 0.0])[idx] for k in strikes]
            plot.addItem(pg.BarGraphItem(x0=[min(v, 0.0) for v in vals], y=ys, width=[abs(v) for v in vals],
                                         height=half * 0.9, brush=pg.mkBrush(color), pen=pg.mkPen(color, width=0.5)))
        plot.addItem(pg.InfiniteLine(pos=0, angle=90, pen=pg.mkPen("#6f7a8c", width=1, style=Qt.PenStyle.DashLine)))
        if not any(v for pair in ch.values() for v in pair):
            # Пустой профиль без объяснения выглядел как поломка (31.10, суббота: по опционам не было сделок)
            text = ("Нет истории OI за этот период" if not ch
                    else f"OI {self._changes_caption or ''} не менялся — по опционам не было сделок")
            note = pg.TextItem(text, color=MUTED, anchor=(0.5, 0.5))
            note.setPos(0, (min(strikes) + max(strikes)) / 2)
            plot.addItem(note)

    def _render_profile(self, rows, price, max_call, max_put, title, kind="Фьючерс") -> None:
        plot = self.profile
        plot.clear()
        by_strike = self._by_strike(rows)
        self._tip_strikes, self._tip_price = by_strike, price     # для подсказки при наведении
        strikes = sorted(by_strike)
        if not strikes:
            return
        differences = [b - a for a, b in zip(strikes, strikes[1:]) if b > a]
        bar_height = min(differences) * 0.72 if differences else 0.08
        if self.profile_mode.currentIndex() > 0:
            self._render_changes(plot, strikes, bar_height)
            self._render_levels(plot, price)
            if price is not None:
                plot.addItem(pg.InfiniteLine(pos=price, angle=0, pen=pg.mkPen(
                    PRICE_COLOR, width=2, style=Qt.PenStyle.DashLine)))
            plot.setLabel("left", "Страйк")
            plot.setLabel("bottom", "←  убыло     прибыло  →   (Call — выше, Put — ниже)")
            caption = self._changes_caption or "нет истории OI"
            plot.setTitle(f"Изменение OI {caption} — {title}", color=CHART_TEXT, size="12pt")
            if not self._user_zoomed:
                values = [abs(v) for pair in (self._changes or {}).values() for v in pair] + [1.0]
                top = max(values)
                plot.setXRange(-top * 1.12, top * 1.12, padding=0)
                plot.setYRange(min(strikes) - bar_height, max(strikes) + bar_height, padding=0)
            return

        call_x, put_x0, put_width, ys = [], [], [], []
        for strike in strikes:
            call = by_strike[strike]["CALL"]
            put = by_strike[strike]["PUT"]
            call_oi = call["oi"] if call and call["oi"] is not None else 0.0
            put_oi = put["oi"] if put and put["oi"] is not None else 0.0
            call_x.append(call_oi)
            put_x0.append(-put_oi)
            put_width.append(put_oi)
            ys.append(strike)

        plot.addItem(pg.BarGraphItem(
            x0=put_x0, y=ys, width=put_width, height=bar_height,
            brush=pg.mkBrush(PUT_COLOR), pen=pg.mkPen(PUT_COLOR, width=0.5)))
        plot.addItem(pg.BarGraphItem(
            x0=[0.0] * len(call_x), y=ys, width=call_x, height=bar_height,
            brush=pg.mkBrush(CALL_COLOR), pen=pg.mkPen(CALL_COLOR, width=0.5)))
        plot.addItem(pg.InfiniteLine(
            pos=0, angle=90, pen=pg.mkPen("#6f7a8c", width=1, style=Qt.PenStyle.DashLine)))
        if max_call:
            plot.plot([max_call["oi"]], [max_call["strike"]], pen=None, symbol="s", symbolSize=10,
                      symbolBrush=HIGHLIGHT, symbolPen=pg.mkPen(HIGHLIGHT))
        if max_put:
            plot.plot([-max_put["oi"]], [max_put["strike"]], pen=None, symbol="s", symbolSize=10,
                      symbolBrush=HIGHLIGHT, symbolPen=pg.mkPen(HIGHLIGHT))
        if price is not None:
            plot.addItem(pg.InfiniteLine(
                pos=price, angle=0, pen=pg.mkPen(PRICE_COLOR, width=2, style=Qt.PenStyle.DashLine)))
            label = pg.TextItem(f"{kind} {fmt_strike(price)}", color=PRICE_COLOR, anchor=(0, 1))
            label.setPos(0, price)
            plot.addItem(label)
        self._render_levels(plot, price)

        plot.setLabel("left", "Страйк")
        plot.setLabel("bottom", "Put OI  ←     →  Call OI")
        plot.setTitle(f"Профиль открытого интереса — {title}", color=CHART_TEXT, size="12pt")
        if not self._user_zoomed:
            max_oi = max([abs(x) for x in call_x + put_x0] + [1.0])
            plot.setXRange(-max_oi * 1.12, max_oi * 1.12, padding=0)
            plot.setYRange(min(strikes) - bar_height, max(strikes) + bar_height, padding=0)

    def _render_table(self, rows) -> None:
        """Таблица по страйкам. Ячейки не пересоздаются: меняется только текст, который изменился, а
        перерисовка — одна на всю таблицу (раньше 8 новых ячеек на страйк при каждом обновлении)."""
        grouped = self._by_strike(rows)
        strikes = sorted(grouped)
        reshaped = strikes != self._table_strikes
        self._table_strikes = strikes
        self.table.setUpdatesEnabled(False)
        try:
            if self.table.rowCount() != len(strikes):
                self.table.setRowCount(len(strikes))
            self._fill_table(grouped, strikes)
            if reshaped:
                for col in range(6):
                    self.table.resizeColumnToContents(col)
        finally:
            self.table.setUpdatesEnabled(True)

    def _fill_table(self, grouped, strikes) -> None:
        colors = {1: CALL_COLOR, 4: CALL_COLOR, 2: PUT_COLOR, 5: PUT_COLOR, 0: PRICE_COLOR}
        for index, strike in enumerate(strikes):
            call = grouped[strike]["CALL"]
            put = grouped[strike]["PUT"]
            call_oi = call["oi"] if call else None
            put_oi = put["oi"] if put else None
            total = ((call_oi or 0.0) + (put_oi or 0.0)
                     if call_oi is not None or put_oi is not None else None)
            change = (self._changes or {}).get(strike)
            values = [
                fmt_strike(strike), fmt_num(call_oi), fmt_num(put_oi), fmt_num(total),
                _signed(change[0]) if change else "", _signed(change[1]) if change else "",
                short_symbol(call["symbol"]) if call else "—",
                short_symbol(put["symbol"]) if put else "—",
            ]
            for col, value in enumerate(values):
                cell = self.table.item(index, col)
                if cell is None:
                    cell = QTableWidgetItem(value)
                    cell.setFlags(cell.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    if col in colors:
                        cell.setForeground(QColor(colors[col]))
                    self.table.setItem(index, col, cell)
                elif cell.text() != value:
                    cell.setText(value)

    def _on_history_mode(self, *_args) -> None:
        self._history_reset = True
        self._render_history()

    def _render_history(self) -> None:
        self.history_plot.clear()
        points = self._points
        if not points:
            self.history_plot.setTitle("История появится, когда накопятся данные OI", color=CHART_MUTED)
            return
        nan = math.nan
        x = list(range(len(points)))                 # по номеру точки — ось сжатая (PointTimeAxis)
        self._time_axis.times = [p[0] for p in points]
        self.history_plot.setTitle(f"История OI / PCR — {len(points)} точек", color=CHART_TEXT, size="11pt")
        dots = len(points) <= HISTORY_SYMBOLS_MAX
        if self.history_mode.currentIndex() == 0:
            call = [p[1] if p[1] is not None else nan for p in points]
            put = [p[2] if p[2] is not None else nan for p in points]
            for values, color, name in ((call, CALL_COLOR, "Call OI"), (put, PUT_COLOR, "Put OI")):
                extra = {"symbol": "o", "symbolSize": 5, "symbolBrush": color} if dots else {}
                self.history_plot.plot(x, values, pen=pg.mkPen(color, width=2), name=name, connect="finite", **extra)
            self.history_plot.setLabel("left", "Открытый интерес")
        else:
            pcr = [p[3] if p[3] is not None else nan for p in points]
            extra = {"symbol": "o", "symbolSize": 6, "symbolBrush": PRICE_COLOR} if dots else {}
            self.history_plot.plot(x, pcr, pen=pg.mkPen(PRICE_COLOR, width=2), name="Put/Call Ratio",
                                   connect="finite", **extra)
            self.history_plot.setLabel("left", "PCR")
        if self._history_reset:
            if len(x) == 1:
                self.history_plot.setXRange(-1, 1, padding=0)
            else:
                self.history_plot.enableAutoRange()
            self._history_reset = False


    # ---- подсказки при наведении ---------------------------------------------------------

    def _hook_hover(self) -> None:
        """Профиль: мышь над строкой страйка — Call / Put OI, сумма, изменение, тикеры, расстояние до цены;
        история — время точки и значения. Линия-курсор показывает, к чему относится подсказка."""
        self._tip_strikes, self._tip_price = {}, None
        self._hover_lines = {}
        for plot, angle, handler in ((self.profile, 0, self._profile_tip), (self.history_plot, 90, self._history_tip)):
            line = pg.InfiniteLine(angle=angle, movable=False,
                                   pen=pg.mkPen(CHART_MUTED, width=1, style=Qt.PenStyle.DotLine))
            line.setZValue(50)
            self._hover_lines[plot] = line
            plot.scene().sigMouseMoved.connect(lambda pos, p=plot, h=handler: self._on_hover(p, h, pos))

    def _on_hover(self, plot, handler, pos) -> None:
        vb = plot.getPlotItem().vb
        line = self._hover_lines[plot]
        if line.scene() is None:                 # график перерисовывается через clear() — линию возвращаем
            plot.addItem(line, ignoreBounds=True)
        point = vb.mapSceneToView(pos)
        result = handler(point) if vb.sceneBoundingRect().contains(pos) else None
        if result is None:
            if line.isVisible():
                line.hide()
                QToolTip.hideText()
            return
        at, text = result
        line.setPos(at)
        line.show()
        QToolTip.showText(QCursor.pos(), text, plot)

    def _profile_tip(self, point):
        strikes = sorted(self._tip_strikes)
        if not strikes:
            return None
        strike = min(strikes, key=lambda k: abs(k - point.y()))
        call, put = self._tip_strikes[strike]["CALL"], self._tip_strikes[strike]["PUT"]
        call_oi = call["oi"] if call else None
        put_oi = put["oi"] if put else None
        lines = [f"<b>Страйк {fmt_strike(strike)}</b>"]
        price = self._tip_price
        if price:
            diff = strike - price
            lines.append(f"<span style='color:{MUTED}'>от цены {fmt_strike(price)}: {diff:+g} "
                         f"({diff / price * 100:+.2f}%)</span>")
        change = (self._changes or {}).get(strike)

        def row(name, color, oi, delta, rec, itm):
            text = f"<span style='color:{color}'>{name} OI {fmt_num(oi)}</span>"
            if delta:
                text += f" ({_signed(delta)} {self._changes_caption})"
            if rec:
                text += f" <span style='color:{MUTED}'>{short_symbol(rec['symbol'])}</span>"
            if itm:
                text += f" <span style='color:{MUTED}'>— в деньгах</span>"
            return text

        lines.append(row("Call", CALL_COLOR, call_oi, change[0] if change else None, call, bool(price and strike < price)))
        lines.append(row("Put", PUT_COLOR, put_oi, change[1] if change else None, put, bool(price and strike > price)))
        if call_oi is not None or put_oi is not None:
            total = (call_oi or 0.0) + (put_oi or 0.0)
            ratio = f", Put/Call {put_oi / call_oi:.2f}" if call_oi and put_oi is not None else ""
            lines.append(f"сумма {fmt_num(total)}{ratio}")
        levels = self._levels
        if levels is not None:
            for key, value in (("Max Pain", getattr(levels, "max_pain", None)),
                               ("Call wall", getattr(levels, "call_wall", None)),
                               ("Put wall", getattr(levels, "put_wall", None))):
                if value is not None and abs(value - strike) < 1e-9:
                    lines.append(f"<b style='color:{HIGHLIGHT}'>{key}</b>")
        return strike, "<br>".join(lines)

    def _history_tip(self, point):
        points = self._points
        if not points:
            return None
        i = max(0, min(len(points) - 1, int(round(point.x()))))   # ось — по номеру точки
        p = points[i]
        text = [f"<b>{datetime.fromtimestamp(p[0]):%d.%m %H:%M}</b>"]
        if p[1] is not None:
            text.append(f"<span style='color:{CALL_COLOR}'>Call OI {fmt_num(p[1])}</span>")
        if p[2] is not None:
            text.append(f"<span style='color:{PUT_COLOR}'>Put OI {fmt_num(p[2])}</span>")
        if p[3] is not None:
            text.append(f"<span style='color:{PRICE_COLOR}'>PCR {p[3]:.3f}</span>")
        return i, "<br>".join(text)
