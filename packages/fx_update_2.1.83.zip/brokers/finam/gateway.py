# -*- coding: utf-8 -*-
"""FinamGateway — единственное место терминала, которое знает про Finam Trade API.

Реализует core.interfaces.MarketDataGateway: справочник, свечи, время сервера и потоки
котировок, стакана и сделок. На выходе — только модели core.models; формат символов
Finam, protobuf и Decimal-обёртки дальше шлюза не уходят.

Откуда код (шаг 3 плана — перенесено из прежних модулей окон, а не написано заново):
    * подключение и параметры канала — прежние GrpcSession / GRPC_CHANNEL_OPTIONS стакана;
    * цикл потока с переподключением — прежний StreamRunner стакана, пауза — как в
      «Алгоритмах» (1, 5, 10, 20, 40, 60 с + до 20 % случайной добавки);
    * разбор стакана и сделок — прежние parse_book / parse_trade / StreamEngine стакана;
    * отсев повторов сделок по trade_id — окно 20 000 id на инструмент, как было в стакане;
    * справочник, свечи, часы — finam_sdk_client.py.

Торговля — рядом, в brokers/finam/live.py (FinamLiveEngine: LIVE-заявки, перенесённые из
стакана); PAPER — brokers/paper. LIVE-движок окон стакана работает через client() этого шлюза
(scalper_widget.SharedTradingSession): одно соединение на данные и заявки, RetryPolicy
с одной попыткой — PlaceOrder не повторяется автоматически.

Потоки: каждый start_* поднимает свой фоновый поток (threading, без Qt); данные уходят в
sink из этого потока. Один и тот же start_* повторно — ничего не делает.
start_quotes_many — котировки многих инструментов (цепочка опционов, ~200 символов): один
поток SubscribeQuote на группу до QUOTE_BATCH символов, группы открываются с паузой.
Группа не пересобирается: отписанный символ просто перестаёт доходить до sink, а поток
группы закрывается, когда отписаны все её символы.

Стакан через Rust (этап 2 Rust-шлюза, с 30.10): поток SubscribeOrderBook открывается «сырым» — сообщения
приходят байтами (brokers/finam/raw_book.py) и разбираются fx_engine.BookEngine, без объектов protobuf
в Python. Режим book_mode (FX_BOOK_ENGINE / «Настройки» → «Разбор стакана»): auto — Rust, а при сбое
(сырой вызов не построился, поток закрылся без сообщений, Rust не разобрал сообщение) инструмент сам
переходит на SDK и через RAW_RETRY_SEC снова пробует Rust; sdk — как раньше. Замирание потока при идущих
сделках сбоем Rust-пути не считается: проба 30.10 показала, что это задержка на стороне Finam (замерший
поток оживал сам через 51–60 с и присылал накопленное пачкой, одновременно с отставанием ленты сделок).
"""
from __future__ import annotations

import os
import random
import sys
import threading
import time
from collections import deque
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Callable

from core.interfaces import MarketDataSink
from core.models import (
    BookLevel,
    Candle,
    ConnectionState,
    Instrument,
    InstrumentId,
    InstrumentKind,
    OrderBook,
    Quote,
    Side,
    Timeframe,
    Trade,
)
from services.perf import PERF

GRPC_ENDPOINT = os.getenv("FINAM_GRPC_ENDPOINT", "api.finam.ru:443")
# Keepalive как в стакане: сервер отвечает GOAWAY «too_many_pings», если пинговать чаще раза в 5 минут.
GRPC_KEEPALIVE_MS = max(10000, int(os.getenv("FINAM_GRPC_KEEPALIVE_MS", "300000")))
GRPC_CHANNEL_OPTIONS = [
    ("grpc.keepalive_time_ms", GRPC_KEEPALIVE_MS),
    ("grpc.keepalive_timeout_ms", 10000),
    ("grpc.keepalive_permit_without_calls", 0),
    ("grpc.http2.max_pings_without_data", 2),
    ("grpc.max_receive_message_length", 32 * 1024 * 1024),
]

# Отдельные соединения для потоков (опыт 2.0.82): стаканы, сделки и котировки — каждые по своему gRPC-соединению,
# заявки и справочник — по основному. 03.11 половина замираний Finam шла пачками: 4–9 инструментов разом, валюта
# и фьючерсы вперемешку (13:38:57 — BRZ6, CCX6, CNYRUBF, CRZ6, GDZ6, USDRUBF, VKCO). Все ~50 потоков шли одним
# HTTP/2-соединением; если пачки теперь распадутся по видам потоков — замирало соединение, если нет — сам Finam.
# С 2.0.89 по умолчанию выключено (FX_STREAM_CHANNELS=1 — включить): по опыту другого клиента API (чат Finam,
# 03.11) задерживает отдельная подписка на сервере — из двух независимых подключений одно отстаёт на ~130 с, другое
# получает те же сделки вовремя, — так что разделение по видам потоков не помогает, а даёт три лишних входа.
# Своё соединение даёт grpc.use_local_subchannel_pool: иначе gRPC сам объединяет одинаковые каналы в одно TCP.
STREAM_CHANNEL_KINDS = ("book", "trades", "quotes")
SPLIT_STREAM_CHANNELS = os.getenv("FX_STREAM_CHANNELS", "0") == "1"

RETRY_DELAYS_SEC = (1, 5, 10, 20, 40, 60)   # пауза перед n-й попыткой; дальше — последняя
BOOK_DEPTH = 0                               # уровней в снимке на сторону; 0 — весь стакан, как прислал
                                             # Finam (окну «Стакан» нужна вся глубина, а не 50 уровней)
TRADE_ID_MEMORY = 20000                      # сколько последних trade_id помнить на инструмент
QUOTE_BATCH = 10                             # символов в одном SubscribeQuote у start_quotes_many
QUOTE_BATCH_STAGGER_SEC = 0.25               # пауза между открытиями групп: залп параллельных
                                             # вызовов на только что созданном канале ронял python.exe

_SIDE_BUY, _SIDE_SELL = 1, 2                 # enum стороны сделки в protobuf Finam

KIND_BY_TYPE = {                             # поле type каталога Finam -> вид инструмента
    "FUTURES": InstrumentKind.FUTURE,
    "CURRENCIES": InstrumentKind.SPOT,
    "EQUITIES": InstrumentKind.SPOT,
    "BONDS": InstrumentKind.SPOT,
    "FUNDS": InstrumentKind.SPOT,
    "INDICES": InstrumentKind.INDEX,
    "OPTIONS": InstrumentKind.OPTION,
}

# Сколько рублей даёт 1,0 цены на 1 лот, если брокер отдаёт лот «1 контракт».
# Квартальные Si / Eu котируются в рублях за контракт (1000 USD/EUR) -> 1; CR (юань) — в рублях
# за 1 юань при контракте в 1000 юаней -> 1000. Для остальных множитель = размер лота
# (CNYRUB_TOM, USDRUBF: лот 1000 единиц). Проверка на живых данных — brokers/finam/check.py.
FUTURES_MULTIPLIER_BY_BASE = {"SI": Decimal(1), "EU": Decimal(1), "CR": Decimal(1000)}
# Вечные валютные фьючерсы: цена — рубли за 1 единицу валюты, контракт — 1000 единиц.
PERPETUAL_MULTIPLIER = {"USDRUBF": Decimal(1000), "EURRUBF": Decimal(1000), "CNYRUBF": Decimal(1000)}
# Валюта на споте Мосбиржи торгуется лотами по 1000 единиц, а GetAsset отдаёт lot_size = 1
# (проверено 20.10.2026: CNYRUB_TOM — лот 1; сверка с QUIK: 52 лота × 12,846 = 667 992 ₽).
CURRENCY_SPOT_LOT = Decimal(1000)


# ============================================================================ помощники

def to_symbol(iid: InstrumentId) -> str:
    """InstrumentId -> символ Finam ("USDRUBF@RTSX"). Единственное место этого знания."""
    return f"{iid.ticker}@{iid.board}" if iid.board else iid.ticker


def from_symbol(symbol: str) -> InstrumentId:
    ticker, _, board = str(symbol or "").partition("@")
    return InstrumentId(ticker, board)


def dec(value) -> float:
    """google.type.Decimal / {"value": "1.5"} / число -> float (пусто -> 0.0)."""
    if value is None:
        return 0.0
    if isinstance(value, dict):
        value = value.get("value")
    else:
        value = getattr(value, "value", value)
    try:
        return float(value) if value not in ("", None) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _dec_or_none(msg, name: str) -> float | None:
    """Поле-Decimal сообщения protobuf, если оно пришло (в инкрементах котировок часть полей пустые)."""
    try:
        if not msg.HasField(name):
            return None
    except ValueError:            # такого поля в этой версии SDK нет
        return None
    except AttributeError:        # не protobuf (тестовые объекты) — смотрим атрибут
        if getattr(msg, name, None) is None:
            return None
    raw = getattr(getattr(msg, name), "value", None)
    if raw in (None, ""):
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def _ts(stamp) -> float:
    """google.protobuf.Timestamp -> epoch-секунды (нет времени -> 0.0)."""
    seconds = getattr(stamp, "seconds", 0) or 0
    return seconds + (getattr(stamp, "nanos", 0) or 0) / 1e9 if seconds else 0.0


def short_error(exc) -> str:
    """Одна строка вместо многострочного repr gRPC: «UNAVAILABLE: Socket closed»."""
    code = getattr(exc, "code", None)
    details = getattr(exc, "details", None)
    try:
        if callable(code) and callable(details):
            name = getattr(code(), "name", str(code()))
            return f"{name}: {details() or ''}".strip().rstrip(":")
    except Exception:
        pass
    lines = str(exc).strip().splitlines()
    return f"{type(exc).__name__}: {lines[0] if lines else ''}".strip().rstrip(":")


# Сторож ленты сделок (29.10: Finam прислал сделки Si и CNYRUB_TOM на ~129 с позже биржи, при этом в очереди
# терминала они не стояли, а стакан шёл вживую). Если живая сделка пришла позже биржи больше чем на
# STALE_TRADES_SEC сверх обычной задержки (базы), поток сделок инструмента переоткрывается: новая
# подписка может сразу получить свежие сделки. Повторы при этом отсеиваются по trade_id (TradeIdMemory).
STALE_TRADES_SEC = 20.0          # насколько позже обычного должна прийти сделка, чтобы переподписаться
STALE_GRACE_SEC = 15.0           # после открытия потока не судим: в начале Finam присылает историю
STALE_RESTART_EVERY_SEC = 120.0  # не чаще раза в столько по одному инструменту
# Сторож молчащей ленты (03.11: лента отставала на 121–131 с — 28 раз за полтора часа по разным инструментам;
# сторож выше срабатывает, только когда опоздавшая сделка всё-таки пришла, то есть через те же ~2 минуты,
# и всё это время роботы, айсберги, «Тики» инструмента слепы). Объём дня в котировках растёт — значит, сделки на
# бирже идут; если при этом из потока сделок ничего не пришло дольше TRADES_SILENT_SEC, а объём за это время
# вырос не меньше TRADES_SILENT_UPDATES раз, поток сделок замер у Finam — переоткрываем сразу.
TRADES_SILENT_SEC = 15.0
TRADES_SILENT_UPDATES = 5
TRADES_SILENT_RESTART_EVERY_SEC = 60.0
LAG_BASE_WINDOW_SEC = 600.0      # база = наименьшая задержка за 10 минут (поправка на часы ПК и сеть)
# Сторож стакана (29.10, видео: стаканы USDRUBF, EURRUBF, CNYRUBF, Si-3.27, Si-12.26 стояли неподвижно десятки
# секунд, а сделки по ним шли — поток стакана у Finam замолчал без ошибки, соединение формально живо).
# Сделка меняет стакан, значит Finam должен прислать его обновление. Если стакан инструмента молчит дольше
# BOOK_STALE_SEC, а сделок, совершённых на бирже ПОСЛЕ его последнего сообщения, набралось BOOK_STALE_TRADES,
# поток стакана переоткрывается (новый поток начинается со снимка — стакан собирается заново).
# Стакан через Rust (этап 2, brokers/finam/raw_book.py): режим — FX_BOOK_ENGINE или «Настройки»
# (FinamGateway.book_mode): auto — Rust, а при сбое сам переходит на SDK; sdk — всегда как раньше;
# rust — только Rust (для проверки: при сбое стакан не переключается, а переподключается).
BOOK_MODES = ("auto", "sdk", "rust")
RAW_STRIKES = 2                  # сбоев быстрого пути подряд по инструменту — переход на SDK
RAW_RETRY_SEC = 600.0            # через столько снова попробовать Rust после перехода на SDK
BOOK_STALE_SEC = 15.0
BOOK_STALE_TRADES = 5
# Новый поток стакана так и не прислал первый снимок (03.11: стакан CNY000000TOD в PAPER появился не сразу).
# Раньше сторож судил только по «молчит после последнего сообщения» — у потока без единого сообщения последнего
# не было, и пустой стакан ждал, пока Finam проснётся. Теперь: снимка нет BOOK_FIRST_SEC с открытия, а сделок
# за это время BOOK_STALE_TRADES — переоткрываем (без паузы STALE_GRACE_SEC: терять нечего, стакана нет совсем).
BOOK_FIRST_SEC = 5.0
BOOK_RESTART_EVERY_SEC = 60.0
# Диагностика замираний (30.10): замерший поток стакана не отменяется сразу — новый поток открывается рядом,
# а прежний ещё BOOK_PROBE_SEC слушается «пробой» (сообщения не применяются): ожил ли он сам, через сколько
# и сколько сообщений прислал разом. Так видно, где замирание: поток у Finam встал и потом догоняет
# (задержка у них) или умер совсем (подписка потеряна на сервере).
BOOK_PROBE_SEC = 120.0
LAG_BASE_MAX_SEC = 5.0           # база не больше: долгое отставание не должно становиться «обычным»


class LagBase:
    """Наименьшая задержка «сейчас − время сделки» за последние LAG_BASE_WINDOW_SEC — обычная задержка
    ленты с учётом сдвига часов ПК относительно биржи (часы ПК могут спешить или отставать на секунды)."""

    def __init__(self, window: float = LAG_BASE_WINDOW_SEC):
        self.window = window
        self._mins: deque = deque()            # (минута, наименьшая задержка за неё)

    def add(self, lag: float, now: float) -> None:
        minute = int(now // 60)
        if self._mins and self._mins[-1][0] == minute:
            if lag < self._mins[-1][1]:
                self._mins[-1] = (minute, lag)
        else:
            self._mins.append((minute, lag))
        while self._mins and self._mins[0][0] < minute - self.window / 60:
            self._mins.popleft()

    def value(self) -> float:
        return min(min((m for _k, m in self._mins), default=0.0), LAG_BASE_MAX_SEC)


def retry_delay(attempt: int) -> float:
    base = RETRY_DELAYS_SEC[min(max(attempt, 1), len(RETRY_DELAYS_SEC)) - 1]
    return base * (1.0 + random.uniform(0.0, 0.2))


# ============================================================================ разбор сообщений

def parse_quotes(msg) -> list[Quote]:
    """SubscribeQuoteResponse -> [Quote]. Поля, которых нет в сообщении, — None."""
    out: list[Quote] = []
    now = time.time()
    for q in getattr(msg, "quote", ()) or ():
        iid = from_symbol(getattr(q, "symbol", ""))
        if not iid.ticker:
            continue
        option = getattr(q, "option", None)
        try:
            has_option = option is not None and q.HasField("option")
        except (ValueError, AttributeError):
            has_option = option is not None
        out.append(Quote(
            instrument=iid,
            ts=_ts(getattr(q, "timestamp", None)) or now,
            last=_dec_or_none(q, "last"),
            bid=_dec_or_none(q, "bid"),
            ask=_dec_or_none(q, "ask"),
            bid_size=_dec_or_none(q, "bid_size"),
            ask_size=_dec_or_none(q, "ask_size"),
            open=_dec_or_none(q, "open"),
            high=_dec_or_none(q, "high"),
            low=_dec_or_none(q, "low"),
            close=_dec_or_none(q, "close"),
            volume=_dec_or_none(q, "volume"),
            turnover=_dec_or_none(q, "turnover"),
            open_interest=(_dec_or_none(q, "open_interest")
                           or (_dec_or_none(option, "open_interest") if has_option else None)),
            theoretical=_dec_or_none(option, "theoretical_price") if has_option else None,
            iv=_dec_or_none(option, "implied_volatility") if has_option else None,
        ))
    return out


class BookState:
    """Локальный стакан одного инструмента: Finam шлёт изменения строк (ADD/UPDATE/REMOVE),
    шлюз применяет их и отдаёт наружу полный снимок OrderBook."""

    def __init__(self, iid: InstrumentId):
        self.iid = iid
        self.bids: dict[float, float] = {}
        self.asks: dict[float, float] = {}

    def apply(self, msg, remove_action) -> bool:
        """Применить SubscribeOrderBookResponse. True — стакан изменился."""
        changed = False
        for ob in getattr(msg, "order_book", ()) or ():
            if getattr(ob, "is_data_snapshot", False):
                self.bids.clear()
                self.asks.clear()
                changed = True
            for row in getattr(ob, "rows", ()) or ():
                price = round(dec(row.price), 10)
                if row.action == remove_action:
                    changed |= self.bids.pop(price, None) is not None
                    changed |= self.asks.pop(price, None) is not None
                    continue
                which = row.WhichOneof("side")
                if which == "buy_size":
                    size = dec(row.buy_size)
                    self.asks.pop(price, None)
                    self._set(self.bids, price, size)
                    changed = True
                elif which == "sell_size":
                    size = dec(row.sell_size)
                    self.bids.pop(price, None)
                    self._set(self.asks, price, size)
                    changed = True
        return changed

    @staticmethod
    def _set(side: dict, price: float, size: float) -> None:
        if size > 0:
            side[price] = size
        else:
            side.pop(price, None)

    def snapshot(self, depth: int = BOOK_DEPTH) -> OrderBook:
        # Уровни — простыми парами (цена, объём) прямо из sorted(): без BookLevel на каждый уровень
        # (core.models.BookLevel — такая же пара). Цены в словаре уникальны — сортировка пар по цене.
        bids = sorted(self.bids.items(), reverse=True)
        asks = sorted(self.asks.items())
        if depth > 0:
            bids, asks = bids[:depth], asks[:depth]
        return OrderBook(self.iid, tuple(bids), tuple(asks), time.time())


class TradeIdMemory:
    """Последние trade_id инструмента — отсев повторов после переподключения."""

    def __init__(self, maxlen: int = TRADE_ID_MEMORY):
        self._order: deque[str] = deque(maxlen=maxlen)
        self._seen: set[str] = set()
        self.duplicates = 0

    def fresh(self, trade_id: str) -> bool:
        if not trade_id:
            return True
        if trade_id in self._seen:
            self.duplicates += 1
            return False
        if len(self._order) == self._order.maxlen:
            self._seen.discard(self._order[0])
        self._order.append(trade_id)
        self._seen.add(trade_id)
        return True


def parse_trades(msg, iid: InstrumentId, memory: TradeIdMemory | None = None) -> list[Trade]:
    """SubscribeLatestTradesResponse -> [Trade] без повторов."""
    out: list[Trade] = []
    for t in getattr(msg, "trades", ()) or ():
        trade_id = str(getattr(t, "trade_id", "") or "")
        if memory is not None and not memory.fresh(trade_id):
            continue
        price, size = dec(t.price), dec(t.size)
        if price <= 0 or size <= 0:
            continue
        side_raw = getattr(t, "side", 0)
        side = Side.BUY if side_raw == _SIDE_BUY else Side.SELL if side_raw == _SIDE_SELL else None
        out.append(Trade(
            instrument=iid,
            price=price,
            volume=size,
            side=side,
            ts=_ts(getattr(t, "timestamp", None)) or time.time(),
            trade_id=trade_id,
            is_snapshot=bool(getattr(t, "is_data_snapshot", False)),
        ))
    return out


def instrument_from_asset(iid: InstrumentId, asset) -> Instrument:
    """Ответ GetAsset (protobuf или dict) -> Instrument."""
    get = (lambda k, d=None: asset.get(k, d)) if isinstance(asset, dict) else \
          (lambda k, d=None: getattr(asset, k, d))
    try:
        decimals = int(get("decimals", 2) or 0)
        min_step = int(get("min_step", 0) or 0)
    except (TypeError, ValueError):
        decimals, min_step = 2, 0
    price_step = Decimal(min_step).scaleb(-decimals) if min_step > 0 else Decimal(1).scaleb(-decimals)
    try:
        lot = Decimal(str(dec(get("lot_size")) or 1))
    except InvalidOperation:
        lot = Decimal(1)
    kind = KIND_BY_TYPE.get(str(get("type", "") or "").upper(), InstrumentKind.OTHER)
    expiration = _expiration(get("future_details"))
    if kind is InstrumentKind.FUTURE and expiration is None:
        kind = InstrumentKind.PERPETUAL                      # фьючерс без даты — вечный
    multiplier = lot
    asset_type = str(get("type", "") or "").upper()
    if asset_type == "CURRENCIES" and lot <= 1:
        lot = multiplier = CURRENCY_SPOT_LOT
    if kind is InstrumentKind.FUTURE:
        multiplier = FUTURES_MULTIPLIER_BY_BASE.get(iid.ticker[:2].upper(), lot)
    elif kind is InstrumentKind.PERPETUAL:
        multiplier = PERPETUAL_MULTIPLIER.get(iid.ticker.upper(), lot)
    return Instrument(
        id=iid,
        name=str(get("name", "") or iid.ticker),
        kind=kind,
        price_step=price_step,
        step_price=price_step * multiplier,
        lot_size=lot,
        multiplier=multiplier,
        decimals=max(0, decimals),
        currency=str(get("quote_currency", "") or "RUB"),
        expiration=expiration,
    )


def _expiration(details) -> date | None:
    if not details:
        return None
    value = details.get("expiration_date") if isinstance(details, dict) else getattr(details, "expiration_date", None)
    if value is None:
        return None
    if isinstance(value, dict):
        value = value.get("value", value)
    year = getattr(value, "year", None) if not isinstance(value, (str, dict)) else None
    if year:                                                   # google.type.Date
        try:
            return date(int(value.year), int(value.month), int(value.day))
        except (TypeError, ValueError):
            return None
    if isinstance(value, dict) and value.get("year"):
        return date(int(value["year"]), int(value["month"]), int(value["day"]))
    if getattr(value, "seconds", None):                       # google.protobuf.Timestamp
        value = datetime.fromtimestamp(_ts(value), tz=timezone.utc)
    if isinstance(value, str) and value.strip():
        try:
            value = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        except ValueError:
            return None
    if isinstance(value, datetime):
        import contracts                                       # биржевая (московская) дата
        return contracts.to_msk_date(value)
    return None


# ============================================================================ поток с переподключением

class StreamRunner(threading.Thread):
    """Один серверный поток gRPC с автопереподключением (из scalper_widget.StreamRunner).

    Поток считается поднятым по ПЕРВОМУ сообщению, а не по открытию вызова: открытый вызов
    может сразу оборваться. После подъёма счётчик попыток сбрасывается.
    Время обработки каждого сообщения (handle) пишется в services/perf.PERF как «шлюз <вид>» — это время
    по часам, в него входит и ожидание GIL. Собственное процессорное время потока — отдельно:
        «ЦП шлюза <вид> · приём» — получение и разбор protobuf внутри gRPC (между сообщениями);
        «ЦП шлюза <вид> · обработка» — handle: перевод в модели и передача в хаб.
    (time.thread_time в Windows идёт квантами ~15 мс; на сотнях сообщений в секунду сумма за секунду верна.)
    По ним решается, окупится ли приём потоков Finam в Rust (замер 24.10).
    restart(reason) — переоткрыть поток сразу (сторож ленты сделок шлюза, см. STALE_TRADES_SEC)."""

    def __init__(self, key: tuple, open_fn: Callable[[], Any], handle: Callable[[Any], None],
                 on_up: Callable[[tuple], None], on_down: Callable[[tuple, str, float], None],
                 initial_delay: float = 0.0):
        super().__init__(daemon=True, name=f"finam-{key[0]}-{key[1]}")
        self.key = key
        self.initial_delay = initial_delay          # пауза перед первым открытием (группы котировок)
        self.open_fn, self.handle = open_fn, handle
        self.on_up, self.on_down = on_up, on_down
        self.stop_event = threading.Event()
        # Замер нагрузки (services/perf.py): разбор сообщения + передача в хаб, по виду потока.
        self.perf_name = f"шлюз {key[0]}"
        self.cpu_recv_name = f"ЦП шлюза {key[0]} · приём"
        self.cpu_handle_name = f"ЦП шлюза {key[0]} · обработка"
        self._call = None
        self._lock = threading.Lock()
        self.opened_at = 0.0                        # когда открыт текущий вызов (time.time) — см. сторож ленты
        self._restart_reason: str | None = None
        self.no_reopen = False                      # проба замершего потока: закончился вызов — не переоткрывать

    def restart(self, reason: str) -> None:
        """Переоткрыть поток сразу, без паузы переподключения. Можно звать из любого потока: текущий вызов
        отменяется (молчащий поток иначе так и ждал бы следующего сообщения)."""
        self._restart_reason = reason
        with self._lock:
            call = self._call
        if call is not None:
            try:
                call.cancel()
            except Exception:
                pass

    def stop(self) -> None:
        self.stop_event.set()
        with self._lock:
            call = self._call
        if call is not None:
            try:
                call.cancel()
            except Exception:
                pass

    def run(self) -> None:
        attempt = 0
        if self.initial_delay > 0 and self.stop_event.wait(self.initial_delay):
            return
        while not self.stop_event.is_set():
            reason = "сервер закрыл поток"
            try:
                call = self.open_fn()
                with self._lock:
                    self._call = call
                if self.stop_event.is_set():
                    call.cancel()
                    break
                self.opened_at = time.time()
                got = False
                cpu_mark = time.thread_time()
                for msg in call:
                    if self.stop_event.is_set():
                        break
                    if not got:
                        got = True
                        attempt = 0
                        self.on_up(self.key)
                    cpu0 = time.thread_time()
                    PERF.add(self.cpu_recv_name, cpu0 - cpu_mark)      # приём и разбор этого сообщения
                    start = time.perf_counter()
                    self.handle(msg)
                    PERF.add(self.perf_name, time.perf_counter() - start)
                    cpu_mark = time.thread_time()
                    PERF.add(self.cpu_handle_name, cpu_mark - cpu0)
                    if self._restart_reason is not None:
                        break
            except Exception as exc:
                reason = short_error(exc)
            finally:
                with self._lock:
                    self._call = None
            if self.stop_event.is_set() or self.no_reopen:
                break
            if self._restart_reason is not None:       # переподписка по сторожу: закрыть вызов и сразу заново
                self._restart_reason = None
                try:
                    call.cancel()
                except Exception:
                    pass
                attempt = 0
                if self.stop_event.wait(0.3):
                    break
                continue
            attempt += 1
            delay = retry_delay(attempt)
            self.on_down(self.key, reason, delay)
            if self.stop_event.wait(delay):
                break


# ============================================================================ шлюз

class FinamGateway:
    """MarketDataGateway поверх Finam Trade API (gRPC)."""

    name = "FINAM"

    def __init__(self, secret: str, account_id: str | None = None,
                 client_factory: Callable[[str], Any] | None = None,
                 log: Callable[[str], None] | None = None):
        if not secret or not str(secret).strip():
            raise ValueError("Finam secret не может быть пустым")
        self._secret = str(secret).strip()
        self._account_id = account_id
        self._client_factory = client_factory or _default_client_factory
        self._client = None
        self._client_lock = threading.Lock()
        # Свои соединения для потоков (SPLIT_STREAM_CHANNELS) — только у настоящего клиента Finam: у тестовой
        # имитации (client_factory) потоки идут через её единственный клиент, как раньше.
        self._split_streams = SPLIT_STREAM_CHANNELS and client_factory is None
        self._stream_clients: dict[str, Any] = {}
        self._sink: MarketDataSink | None = None
        self._log = log or (lambda text: print(f"[finam] {text}", file=sys.stderr))

        self._lock = threading.Lock()                 # защищает словари ниже
        self._runners: dict[tuple, StreamRunner] = {}
        self._books: dict[InstrumentId, BookState] = {}
        self._trade_ids: dict[InstrumentId, TradeIdMemory] = {}
        # Группы котировок start_quotes_many: номер -> символы, которые ещё нужны подписчикам.
        self._quote_groups: dict[int, set[InstrumentId]] = {}
        self._quote_group_of: dict[InstrumentId, int] = {}
        self._quote_group_key: dict[int, tuple] = {}   # номер группы -> ключ её потока в _runners
        self._quote_group_seq = 0
        self._up: set[tuple] = set()
        # Для окна «Состояние подключения»: счётчики без блокировок (приблизительные — это сводка).
        self._reconnects = 0                          # сколько раз потоки обрывались
        self._messages = {"quotes": 0, "book": 0, "trades": 0}
        self._last_message: dict[str, float] = {}     # вид потока -> время последнего сообщения
        self._trade_lag_ms: float | None = None       # задержка ленты (EMA): сейчас − время сделки
        self._lag_base = LagBase()                    # обычная задержка ленты (для сторожа, см. STALE_TRADES_SEC)
        self._stale_restart_at: dict[InstrumentId, float] = {}
        self.stale_restarts = 0                       # сколько раз сторож переоткрыл поток сделок
        # Сторож молчащей ленты (TRADES_SILENT_SEC): когда пришло последнее сообщение потока сделок, объём дня
        # из котировок и сколько раз он вырос с тех пор, по инструменту.
        self._trades_last_msg: dict[InstrumentId, float] = {}
        self._quote_volume: dict[InstrumentId, float] = {}
        self._volume_ups: dict[InstrumentId, int] = {}
        self._silent_restart_at: dict[InstrumentId, float] = {}
        self.silent_trade_restarts = 0
        # Сторож стакана (BOOK_STALE_SEC): время последнего сообщения стакана и сделок после него, по инструменту.
        self._book_last_msg: dict[InstrumentId, float] = {}
        self._book_trades_after: dict[InstrumentId, int] = {}
        self._book_restart_at: dict[InstrumentId, float] = {}
        self._book_first_wait: dict[InstrumentId, list] = {}   # [opened_at потока, сделок после открытия] — ждём снимок
        self.book_stale_restarts = 0
        self._book_probes: list = []                  # прежние замершие потоки стакана, которые ещё слушаем
        self._book_reopened_at: dict[InstrumentId, float] = {}   # переоткрыт сторожем: когда (для «снимок через X с»)
        # Стакан через Rust (этап 2): режим, сырой вызов (строится один раз), движки и состояние по инструменту.
        env_mode = os.getenv("FX_BOOK_ENGINE", "").strip().lower()
        self.book_mode = env_mode if env_mode in BOOK_MODES else "auto"
        self._raw_call = None                         # raw_book.RawBookCall или False (недоступен)
        self._raw_schema: dict | None = None
        self._raw_fx = None                           # модуль fx_engine
        self._raw_engines: dict[InstrumentId, Any] = {}      # инструмент -> BookEngine текущего быстрого потока
        self._raw_open: dict[InstrumentId, bool] = {}        # открыт быстрый поток: пришло ли сообщение
        self._raw_strikes: dict[InstrumentId, int] = {}
        self._raw_sdk_until: dict[InstrumentId, float] = {}  # инструмент на SDK до этого времени
        self._raw_logged = False
        self.raw_book_msgs = 0
        self._down: set[tuple] = set()               # потоки, оборвавшиеся и ещё не поднявшиеся
        self._connected = False
        self._catalog: list[Instrument] | None = None
        self._instruments: dict[InstrumentId, Instrument] = {}

    # ---- подключение -----------------------------------------------------------
    def set_sink(self, sink: MarketDataSink) -> None:
        self._sink = sink

    def connect_(self) -> None:
        """Создаёт клиента (сам вход по токену SDK выполняет при первом вызове)."""
        self.client()

    def disconnect_(self) -> None:
        with self._lock:
            probes, self._book_probes = list(self._book_probes), []
        for probe in probes:
            probe.stop()
        with self._lock:
            runners = list(self._runners.values())
            self._runners.clear()
            self._quote_groups.clear()
            self._quote_group_of.clear()
            self._quote_group_key.clear()
            self._up.clear()
            self._down.clear()
        for runner in runners:
            runner.stop()
        with self._client_lock:
            client, self._client = self._client, None
            extra, self._stream_clients = list(self._stream_clients.values()), {}
        for c in [client, *extra]:
            if c is None:
                continue
            try:
                c.close()
            except Exception:
                pass
        self._set_connected(False, "отключено")

    def client(self):
        with self._client_lock:
            if self._client is None:
                self._client = self._client_factory(self._secret)
            return self._client

    def stream_client(self, kind: str):
        """Клиент для потоков вида kind (book / trades / quotes): своё gRPC-соединение (SPLIT_STREAM_CHANNELS)
        или основной клиент, если разделение выключено / тестовая имитация."""
        if not self._split_streams or kind not in STREAM_CHANNEL_KINDS:
            return self.client()
        with self._client_lock:
            c = self._stream_clients.get(kind)
            if c is None:
                c = self._stream_clients[kind] = _default_client_factory(self._secret, separate=True)
                first = len(self._stream_clients) == 1
            else:
                first = False
        if first:
            self._log("потоки Finam — по отдельным соединениям: стаканы, сделки, котировки (заявки и справочник — "
                      "по основному; FX_STREAM_CHANNELS=1)")
        return c

    # ---- справочник ---------------------------------------------------------------
    def account_id(self) -> str:
        if not self._account_id:
            from finam_sdk_client import FinamStreamClient   # тот же разбор /v1/sessions/details
            helper = FinamStreamClient.__new__(FinamStreamClient)
            helper.secret, helper.account_id = self._secret, None
            self._account_id = helper._find_account_id()
        return self._account_id

    def list_instruments(self) -> list[Instrument]:
        """Каталог: имя, вид и площадка. Шаг цены и лот здесь не известны (price_step = 0) —
        их даёт get_instrument()."""
        if self._catalog is None:
            from finam_trade_api.assets import AssetsRequest
            response = self.client().assets.Assets(AssetsRequest())
            catalog: list[Instrument] = []
            for a in getattr(response, "assets", ()) or ():
                symbol = getattr(a, "symbol", "") or ""
                if not symbol:
                    continue
                catalog.append(Instrument(
                    id=from_symbol(symbol),
                    name=str(getattr(a, "name", "") or symbol),
                    kind=KIND_BY_TYPE.get(str(getattr(a, "type", "")).upper(), InstrumentKind.OTHER),
                    price_step=Decimal(0), step_price=Decimal(0),
                ))
            self._catalog = catalog
        return list(self._catalog)

    def search_instruments(self, query: str) -> list[Instrument]:
        text = str(query or "").strip().upper()
        if not text:
            return []
        return [i for i in self.list_instruments()
                if text in str(i.id).upper() or text in i.name.upper()]

    def get_instrument(self, iid: InstrumentId) -> Instrument:
        with self._lock:
            known = self._instruments.get(iid)
        if known is not None:
            return known
        from finam_trade_api.assets import GetAssetRequest
        asset = self.client().assets.GetAsset(
            GetAssetRequest(symbol=to_symbol(iid), account_id=self.account_id()))
        instrument = instrument_from_asset(iid, asset)
        if instrument.expiration is not None:
            import contracts
            contracts.register_expiration(str(iid), instrument.expiration)   # общее правило ролловера
        with self._lock:
            self._instruments[iid] = instrument
        return instrument

    def get_candles(self, iid: InstrumentId, timeframe: Timeframe,
                    start_ts: float, end_ts: float) -> list[Candle]:
        from google.protobuf.timestamp_pb2 import Timestamp
        from google.type.interval_pb2 import Interval
        from finam_trade_api.market_data import BarsRequest, TimeFrame

        tf_name = {"D1": "TIME_FRAME_D", "W1": "TIME_FRAME_W", "MN1": "TIME_FRAME_MN"}.get(
            timeframe.value, f"TIME_FRAME_{timeframe.value}")
        start, end = Timestamp(), Timestamp()
        start.FromSeconds(int(start_ts))
        end.FromSeconds(int(end_ts))
        response = self.client().market_data.Bars(BarsRequest(
            symbol=to_symbol(iid), timeframe=getattr(TimeFrame, tf_name),
            interval=Interval(start_time=start, end_time=end)))
        candles: dict[float, Candle] = {}
        for bar in getattr(response, "bars", ()) or ():
            ts = _ts(bar.timestamp)
            if not ts:
                continue
            candles[ts] = Candle(iid, ts, dec(bar.open), dec(bar.high), dec(bar.low),
                                 dec(bar.close), dec(bar.volume))
        return [candles[k] for k in sorted(candles)]

    def server_time(self) -> float:
        try:
            from finam_trade_api.assets import ClockRequest
            request = ClockRequest()
        except ImportError:
            from google.protobuf.empty_pb2 import Empty
            request = Empty()
        return _ts(self.client().assets.Clock(request).timestamp) or time.time()

    # ---- потоки -------------------------------------------------------------------
    def start_quotes(self, iid: InstrumentId) -> None:
        with self._lock:
            if iid in self._quote_group_of:         # уже идёт в группе start_quotes_many
                return
        def open_call():
            from finam_trade_api.market_data import SubscribeQuoteRequest
            return self.stream_client("quotes").market_data.SubscribeQuote(SubscribeQuoteRequest(symbols=[to_symbol(iid)]))
        self._start(("quotes", iid), open_call, self._on_quote_msg)

    def start_quotes_many(self, iids, batch: int = QUOTE_BATCH,
                          stagger: float = QUOTE_BATCH_STAGGER_SEC) -> None:
        """Котировки многих инструментов: по потоку на группу до batch символов.
        Уже подписанные (поодиночке или в группе) пропускаются."""
        with self._lock:
            todo = []
            for iid in iids:
                if (iid in self._quote_group_of or ("quotes", iid) in self._runners
                        or iid in todo):
                    continue
                todo.append(iid)
            groups = []
            for i in range(0, len(todo), max(1, batch)):
                self._quote_group_seq += 1
                gid, members = self._quote_group_seq, todo[i:i + batch]
                symbols = [to_symbol(iid) for iid in members]
                key = ("quotes", f"группа {gid} ({len(members)}: {symbols[0]}…)")
                self._quote_groups[gid] = set(members)
                self._quote_group_key[gid] = key
                for iid in members:
                    self._quote_group_of[iid] = gid
                groups.append((gid, key, symbols))
        for n, (gid, key, symbols) in enumerate(groups):
            def open_call(symbols=symbols):
                from finam_trade_api.market_data import SubscribeQuoteRequest
                return self.stream_client("quotes").market_data.SubscribeQuote(SubscribeQuoteRequest(symbols=symbols))
            with self._lock:
                if gid not in self._quote_groups:   # все символы уже отписали, пока открывали прежние
                    continue
            self._start(key, open_call, lambda msg, gid=gid: self._on_quote_group_msg(gid, msg),
                        initial_delay=n * stagger)
            with self._lock:
                orphan = gid not in self._quote_groups  # отписали между проверкой и запуском
            if orphan:
                self._stop(key)

    def stop_quotes(self, iid: InstrumentId) -> None:
        with self._lock:
            gid = self._quote_group_of.pop(iid, None)
            key = None
            if gid is not None:
                members = self._quote_groups.get(gid)
                if members is not None:
                    members.discard(iid)
                    if not members:                 # отписаны все символы группы — закрываем поток
                        self._quote_groups.pop(gid, None)
                        key = self._quote_group_key.pop(gid, None)
        if gid is None:
            self._stop(("quotes", iid))
        elif key is not None:
            self._stop(key)

    def start_orderbook(self, iid: InstrumentId) -> None:
        with self._lock:
            self._books[iid] = BookState(iid)               # с чистого листа: придёт снимок

        def open_call():
            from finam_trade_api.market_data import SubscribeOrderBookRequest
            request = SubscribeOrderBookRequest(symbol=to_symbol(iid))
            raw = self._open_raw_book(iid, request)          # Rust-путь: поток байтов (или None — SDK)
            if raw is not None:
                return raw
            return self.stream_client("book").market_data.SubscribeOrderBook(request)
        self._start(("book", iid), open_call, lambda msg: self._on_book_msg(iid, msg))

    def stop_orderbook(self, iid: InstrumentId) -> None:
        self._stop(("book", iid))
        with self._lock:
            self._books.pop(iid, None)
            self._raw_engines.pop(iid, None)
            self._raw_open.pop(iid, None)

    def start_trades(self, iid: InstrumentId) -> None:
        with self._lock:
            # Память trade_id переживает остановку: подписались снова — старые сделки не задвоятся.
            self._trade_ids.setdefault(iid, TradeIdMemory())

        def open_call():
            from finam_trade_api.market_data import SubscribeLatestTradesRequest
            return self.stream_client("trades").market_data.SubscribeLatestTrades(
                SubscribeLatestTradesRequest(symbol=to_symbol(iid)))
        self._start(("trades", iid), open_call, lambda msg: self._on_trades_msg(iid, msg))

    def stop_trades(self, iid: InstrumentId) -> None:
        self._stop(("trades", iid))

    def active_streams(self) -> list[tuple[str, str]]:
        """Для диагностики: [("trades", "USDRUBF@RTSX"), …]."""
        with self._lock:
            return sorted((kind, str(iid)) for kind, iid in self._runners)

    # ---- внутреннее -----------------------------------------------------------------
    def _start(self, key: tuple, open_fn, handle, initial_delay: float = 0.0) -> None:
        with self._lock:
            if key in self._runners:
                return
            runner = StreamRunner(key, open_fn, handle, self._on_up, self._on_down, initial_delay)
            self._runners[key] = runner
        runner.start()

    def _stop(self, key: tuple) -> None:
        with self._lock:
            runner = self._runners.pop(key, None)
            self._up.discard(key)
            self._down.discard(key)
        if runner is not None:
            runner.stop()

    def _on_up(self, key: tuple) -> None:
        with self._lock:
            if key not in self._runners:
                return
            self._up.add(key)
            recovered = key in self._down
            self._down.discard(key)
        if recovered:
            self._log(f"{key[0]} {key[1]}: поток восстановлен")
        self._set_connected(True, "")

    def _on_down(self, key: tuple, reason: str, delay: float) -> None:
        with self._lock:
            if key not in self._runners:
                return
            self._up.discard(key)
            self._down.add(key)
            any_up = bool(self._up)
            self._reconnects += 1
        self._log(f"{key[0]} {key[1]}: {reason} — переподключение через {delay:.0f} с")
        if not any_up:
            self._set_connected(False, reason)

    def stats(self) -> dict:
        """Сводка для окна «Состояние подключения» (вызывается из GUI раз в секунду)."""
        now = time.time()
        with self._lock:
            runners = list(self._runners)
            up, down = len(self._up), len(self._down)
            groups = len(self._quote_groups)
            grouped = len(self._quote_group_of)
        by_kind: dict[str, int] = {}
        for kind, _ in runners:
            by_kind[kind] = by_kind.get(kind, 0) + 1
        return {
            "connected": self._connected,
            "streams": len(runners), "up": up, "down": down,
            "starting": max(0, len(runners) - up - down),
            "by_kind": by_kind,
            "quote_groups": groups, "grouped_symbols": grouped,
            "reconnects": self._reconnects,
            "messages": dict(self._messages),
            "idle_sec": {k: now - t for k, t in self._last_message.items()},
            "trade_lag_ms": self._trade_lag_ms,
            "stale_restarts": self.stale_restarts,
            "book_stale_restarts": self.book_stale_restarts,
            "silent_trade_restarts": self.silent_trade_restarts,
            "book_mode": self.book_mode,
            "book_rust": len(self._raw_engines),
            "raw_book_msgs": self.raw_book_msgs,
        }

    def _count(self, kind: str) -> None:
        self._messages[kind] = self._messages.get(kind, 0) + 1
        self._last_message[kind] = time.time()

    def _set_connected(self, connected: bool, reason: str) -> None:
        if connected == self._connected:
            return
        self._connected = connected
        sink = self._sink
        if sink is not None:
            sink.push_connection(ConnectionState(connected, reason, time.time()))

    def _on_quote_msg(self, msg) -> None:
        self._count("quotes")
        sink = self._sink
        if sink is None:
            return
        now = time.time()
        for quote in parse_quotes(msg):
            sink.push_quote(quote)
            self._watch_silent_trades(quote.instrument, quote.volume, now)

    def _on_quote_group_msg(self, gid: int, msg) -> None:
        self._count("quotes")
        sink = self._sink
        if sink is None:
            return
        with self._lock:
            members = self._quote_groups.get(gid)
            active = frozenset(members) if members else frozenset()
        now = time.time()
        for quote in parse_quotes(msg):
            if quote.instrument in active:          # отписанные символы группы дальше не идут
                sink.push_quote(quote)
                self._watch_silent_trades(quote.instrument, quote.volume, now)

    # ---- стакан через Rust (этап 2) ---------------------------------------------------
    def set_book_mode(self, mode: str) -> None:
        """Режим стакана из «Настроек» (auto / sdk / rust). FX_BOOK_ENGINE важнее. Сменился — открытые
        стаканы переоткрываются уже в новом режиме (новый поток начинается со снимка)."""
        if os.getenv("FX_BOOK_ENGINE", "").strip().lower() in BOOK_MODES:
            return
        mode = mode if mode in BOOK_MODES else "auto"
        if mode == self.book_mode:
            return
        self.book_mode = mode
        self._raw_sdk_until.clear()
        self._raw_strikes.clear()
        if mode != "sdk" and self._raw_call is False:
            self._raw_call = None                  # недоступность могла быть временной — попробовать снова
        with self._lock:
            runners = [r for (kind, _iid), r in self._runners.items() if kind == "book"]
        self._log(f"режим стакана: {mode} — переоткрываю стаканы ({len(runners)})")
        for runner in runners:
            runner.restart(f"режим стакана {mode}")

    def _raw_ready(self) -> bool:
        """Построить сырой вызов стакана и схему для Rust (один раз). False — Rust-путь недоступен."""
        if self._raw_call is False:
            return False
        if self._raw_call is not None:
            return True
        try:
            import app_paths  # noqa: F401  — готовый fx_engine из обновления (2.1.83)
            import fx_engine
            if not hasattr(fx_engine, "BookEngine"):
                raise RuntimeError(f"fx_engine {getattr(fx_engine, '__version__', '?')} без BookEngine")
            from finam_trade_api.market_data import SubscribeOrderBookRequest
            from brokers.finam import raw_book
            from services.rust_book_shadow import schema_from_message
            call = raw_book.build(self.stream_client("book"), SubscribeOrderBookRequest)
            self._raw_schema = schema_from_message(call.response_cls(), _remove_action())
            self._raw_fx = fx_engine
            self._raw_call = call
            self._log(f"стакан через Rust: сырые байты из gRPC ({call.how}), fx_engine "
                      f"{getattr(fx_engine, '__version__', '?')}; при сбое — сам переходит на SDK")
            return True
        except Exception as exc:
            self._raw_call = False
            self._log(f"стакан через Rust недоступен ({type(exc).__name__}: {exc}) — стакан через SDK, как раньше")
            return False

    def _open_raw_book(self, iid: InstrumentId, request):
        """Открыть быстрый поток стакана (байты -> Rust) или None — открывать через SDK.
        Здесь же учёт сбоев: прошлый быстрый поток закрылся, не прислав ни одного сообщения, а связь
        у остальных потоков была, — сбой быстрого пути (два подряд — инструмент на SDK на RAW_RETRY_SEC).
        Заголовок авторизации ставит сам канал SDK (учётные данные вызова, _metadata.py SDK) — как у SDK-пути."""
        now = time.time()
        with self._lock:
            was_raw = iid in self._raw_open
            got = self._raw_open.pop(iid, False)
            self._raw_engines.pop(iid, None)
            others_up = bool(self._up - {("book", iid)})
        if was_raw and not got and others_up:
            self._raw_strike(iid, "быстрый поток закрылся без единого сообщения", now)
        if self.book_mode == "sdk" or not self._raw_ready():
            return None
        if self.book_mode == "auto" and now < self._raw_sdk_until.get(iid, 0.0):
            return None
        engine = self._raw_fx.BookEngine(self._raw_schema)
        stream = self._raw_call(request)
        with self._lock:
            self._raw_engines[iid] = engine
            self._raw_open[iid] = False
        return stream

    def _raw_strike(self, iid: InstrumentId, reason: str, now: float) -> None:
        strikes = self._raw_strikes.get(iid, 0) + 1
        self._raw_strikes[iid] = strikes
        if self.book_mode == "auto" and strikes >= RAW_STRIKES:
            self._raw_strikes[iid] = 0
            self._raw_sdk_until[iid] = now + RAW_RETRY_SEC
            self._log(f"book {iid}: Rust-путь — {reason}; перехожу на SDK, снова попробую Rust через "
                      f"{RAW_RETRY_SEC / 60:.0f} мин")
        else:
            self._log(f"book {iid}: Rust-путь — {reason} (сбой {strikes} из {RAW_STRIKES})")

    def _on_raw_book(self, iid: InstrumentId, data: bytes) -> None:
        """Сообщение стакана байтами: разбор и применение — в Rust, наружу — OrderBook как у SDK-пути."""
        with self._lock:
            engine = self._raw_engines.get(iid)
            if iid in self._raw_open:
                self._raw_open[iid] = True
        if engine is None:
            return
        self.raw_book_msgs += 1
        try:
            changed = engine.apply(data)
        except ValueError as exc:
            # Rust не разобрал сообщение (Finam изменил протокол?) — этот стакан переходит на SDK сразу.
            with self._lock:
                self._raw_engines.pop(iid, None)
                runner = self._runners.get(("book", iid))
            self._raw_strikes[iid] = RAW_STRIKES - 1
            self._raw_strike(iid, f"Rust не разобрал сообщение ({exc})", time.time())
            if self.book_mode == "rust":
                self._raw_sdk_until.pop(iid, None)
            if runner is not None:
                runner.restart("Rust не разобрал сообщение стакана")
            return
        if self._raw_strikes.get(iid):
            self._raw_strikes[iid] = 0             # быстрый путь работает — сбои забыты
        if not changed:
            return
        bids, asks = engine.snapshot(BOOK_DEPTH)
        sink = self._sink
        if sink is not None:
            sink.push_orderbook(OrderBook(iid, tuple(bids), tuple(asks), time.time()))

    def _on_book_msg(self, iid: InstrumentId, msg) -> None:
        self._count("book")
        now = time.time()
        reopened = self._book_reopened_at.pop(iid, None)
        if reopened is not None:
            self._log(f"book {iid}: новый поток прислал стакан через {now - reopened:.1f} с")
        self._book_last_msg[iid] = now                  # сторож стакана: стакан жив
        self._book_trades_after[iid] = 0
        if isinstance(msg, (bytes, bytearray, memoryview)):
            self._on_raw_book(iid, bytes(msg))
            return
        self._maybe_back_to_raw(iid)
        with self._lock:
            book = self._books.get(iid)
        if book is None:
            return
        changed = book.apply(msg, _remove_action())
        snapshot = book.snapshot() if changed else None
        if snapshot is not None:
            sink = self._sink
            if sink is not None:
                sink.push_orderbook(snapshot)

    def _maybe_back_to_raw(self, iid: InstrumentId) -> None:
        """Стакан на SDK после сбоя Rust-пути, а RAW_RETRY_SEC прошло — переоткрыть поток, снова через Rust."""
        until = self._raw_sdk_until.get(iid)
        if until is None or time.time() < until or self.book_mode != "auto" or self._raw_call is False:
            return
        self._raw_sdk_until.pop(iid, None)
        with self._lock:
            runner = self._runners.get(("book", iid))
        if runner is not None:
            self._log(f"book {iid}: снова пробую стакан через Rust")
            runner.restart("снова через Rust")

    def _on_trades_msg(self, iid: InstrumentId, msg) -> None:
        self._count("trades")
        with self._lock:
            memory = self._trade_ids.get(iid)
        sink = self._sink
        now = time.time()
        self._trades_last_msg[iid] = now             # лента жива — счёт роста объёма заново
        self._volume_ups[iid] = 0
        newest = 0.0
        for trade in parse_trades(msg, iid, memory):
            if not trade.is_snapshot and trade.ts > 0:
                lag = max(0.0, (now - trade.ts) * 1000.0)
                prev = self._trade_lag_ms
                self._trade_lag_ms = lag if prev is None else prev * 0.9 + lag * 0.1
                newest = max(newest, trade.ts)
            if sink is not None:
                sink.push_trade(trade)
        if newest > 0:
            self._watch_trades_lag(iid, now - newest, now)
            self._watch_book(iid, newest, now)

    def _watch_book(self, iid: InstrumentId, newest_trade_ts: float, now: float) -> None:
        """Сторож стакана: сделки идут, а стакан инструмента молчит — переоткрыть поток стакана.
        Поток, не приславший ни одного сообщения (нет первого снимка), — быстрее: BOOK_FIRST_SEC."""
        last = self._book_last_msg.get(iid)
        with self._lock:
            runner = self._runners.get(("book", iid))
        if runner is None or runner.opened_at <= 0:
            return
        if last is None or last < runner.opened_at:     # с открытия потока стакана — ни одного сообщения
            self._watch_first_snapshot(iid, runner, newest_trade_ts, now)
            return
        if now - runner.opened_at < STALE_GRACE_SEC:
            return
        if newest_trade_ts > last:                       # сделка совершена после последнего сообщения стакана
            self._book_trades_after[iid] = self._book_trades_after.get(iid, 0) + 1
        silent = now - last
        trades = self._book_trades_after.get(iid, 0)
        if (silent < BOOK_STALE_SEC or trades < BOOK_STALE_TRADES
                or now - self._book_restart_at.get(iid, 0.0) < BOOK_RESTART_EVERY_SEC):
            return
        self._book_restart_at[iid] = now
        self.book_stale_restarts += 1
        self._log(f"book {iid}: стакан молчит {silent:.0f} с, а сделок за это время {trades} — "
                  "поток стакана Finam замер, переоткрываю")
        self._reopen_book_with_probe(iid, runner, last)

    def _watch_first_snapshot(self, iid: InstrumentId, runner: "StreamRunner", newest_trade_ts: float,
                              now: float) -> None:
        wait = self._book_first_wait.get(iid)
        if wait is None or wait[0] != runner.opened_at:  # новый поток — считаем сделки с его открытия
            wait = self._book_first_wait[iid] = [runner.opened_at, 0]
        if newest_trade_ts > runner.opened_at:
            wait[1] += 1
        silent = now - runner.opened_at
        if (silent < BOOK_FIRST_SEC or wait[1] < BOOK_STALE_TRADES
                or now - self._book_restart_at.get(iid, 0.0) < BOOK_RESTART_EVERY_SEC):
            return
        self._book_restart_at[iid] = now
        self._book_first_wait.pop(iid, None)
        self.book_stale_restarts += 1
        self._log(f"book {iid}: новый поток стакана {silent:.0f} с не прислал снимок, а сделок за это время "
                  f"{wait[1]} — поток Finam замер на старте, переоткрываю")
        self._reopen_book_with_probe(iid, runner, runner.opened_at)

    def _reopen_book_with_probe(self, iid: InstrumentId, old: "StreamRunner", last_msg: float) -> None:
        """Новый поток стакана — новым StreamRunner; прежний (замерший) не отменяется, а BOOK_PROBE_SEC слушается
        пробой: его сообщения не применяются, только отмечается, ожил ли он и сколько прислал (см. BOOK_PROBE_SEC)."""
        key = ("book", iid)
        with self._lock:
            if self._runners.get(key) is not old:
                return
            new = StreamRunner(key, old.open_fn, old.handle, self._on_up, self._on_down)
            self._runners[key] = new
            self._book_probes.append(old)
        state = {"first": None, "n": 0}

        def probe_handle(_msg) -> None:
            now = time.time()
            state["n"] += 1
            if state["first"] is None:
                state["first"] = now
                self._log(f"book {iid}: прежний (замерший) поток ожил сам — молчал {now - last_msg:.0f} с; "
                          "Finam задержал сообщения, а не потерял подписку")

        def finish() -> None:
            old.stop()
            with self._lock:
                if old in self._book_probes:
                    self._book_probes.remove(old)
            if state["first"] is None:
                self._log(f"book {iid}: прежний (замерший) поток так и не ожил за {BOOK_PROBE_SEC:.0f} с — "
                          "подписка на сервере Finam умерла без ошибки")
            else:
                self._log(f"book {iid}: прежний поток после замирания прислал {state['n']} сообщений "
                          f"за {time.time() - state['first']:.0f} с (из них сразу — пачкой — видно по времени выше)")

        old.no_reopen = True
        old.on_up = lambda _key: None               # проба не трогает состояние связи нового потока
        old.on_down = lambda _key, _reason, _delay: None
        old.handle = probe_handle
        timer = threading.Timer(BOOK_PROBE_SEC, finish)
        timer.daemon = True
        timer.start()
        self._book_reopened_at[iid] = time.time()
        new.start()

    def _watch_silent_trades(self, iid: InstrumentId, volume: float | None, now: float) -> None:
        """Сторож молчащей ленты: объём дня в котировках растёт (сделки на бирже идут), а поток сделок
        инструмента молчит дольше TRADES_SILENT_SEC — переоткрыть его, не дожидаясь опоздавших сделок."""
        if volume is None:
            return
        prev = self._quote_volume.get(iid)
        self._quote_volume[iid] = volume
        if prev is None or volume < prev:            # первая котировка или новый день (объём с нуля)
            return
        with self._lock:
            runner = self._runners.get(("trades", iid))
        if runner is None or runner.opened_at <= 0 or now - runner.opened_at < STALE_GRACE_SEC:
            return                                   # поток ещё не открыт или в начале (Finam шлёт историю)
        if volume > prev:
            self._volume_ups[iid] = self._volume_ups.get(iid, 0) + 1
        last = max(self._trades_last_msg.get(iid, 0.0), runner.opened_at)
        silent = now - last
        ups = self._volume_ups.get(iid, 0)
        if (silent < TRADES_SILENT_SEC or ups < TRADES_SILENT_UPDATES
                or now - self._silent_restart_at.get(iid, 0.0) < TRADES_SILENT_RESTART_EVERY_SEC):
            return
        self._silent_restart_at[iid] = now
        self._stale_restart_at[iid] = now            # опоздавшие сделки нового потока — уже не повод
        self._volume_ups[iid] = 0
        self.silent_trade_restarts += 1
        self._log(f"trades {iid}: сделок нет {silent:.0f} с, а объём в котировках за это время вырос {ups} раз — "
                  "поток сделок Finam замер, переоткрываю")
        runner.restart(f"лента молчит {silent:.0f} с")

    def _watch_trades_lag(self, iid: InstrumentId, lag: float, now: float) -> None:
        """Сторож ленты: самая свежая сделка сообщения пришла намного позже обычного — переоткрыть поток."""
        with self._lock:
            runner = self._runners.get(("trades", iid))
        if runner is None or now - runner.opened_at < STALE_GRACE_SEC:
            return                                  # начало потока: Finam присылает историю
        self._lag_base.add(lag, now)
        extra = lag - self._lag_base.value()
        if extra < STALE_TRADES_SEC or now - self._stale_restart_at.get(iid, 0.0) < STALE_RESTART_EVERY_SEC:
            return
        self._stale_restart_at[iid] = now
        self.stale_restarts += 1
        self._log(f"trades {iid}: сделка пришла на {lag:.0f} с позже биржи (обычно {self._lag_base.value():.1f} с) — "
                  "лента Finam отстаёт, переоткрываю поток сделок")
        runner.restart(f"лента отстаёт на {lag:.0f} с")


_REMOVE_ACTION = None


def _remove_action():
    """Код действия REMOVE строки стакана из SDK (берётся один раз)."""
    global _REMOVE_ACTION
    if _REMOVE_ACTION is None:
        from finam_trade_api.market_data import StreamOrderBook
        _REMOVE_ACTION = StreamOrderBook.Row.ACTION_REMOVE
    return _REMOVE_ACTION


def _default_client_factory(secret: str, separate: bool = False):
    """Клиент Finam. separate=True — со своим TCP-соединением (свой пул подканалов gRPC): для потоков данных,
    см. SPLIT_STREAM_CHANNELS."""
    from finam_trade_api import FinamClient, RetryPolicy
    # Торговые вызовы не повторяем автоматически (повтор PlaceOrder мог бы продублировать заявку);
    # потоки переподключает StreamRunner.
    policy = RetryPolicy(max_attempts=1)
    options = list(GRPC_CHANNEL_OPTIONS) + ([("grpc.use_local_subchannel_pool", 1)] if separate else [])
    if os.getenv("FINAM_GRPC_INSECURE") == "1":           # локальный стенд / тесты
        return FinamClient.for_testing(secret, endpoint=GRPC_ENDPOINT, retry_policy=policy,
                                       channel_options=options)
    return FinamClient(secret, endpoint=GRPC_ENDPOINT, retry_policy=policy,
                       channel_options=options)
