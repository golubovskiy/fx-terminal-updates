"""
Тема FX Terminal — минималистичный профессиональный интерфейс (в духе Adobe / Photoshop,
адаптированный под трейдинг).

Принципы:
  * графитовая основа, серые панели, тонкие границы 1 px, аккуратные отступы;
  * компактные кнопки и поля (высота ≈ 22 px), простая функциональная типографика;
  * монохромные иконки (рисуются кодом, без emoji);
  * акцентный цвет — точечно: активное/выбранное состояние и фокус;
    цвета покупки/продажи (зелёный/красный) — только для данных;
  * у каждого элемента различимы состояния: normal, hover, pressed, checked, focus, disabled.

Использование:
    import fx_theme
    window.setObjectName("fxTickWindow")          # или любой другой objectName
    window.setStyleSheet(fx_theme.stylesheet())    # на одно окно
    # или на всё приложение: app.setStyleSheet(fx_theme.stylesheet())
    button.setIcon(fx_theme.icon("gear"))
"""

from __future__ import annotations

import tempfile
from functools import lru_cache
from pathlib import Path
import os
import sys

from PySide6 import QtCore, QtGui, QtWidgets

# ------------------------------------------------------------------ палитра

BG_WINDOW = "#1c1d20"     # фон окна
BG_PANEL = "#232529"      # панели, диалоги, выпадающие списки
BG_CONTROL = "#2a2c31"    # кнопки
BG_INPUT = "#18191c"      # поля ввода (чуть темнее фона)
BG_HOVER = "#33363c"
BG_PRESSED = "#3b3f46"
BORDER = "#383b41"        # тонкие разделители и границы
BORDER_STRONG = "#4a4e56"
TEXT = "#d3d6db"
TEXT_DIM = "#8c9199"
TEXT_DISABLED = "#5b5f66"
ACCENT = "#3d8bfd"        # активное / выбранное / фокус — только точечно
ACCENT_BG = "#1f3556"

# Цвет системной шапки окна по референсу «Тики Bid/Ask».
TITLEBAR_COLOR = "#103638"
TITLEBAR_TEXT_COLOR = "#e0e8e8"

# цвета данных (не для оформления интерфейса)
BUY = "#2ecc55"
SELL = "#e61e1e"

ICON_NORMAL = "#aab0b8"
ICON_HOVER = "#eceef1"
ICON_DISABLED = "#555960"
SELECTED_TEXT = "#ffffff"   # текст на выделенном / включённом (на ACCENT_BG)
HOVER_TINT = "255, 255, 255"  # rgba-подсветка при наведении: светлая на тёмной теме, тёмная на светлой

_ASSET_DIR = Path(tempfile.gettempdir()) / "fx_terminal_theme"


# ------------------------------------------------------------------ иконки

def _pen(color: str, width: float = 1.4) -> QtGui.QPen:
    pen = QtGui.QPen(QtGui.QColor(color))
    pen.setWidthF(width)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
    return pen


def paint_icon(p: QtGui.QPainter, name: str, color: str, size: float) -> None:
    """Рисует монохромную иконку `name` цветом `color` в квадрате size×size (начало — в (0, 0))."""
    import math

    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    p.setPen(_pen(color))
    p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
    s = float(size)
    c = s / 2
    P = QtCore.QPointF

    def line(x0, y0, x1, y1):
        p.drawLine(P(s * x0, s * y0), P(s * x1, s * y1))

    def dot(x, y, r=1.7, fill=True):
        if fill:
            p.setBrush(QtGui.QColor(color))
        p.drawEllipse(P(s * x, s * y), r, r)
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)

    if name == "lupa":
        r = s * 0.27
        p.drawEllipse(P(c - s * 0.07, c - s * 0.07), r, r)
        p.drawLine(P(c + s * 0.14, c + s * 0.14), P(s - 2.6, s - 2.6))
    elif name == "gear":
        p.drawEllipse(P(c, c), s * 0.17, s * 0.17)
        p.drawEllipse(P(c, c), s * 0.30, s * 0.30)
        for k in range(8):
            a = math.radians(k * 45)
            p.drawLine(
                P(c + math.cos(a) * s * 0.30, c + math.sin(a) * s * 0.30),
                P(c + math.cos(a) * s * 0.42, c + math.sin(a) * s * 0.42),
            )
    elif name == "pause":
        line(0.36, 0.24, 0.36, 0.76)
        line(0.64, 0.24, 0.64, 0.76)
    elif name == "play":
        p.drawPolygon(QtGui.QPolygonF([P(s * 0.32, s * 0.22), P(s * 0.32, s * 0.78), P(s * 0.78, c)]))
    elif name in ("clear", "close"):
        line(0.28, 0.28, 0.72, 0.72)
        line(0.72, 0.28, 0.28, 0.72)
    elif name == "sliders":
        for y, x in ((0.3, 0.38), (0.5, 0.64), (0.7, 0.46)):
            line(0.2, y, 0.8, y)
            dot(x, y, 1.9)
    elif name == "list":
        for y in (0.28, 0.5, 0.72):
            line(0.24, y, 0.76, y)
    # ---- инструменты рисования на графике ----
    elif name == "pointer":
        p.drawPolygon(QtGui.QPolygonF([
            P(s * 0.30, s * 0.20), P(s * 0.30, s * 0.78), P(s * 0.46, s * 0.63),
            P(s * 0.58, s * 0.84), P(s * 0.68, s * 0.79), P(s * 0.56, s * 0.58), P(s * 0.76, s * 0.58),
        ]))
    elif name == "crosshair":
        line(0.5, 0.16, 0.5, 0.40)
        line(0.5, 0.60, 0.5, 0.84)
        line(0.16, 0.5, 0.40, 0.5)
        line(0.60, 0.5, 0.84, 0.5)
        dot(0.5, 0.5, 1.2, fill=False)
    elif name == "magnet":
        p.drawArc(QtCore.QRectF(s * 0.28, s * 0.30, s * 0.44, s * 0.50), 180 * 16, 180 * 16)
        line(0.28, 0.55, 0.28, 0.20)
        line(0.72, 0.55, 0.72, 0.20)
        line(0.20, 0.30, 0.36, 0.30)
        line(0.64, 0.30, 0.80, 0.30)
    elif name == "trendline":
        line(0.22, 0.76, 0.78, 0.24)
        dot(0.22, 0.76)
        dot(0.78, 0.24)
    elif name == "hline":
        line(0.14, 0.5, 0.86, 0.5)
        dot(0.14, 0.5)
        dot(0.86, 0.5)
    elif name == "rect":
        p.drawRect(QtCore.QRectF(s * 0.22, s * 0.28, s * 0.56, s * 0.44))
    elif name == "ruler":
        line(0.14, 0.62, 0.86, 0.62)
        for k, x in enumerate((0.14, 0.32, 0.50, 0.68, 0.86)):
            line(x, 0.62, x, 0.40 if k % 2 == 0 else 0.50)
    elif name == "trash":
        line(0.24, 0.30, 0.76, 0.30)
        p.drawPolyline(QtGui.QPolygonF([P(s * 0.42, s * 0.30), P(s * 0.42, s * 0.20), P(s * 0.58, s * 0.20), P(s * 0.58, s * 0.30)]))
        p.drawPolyline(QtGui.QPolygonF([P(s * 0.30, s * 0.30), P(s * 0.34, s * 0.80), P(s * 0.66, s * 0.80), P(s * 0.70, s * 0.30)]))
        line(0.50, 0.42, 0.50, 0.68)
    elif name == "percent":
        dot(0.32, 0.30, s * 0.10, fill=False)
        dot(0.68, 0.70, s * 0.10, fill=False)
        line(0.72, 0.22, 0.28, 0.78)
    elif name == "band":
        for y in (0.28, 0.50, 0.72):
            line(0.16, y, 0.40, y)
        brush = QtGui.QColor(color)
        brush.setAlpha(80)
        p.setBrush(brush)
        p.drawRect(QtCore.QRectF(s * 0.52, s * 0.20, s * 0.26, s * 0.60))
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
    elif name == "bell":
        p.drawArc(QtCore.QRectF(s * 0.30, s * 0.20, s * 0.40, s * 0.40), 0, 180 * 16)
        line(0.30, 0.40, 0.24, 0.70)
        line(0.70, 0.40, 0.76, 0.70)
        line(0.20, 0.70, 0.80, 0.70)
        p.drawArc(QtCore.QRectF(s * 0.42, s * 0.74, s * 0.16, s * 0.12), 180 * 16, 180 * 16)
        line(0.5, 0.14, 0.5, 0.20)


_THEME = "dark"   # текущая тема; меняется в stylesheet(theme_name)


class _VectorIconEngine(QtGui.QIconEngine):
    """
    Иконка, которая рисуется В МОМЕНТ ОТРИСОВКИ цветами текущей темы (ICON_*, ACCENT).
    Поэтому после смены темы иконки сами становятся читаемыми — их не нужно
    пересоздавать (раньше пиксмапы кэшировались в цвете старой темы).
    """

    def __init__(self, name: str):
        super().__init__()
        self._name = name

    def clone(self) -> "_VectorIconEngine":
        return _VectorIconEngine(self._name)

    def _color(self, mode, state) -> str:
        Mode, State = QtGui.QIcon.Mode, QtGui.QIcon.State
        if mode == Mode.Disabled:
            return ICON_DISABLED
        if state == State.On:
            return ACCENT
        return ICON_HOVER if mode == Mode.Active else ICON_NORMAL

    def paint(self, painter: QtGui.QPainter, rect: QtCore.QRect, mode, state) -> None:
        painter.save()
        painter.translate(rect.topLeft())
        paint_icon(painter, self._name, self._color(mode, state), min(rect.width(), rect.height()))
        painter.restore()

    def pixmap(self, size: QtCore.QSize, mode, state) -> QtGui.QPixmap:
        ratio = 2
        pm = QtGui.QPixmap(size.width() * ratio, size.height() * ratio)
        pm.fill(QtCore.Qt.GlobalColor.transparent)
        pm.setDevicePixelRatio(ratio)
        p = QtGui.QPainter(pm)
        self.paint(p, QtCore.QRect(0, 0, size.width(), size.height()), mode, state)
        p.end()
        return pm


def icon(name: str, size: int = 16) -> QtGui.QIcon:
    """Монохромная иконка, следующая за текущей темой (обычная, hover, неактивная, включённая)."""
    return QtGui.QIcon(_VectorIconEngine(name))


# ------------------------------------------------- картинки для QSS (стрелки, галочка)

@lru_cache(maxsize=None)
def _assets(theme: str = "dark") -> dict[str, str]:
    """Рисует маленькие png для стрелок списков/счётчиков и галочки; возвращает пути (с «/»)."""
    paths: dict[str, str] = {}
    try:
        _ASSET_DIR.mkdir(parents=True, exist_ok=True)

        def save(name: str, painter_fn, w: int = 16, h: int = 16) -> None:
            img = QtGui.QImage(w, h, QtGui.QImage.Format.Format_ARGB32)
            img.fill(QtCore.Qt.GlobalColor.transparent)
            p = QtGui.QPainter(img)
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            painter_fn(p)
            p.end()
            path = _ASSET_DIR / f"{theme}_{name}"   # свой файл на тему: Qt кэширует картинки QSS по пути
            img.save(str(path))
            paths[name] = path.as_posix()

        def chevron(up: bool, color: str):
            def draw(p: QtGui.QPainter) -> None:
                p.setPen(_pen(color, 1.8))
                y0, y1 = (10, 5.5) if up else (5.5, 10)
                p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(4, y0), QtCore.QPointF(8, y1), QtCore.QPointF(12, y0)]))
            return draw

        def tick(p: QtGui.QPainter) -> None:
            p.setPen(_pen("#ffffff", 1.9))
            p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(3.5, 8.5), QtCore.QPointF(6.5, 11.5), QtCore.QPointF(12.5, 4.5)]))

        save("down.png", chevron(False, TEXT_DIM))
        save("up.png", chevron(True, TEXT_DIM))
        save("check.png", tick)
    except Exception:
        paths.clear()   # без картинок QSS работает, просто со стандартными стрелками
    return paths


# ------------------------------------------------------ системная шапка Windows

class _WindowsTitleBarFilter(QtCore.QObject):
    """Окрашивает системные заголовки всех окон Qt на Windows 11+.

    Красим не только при показе (Show), но и когда окно получает новый номер окна Windows (WinIdChange) и когда
    становится активным (WindowActivate) — 2.1.18: у вынесенных из раскладки окон (график, «Тики», панели в
    плавающем окне докинга) шапка оставалась системной тёмной, а не цвета основного окна: докинг пересоздаёт
    окно Windows уже после показа, и цвет, поставленный прежнему окну, терялся. Вызов дешёвый (микросекунды)."""

    _EVENTS = (QtCore.QEvent.Type.Show, QtCore.QEvent.Type.WinIdChange, QtCore.QEvent.Type.WindowActivate)
    _POLISH = QtCore.QEvent.Type.Polish

    def eventFilter(self, watched, event):
        kind = event.type()
        if kind == self._POLISH:
            # Отклик кнопок на нажатие (button_feedback, 2.1.43): тот же фильтр, чтобы не ставить второй на всё
            # приложение (каждый фильтр на Python — лишняя работа на каждом событии Qt).
            if isinstance(watched, QtWidgets.QPushButton):
                try:
                    import button_feedback
                    button_feedback.attach(watched)
                except Exception:
                    pass
            return False
        if not _CAPTION_ON:
            return False
        if kind in self._EVENTS:
            try:
                if (
                    isinstance(watched, QtWidgets.QWidget)
                    and watched.isWindow()
                    and (watched.windowFlags() & QtCore.Qt.WindowType.WindowType_Mask)
                    in (QtCore.Qt.WindowType.Window, QtCore.Qt.WindowType.Dialog, QtCore.Qt.WindowType.Tool)
                ):
                    # Отложенный вызов: HWND должен быть создан после Show. За это время окно может
                    # перестать быть окном (виджет без родителя показали, а потом положили в раскладку) —
                    # это проверяет _set_windows_caption.
                    QtCore.QTimer.singleShot(0, lambda w=watched: _set_windows_caption(w))
                elif (isinstance(watched, QtWidgets.QWidget) and watched.isWindow()
                      and event.type() == QtCore.QEvent.Type.Show
                      and not (watched.windowFlags() & QtCore.Qt.WindowType.FramelessWindowHint)
                      and (watched.windowFlags() & QtCore.Qt.WindowType.WindowType_Mask)
                      not in (QtCore.Qt.WindowType.ToolTip, QtCore.Qt.WindowType.Popup)):
                    _caption_log(watched, "тип окна не из списка — шапку не красим")
            except RuntimeError:
                pass
        return super().eventFilter(watched, event)


def _window_hwnd(widget) -> int:
    """HWND окна верхнего уровня, у которого он уже есть; 0 — не окно (или окна ещё нет).

    Только через windowHandle(): QWidget.winId() у дочернего виджета не «узнаёт» номер, а СОЗДАЁТ ему
    собственное окно Windows — и по правилам Qt ещё всем его предкам и соседям на каждом уровне. Так было
    до 2.0.96: флажок «Звук» окна «Уведомления» показывался до того, как попадал в раскладку, через миг
    становился дочерним, и отложенный вызов отсюда превращал в отдельные HWND-окна панель, её кнопки,
    списки и всю цепочку докинга до главного окна. Плавающее окно с такой панелью перерисовывалось
    кусками (белые и «застывшие» полосы после «развернуть» и при перетаскивании края), а каждый шаг
    изменения размера стоил ~20 мс вместо 2–5."""
    if not widget.isWindow():
        return 0
    handle = widget.windowHandle()
    if handle is not None:
        return int(handle.winId())
    # Окна нет у Qt, но номер окна Windows у виджета может уже быть (плавающее окно докинга): internalWinId
    # только читает его, ничего не создавая (в отличие от winId), — 2.1.19.
    try:
        return int(widget.internalWinId() or 0)
    except Exception:
        return 0


_CAPTION_LOGGED: set = set()


def _caption_log(widget, text: str) -> None:
    """Диагностика цвета шапки (2.1.19): по одной строке в журнал на вид окна и исход — почему у вынесенных
    окон шапка не того цвета, что у основного. Не больше 40 строк за запуск. Вопрос с шапками закрыт
    (2.1.22), поэтому с 2.1.57 строки «[шапка]» пишутся только при переменной окружения FX_CAPTION_LOG=1."""
    if os.getenv("FX_CAPTION_LOG", "").strip() not in ("1", "true", "yes", "on"):
        return
    try:
        kind = type(widget).__name__
        key = (kind, text.split("(", 1)[-1] if "ответ" in text else text.split("(")[0])
        if key in _CAPTION_LOGGED or len(_CAPTION_LOGGED) >= 40:
            return
        _CAPTION_LOGGED.add(key)
        flags = int(widget.windowFlags().value) if hasattr(widget.windowFlags(), "value") else 0
        print(f"[шапка] {kind} «{widget.windowTitle()[:40]}» (флаги {flags:#x}): {text}", file=sys.stderr)
    except Exception:
        pass


def _native_windows(widget, hwnd: int) -> list[tuple[int, str]]:
    """Окна Windows, которым красить шапку: [(номер, откуда он)]. Сначала — номер от Qt (если это окно — его окно
    верхнего уровня), затем — окна нашего процесса с тем же заголовком.

    Зачем второе (2.1.22): у плавающего окна докинга (вынесенный график, «Тики») Qt отдаёт номер, который Windows
    окном не считает, — DwmSetWindowAttribute отвечал 0x80070006 («неверный описатель»), и шапка оставалась
    системной. Настоящее окно находится перебором окон процесса по заголовку."""
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.WinDLL("user32")
    user32.GetAncestor.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, ctypes.c_uint]
    user32.IsWindow.argtypes = [wintypes.HWND]
    found: list[tuple[int, str]] = []
    if hwnd and user32.IsWindow(hwnd):
        root = user32.GetAncestor(hwnd, 2) or hwnd            # GA_ROOT: окно верхнего уровня
        found.append((int(root), "Qt" if int(root) == hwnd else "Qt, окно-владелец"))
    title = str(widget.windowTitle() or "")
    if title:
        pid = os.getpid()
        matches: list[int] = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def visit(handle, _param):
            owner = wintypes.DWORD()
            user32.GetWindowThreadProcessId(handle, ctypes.byref(owner))
            if owner.value == pid and user32.IsWindowVisible(handle):
                buf = ctypes.create_unicode_buffer(512)
                user32.GetWindowTextW(handle, buf, 512)
                if buf.value == title:
                    matches.append(int(handle))
            return True

        user32.EnumWindows(visit, 0)
        for handle in matches:
            if all(handle != known for known, _how in found):
                found.append((handle, "по заголовку"))
    return found


def _set_windows_caption(widget) -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes
        if not widget.isWindow():
            return                     # уже не окно (стало панелью) — шапки нет
        hwnd = _window_hwnd(widget)
        dwmapi = ctypes.WinDLL("dwmapi")
        # DWMWA_CAPTION_COLOR=35, DWMWA_TEXT_COLOR=36; COLORREF = 0x00BBGGRR.
        def colorref(hex_color: str) -> int:
            value = hex_color.lstrip("#")
            r, g, b = (int(value[i:i + 2], 16) for i in (0, 2, 4))
            return r | (g << 8) | (b << 16)
        caption = ctypes.c_int(colorref(TITLEBAR_COLOR))
        text_color = ctypes.c_int(colorref(TITLEBAR_TEXT_COLOR))
        targets = _native_windows(widget, hwnd)
        if not targets:
            _caption_log(widget, f"окно Windows не найдено (номер от Qt {hwnd:#x}) — шапка не окрашена")
            return
        for target, how in targets:
            code = dwmapi.DwmSetWindowAttribute(
                ctypes.c_void_p(target), 35, ctypes.byref(caption), ctypes.sizeof(caption)
            )
            dwmapi.DwmSetWindowAttribute(
                ctypes.c_void_p(target), 36, ctypes.byref(text_color), ctypes.sizeof(text_color)
            )
            _caption_log(widget, f"окно {target:#x} ({how}), цвет {TITLEBAR_COLOR}, ответ Windows "
                                 f"{code & 0xFFFFFFFF:#x}" + (" (принято)" if code == 0 else " (отказ)"))
    except Exception as exc:
        # На неподдерживаемых сборках Windows оставляем системную шапку как есть.
        _caption_log(widget, f"ошибка {type(exc).__name__}: {exc}")


_CAPTION_ON = sys.platform == "win32"     # цвет шапки — только Windows; отклик кнопок — везде


def install_windows_titlebar_color(app) -> None:
    """Установить цвет шапки для главного окна, диалогов и отдельных окон (Windows) и отклик кнопок на нажатие
    (button_feedback, все системы) — один фильтр событий на всё приложение."""
    event_filter = _WindowsTitleBarFilter(app)
    app.installEventFilter(event_filter)
    # Сохраняем ссылку, чтобы фильтр не был удалён сборщиком мусора.
    app._fx_windows_titlebar_filter = event_filter


# ------------------------------------------------------------------ QSS

def stylesheet(theme_name: str | None = None) -> str:
    """
    QSS выбранной темы (dark/light). Без аргумента — текущая тема: вызов stylesheet()
    из любого окна раньше молча переключал палитру обратно на тёмную.
    """
    global _THEME
    if theme_name is None:
        theme_name = _THEME
    _THEME = "light" if str(theme_name).lower() == "light" else "dark"
    global BG_WINDOW, BG_PANEL, BG_CONTROL, BG_INPUT, BG_HOVER, BG_PRESSED
    global BORDER, BORDER_STRONG, TEXT, TEXT_DIM, TEXT_DISABLED, ACCENT, ACCENT_BG
    global ICON_NORMAL, ICON_HOVER, ICON_DISABLED, SELECTED_TEXT, HOVER_TINT
    global TITLEBAR_COLOR, TITLEBAR_TEXT_COLOR

    base = base_colors(_THEME)
    BG_WINDOW, BG_PANEL, BG_CONTROL, BG_INPUT = base["BG_WINDOW"], base["BG_PANEL"], base["BG_CONTROL"], base["BG_INPUT"]
    BG_HOVER, BG_PRESSED = base["BG_HOVER"], base["BG_PRESSED"]
    BORDER, BORDER_STRONG = base["BORDER"], base["BORDER_STRONG"]
    TEXT, TEXT_DIM, TEXT_DISABLED = base["TEXT"], base["TEXT_DIM"], base["TEXT_DISABLED"]
    ACCENT, ACCENT_BG = base["ACCENT"], base["ACCENT_BG"]
    ICON_NORMAL, ICON_HOVER, ICON_DISABLED = base["ICON_NORMAL"], base["ICON_HOVER"], base["ICON_DISABLED"]
    SELECTED_TEXT, HOVER_TINT = base["SELECTED_TEXT"], base["HOVER_TINT"]
    TITLEBAR_COLOR, TITLEBAR_TEXT_COLOR = base["TITLEBAR_COLOR"], base["TITLEBAR_TEXT_COLOR"]
    _apply_user_colors()

    a = _assets(_THEME)
    down = f"image: url({a['down.png']});" if "down.png" in a else ""
    up = f"image: url({a['up.png']});" if "up.png" in a else ""
    check = f"image: url({a['check.png']});" if "check.png" in a else ""

    tab_selected = TEXT if _THEME == "light" else "#ffffff"   # выбранная вкладка — на фоне окна
    extra = _light_extra() if _THEME == "light" else ""
    return f"""
QMainWindow, QDialog, QMenu {{ background-color: {BG_PANEL}; color: {TEXT}; }}
QLabel {{ color: {TEXT}; background: transparent; }}
QLabel:disabled {{ color: {TEXT_DISABLED}; }}

QToolTip {{
    background-color: {BG_CONTROL}; color: {TEXT};
    border: 1px solid {BORDER_STRONG}; padding: 3px 6px;
}}

/* кнопки: компактные, плоские, чёткие состояния */
QPushButton, QToolButton {{
    background-color: {BG_CONTROL}; color: {TEXT};
    border: 1px solid {BORDER}; border-radius: 3px;
    padding: 2px 10px; min-height: 18px;
}}
QPushButton:hover, QToolButton:hover {{ background-color: {BG_HOVER}; border-color: {BORDER_STRONG}; }}
QPushButton:pressed, QToolButton:pressed {{ background-color: {BG_PRESSED}; }}
QPushButton:checked, QToolButton:checked {{
    background-color: {ACCENT_BG}; border-color: {ACCENT}; color: {SELECTED_TEXT};
}}
QPushButton:disabled, QToolButton:disabled {{
    background-color: {BG_PANEL}; color: {TEXT_DISABLED}; border-color: {BORDER};
}}
QPushButton:focus {{ outline: none; }}

/* поля ввода и списки */
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {{
    background-color: {BG_INPUT}; color: {TEXT};
    border: 1px solid {BORDER}; border-radius: 3px;
    padding: 1px 6px; min-height: 18px;
    selection-background-color: {ACCENT_BG}; selection-color: {SELECTED_TEXT};
}}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover, QLineEdit:hover {{ border-color: {BORDER_STRONG}; }}
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QLineEdit:focus {{ border-color: {ACCENT}; }}
QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QLineEdit:disabled {{
    color: {TEXT_DISABLED}; background-color: {BG_PANEL};
}}
QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: center right; width: 16px; border: none; }}
QComboBox::down-arrow {{ {down} width: 12px; height: 12px; }}
QComboBox QAbstractItemView {{
    background-color: {BG_PANEL}; color: {TEXT};
    border: 1px solid {BORDER_STRONG}; outline: 0;
    selection-background-color: {ACCENT_BG}; selection-color: {SELECTED_TEXT};
}}
QSpinBox::up-button, QDoubleSpinBox::up-button {{
    subcontrol-origin: border; subcontrol-position: top right; width: 14px; border: none; background: transparent;
}}
QSpinBox::down-button, QDoubleSpinBox::down-button {{
    subcontrol-origin: border; subcontrol-position: bottom right; width: 14px; border: none; background: transparent;
}}
QSpinBox::up-button:hover, QSpinBox::down-button:hover,
QDoubleSpinBox::up-button:hover, QDoubleSpinBox::down-button:hover {{ background-color: {BG_HOVER}; }}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{ {up} width: 10px; height: 10px; }}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{ {down} width: 10px; height: 10px; }}

QCheckBox {{ color: {TEXT}; spacing: 6px; background: transparent; }}
QCheckBox:disabled {{ color: {TEXT_DISABLED}; }}
QCheckBox::indicator {{
    width: 13px; height: 13px; border: 1px solid {BORDER_STRONG};
    border-radius: 2px; background-color: {BG_INPUT};
}}
QCheckBox::indicator:hover {{ border-color: {TEXT_DIM}; }}
QCheckBox::indicator:checked {{ background-color: {ACCENT}; border-color: {ACCENT}; {check} }}
QCheckBox::indicator:disabled {{ border-color: {BORDER}; background-color: {BG_PANEL}; }}

QSplitter::handle {{ background-color: {BORDER}; }}

/* панели приложения */
QWidget {{ color: {TEXT}; }}
QMainWindow, QWidget#centralWidget, QWidget[fxWindow="true"] {{ background-color: {BG_WINDOW}; }}
QToolBar {{ background-color: {BG_PANEL}; border: none; border-bottom: 1px solid {BORDER}; spacing: 4px; padding: 3px 5px; }}
QStatusBar {{ background-color: {BG_PANEL}; color: {TEXT_DIM}; border-top: 1px solid {BORDER}; }}
QStatusBar::item {{ border: none; }}

QTabWidget::pane {{ background-color: {BG_WINDOW}; border: 1px solid {BORDER}; top: -1px; }}
QTabBar::tab {{ background-color: {BG_PANEL}; color: {TEXT_DIM}; border: 1px solid {BORDER}; padding: 5px 11px; margin-right: 1px; }}
QTabBar::tab:hover {{ color: {TEXT}; background-color: {BG_HOVER}; }}
QTabBar::tab:selected {{ color: {tab_selected}; background-color: {BG_WINDOW}; border-bottom: 2px solid {ACCENT}; }}
QTabBar::tab:disabled {{ color: {TEXT_DISABLED}; }}

QTableView, QTableWidget, QTreeView, QListView {{
    background-color: {BG_WINDOW}; alternate-background-color: {BG_PANEL};
    color: {TEXT}; gridline-color: {BORDER};
    border: 1px solid {BORDER}; selection-background-color: {ACCENT_BG};
    selection-color: {SELECTED_TEXT}; outline: 0;
}}
QHeaderView::section {{ background-color: {BG_PANEL}; color: {TEXT_DIM};
    border: none; border-right: 1px solid {BORDER}; border-bottom: 1px solid {BORDER};
    padding: 4px 7px; }}
QTableCornerButton::section {{ background-color: {BG_PANEL}; border: none; }}

QMenu {{ border: 1px solid {BORDER_STRONG}; padding: 3px 0; }}
QMenu::item {{ padding: 4px 22px 4px 12px; }}
QMenu::item:selected {{ background-color: {ACCENT_BG}; color: {SELECTED_TEXT}; }}
QMenu::item:disabled {{ color: {TEXT_DISABLED}; }}
QMenu::separator {{ height: 1px; background: {BORDER}; margin: 3px 6px; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {BORDER_STRONG}; min-height: 24px; border-radius: 4px; margin: 1px; }}
QScrollBar::handle:vertical:hover {{ background: {TEXT_DIM}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0; }}
QScrollBar::handle:horizontal {{ background: {BORDER_STRONG}; min-width: 24px; border-radius: 4px; margin: 1px; }}
QScrollBar::handle:horizontal:hover {{ background: {TEXT_DIM}; }}
{extra}
"""


# Цвета тем без пользовательских (stylesheet берёт их отсюда; appearance — для цветов «по умолчанию»).
_BASE = {
    # Светло-серая, как светлый интерфейс Photoshop: нейтральный серый без синевы, поля ввода — светлее панелей.
    "light": {"BG_WINDOW": "#e1e1e1", "BG_PANEL": "#eaeaea", "BG_CONTROL": "#e4e4e4", "BG_INPUT": "#f6f6f6",
              "BG_HOVER": "#d6d6d6", "BG_PRESSED": "#cbcbcb", "BORDER": "#c6c6c6", "BORDER_STRONG": "#9c9c9c",
              "TEXT": "#1e1e1e", "TEXT_DIM": "#5a5a5a", "TEXT_DISABLED": "#a0a0a0",
              "ACCENT": "#2878d0", "ACCENT_BG": "#cddff5",
              "ICON_NORMAL": "#5b6470", "ICON_HOVER": "#20242a", "ICON_DISABLED": "#aeb4bc",
              "SELECTED_TEXT": "#0f3d73", "HOVER_TINT": "0, 0, 0",
              "TITLEBAR_COLOR": "#bcbcbc", "TITLEBAR_TEXT_COLOR": "#1a1a1a"},        # серая шапка окон
    "dark": {"BG_WINDOW": "#1c1d20", "BG_PANEL": "#232529", "BG_CONTROL": "#2a2c31", "BG_INPUT": "#18191c",
             "BG_HOVER": "#33363c", "BG_PRESSED": "#3b3f46", "BORDER": "#383b41", "BORDER_STRONG": "#4a4e56",
             "TEXT": "#d3d6db", "TEXT_DIM": "#8c9199", "TEXT_DISABLED": "#5b5f66",
             "ACCENT": "#3d8bfd", "ACCENT_BG": "#1f3556",
             "ICON_NORMAL": "#aab0b8", "ICON_HOVER": "#eceef1", "ICON_DISABLED": "#555960",
             "SELECTED_TEXT": "#ffffff", "HOVER_TINT": "255, 255, 255",
             "TITLEBAR_COLOR": "#103638", "TITLEBAR_TEXT_COLOR": "#e0e8e8"},        # тёмный teal
}


def base_colors(theme_name: str | None = None) -> dict:
    """Цвета темы без пользовательских — не трогая текущих (stylesheet меняет глобальные)."""
    return dict(_BASE["light" if str(theme_name or _THEME).lower() == "light" else "dark"])


def mix(a: str, b: str, t: float) -> str:
    """Цвет между a и b: t = 0 — a, 1 — b (#RRGGBB). Оттенки фона и текста из одного выбранного цвета."""
    ca, cb = QtGui.QColor(a), QtGui.QColor(b)
    k = max(0.0, min(1.0, float(t)))
    return QtGui.QColor(round(ca.red() + (cb.red() - ca.red()) * k), round(ca.green() + (cb.green() - ca.green()) * k),
                        round(ca.blue() + (cb.blue() - ca.blue()) * k)).name()


def is_dark(color: str) -> bool:
    c = QtGui.QColor(color)
    return (0.299 * c.red() + 0.587 * c.green() + 0.114 * c.blue()) < 128


def shades(bg: str, text: str) -> dict:
    """Оттенки интерфейса из фона и текста (2.1.83, «Фон окон» / «Текст» и фон окон «Аналитики»): панели и кнопки —
    шаг к цвету текста, поля ввода — шаг от него (темнее на тёмном фоне, светлее на светлом), рамки и
    приглушённый текст — между фоном и текстом. Так один выбранный цвет фона перекрашивает всё согласованно."""
    away = "#000000" if is_dark(bg) else "#ffffff"
    return {"BG_WINDOW": bg, "BG_PANEL": mix(bg, text, 0.035), "BG_CONTROL": mix(bg, text, 0.07),
            "BG_INPUT": mix(bg, away, 0.18), "BG_HOVER": mix(bg, text, 0.12), "BG_PRESSED": mix(bg, text, 0.16),
            "BORDER": mix(bg, text, 0.14), "BORDER_STRONG": mix(bg, text, 0.24),
            "TEXT": text, "TEXT_DIM": mix(text, bg, 0.4), "TEXT_DISABLED": mix(text, bg, 0.62)}


def _apply_user_colors() -> None:
    """Цвета из «Настройки» → «Цвета» → «Цвета приложения» (appearance.py) поверх темы: акцент, шапка окон,
    а с 2.1.83 — фон окон и текст (app.bg / app.text): из них по shades() выводятся панели, кнопки, поля, рамки и
    приглушённый текст. Не задано — цвета темы как есть."""
    global ACCENT, TITLEBAR_COLOR
    global BG_WINDOW, BG_PANEL, BG_CONTROL, BG_INPUT, BG_HOVER, BG_PRESSED, BORDER, BORDER_STRONG
    global TEXT, TEXT_DIM, TEXT_DISABLED
    try:
        import appearance
        ACCENT = appearance.override("app.accent", _THEME) or ACCENT
        TITLEBAR_COLOR = appearance.override("app.titlebar", _THEME) or TITLEBAR_COLOR
        bg, text = appearance.override("app.bg", _THEME), appearance.override("app.text", _THEME)
    except Exception:
        return
    if not bg and not text:
        return
    sh = shades(QtGui.QColor(bg or BG_WINDOW).name(), QtGui.QColor(text or TEXT).name())
    if bg:
        BG_WINDOW, BG_PANEL, BG_CONTROL, BG_INPUT = sh["BG_WINDOW"], sh["BG_PANEL"], sh["BG_CONTROL"], sh["BG_INPUT"]
        BG_HOVER, BG_PRESSED, BORDER, BORDER_STRONG = sh["BG_HOVER"], sh["BG_PRESSED"], sh["BORDER"], sh["BORDER_STRONG"]
    TEXT, TEXT_DIM, TEXT_DISABLED = sh["TEXT"], sh["TEXT_DIM"], sh["TEXT_DISABLED"]


def _light_extra() -> str:
    """Светлая тема: то, что в тёмной рисует системная (тёмная) палитра Windows —
    строка меню, многострочные поля, рамки групп, фоны областей прокрутки."""
    return f"""
QMenuBar {{ background-color: {BG_PANEL}; color: {TEXT}; border-bottom: 1px solid {BORDER}; }}
QMenuBar::item {{ background: transparent; padding: 4px 10px; }}
QMenuBar::item:selected {{ background-color: {BG_HOVER}; }}
QMenuBar::item:pressed {{ background-color: {ACCENT_BG}; color: {SELECTED_TEXT}; }}
QPlainTextEdit, QTextEdit {{
    background-color: {BG_INPUT}; color: {TEXT}; border: 1px solid {BORDER}; border-radius: 3px;
    selection-background-color: {ACCENT_BG}; selection-color: {SELECTED_TEXT};
}}
QPlainTextEdit:focus, QTextEdit:focus {{ border-color: {ACCENT}; }}
QGroupBox {{ color: {TEXT}; }}
"""


# --------------------------------------------------------------- палитра Qt

def apply_palette(app, theme_name: str | None = None) -> None:
    """Палитра приложения под тему — для того, что стиль (QSS) не задаёт явно.
    На Windows в тёмном режиме Qt берёт тёмную системную палитру, и в светлой теме часть
    окон оставалась тёмной, а текст — тёмным по тёмному.
    Тёмная тема — исходная палитра (как было); светлая — своя, из цветов темы."""
    if app is None:
        return
    if app.property("fx_base_palette") is None:
        app.setProperty("fx_base_palette", QtGui.QPalette(app.palette()))
    name = "light" if str(theme_name or _THEME).lower() == "light" else "dark"
    hints = app.styleHints()
    if hasattr(hints, "setColorScheme"):        # Qt 6.8+: Fusion рисует под нужную схему
        try:
            if name == "light":
                hints.setColorScheme(QtCore.Qt.ColorScheme.Light)
            elif hasattr(hints, "unsetColorScheme"):
                hints.unsetColorScheme()
        except Exception:
            pass
    if name != "light":
        base = app.property("fx_base_palette")
        if isinstance(base, QtGui.QPalette):
            app.setPalette(base)
        return
    C = QtGui.QColor
    R = QtGui.QPalette.ColorRole
    pal = QtGui.QPalette()
    for role, color in (
        (R.Window, BG_WINDOW), (R.WindowText, TEXT), (R.Base, BG_INPUT), (R.AlternateBase, BG_CONTROL),
        (R.Text, TEXT), (R.Button, BG_CONTROL), (R.ButtonText, TEXT), (R.BrightText, "#000000"),
        (R.ToolTipBase, BG_PANEL), (R.ToolTipText, TEXT), (R.PlaceholderText, TEXT_DIM),
        (R.Highlight, ACCENT_BG), (R.HighlightedText, SELECTED_TEXT), (R.Link, ACCENT),
        (R.Light, "#ffffff"), (R.Midlight, BG_HOVER), (R.Mid, BORDER), (R.Dark, BORDER_STRONG),
        (R.Shadow, "#9c9c9c"),
    ):
        pal.setColor(role, C(color))
    for role in (R.WindowText, R.Text, R.ButtonText):
        pal.setColor(QtGui.QPalette.ColorGroup.Disabled, role, C(TEXT_DISABLED))
    app.setPalette(pal)


# ----------------------------------------------------------- цвета графиков

# Фон и подписи графиков (свечи, тики, открытый интерес, опционы). Свечи, объёмы и линии
# остаются своих цветов — они читаются и на тёмном, и на белом фоне.
CHART_COLORS = {
    "dark": {
        "bg": "#131722", "fg": "#d1d4dc",
        "overlay": "rgba(19, 23, 34, 215)", "overlay_border": "#2a2e39",   # панель управления поверх графика
        "label": "#ffffff",                                                # подписи-метки на графике
        "clock": "#ffe600",
    },
    "light": {
        "bg": "#ffffff", "fg": "#3d434c",
        "overlay": "rgba(234, 234, 234, 235)", "overlay_border": "#c6c6c6",
        "label": "#20242a",
        "clock": "#7b2fbe",
    },
}


def saved_theme() -> str:
    """Тема из настроек терминала (можно звать до создания QApplication)."""
    try:
        name = str(QtCore.QSettings("MyTradingTools", "FxTerminal").value("appearance/theme", "dark"))
    except Exception:
        name = "dark"
    return "light" if name.lower() == "light" else "dark"


def chart_color(key: str, theme_name: str | None = None) -> str:
    """Цвет графиков текущей темы: bg, fg, overlay, overlay_border, label, clock.
    Фон (bg) и текст (fg) можно поменять в «Настройки» → «Цвета» → «Цвета графиков» (appearance.py)."""
    name = "light" if str(theme_name or _THEME).lower() == "light" else "dark"
    if key in ("bg", "fg"):
        try:
            import appearance
            user = appearance.override(f"chart.{key}", name)
            if user:
                return user
        except Exception:
            pass
    table = CHART_COLORS.get(name)
    return table.get(key, CHART_COLORS["dark"].get(key, "#ffffff"))
