# -*- coding: utf-8 -*-
"""LIVE-торговля через Finam Trade API (gRPC) — без Qt.

Код перенесён из стакана (прежний scalper_widget.FinamGrpcGateway) без изменения логики (шаг 6.3 плана):
    * заявки и отмены — в одном потоке-исполнителе, строго по порядку;
    * объём заявки резервируется сразу при постановке в очередь (pending_qty) — лимиты риска
      видят его до ответа PlaceOrder; резерв снимается по подтверждённому статусу или через 10 с;
    * однозначный отказ сервера (INVALID_ARGUMENT, PERMISSION_DENIED …) — заявки нет;
      тайм-аут / обрыв — результат неизвестен: повторно не отправляем, сразу полная сверка;
    * PlaceOrder не повторяется автоматически (RetryPolicy(max_attempts=1) у сессии):
      повтор мог бы продублировать заявку;
    * закрытие / реверс — только после подтверждённой отмены всех заявок и повторной проверки
      на сервере, что активных заявок по инструменту не осталось; повторный F4/F5 в течение
      15 с пропускается; отказ в отмене «cannot be canceled» (FAILED_PRECONDITION / NOT_FOUND) —
      заявка уже в конечном статусе: после проверки по GetOrders она убирается и считается снятой;
    * конечный статус заявки запоминается: устаревшее «активное» состояние (ответ PlaceOrder, пришедший
      позже FILLED из потока) заявку в список не возвращает;
    * свои исполнения — из потока SubscribeTrades, повторы отсеиваются по trade_id, сделки
      дня до запуска не считаются исполнениями этой сессии;
    * пропажа позиции без исполнения не принимается сразу (2.1.51): во время утренних работ Finam отдаёт
      пустой счёт (13–14.11, 05:54–06:10 — от секунды до 4,5 минут), и стакан «закрывал» позицию: ложные
      уведомления о сделке, сброс ручных Stop-loss / Take-profit, снятие серверного TP. Теперь позиция
      держится прежней, пока не придёт подтверждение — исполнение (поток сделок или исполненная заявка)
      или пока брокер не показывает её дольше VANISH_HOLD_SEC (см. FinamLiveEngine._apply_account).

Сессия (session) — любой объект с методом client(), возвращающим FinamClient: в терминале —
scalper_widget.SharedTradingSession поверх FinamGateway (одно соединение на рыночные данные
и заявки). client() вызывается на каждый запрос, поэтому после переподключения терминала
движок сам берёт новый клиент.

Обёртка для стакана — scalper_widget.LiveGateway: переводит колбэки в Qt-сигналы.
"""
from __future__ import annotations

import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Callable

from google.type.decimal_pb2 import Decimal as DecimalMsg

from finam_trade_api import (
    AuthError, InvalidArgumentError, NotFoundError, PermissionDeniedError, RateLimitError,
)
from finam_trade_api.accounts import GetAccountRequest
from finam_trade_api.orders import (
    CancelOrderRequest, Order, OrdersRequest, OrderType, SubscribeOrdersRequest, SubscribeTradesRequest,
    TimeInForce,
)

from brokers.paper.engine import tick_decimals


def _noop(*_args) -> None:
    pass


def fmt_price(price, decimals):
    return f"{price:.{decimals}f}".replace(".", ",")


def status_name(st) -> str:
    """Имя статуса заявки Finam (ORDER_STATUS_CANCELED …) по числу из OrderState; не вышло — само число."""
    try:
        return st.DESCRIPTOR.fields_by_name["status"].enum_type.values_by_number[int(st.status)].name
    except Exception:
        return str(int(getattr(st, "status", 0)))


def gone_text(prev, name: str, decimals: int, tick: float, rtt_ms: float | None,
              filled: bool = False) -> str | None:
    """Строка журнала: своя активная заявка prev (LiveOrder) ушла из активных со статусом name.
    Исполнение (filled — исполнено всё, или статус FILLED) — None (его пишет поток сделок: «BUY 1 @ …»); снятие по нашей команде — с временем ответа;
    снятие не нами (брокер, биржа, другой терминал), отклонение, истечение — с именем статуса."""
    price = fmt_price(prev.tick * tick, decimals)
    what = f"{prev.side} {prev.qty} @ {price}"
    upper = name.upper()
    if filled or ("FILLED" in upper and "PARTIAL" not in upper):
        return None
    if "REJECT" in upper:
        return f"✖ отклонена {what} ({name})"
    if rtt_ms is not None:
        return f"× снята {what} · {rtt_ms:.0f} мс"
    if "EXPIRE" in upper or "DONE_FOR_DAY" in upper:
        return f"× истекла {what} ({name})"
    return f"× снята не из этого окна {what} ({name})"


@dataclass
class LiveOrder:
    """Своя активная лимитная заявка — в том же виде, что заявки PAPER (стакан рисует их одинаково)."""
    id: str
    side: str          # "BUY" | "SELL"
    tick: int          # цена в номерах шага
    qty: int           # остаток
    tag: str = "entry"  # entry | tp | close | ext (ext — выставлена не этим окном)
    ahead: int = 0     # только для PAPER; в LIVE очередь знает биржа


SIDE_BUY, SIDE_SELL = 1, 2
DEFINITE_REJECTS = (InvalidArgumentError, PermissionDeniedError, RateLimitError, NotFoundError, AuthError)
# Простые вызовы SDK поднимают «сырой» grpc.RpcError — классифицируем по коду статуса.
# Однозначный отказ: сервер заявку не принял. Всё остальное (тайм-аут, обрыв, внутренняя ошибка) — неопределённо.
DEFINITE_CODES = {"INVALID_ARGUMENT", "PERMISSION_DENIED", "UNAUTHENTICATED", "NOT_FOUND", "RESOURCE_EXHAUSTED",
                  "FAILED_PRECONDITION", "OUT_OF_RANGE", "UNIMPLEMENTED", "ALREADY_EXISTS"}


def rpc_code(exc):
    try:
        code = exc.code() if callable(getattr(exc, "code", None)) else None
        return code.name if code is not None else ""
    except Exception:
        return ""


def rpc_text(exc):
    """Короткий текст ошибки: «INVALID_ARGUMENT: причина» вместо многострочного repr gRPC."""
    code = rpc_code(exc)
    try:
        details = exc.details() if callable(getattr(exc, "details", None)) else ""
    except Exception:
        details = ""
    return f"{code}: {details}" if code else str(exc)


_CYRILLIC = re.compile(r"[А-Яа-яЁё]")
_REJECT_NUMBER = re.compile(r"\[(\d+)\]\s*")
_CODE_PREFIX = re.compile(r"^([A-Z_]+): (?:\1: )+")


def reject_reason(text: str) -> str:
    """Причина отказа для человека (2.1.78) из rpc_text: Finam пишет «INVALID_ARGUMENT: INVALID_ARGUMENT:
    [157]Equities shortage by value of 1 pcsНе хватает собственных бумаг - 1 штук» — английский и русский текст
    подряд. Есть русский — остаётся он и номер отказа: «Не хватает собственных бумаг - 1 штук (код 157)»;
    русского нет — исходный текст, только без повтора кода («INVALID_ARGUMENT: price out of range»)."""
    raw = _CODE_PREFIX.sub(r"\1: ", str(text or "").strip())
    found = _CYRILLIC.search(raw)
    if found is None:
        return raw
    number = _REJECT_NUMBER.search(raw)
    reason = raw[found.start():].strip().rstrip(".")
    return f"{reason} (код {number.group(1)})" if number else reason


def is_definite_reject(exc):
    return isinstance(exc, DEFINITE_REJECTS) or rpc_code(exc) in DEFINITE_CODES


# client_order_id у Finam: не длиннее 20 символов, только буквы, цифры и пробел (иначе INVALID_ARGUMENT).
# Свои заявки: "fx" + тег + случайный hex, без разделителей: fxentry3f9a1c0b7d2e4, fxtp…, fxclose….
# По префиксу окно узнаёт свою заявку и её тег после переподключения; прочие — "ext".
CLIENT_ORDER_ID_MAX = 20
CLIENT_ORDER_ID_PREFIX = "fx"
OWN_ORDER_TAGS = ("entry", "close", "tp")


def make_client_order_id(tag):
    return f"{CLIENT_ORDER_ID_PREFIX}{tag}{uuid.uuid4().hex}"[:CLIENT_ORDER_ID_MAX]


def client_order_tag(cid):
    """Тег своей заявки по client_order_id ("entry" / "tp" / "close") или "ext" — чужая / ручная."""
    if cid and cid.startswith(CLIENT_ORDER_ID_PREFIX):
        rest = cid[len(CLIENT_ORDER_ID_PREFIX):]
        for tag in OWN_ORDER_TAGS:
            if rest.startswith(tag):
                return tag
    return "ext"


ACTIVE_ORDER_STATUSES = {1, 2, 11, 17, 18, 21}   # NEW, PARTIALLY_FILLED, PENDING_NEW, FORWARDING, WAIT, WATCHING


def dec(x):
    """google.type.Decimal -> float (пустое поле = 0)."""
    v = x.value
    return float(v) if v else 0.0


def open_positions(account) -> dict[str, int]:
    """Ответ GetAccount -> {инструмент: количество со знаком} только для открытых позиций.
    По нему терминал после перезапуска решает, какие окна стакана открыть сразу в LIVE."""
    found: dict[str, int] = {}
    for p in getattr(account, "positions", None) or ():
        qty = int(round(dec(p.quantity)))
        if p.symbol and qty:
            found[p.symbol] = qty
    return found


def account_brief(account) -> str:
    """Коротко, что было в ответе брокера, где пропала позиция: сколько позиций и сколько средств. Для журнала —
    понять, отличается ли «пустой» ответ во время работ у брокера от настоящего счёта без позиций."""
    try:
        count = len(list(getattr(account, "positions", None) or ()))
    except Exception:
        count = 0
    try:
        equity = getattr(account, "equity", None)
        money = f"{dec(equity):.0f}" if equity is not None and equity.value else "не указаны"
    except Exception:
        money = "не указаны"
    return f"в ответе брокера позиций: {count}, средства: {money}"


def fetch_open_positions(session, account_id: str) -> dict[str, int]:
    """Открытые позиции счёта у брокера (блокирующий вызов — только из потока)."""
    return open_positions(session.client().accounts.GetAccount(GetAccountRequest(account_id=account_id)))


class OrderStreamRunner(threading.Thread):
    """Серверный поток gRPC с автопереподключением (экспоненциально: 0,5 → 5 с).

    Торговые потоки (заявки, исполнения, счёт) — со своей, короткой паузой: после разрыва
    состояние счёта нужно вернуть как можно скорее. Потоки рыночных данных переподключает
    FinamGateway со своей шкалой (1 … 60 с)."""

    def __init__(self, name, stop, open_fn, handle, on_up=None, on_down=None):
        super().__init__(daemon=True, name=f"grpc-stream-{name}")
        self.sname, self.stop_event, self.open_fn, self.handle = name, stop, open_fn, handle
        self.on_up, self.on_down = on_up, on_down
        self.call = None

    def cancel(self):
        call = self.call
        if call is not None:
            try:
                call.cancel()
            except Exception:
                pass

    def run(self):
        backoff = 0.5
        while not self.stop_event.is_set():
            try:
                self.call = self.open_fn()
                got = False
                for msg in self.call:
                    if self.stop_event.is_set():
                        break
                    if not got:
                        got = True
                        backoff = 0.5
                        if self.on_up:
                            self.on_up(self.sname)
                    self.handle(msg)
                if not self.stop_event.is_set() and self.on_down:
                    self.on_down(self.sname, None)           # сервер закрыл поток
            except Exception as exc:
                if self.stop_event.is_set():
                    break
                if self.on_down:
                    self.on_down(self.sname, exc)
            finally:
                self.call = None
            if self.stop_event.wait(backoff):
                break
            backoff = min(5.0, backoff * 2)


# ---- LIVE-движок ----------------------------------------------------------------------

class FinamLiveEngine:
    """
    LIVE по gRPC для одного инструмента и одного счёта.
    PlaceOrder / CancelOrder — унарные вызовы в отдельном потоке (строго по порядку);
    состояние приходит потоками SubscribeOrders, SubscribeTrades и SubscribeAccount — без опроса,
    плюс полная сверка GetOrders / GetAccount после старта, после разрыва и раз в 30 с.
    Подтверждение PlaceOrder сразу попадает в orders, не дожидаясь потока.

    Колбэки вызываются из фоновых потоков (исполнитель команд и потоки gRPC) — обёртка
    сама переводит их в GUI-поток (в стакане это Qt-сигналы с очередью).
    """
    name = "LIVE"
    RESYNC_SEC = 30.0
    # Позиция пропала у брокера, а исполнения не было — не верим, пока не подтвердится (_apply_account):
    VANISH_FILL_SEC = 120.0       # исполнение не раньше чем за столько секунд до пропажи — пропажа настоящая
    VANISH_ANNOUNCE_SEC = 20.0    # держим дольше — строка в журнал (короткая гонка «счёт раньше сделки» молчит)
    VANISH_HOLD_SEC = 900.0       # брокер не показывает позицию дольше — принимаем, что её нет

    def __init__(self, session, account_id, symbol, tick,
                 on_orders: Callable[[], None] = _noop,
                 on_position: Callable[[], None] = _noop,
                 on_fill: Callable[[str, float, int], None] = _noop,
                 on_message: Callable[[str], None] = _noop):
        # Колбэки задаём до запуска потоков: события могут прийти сразу.
        self.on_orders, self.on_position = on_orders, on_position
        self.on_fill, self.on_message = on_fill, on_message
        # Состояние для окна (раньше — поля базового Gateway стакана).
        self.orders: list[LiveOrder] = []
        self.pos_qty = 0
        self.pos_avg = 0.0
        # Позиция получена от брокера хотя бы раз. До этого pos_qty == 0 значит «ещё не знаем», а не «позиции
        # нет»: дневной лимит убытка (services/live_guard.py) стартовую позицию берёт только после этого.
        self.account_seen = False
        self.realized = 0.0                       # в LIVE не считаем: результат отдаёт брокер
        self.broker_unrealized: float | None = None  # деньги, от брокера
        self.broker_daily: float | None = None
        self.session, self.account_id, self.symbol, self.tick = session, account_id, symbol, tick
        self.decimals = tick_decimals(tick)
        self._stop = threading.Event()
        self._cmd: queue.Queue = queue.Queue()
        self._orders: dict[str, LiveOrder] = {}
        # Заявки, уже виденные в конечном статусе (исполнена / снята / отклонена): id -> время. Конечный статус
        # не отменяется, поэтому более позднее «активное» состояние — устаревшее и не применяется (см. _apply_state).
        self._final_ids: dict[str, float] = {}
        self._cancel_sent: dict[str, float] = {}     # id заявки -> perf_counter() отправки CancelOrder (журнал)
        self._seen_trades: set[str] = set()
        self._started = time.time()
        self._lock = threading.Lock()
        # Резервируем объём сразу при постановке команды в очередь: GUI может
        # принять несколько кликов раньше, чем PlaceOrder вернёт ответ.
        self._pending_submits: dict[str, tuple[str, int]] = {}
        self._pending_client_ids: dict[str, str] = {}
        self._pending_time: dict[str, float] = {}
        self._close_lock = threading.Lock()
        self._close_in_progress = False
        self._close_started = 0.0
        self._need_resync = True
        self._last_error = ""
        self._resync_fails = 0                      # сверок не удалось подряд (строка в журнал — одна на серию)
        # Сверка позиции с исполнениями (пропажа без исполнения — см. _apply_account).
        self._clock = time.monotonic                # в проверках подменяется
        self._pos_lock = threading.Lock()
        self._last_exec: float | None = None        # когда последний раз видели исполнение по инструменту
        self._exec_seen: dict[str, float] = {}      # id заявки -> исполненный объём, который уже видели
        self._own_cids: set[str] = set()            # client_order_id заявок этого окна
        self._vanish_since: float | None = None     # с какого момента брокер не показывает позицию
        self._vanish_told = False
        self._vanish_info = ""
        self.last_rtt_ms = None
        self.runners: list[OrderStreamRunner] = []
        # Один поток-исполнитель: команды (заявка, отмена, закрытие) строго по порядку.
        # Запускаем после того, как все поля созданы.
        self._worker_thread = threading.Thread(target=self._worker, daemon=True, name="grpc-orders")
        self._worker_thread.start()
        self._open_streams()
        self._cmd.put(self._resync)

    # ---- потоки ---------------------------------------------------------------------

    def _open_streams(self):
        acc = self.account_id

        def od():
            return self.session.client().orders

        specs = (
            ("orders", lambda: od().SubscribeOrders(SubscribeOrdersRequest(account_id=acc)), self._on_orders),
            ("fills", lambda: od().SubscribeTrades(SubscribeTradesRequest(account_id=acc)), self._on_fills),
            ("account", lambda: self.session.client().accounts.SubscribeAccount(GetAccountRequest(account_id=acc)),
             self._on_account),
        )
        for name, opener, handler in specs:
            r = OrderStreamRunner(name, self._stop, opener, handler, self._up_cb, self._down_cb)
            self.runners.append(r)
            r.start()

    def _up_cb(self, name):
        if name == "account" and self._need_resync:
            self._need_resync = False
            self._cmd.put(self._resync)
            self.on_message("LIVE: связь с торговым API установлена")

    def _down_cb(self, name, exc):
        self._need_resync = True
        self._err(f"LIVE: поток {name} прерван ({rpc_text(exc) if exc else 'закрыт сервером'}), переподключение…")

    def _err(self, text):
        """Ошибка связи — в журнал, но одна и та же подряд не повторяется. Числа в тексте не сравниваются:
        12.11 Finam час не отвечал на сверку, и «deadline exceeded after 29.9999…s» с разными долями секунды
        дала 35 одинаковых по смыслу строк."""
        key = re.sub(r"\d+(?:[.,]\d+)?", "#", text)
        if key != self._last_error:
            self._last_error = key
            self.on_message(text)

    # ---- состояние: заявки / исполнения / счёт --------------------------------------------

    def _publish_orders(self):
        with self._lock:
            new = sorted(self._orders.values(), key=lambda o: (o.tick, o.id))
        key = lambda lst: [(x.id, x.tick, x.qty, x.side, x.tag) for x in lst]   # noqa: E731
        changed = key(new) != key(self.orders)
        self.orders = new
        if changed:
            self.on_orders()

    def _apply_state(self, st, publish=True, live=True):
        """Состояние заявки -> список своих активных заявок. live=False — состояние из полной сверки (GetOrders):
        она повторяет и старые заявки, поэтому незнакомая исполненная заявка оттуда — не свежее исполнение."""
        o = st.order
        if o.symbol != self.symbol:
            return
        remaining = dec(st.remaining_quantity)
        if remaining <= 0 and int(st.status) in ACTIVE_ORDER_STATUSES:
            remaining = dec(st.initial_quantity) - dec(st.executed_quantity)
        is_active = int(st.status) in ACTIVE_ORDER_STATUSES and remaining > 0
        active = is_active and o.HasField("limit_price")
        gone = None                        # своя активная заявка ушла из активных — строка в журнал
        with self._lock:
            cid = o.client_order_id or ""
            reservation_id = self._pending_client_ids.get(cid)
            self._note_execution(st.order_id, cid, dec(st.executed_quantity), live)
            # Лимитная заявка теперь учитывается через self.orders. Рыночную
            # держим в резерве до терминального статуса: позиция может обновиться позже.
            if reservation_id and (not is_active or o.HasField("limit_price")):
                self._pending_submits.pop(reservation_id, None)
                self._pending_client_ids.pop(cid, None)
            if client_order_tag(cid) == "close" and not is_active:
                self._close_in_progress = False
            if not is_active:
                self._remember_final(st.order_id)
            elif st.order_id in self._final_ids:
                # Гонка 30.10 18:48: заявка исполнилась сразу, поток заявок принёс FILLED раньше ответа PlaceOrder,
                # а ответ (ещё NEW) возвращал её в список — «зависшая» заявка, которую потом нельзя снять.
                active = False
            if active:
                self._orders[st.order_id] = LiveOrder(
                    st.order_id, "BUY" if o.side == SIDE_BUY else "SELL",
                    int(round(dec(o.limit_price) / self.tick)), int(round(remaining)),
                    client_order_tag(cid))
            else:
                prev = self._orders.pop(st.order_id, None)
                if prev is not None and not is_active:
                    t0 = self._cancel_sent.pop(st.order_id, None)
                    rtt = (time.perf_counter() - t0) * 1000.0 if t0 is not None else None
                    initial, executed = dec(st.initial_quantity), dec(st.executed_quantity)
                    gone = gone_text(prev, status_name(st), self.decimals, self.tick, rtt,
                                     filled=initial > 0 and executed >= initial)
        if gone:
            self.on_message(gone)
        if publish:
            self._publish_orders()

    def _note_execution(self, order_id, cid, executed, live):
        """Исполненный объём заявки вырос — это исполнение по инструменту (вызывать под self._lock). Считается
        только рост: сверка и переподключение потока присылают те же заявки заново. Заявка, которую видим впервые
        уже исполненной, считается исполнением, если она своя или пришла из потока (live), а не из сверки."""
        if executed <= 0:
            return
        seen = self._exec_seen.get(order_id)
        if seen is None and len(self._exec_seen) > 5000:
            self._exec_seen.clear()
        self._exec_seen[order_id] = max(executed, seen or 0.0)
        if (seen is None and (live or cid in self._own_cids)) or (seen is not None and executed > seen):
            self._last_exec = self._clock()

    FINAL_KEEP_SEC = 600.0          # сколько помнить заявки в конечном статусе (гонке хватает секунд)

    def _remember_final(self, order_id):
        """Запомнить заявку в конечном статусе (вызывать под self._lock)."""
        now = time.monotonic()
        self._final_ids[order_id] = now
        if len(self._final_ids) > 500:
            for oid, t in list(self._final_ids.items()):
                if now - t > self.FINAL_KEEP_SEC:
                    del self._final_ids[oid]

    def _on_orders(self, msg):
        for st in msg.orders:
            self._apply_state(st, publish=False)
        self._publish_orders()

    def _on_fills(self, msg):
        for t in msg.trades:
            if t.symbol != self.symbol or not t.trade_id or t.trade_id in self._seen_trades:
                continue
            self._seen_trades.add(t.trade_id)
            if t.timestamp.seconds and t.timestamp.seconds < self._started - 2:
                continue                                            # старые сделки дня — не исполнения этой сессии
            side = "BUY" if t.side == SIDE_BUY else "SELL"
            price, qty = dec(t.price), int(round(dec(t.size)))
            self._last_exec = self._clock()
            self.on_message(f"{side} {qty} @ {fmt_price(price, self.decimals)}")
            self.on_fill(side, price, qty)
            self._confirm_vanish()                                  # пропажа позиции подтвердилась сделкой

    def _apply_account(self, acc):
        """Позиция по инструменту из ответа брокера (поток счёта и сверка).

        Пропажа позиции без исполнения не принимается сразу. Утром Finam перезапускает сервисы и отдаёт пустой
        счёт: 13.11 и 14.11 позиция VKCO «исчезала» на 1 с, на 4,5 мин и ещё на 1 с (05:54–06:10), и стакан
        каждый раз закрывал её у себя — ложные уведомления «Сделка», сброс ручных Stop-loss / Take-profit,
        снятие серверного TP, расхождение в дневном лимите. Правило: брокер показывает 0, у нас позиция есть —
            * было исполнение (сделка из потока или исполненная заявка) за последние VANISH_FILL_SEC — верим;
            * не было — держим прежнюю позицию и ждём: исполнение придёт (_confirm_vanish) — принимаем,
              позиция вернётся — ничего не меняем, брокер не показывает её дольше VANISH_HOLD_SEC — принимаем
              (закрытие без сделки бывает: экспирация). Изменения позиции не до нуля принимаются как раньше.
        Пока позиция «под сомнением», закрытие и стоп заявку не отправляют (_close): если позиции на самом
        деле уже нет, закрывающая заявка открыла бы обратную."""
        qty, avg, unreal, daily = 0, 0.0, None, self.broker_daily
        for p in acc.positions:
            if p.symbol == self.symbol:
                qty = int(round(dec(p.quantity)))
                avg = dec(p.average_price)
                # None — брокер не прислал поле (0 — это «не заполнено», а не «ноль прибыли»)
                unreal = dec(p.unrealized_pnl) if p.HasField("unrealized_pnl") else None
                daily = dec(p.daily_pnl) if p.HasField("daily_pnl") else daily
                break
        note, report, hold = None, False, False
        with self._pos_lock:
            now, held = self._clock(), self.pos_qty
            if qty == 0 and held != 0 and not self._executed_recently(now):
                if self._vanish_since is None:
                    self._vanish_since, self._vanish_told = now, False
                    self._vanish_info = account_brief(acc)
                waited = now - self._vanish_since
                if waited < self.VANISH_HOLD_SEC:
                    hold = True
                    if waited >= self.VANISH_ANNOUNCE_SEC and not self._vanish_told:
                        self._vanish_told = True
                        note = (f"LIVE: брокер не показывает позицию {held:+d} уже {waited:.0f} с, а исполнения не "
                                f"было — считаю её открытой, жду подтверждения до {self.VANISH_HOLD_SEC / 60:.0f} мин "
                                f"({self._vanish_info})")
                else:
                    note = (f"LIVE: брокер не показывает позицию {held:+d} дольше {self.VANISH_HOLD_SEC / 60:.0f} мин "
                            f"— считаю её закрытой")
            elif self._vanish_since is not None and qty != 0:
                note = (f"LIVE: брокер {now - self._vanish_since:.0f} с не показывал позицию, исполнений не было — "
                        f"позиция оставалась {held:+d} ({self._vanish_info})")
            if not hold:                                    # принимаем ответ брокера
                self._vanish_since = None
                if qty and avg <= 0 and (qty > 0) == (self.pos_qty > 0) and self.pos_avg > 0:
                    avg = self.pos_avg                      # средняя цена не пришла — оставляем прежнюю
                changed = (qty, round(avg, 6)) != (self.pos_qty, round(self.pos_avg, 6))
                self.pos_qty, self.pos_avg = qty, (avg if qty else 0.0)
                self.broker_unrealized, self.broker_daily = unreal, daily
                first, self.account_seen = not self.account_seen, True
                report = changed or first               # первый ответ брокера сообщаем всегда, даже «позиции нет»
        if note:
            self.on_message(note)
        if report:
            self.on_position()

    def _executed_recently(self, now) -> bool:
        return self._last_exec is not None and now - self._last_exec <= self.VANISH_FILL_SEC

    def _confirm_vanish(self) -> None:
        """Пришло исполнение, пока позиция держалась «под сомнением» (счёт обновился раньше потока сделок) —
        пропажа настоящая: позиции нет."""
        with self._pos_lock:
            if self._vanish_since is None:
                return
            self._vanish_since = None
            self.pos_qty, self.pos_avg, self.broker_unrealized = 0, 0.0, None
        self.on_position()

    def _on_account(self, msg):
        self._apply_account(msg)

    def _resync(self):
        """Полная сверка: заявки и позиция из GetOrders / GetAccount (после старта, разрыва и раз в 30 с)."""
        try:
            c = self.session.client()
            resp = c.orders.GetOrders(OrdersRequest(account_id=self.account_id))
            with self._lock:
                self._orders.clear()
            for st in resp.orders:
                self._apply_state(st, publish=False, live=False)
            self._publish_orders()
            self._apply_account(c.accounts.GetAccount(GetAccountRequest(account_id=self.account_id)))
            self._expire_reservations(5.0)          # после сверки состояние известно — старые резервы не нужны
        except Exception as exc:
            self._resync_fails += 1
            self._err(f"LIVE: сверка не удалась: {rpc_text(exc)}")
        else:
            if self._resync_fails:                  # серия неудач закончилась — следующая снова попадёт в журнал
                self.on_message(f"LIVE: сверка снова проходит (не удалась {self._resync_fails} раз подряд)")
                self._resync_fails, self._last_error = 0, ""

    # ---- команды (по порядку, в отдельном потоке) ---------------------------------------

    def _worker(self):
        next_resync = time.monotonic() + self.RESYNC_SEC
        while not self._stop.is_set():
            try:
                fn = self._cmd.get(timeout=1.0)
            except queue.Empty:
                fn = None
            if self._stop.is_set():
                break
            if fn is not None:
                try:
                    fn()
                except Exception as exc:
                    self.on_message(f"LIVE: ошибка команды: {rpc_text(exc)}")
            if time.monotonic() >= next_resync:
                next_resync = time.monotonic() + self.RESYNC_SEC
                self._resync()

    def _build_order(self, side, qty, tag, tick):
        cid = make_client_order_id(tag)          # формат и ограничения Finam — у CLIENT_ORDER_ID_MAX
        kw = dict(account_id=self.account_id, symbol=self.symbol,
                  quantity=DecimalMsg(value=str(int(qty))),
                  side=SIDE_BUY if side == "BUY" else SIDE_SELL, client_order_id=cid)
        if tick is None:
            kw["type"] = OrderType.ORDER_TYPE_MARKET
        else:
            kw["type"] = OrderType.ORDER_TYPE_LIMIT
            kw["time_in_force"] = TimeInForce.TIME_IN_FORCE_DAY
            kw["limit_price"] = DecimalMsg(value=f"{tick * self.tick:.{self.decimals}f}")
        return Order(**kw)

    def _place(self, side, qty, tag, tick, reservation_id=None):
        t0 = time.perf_counter()
        order = self._build_order(side, qty, tag, tick)
        with self._lock:
            if len(self._own_cids) > 5000:
                self._own_cids.clear()
            self._own_cids.add(order.client_order_id)       # своя заявка: её исполнение подтверждает смену позиции
            if reservation_id is not None:
                self._pending_client_ids[order.client_order_id] = reservation_id
        try:
            st = self.session.client().orders.PlaceOrder(order)
        except Exception as exc:
            if is_definite_reject(exc):
                # Сервер явно отказал (неверные параметры, нет прав, лимит запросов): заявки нет — резерв снимаем.
                self._release_reservation(reservation_id)
                # В окне — понятная причина (reject_reason), полный ответ сервера — в журнал терминала
                print(f"[LIVE {self.symbol}] отказ сервера: {rpc_text(exc)}", flush=True)
                self.on_message(f"Заявка отклонена: {reject_reason(rpc_text(exc))}")
                return "rejected"
            # Тайм-аут / обрыв не доказывает, что сервер не принял заявку: резерв остаётся до сверки
            # (её делает _resync), повторную отправку не разрешаем.
            self.on_message(
                f"Неопределённый результат PlaceOrder ({side} {qty}): {rpc_text(exc)}. "
                "Повторно не отправляйте заявку до проверки заявок и позиции в терминале брокера.")
            self._cmd.put(self._resync)
            return "uncertain"
        else:
            self.last_rtt_ms = (time.perf_counter() - t0) * 1000.0
            self._apply_state(st)                            # заявка в orders сразу, не дожидаясь потока
            price = f" @ {fmt_price(tick * self.tick, self.decimals)}" if tick is not None else " MKT"
            self.on_message(f"→ {side} {qty}{price} · {self.last_rtt_ms:.0f} мс")
            remaining = dec(st.remaining_quantity)
            if remaining <= 0:
                remaining = dec(st.initial_quantity) - dec(st.executed_quantity)
            if int(st.status) in ACTIVE_ORDER_STATUSES and remaining > 0:
                return "active"
            return "done"
        finally:
            # Резерв снимается в _apply_state только после подтверждённого
            # терминального статуса либо когда лимитная заявка попала в self.orders.
            pass

    def _queue_place(self, side, qty, tag, tick):
        reservation_id = uuid.uuid4().hex
        with self._lock:
            self._pending_submits[reservation_id] = (side, int(qty))
            self._pending_time[reservation_id] = time.monotonic()
        self._cmd.put(lambda: self._place(side, qty, tag, tick, reservation_id))

    PENDING_TTL = 10.0          # резерв старше — уже виден в заявках / позиции или потерян: в риск не считаем

    def _release_reservation(self, rid):
        if rid is None:
            return
        with self._lock:
            self._pending_submits.pop(rid, None)
            self._pending_time.pop(rid, None)
            for cid, r in list(self._pending_client_ids.items()):
                if r == rid:
                    self._pending_client_ids.pop(cid, None)

    def _expire_reservations(self, ttl):
        now = time.monotonic()
        for rid, t in list(self._pending_time.items()):
            if now - t > ttl:
                self._release_reservation(rid)

    def pending_qty(self, side):
        now = time.monotonic()
        with self._lock:
            return sum(qty for rid, (pending_side, qty) in self._pending_submits.items()
                       if pending_side == side and now - self._pending_time.get(rid, now) < self.PENDING_TTL)

    def pending_count(self):
        now = time.monotonic()
        with self._lock:
            return sum(1 for rid in self._pending_submits if now - self._pending_time.get(rid, now) < self.PENDING_TTL)

    # Сервер отказал в отмене, потому что заявка уже в конечном статусе (исполнена / снята / отклонена):
    # FAILED_PRECONDITION «Order … cannot be canceled» (журнал 30.10 18:48) или NOT_FOUND.
    CANCEL_FINAL_CODES = {"FAILED_PRECONDITION", "NOT_FOUND"}

    def _cancel(self, order_id):
        """Снять заявку. True — на сервере она больше не активна (снята сейчас или уже была в конечном статусе).
        Время отправки — в _cancel_sent: когда заявка уйдёт из активных, журнал напишет «× снята … · N мс»."""
        with self._lock:
            self._cancel_sent[order_id] = time.perf_counter()
        try:
            st = self.session.client().orders.CancelOrder(
                CancelOrderRequest(account_id=self.account_id, order_id=order_id))
            self._apply_state(st)
            return int(st.status) not in ACTIVE_ORDER_STATUSES
        except Exception as exc:
            if rpc_code(exc) in self.CANCEL_FINAL_CODES:
                # Локальный список отстал от сервера (исполнение / снятие ещё не дошло из потока заявок):
                # спрашиваем сервер. Не активна — убираем у себя и считаем отмену выполненной; раньше такая
                # «зависшая» заявка срывала закрытие позиции (F4), пока не пройдёт сверка раз в 30 с.
                active = self._order_active_on_server(order_id)
                if active is False:
                    self.on_message(f"Заявка {order_id} уже не активна на сервере (исполнена или снята) — "
                                    "убрана из списка")
                    return True
            self.on_message(f"Отмена не удалась для {order_id}: {rpc_text(exc)}")
            return False

    def _order_active_on_server(self, order_id):
        """Активна ли заявка по GetOrders: True / False, None — сервер не ответил. Попутно обновляет
        состояние всех заявок инструмента, а пропавшую из ответа заявку убирает из локального списка."""
        try:
            resp = self.session.client().orders.GetOrders(OrdersRequest(account_id=self.account_id))
        except Exception as exc:
            self.on_message(f"LIVE: не удалось проверить заявку {order_id}: {rpc_text(exc)}")
            return None
        active = False
        for st in resp.orders:
            self._apply_state(st, publish=False)
            if st.order_id == order_id and int(st.status) in ACTIVE_ORDER_STATUSES:
                active = order_id in self._orders or not st.order.HasField("limit_price")
        if not active:
            with self._lock:
                self._orders.pop(order_id, None)
        self._publish_orders()
        return active

    def place_limit(self, side, tick, qty, tag="entry"):
        self._queue_place(side, qty, tag, tick)

    def place_market(self, side, qty, tag="entry"):
        self._queue_place(side, qty, tag, None)

    def cancel(self, order_id):
        self._cmd.put(lambda: self._cancel(order_id))

    def cancel_all(self, tag=None):
        ids = [o.id for o in list(self.orders) if tag is None or o.tag == tag]
        for oid in ids:
            self._cmd.put(lambda oid=oid: self._cancel(oid))

    def _close(self, reverse_lot, limits, force=False):
        """Закрытие/реверс только после подтверждённой отмены и повторной сверки.

        force — Stop-loss (сработал стоп — снять ВСЕ заявки инструмента и закрыть позицию).
        Обычное закрытие (F4, кнопка) при заявке, которую не удалось снять, отменяется — иначе она могла бы
        исполниться следом и открыть позицию. Для стопа так нельзя: позиция в убытке осталась бы открытой.
        Поэтому при force снимаются и заявки, которых окно не знает (выставлены в приложении Finam, в другом
        окне), а если какую-то снять не удалось или сервер не ответил — позиция всё равно закрывается,
        в журнал — предупреждение с номерами заявок."""
        failed: list[str] = []
        c = None
        try:
            # Не полагаемся только на локальный список: после отмены перечитываем
            # серверные заявки и не закрываем позицию, если что-то осталось активным.
            for o in list(self.orders):
                if not self._cancel(o.id):
                    if not force:
                        self.on_message("Закрытие отменено: не удалось подтвердить снятие всех заявок.")
                        return
                    failed.append(o.id)
            c = self.session.client()
            resp = c.orders.GetOrders(OrdersRequest(account_id=self.account_id))
            active_left = []
            for st in resp.orders:
                if st.order.symbol == self.symbol and int(st.status) in ACTIVE_ORDER_STATUSES:
                    remaining = dec(st.remaining_quantity)
                    if remaining <= 0:
                        remaining = dec(st.initial_quantity) - dec(st.executed_quantity)
                    if remaining > 0:
                        active_left.append(st.order_id)
            if active_left and force:                 # стоп: снять и чужие заявки инструмента
                active_left = [oid for oid in active_left if oid in failed or not self._cancel(oid)]
            if active_left and not force:
                self.on_message(
                    "Закрытие отменено: на сервере ещё есть активные заявки "
                    + ", ".join(active_left[:5]) + ". Проверьте их в терминале брокера.")
                self._resync()
                return
            if active_left:
                self.on_message(
                    "STOP-LOSS: не удалось снять заявки " + ", ".join(active_left[:5])
                    + " — позицию закрываю всё равно. Проверьте их в терминале брокера.")
            self._apply_account(c.accounts.GetAccount(GetAccountRequest(account_id=self.account_id)))
        except Exception as exc:
            if not force:
                self.on_message(f"Закрытие отменено: не удалось проверить заявки/позицию: {exc}")
                return
            self.on_message(f"STOP-LOSS: не удалось проверить заявки/позицию ({exc}) — закрываю по известной "
                            "позиции. Проверьте заявки в терминале брокера.")
        if self._vanish_since is not None:
            # Позиция «под сомнением» (_apply_account): брокер её сейчас не показывает, исполнения не было.
            # Закрывающая заявка при действительно закрытой позиции открыла бы обратную — не отправляем.
            self.on_message(("STOP-LOSS: " if force else "Закрытие отменено: ")
                            + f"брокер сейчас не показывает позицию {self.pos_qty:+d} (исполнения не было) — "
                            "закрывающую заявку не отправляю. Проверьте позицию в терминале брокера.")
            return
        q = self.pos_qty
        if q == 0:
            self.on_message("Закрытие: позиция уже нулевая.")
            return
        side = "SELL" if q > 0 else "BUY"
        tick = limits.get(side) if limits else None
        return self._place(side, abs(q) + reverse_lot, "close", tick)

    def close_position(self, reverse_lot=0, limits=None, force=False):
        """force — закрытие по Stop-loss: см. _close."""
        # Блокируем повторный F4/F5, пока первая операция не завершена.
        with self._close_lock:
            if self._close_in_progress and time.monotonic() - self._close_started < 15.0:
                self.on_message("Закрытие/реверс уже выполняется — повторная команда пропущена.")
                return
            self._close_in_progress = True            # по истечении 15 с защита снимается, чтобы не «залипнуть»
            self._close_started = time.monotonic()

        def run_close():
            keep_guard = False
            try:
                result = self._close(reverse_lot, limits, force)
                keep_guard = result in ("active", "uncertain")
            finally:
                if not keep_guard:
                    with self._close_lock:
                        self._close_in_progress = False
        self._cmd.put(run_close)

    def shutdown(self):
        self._stop.set()
        for r in self.runners:
            r.cancel()
        self._cmd.put(lambda: None)
        if threading.current_thread() is not self._worker_thread:
            self._worker_thread.join(timeout=2.0)
