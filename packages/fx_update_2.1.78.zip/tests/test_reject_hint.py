# -*- coding: utf-8 -*-
"""Отказ брокера виден в стакане (2.1.78): причина отказа Finam по-русски (brokers.finam.live.reject_reason) и
красная плашка поверх стакана (scalper_widget._Toast) для сообщений о проблеме; обычные сообщения — только строкой
состояния. Настройки терминала и стаканов не трогаются.  Запуск:  python tests/test_reject_hint.py"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):           # offscreen-Qt не видит шрифты Windows без подсказки
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))
os.environ["SCALPER_CONFIG"] = os.path.join(tempfile.mkdtemp(prefix="fx_scalper_cfg_"), "scalper.json")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import appearance  # noqa: E402

_INI = os.path.join(tempfile.mkdtemp(prefix="fx_paint_"), "settings.ini")
appearance._settings = lambda: QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)

import scalper_widget as sw  # noqa: E402

SYM = "CRZ6@RTSX"


class FakeManager:
    hub = None
    friendly = staticmethod(lambda s: s)
    from_friendly = staticmethod(lambda t: t)
    symbols = staticmethod(lambda: [SYM])
    catalog_symbols = staticmethod(lambda: [])


def _iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _window():
    s = sw.Settings()
    s.cluster_panel = True
    win = sw.TerminalScalperWindow(FakeManager(), SYM, "", 0.01, s, {}, embedded=True)
    win.ladder.resize(640, 820)
    rows = [(round(100 - i * 0.01, 2), 50 + i * 7, 0) for i in range(1, 61)]
    rows += [(round(100 + i * 0.01, 2), 0, 40 + i * 9) for i in range(0, 60)]
    win.on_book(rows, snapshot=True)
    now = datetime.now(timezone.utc)
    for m in range(40):                       # 40 минут сделок — несколько колонок кластеров
        for k in range(25):
            price = round(100 + ((k * 7 + m) % 21 - 10) * 0.01, 2)
            win.on_trade({"price": price, "size": 1 + (k % 5), "side": "BUY" if k % 2 else "SELL",
                          "timestamp": _iso(now - timedelta(minutes=m, seconds=k))})
    return win


from brokers.finam.live import reject_reason  # noqa: E402


def test_reject_reason_text():
    raw = "INVALID_ARGUMENT: INVALID_ARGUMENT: [157]Equities shortage by value of 1 pcsНе хватает собственных бумаг - 1 штук"
    assert reject_reason(raw) == "Не хватает собственных бумаг - 1 штук (код 157)"
    assert reject_reason("INVALID_ARGUMENT: price out of range") == "INVALID_ARGUMENT: price out of range"
    assert reject_reason("PERMISSION_DENIED: PERMISSION_DENIED: no rights") == "PERMISSION_DENIED: no rights"
    assert reject_reason("") == ""


def test_problem_banner_over_dom():
    win = _window()
    try:
        win.resize(260, 700)                      # узкий стакан: строка состояния обрезается
        win.show()
        APP.processEvents()
        toast, lad = win._toast, win.ladder
        assert toast.isHidden()
        win.flash("→ SELL 1 @ 231,55 · 130 мс")             # обычное сообщение — без плашки
        assert toast.isHidden()
        text = "Заявка отклонена: Не хватает собственных бумаг - 1 штук (код 157)"
        win.flash(text)
        APP.processEvents()
        assert not toast.isHidden() and toast.text() == text
        assert toast.parentWidget() is lad and lad.rect().contains(toast.geometry()), (toast.geometry(), lad.rect())
        assert toast.height() >= toast.heightForWidth(toast.width()), "текст не помещается в плашку"
        assert text in win.status_label.text()                  # и в строке состояния, как раньше
        lad.resize(lad.width() + 40, lad.height())              # стакан шире — плашка следом
        APP.processEvents()
        assert toast.width() == lad.width() - 12
        toast.mousePressEvent(None)                             # щелчок — убрать
        assert toast.isHidden()
        win.flash("Отказ: лот 10 > лимита 5")
        assert not toast.isHidden()
        toast._timer.timeout.emit()                             # время вышло — ушла сама
        assert toast.isHidden()
    finally:
        win.close()
        win.deleteLater()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
