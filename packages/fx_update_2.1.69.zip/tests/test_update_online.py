# -*- coding: utf-8 -*-
"""Обновления через интернет (2.1.68): подпись latest.json, цепочка версий, скачивание и проверка пакетов
(update_online.py), установка цепочки (updater.apply_chain), публикация (tools/publish_update.py) в локальный
репозиторий git. Без Qt и без интернета: «GitHub» — папка, адрес file://.  Запуск:  python tests/test_update_online.py
Часть с публикацией пропускается, если git не установлен."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import ed25519_lite as ed  # noqa: E402
import update_online as uo  # noqa: E402
import updater  # noqa: E402

SEED = bytes(range(1, 33))
PUB = base64.b64encode(ed.public_key(SEED)).decode("ascii")
KEYS = (PUB,)


def _terminal(folder: Path, version: str = "2.1.0") -> Path:
    """Папка «терминала»: version.py и один модуль."""
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "version.py").write_text(f'VERSION = "{version}"\n', encoding="utf-8")
    (folder / "mod_a.py").write_text("A = 0\n", encoding="utf-8")
    return folder


def _package(folder: Path, version: str, requires: str | None, value: int) -> Path:
    """Пакет обновления, как у tools/make_update.py: mod_a.py и version.py, manifest.json с суммами."""
    files = {"mod_a.py": f"A = {value}\n".encode(), "version.py": f'VERSION = "{version}"\n'.encode()}
    manifest = {"format": 1, "app": "FX Terminal", "version": version, "date": "2026-11-15",
                "changes": [f"изменение {version}"], "requires": requires, "delete": [], "pip": [],
                "build_rust": False, "checks": [],
                "files": {k: {"sha256": hashlib.sha256(v).hexdigest(), "size": len(v)} for k, v in files.items()}}
    path = folder / f"fx_update_{version}.zip"
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
        for name, data in files.items():
            zf.writestr(name, data)
    return path


def _site(folder: Path, packages: list[Path], seed: bytes = SEED) -> Path:
    """«Репозиторий обновлений» без git: packages/ и подписанный latest.json."""
    folder.mkdir(parents=True, exist_ok=True)
    entries = [uo.entry_for(p, uo.copy_package(p, folder)) for p in packages]
    payload = {"app": "FX Terminal", "published": "2026-11-15 20:00", "latest": entries[-1]["version"],
               "packages": entries}
    (folder / uo.INDEX_FILE).write_bytes(uo.index_bytes(uo.sign_index(payload, seed)))
    return folder


class _Url:
    """FX_UPDATES_URL на время проверки."""

    def __init__(self, folder: Path):
        self.url = folder.resolve().as_uri() + "/"

    def __enter__(self):
        self.saved = os.environ.get("FX_UPDATES_URL")
        os.environ["FX_UPDATES_URL"] = self.url
        return self

    def __exit__(self, *exc):
        if self.saved is None:
            os.environ.pop("FX_UPDATES_URL", None)
        else:
            os.environ["FX_UPDATES_URL"] = self.saved
        return False


def test_signed_index_roundtrip_and_damage():
    payload = {"app": "FX Terminal", "latest": "2.1.2", "packages": [{"version": "2.1.2", "changes": ["ё ✓"]}]}
    raw = uo.index_bytes(uo.sign_index(payload, SEED))
    assert uo.verify_index(raw, KEYS) == payload
    pretty = json.dumps(json.loads(raw), ensure_ascii=True, indent=4).encode()     # другие отступы — подпись та же
    assert uo.verify_index(pretty, KEYS) == payload
    index = json.loads(raw)
    index["payload"]["latest"] = "9.9.9"                                           # подменили данные
    for bad, words in ((json.dumps(index).encode(), "не сходится"), (b"{", "повреждён"),
                       (uo.index_bytes(uo.sign_index(payload, bytes(32))), "неизвестным ключом")):
        try:
            uo.verify_index(bad, KEYS)
            raise AssertionError("испорченный latest.json принят")
        except uo.OnlineError as exc:
            assert words in str(exc), exc
    try:
        uo.verify_index(raw, ())
        raise AssertionError("без ключей принят")
    except uo.OnlineError as exc:
        assert "нет ключа" in str(exc)
    assert uo.known_keys(("не base64!", base64.b64encode(b"short").decode(), PUB)) == \
        {uo.key_id(ed.public_key(SEED)): ed.public_key(SEED)}


def test_chain_planning():
    e = lambda v, r, f=True: {"version": v, "requires": r, "file": f"packages/fx_update_{v}.zip" if f else None}
    payload = {"packages": [e("2.1.3", "2.1.2"), e("2.1.1", "2.1.0"), e("2.1.2", "2.1.1"), e("2.1.0", None)]}
    steps, gap = uo.plan_chain(payload, "2.1.0")
    assert [s["version"] for s in steps] == ["2.1.1", "2.1.2", "2.1.3"] and gap is None
    steps, gap = uo.plan_chain(payload, "2.1.3")
    assert steps == [] and gap is None
    steps, gap = uo.plan_chain({"packages": [e("2.1.1", "2.1.0"), e("2.1.5", "2.1.4")]}, "2.1.0")
    assert [s["version"] for s in steps] == ["2.1.1"] and "нужна версия 2.1.4" in gap
    steps, gap = uo.plan_chain({"packages": [e("2.1.1", "2.1.0", f=False)]}, "2.1.0")
    assert steps == [] and "уже нет" in gap
    steps, gap = uo.plan_chain({"packages": [e("2.1.10", "2.1.9"), e("2.1.9", None)]}, "2.1.8")   # 10 > 9
    assert [s["version"] for s in steps] == ["2.1.9", "2.1.10"]


def test_check_download_and_install_chain():
    """Терминал 2.1.0, в репозитории 2.1.1 и 2.1.2: проверка скачивает оба пакета, updater ставит их по очереди;
    после этого — «последняя версия»."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        term = _terminal(tmp / "term")
        built = tmp / "built"
        built.mkdir()
        site = _site(tmp / "site", [_package(built, "2.1.1", "2.1.0", 1), _package(built, "2.1.2", "2.1.1", 2)])
        with _Url(site):
            assert uo.check(term, keys=()).status == uo.NO_KEY
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.OK, res.message
            assert [s["version"] for s in res.steps] == ["2.1.1", "2.1.2"] and res.target == "2.1.2"
            assert [c[0] for c in res.changes()] == ["2.1.2", "2.1.1"]
            assert all(Path(f).exists() and Path(f).parent == uo.downloads_dir(term) for f in res.files)
            cmd = uo.install_command(term, res)
            assert cmd[2] == "apply" and cmd[3:5] == res.files and "--wait-pid" in cmd
            again = uo.check(term, keys=KEYS)                       # скачанное и верное — не качается заново
            assert again.status == uo.OK and again.files == res.files
            out = updater.apply_chain(term, res.files, checks=False, log=lambda *_: None)
            assert out["status"] == "ok" and "2.1.1, 2.1.2" in out["message"], out
            assert updater.current_version(term) == "2.1.2" and (term / "mod_a.py").read_text() == "A = 2\n"
            last = json.loads((term / updater.INSTALL_DIR / updater.LAST_FILE).read_text(encoding="utf-8"))
            assert last["status"] == "ok" and "теперь версия 2.1.2" in last["message"]
            done = uo.check(term, keys=KEYS)
            assert done.status == uo.NONE and done.steps == [] and "последняя" in done.message


def test_bad_package_and_gap_are_reported():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        term = _terminal(tmp / "term")
        built = tmp / "built"
        built.mkdir()
        site = _site(tmp / "site", [_package(built, "2.1.1", "2.1.0", 1)])
        (site / "packages" / "fx_update_2.1.1.zip").write_bytes(b"PK-fake-package")      # пакет подменили на GitHub
        with _Url(site):
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.ERROR and ("размер" in res.message or "сумма" in res.message), res.message
            assert uo.install_command(term, res) is None
        gap_site = _site(tmp / "gap", [_package(built, "2.1.5", "2.1.4", 5)])
        with _Url(gap_site):
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.GAP and "2.1.4" in res.message and res.files == []
        with _Url(tmp / "нет такой папки"):
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.ERROR and "GitHub" in res.message


def test_chain_stops_on_failed_step():
    """Второй пакет цепочки не ставится (испорчен после скачивания) — первый остаётся, итог об этом говорит."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        term = _terminal(tmp / "term")
        p1 = _package(tmp, "2.1.1", "2.1.0", 1)
        p2 = _package(tmp, "2.1.2", "2.1.5", 2)                      # требует версию, которой нет
        out = updater.apply_chain(term, [p1, p2], checks=False, log=lambda *_: None)
        assert out["status"] != "ok" and "Перед этим установлены 2.1.1" in out["message"], out
        assert updater.current_version(term) == "2.1.1"


def _git_env():
    os.environ.setdefault("GIT_AUTHOR_NAME", "test")
    os.environ.setdefault("GIT_AUTHOR_EMAIL", "test@example.invalid")
    os.environ.setdefault("GIT_COMMITTER_NAME", "test")
    os.environ.setdefault("GIT_COMMITTER_EMAIL", "test@example.invalid")


def test_publish_to_local_git_repo():
    """tools/publish_update.py: ключ (не внутри git), публикация двух пакетов в «GitHub» (голый репозиторий),
    повторная публикация пропускает уже опубликованное, терминал находит и проверяет пакеты."""
    if shutil.which("git") is None:
        print("      (git не установлен — проверка публикации пропущена)")
        return
    import publish_update as pu
    _git_env()
    # ignore_cleanup_errors: файлы объектов git только для чтения — Windows не даёт удалить их вместе с папкой
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        tmp = Path(tmp)
        os.environ[pu.KEY_ENV] = str(tmp / "keys" / "update_signing.key")
        try:
            pub = pu.init_key()
            try:
                pu.init_key()
                raise AssertionError("ключ перезаписан")
            except pu.PublishError as exc:
                assert "уже есть" in str(exc)
            seed = pu.load_key()
            assert ed.public_key(seed) == pub
            subprocess.run(["git", "init", "--quiet", str(tmp / "inrepo")], check=True)
            try:
                pu.init_key(tmp / "inrepo" / "k.key")
                raise AssertionError("ключ внутри git принят")
            except pu.PublishError as exc:
                assert "репозитория git" in str(exc)
            origin = tmp / "origin.git"
            subprocess.run(["git", "init", "--quiet", "--bare", str(origin)], check=True)
            work = tmp / "work"
            pu.ensure_repo(work, url=str(origin), log=lambda *_: None)
            downloads = tmp / "dl"
            downloads.mkdir()
            _package(downloads, "2.1.1", "2.1.0", 1)
            p2 = _package(downloads, "2.1.2", "2.1.1", 2)
            found = pu.find_downloads(downloads, None)
            assert [p.name for p in found] == ["fx_update_2.1.1.zip", "fx_update_2.1.2.zip"]
            assert pu.publish(found, work, seed, dry_run=True, log=lambda *_: None) == ["2.1.1", "2.1.2"]
            assert not (work / uo.INDEX_FILE).exists()                       # пробный запуск ничего не пишет
            assert pu.publish(found, work, seed, log=lambda *_: None) == ["2.1.1", "2.1.2"]
            assert pu.publish([p2], work, seed, log=lambda *_: None) == []   # уже опубликовано
            assert pu.find_downloads(downloads, "2.1.2") == []
            clone = tmp / "clone"                                            # что видит «GitHub»
            subprocess.run(["git", "clone", "--quiet", str(origin), str(clone)], check=True)
            payload = uo.verify_index((clone / uo.INDEX_FILE).read_bytes(), (pu.public_text(pub),))
            assert payload["latest"] == "2.1.2" and [e["version"] for e in payload["packages"]] == ["2.1.1", "2.1.2"]
            assert (clone / ".gitattributes").read_text() == "* -text\n"
            term = _terminal(tmp / "term")
            with _Url(clone):
                res = uo.check(term, keys=(pu.public_text(pub),))
            assert res.status == uo.OK and [s["version"] for s in res.steps] == ["2.1.1", "2.1.2"], res.message
            log = subprocess.run(["git", "-C", str(clone), "log", "--format=%s"], capture_output=True, text=True,
                                 encoding="utf-8").stdout
            assert "FX Terminal 2.1.1…2.1.2: пакеты обновления" in log
        finally:
            os.environ.pop(pu.KEY_ENV, None)


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
