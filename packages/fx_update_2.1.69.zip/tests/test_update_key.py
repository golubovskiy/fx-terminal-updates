# -*- coding: utf-8 -*-
"""Ключ подписи обновлений в терминале (2.1.69) и проверка по HTTP: ключ автора зашит и годится, пустой
репозиторий (latest.json ещё нет, HTTP 404) — «обновлений нет», а не ошибка; список, выложенный по HTTP, проверяется
и пакеты скачиваются. Без Qt и без интернета (сервер на 127.0.0.1).  Запуск:  python tests/test_update_key.py"""
from __future__ import annotations

import base64
import functools
import http.server
import os
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ed25519_lite as ed  # noqa: E402
import update_online as uo  # noqa: E402
from test_update_online import KEYS, _Url, _package, _site, _terminal  # noqa: E402

AUTHOR_KEY = "ZppzuWxkmYXa0cZ3MReF2NHTUhSH6YpVNMVppa6tulI="


def test_author_key_is_built_in():
    assert AUTHOR_KEY in uo.PUBLIC_KEYS
    pub = base64.b64decode(AUTHOR_KEY, validate=True)
    assert len(pub) == 32 and ed._decompress(pub) is not None                  # точка на кривой — ключ настоящий
    assert uo.known_keys() == {"9daad1147531048a": pub}


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):                       # без строки в консоль на каждый запрос
        pass


class _Server:
    """HTTP-сервер на 127.0.0.1 над папкой; без вывода в консоль. На время работы — запросы без прокси: прокси
    из настроек Windows мог бы не пропускать 127.0.0.1, и проверка падала бы не по своей вине."""

    def __init__(self, folder: Path):
        handler = functools.partial(_Quiet, directory=str(folder))
        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def __enter__(self):
        urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()
        urllib.request.install_opener(None)                 # снова обычный (с прокси из настроек, если он есть)
        return False


def test_empty_repository_is_not_an_error():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        term = _terminal(tmp / "term")
        (tmp / "site").mkdir()
        with _Server(tmp / "site") as server, _Url(tmp):
            os.environ["FX_UPDATES_URL"] = server.url
            res = uo.check(term, keys=KEYS)
        assert res.status == uo.NONE and "ещё нет опубликованных" in res.message, res.message


def test_check_over_http():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        term = _terminal(tmp / "term")
        built = tmp / "built"
        built.mkdir()
        site = _site(tmp / "site", [_package(built, "2.1.1", "2.1.0", 1)])
        with _Server(site) as server, _Url(tmp):
            os.environ["FX_UPDATES_URL"] = server.url
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.OK and res.target == "2.1.1" and Path(res.files[0]).exists(), res.message
            (site / "packages" / "fx_update_2.1.1.zip").unlink()                    # пакет удалили, а список остался
            for f in res.files:
                Path(f).unlink()
            res = uo.check(term, keys=KEYS)
            assert res.status == uo.ERROR and "404" in res.message, res.message


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
