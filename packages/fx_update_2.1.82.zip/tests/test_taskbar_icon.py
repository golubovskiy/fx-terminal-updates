# -*- coding: utf-8 -*-
"""Значок на панели задач (2.1.82): из исходников (python.exe) терминал задаёт свой AppUserModelID — иначе был бы
значок Python; собранная программа (FX Terminal.exe) — нет: Windows берёт значок самого exe. Системная функция
подменяется — реестр и панель задач не трогаются.  Запуск:  python tests/test_taskbar_icon.py"""
from __future__ import annotations

import ctypes
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import gui_app  # noqa: E402


class _Shell32:
    def __init__(self):
        self.calls = []

    def SetCurrentProcessExplicitAppUserModelID(self, app_id):        # noqa: N802 — имя функции Windows
        self.calls.append(app_id)
        return 0


def _calls(frozen: bool) -> list:
    fake = type("WinDLL", (), {})()
    fake.shell32 = _Shell32()
    saved_windll = getattr(ctypes, "windll", None)
    saved_platform = sys.platform
    had_frozen, saved_frozen = hasattr(sys, "frozen"), getattr(sys, "frozen", None)
    try:
        ctypes.windll = fake
        sys.platform = "win32"
        if frozen:
            sys.frozen = True
        elif had_frozen:
            del sys.frozen
        gui_app._set_windows_app_id()
    finally:
        sys.platform = saved_platform
        if saved_windll is None:
            del ctypes.windll
        else:
            ctypes.windll = saved_windll
        if had_frozen:
            sys.frozen = saved_frozen
        elif hasattr(sys, "frozen"):
            del sys.frozen
    return fake.shell32.calls


def test_source_run_sets_app_id():
    assert _calls(frozen=False) == [gui_app.APP_USER_MODEL_ID]


def test_built_program_keeps_exe_identity():
    assert _calls(frozen=True) == []


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
