# -*- coding: utf-8 -*-
"""Главное окно терминала (MainWindow): меню, рабочие пространства и панели, подключение к Finam
(шлюз, хаб, клиент SDK), запуск и остановка вкладок, окна стакана и «Тики».

Часть gui_app.py, вынесенная в отдельный модуль; запуск терминала — по-прежнему python gui_app.py.
"""
from __future__ import annotations

import faulthandler
import json
import os
import re
import ssl
import sys
import threading
import time
import traceback
from datetime import date, timedelta
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)
from zoneinfo import available_timezones

import pandas as pd
import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6
import pyqtgraph as pg
import fx_theme

from candlestick_item import CandlestickItem, TimeAxisItem, BULL_COLOR, BEAR_COLOR
from finam_terminal import (
    FinamClient,
    enrich_with_indicators,
    INSTRUMENTS,
    to_friendly_symbol,
    from_friendly_symbol,
    register_symbols,
    sma,
    vwap,
)
from finam_sdk_client import FinamStreamClient
import hotkeys
import notify_badge
from quotes_tab import QuotesTab, QuotesEventMarker
from instrument_picker import InstrumentPickerDialog
from tick_volume_manager import TickVolumeManager
from window_links import LinkHub, install_link_titlebar
from order_flow import (
    OrderFlowChartPanel,
    OrderFlowController,
    OrderFlowTab,
    ORDER_FLOW_SYMBOLS,
    resolve_quarterly_symbols,
)
from connection_diagnostics import ConnectionDiagnosticsDialog
from cny_forward_tab import CnyForwardMonitorTab, set_display_timezone as set_cny_display_timezone
import docking
from open_interest_tab import OpenInterestTab
from options_tab import OptionsTab
from status_clock import StatusClock, FinamClockSource
from notes_panel import NotesStore, NotesPanel
from sound_notifier import SoundNotifier, PULSE, SIGNAL, ALERT, TITLES as SOUND_TITLES
from workspace_shell import PanelSpec, ShellGroup, WorkspaceShell, new_windows_float, set_new_windows_float
import candle_cache

from app_common import (  # noqa: F401
    DEFAULT_DISPLAY_TZ,
    DEFAULT_HISTORY_PERIOD,
    DEFAULT_SYMBOLS,
    HISTORY_PERIODS,
    MIC_LABELS,
    QUARTERLY_SYMBOLS,
    TYPE_LABELS,
    _HISTORY_SETTINGS_KEY,
    _TZ_SETTINGS_KEY,
    _friendly_symbol,
    _from_friendly_symbol,
    _is_valid_timezone,
    _sound_dir,
    app_stylesheet,
    apply_app_font_size,
)
from settings_dialog import (  # noqa: F401
    SettingsDialog,
)
from data_workers import (  # noqa: F401
    SdkInitWorker,
    run_account_diagnostics,
)
from chart_panel import (  # noqa: F401
    ChartPanel,
    QuoteChartWindow,
)



EXIT_WATCHDOG_SEC = 20     # закрытие дольше — что-то зависло: снимок потоков в журнал и принудительный выход
CONN_POLL_MS = 2000         # как часто индикатор подключения сверяется с потоками шлюза


def _start_exit_watchdog(seconds: float) -> None:
    """Страховка закрытия. Если через seconds секунд процесс ещё жив (поток не остановился,
    gRPC-вызов завис), пишет в журнал, где стоит каждый поток, и завершает процесс сам —
    терминал не остаётся висеть без окна. Обычное закрытие идёт до этого через os._exit
    в gui_app._finish_process, и сторож не успевает сработать."""
    def watch():
        time.sleep(seconds)
        try:
            print(f"[завершение] терминал не завершился за {seconds:.0f} с — где стоят потоки:", file=sys.stderr)
            names = {t.ident: t.name for t in threading.enumerate()}
            for ident, frame in sys._current_frames().items():
                if ident == threading.get_ident():
                    continue
                stack = "".join(traceback.format_stack(frame)[-6:])
                print(f"  поток {names.get(ident, ident)}:\n{stack}", file=sys.stderr)
            print("[завершение] выхожу принудительно", file=sys.stderr)
            try:
                from services.log_file import drain_console
                drain_console()
            except Exception:
                pass
            for stream in (sys.stdout, sys.stderr):
                stream.flush()
        finally:
            os._exit(0)

    threading.Thread(target=watch, name="exit-watchdog", daemon=True).start()

class MainWindow(QtWidgets.QMainWindow):
    POLL_INTERVAL_MS = 15_000  # опрос REST за свечами (стрим покрывает только последнюю цену)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("FX Terminal — валюта и валютные фьючерсы")
        self.resize(1400, 850)

        self.settings = QtCore.QSettings("MyTradingTools", "FxTerminal")
        self._restore_window_geometry()
        self.display_tz: str = self._load_display_tz()
        set_cny_display_timezone(self.display_tz)
        self.client: FinamClient | None = None
        self.sdk_client: FinamStreamClient | None = None
        self.finam_clock_source: FinamClockSource | None = None
        self.tick_volume_manager: TickVolumeManager | None = None
        self._scalper_manager = None   # окна «Стакан» (scalper_widget.ScalperManager), создаётся при первом клике
        self._tick_restored = False

        self._sdk_thread: QtCore.QThread | None = None
        self._active_assets: list[dict] = []
        self._catalog_symbols: list[str] = []

        # Графики — панели рабочих областей («1: EURUSD», «2: …»). Графиков может не быть вовсе
        # (пустой стартовый экран), поэтому panels[0] «основным» больше не считается.
        self.panels: list[ChartPanel] = []
        self._chart_counter = 0
        self._chart_template: tuple[str | None, str | None] | None = None   # (инструмент, ТФ) для следующего графика
        self._quote_chart_windows: dict[str, QuoteChartWindow] = {}

        self._build_ui()
        self._try_init_client()

        self.poll_timer = QtCore.QTimer(self)
        self.poll_timer.timeout.connect(self.refresh_data)
        # self.poll_timer.start(self.POLL_INTERVAL_MS)
        QtCore.QTimer.singleShot(100, self.refresh_all_data)
        self._quotes_ui_timer = QtCore.QTimer(self)
        self._quotes_ui_timer.timeout.connect(self._update_quotes_toolbar)
        self._quotes_ui_timer.start(1000)
        self._start_perf()
        # Сроки журналов (2.1.85, «Настройки» → «Журналы»): очистка через 2 минуты после запуска и раз в 6 часов —
        # терминал работает сутками, и старые журналы иначе ждали бы следующего запуска.
        self._logs_timer = QtCore.QTimer(self)
        self._logs_timer.timeout.connect(self._cleanup_logs)
        self._logs_timer.start(6 * 3600 * 1000)
        QtCore.QTimer.singleShot(120_000, self._cleanup_logs)
        try:                                   # журналы убранных сверок «в тени» больше не нужны (2.1.57)
            from services import algo_shadow
            dropped = algo_shadow.drop_old_shadow_logs()
            if dropped:
                print(f"[журналы] удалены старые журналы сверок Rust «в тени»: файлов {dropped}")
        except Exception:
            traceback.print_exc()
        # Рисунки графиков между терминалами (drawings_sync.py); выключена, пока не настроена
        # в «Настройки» → «Синхронизация».
        try:
            import drawings_sync
            self.drawings_sync = drawings_sync.SyncManager(self.settings, parent=self)
        except Exception as exc:               # синхронизация — дополнение; терминал работает и без неё
            self.drawings_sync = None
            print(f"[синхронизация] не запущена: {type(exc).__name__}: {exc}", file=sys.stderr)
        # Горячие клавиши группы «Все стаканы» (hotkeys.py) — исполняет главное окно.
        hotkeys.REGISTRY.global_handler = self._run_global_hotkey

    GEOMETRY_KEY = "ui/main_geometry"

    def _restore_window_geometry(self) -> None:
        """Размер, положение и «развёрнуто на весь экран» главного окна — как при прошлом закрытии
        (сохраняет closeEvent). Пропавший монитор Qt учитывает сам: окно окажется на доступном экране.
        Дополнительные пространства запоминают своё окно в раскладке (workspace_shell.ShellGroup.save)."""
        raw = self.settings.value(self.GEOMETRY_KEY)
        if not raw:
            return
        try:
            self.restoreGeometry(raw if isinstance(raw, QtCore.QByteArray) else QtCore.QByteArray(raw))
        except Exception:
            traceback.print_exc()

    def keyPressEvent(self, event: QtGui.QKeyEvent) -> None:
        """Горячие клавиши «Все стаканы», нажатые не в стакане (в графике, «Алгоритмах»…).
        В окнах стакана их ловит само окно (ScalperWindow.keyPressEvent)."""
        action = hotkeys.REGISTRY.match(event, (hotkeys.GLOBAL,))
        if action is None:
            super().keyPressEvent(event)
            return
        event.accept()
        self._run_global_hotkey(action)

    def _run_global_hotkey(self, action: str) -> None:
        manager = self._scalper_manager
        print(f"[горячая клавиша] {hotkeys.ACTION_BY_ID[action].title}", file=sys.stderr)
        if action == "flatten_all" and manager is not None:
            manager.flatten_all(self, confirm=False, live_only=False)
        elif action == "cancel_all_windows" and manager is not None:
            manager.cancel_all_windows()
        elif action == "notifications":
            self.quotes_tab.open_notifications()

    def _start_perf(self) -> None:
        """Замер нагрузки (services/perf_qt.py) — всё время работы терминала: раздел «Нагрузка» окна
        «Состояние подключения», поминутные сводки в logs/perf_ГГГГ-ММ-ДД.csv и строка в журнале."""
        self.perf_sampler = None
        try:
            from services.perf_qt import PerfSampler

            def messages():
                gateway = getattr(self, "md_gateway", None)
                return gateway.stats()["messages"] if gateway is not None else None

            self.perf_sampler = PerfSampler(app_paths.LOG_DIR, messages, parent=self)
        except Exception:
            print("[нагрузка] замер не запустился:", file=sys.stderr)
            traceback.print_exc()

    # ---------------------------------------------------------- UI layout

    def _build_ui(self) -> None:
        # Верхней панели инструментов больше нет: «График», «Стакан» и «Новое пространство» — кнопки справа
        # в нижней панели каждого пространства, «Настройки», «Окна», «Аналитика» — строка меню,
        # уведомления «Алгоритмов» — справа в строке меню рядом с индикатором и часами.

        # Связь окон по цветным группам (график / стакан / тики): один хаб на всё приложение.
        self.link_hub = LinkHub(friendly=_friendly_symbol)

        # --- таблицы позиций и заявок (вкладки главного окна) ---
        self.positions_table = QtWidgets.QTableWidget()
        self.positions_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.orders_table = QtWidgets.QTableWidget()
        self.orders_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

        # Позиции и заявки — отдельные вкладки главного окна (раньше стояли справа от графика):
        # теперь график занимает всё окно, а таблицы — всю ширину своей вкладки.
        for table in (self.positions_table, self.orders_table):
            table.horizontalHeader().setStretchLastSection(True)

        self.order_flow_controller = OrderFlowController(ORDER_FLOW_SYMBOLS, self)
        self.order_flow_tab = OrderFlowTab(self.order_flow_controller)
        self._order_flow_chart = None             # панель «Баланс покупок/продаж» — создаётся при первом открытии
        self.order_flow_tab.open_chart = lambda: self._active_shell().open_panel("order_flow_chart")

        self.cny_forward_tab = CnyForwardMonitorTab()
        # Заметки: одна общая копия — окно «Заметки» и кнопка «В заметки» в уведомлениях
        self.notes_store = NotesStore(self.settings, self)
        # Заметки между терминалами (notes_sync.py) — через тот же WebDAV, что и рисунки; выключена,
        # пока обмен не настроен в «Настройки» → «Синхронизация»
        try:
            import notes_sync
            self.notes_sync = notes_sync.NotesSyncManager(self.settings, self.notes_store, parent=self)
        except Exception as exc:               # синхронизация — дополнение; заметки работают и без неё
            self.notes_sync = None
            print(f"[синхронизация заметок] не запущена: {type(exc).__name__}: {exc}", file=sys.stderr)
        self.notes_panel = NotesPanel(self.notes_store, display_tz_fn=lambda: getattr(self, "display_tz", "Europe/Moscow"))
        self.notes_panel.open_chart_at = self.open_chart_at          # «Показать на графике» из «Заметок»
        self.notes_panel.day_trades_fn = self._day_closed_trades       # «Дневник дня»: сделки дня со счёта
        self.quotes_tab = QuotesTab(self, InstrumentPickerDialog, MIC_LABELS, TYPE_LABELS)
        self.sound = SoundNotifier(self.settings, _sound_dir(), self)
        self._hook_notification_sound()
        for _sig_name in ("chart_requested", "open_chart_requested", "chart_clicked", "show_chart_requested"):
            _sig = getattr(self.quotes_tab, _sig_name, None)
            if _sig is not None and hasattr(_sig, "connect"):
                try:
                    _sig.connect(self.open_quote_chart_window)
                    print(f"[АЛГОРИТМЫ] кнопка графика: подключён сигнал {_sig_name}", file=sys.stderr)
                except Exception:
                    traceback.print_exc()

        # --- рабочие области: докинг-панели (QtAds) вместо прежних вкладок ---
        docking.ensure_available()
        # Открытый интерес по фьючерсам (один SubscribeQuote-стрим); start()/stop() — как у CNY Forward.
        self.open_interest_tab = OpenInterestTab()
        # Опционы: содержимое создаётся лениво, когда панель впервые видна (OptionsTab.activate).
        self.options_tab = OptionsTab(self)

        # Пространства: основное — центр этого окна, остальные — отдельные окна со своими
        # вкладками. Реестр панелей, карточки и поиск одноэкземплярных панелей общие (ShellGroup).
        self.group = ShellGroup(self)
        self.group.main_window = self
        self.group.tools_builder = self._build_workspace_bar_tools
        self.shell = WorkspaceShell(group=self.group)
        reg = self.group.register
        reg(PanelSpec(
            "chart", "График", self._new_chart_panel, single=False, on_close=self._on_chart_closed,
            save_state=self._chart_state, restore_factory=self._chart_from_state,
        ))
        # «Тики Bid/Ask» — панели: их можно закреплять в пространствах и выносить в плавающие окна.
        reg(PanelSpec(
            "ticks", "Тики", lambda: self._make_tick_window(), single=False,
            on_close=lambda w: w.close(), save_state=lambda w: {"index": w.index},
            restore_factory=lambda state: self._make_tick_window(state.get("index")),
        ))
        # «ATR» (2.1.13, atr_window.py) — многоэкземплярная панель: инструмент и параметры переживают перезапуск.
        reg(PanelSpec(
            "atr", "ATR", lambda: self._make_atr_panel(), single=False, on_close=lambda w: w.shutdown(),
            save_state=lambda w: w.state(), restore_factory=lambda state: self._make_atr_panel(state),
        ))
        reg(PanelSpec(
            "scalper", "Стакан", lambda: self._open_scalper_panel(), single=False,
            save_state=lambda w: {"symbol": str(getattr(w, "symbol", "") or "")},
            restore_factory=lambda state: self._restore_scalper(state.get("symbol")),
            # Закрытие вкладки = закрытие окна: LIVE со позицией/заявками спросит подтверждение и может отказать.
            confirm_close=lambda w: bool(w.close()),
        ))
        # «Позиции» / «Заявки» из сохранённых раскладок — те же таблицы, что во вкладках «Сделок» (account_window).
        reg(PanelSpec("positions", "Позиции", lambda: self._deals_tab_panel("positions"), single=True))
        reg(PanelSpec("orders", "Заявки", lambda: self._deals_tab_panel("orders"), single=True))
        reg(PanelSpec("order_flow", "Покупка/Продажа", lambda: self.order_flow_tab, single=True))
        # График баланса покупок/продаж — отдельная панель с выбором таймфрейма (раньше — под таблицей).
        reg(PanelSpec("order_flow_chart", "Баланс покупок/продаж", self._order_flow_chart_panel, single=True))
        reg(PanelSpec("cny_forward", "CNY Forward", lambda: self.cny_forward_tab, single=True))
        reg(PanelSpec("quotes", "Алгоритмы", lambda: self.quotes_tab, single=True))
        reg(PanelSpec("open_interest", "Открытый интерес", lambda: self.open_interest_tab, single=True))
        reg(PanelSpec("options", "Опционы", lambda: self.options_tab, single=True, on_show=self.options_tab.activate))
        reg(PanelSpec("notes", "Заметки", lambda: self.notes_panel, single=True))
        # «Уведомления» «Алгоритмов» — панель, как «Заметки» (с 2.0.95; раньше — отдельный диалог): закрепляется
        # в любом пространстве и области, выносится в плавающее окно. Окно одно — его держит вкладка.
        reg(PanelSpec("notifications", "Уведомления", lambda: self.quotes_tab.notifications_panel(), single=True))
        # «Сделки» и «Финрез» как в скальперских терминалах (account_window.py); прежние «Позиции» / «Заявки» оставлены
        # для сохранённых раскладок.
        reg(PanelSpec("deals", "Сделки", self._deals_panel, single=True))
        reg(PanelSpec("finrez", "Финрез", self._finrez_panel, single=True))
        # Карточки стартового экрана -> панели терминала («Скринер» пока без панели).
        self.group.card_targets.update({"trade": "scalper", "portfolio": "deals", "algos": "quotes"})
        self.setCentralWidget(self.shell)

        # Раскладка сохраняется сама (с задержкой, чтобы не писать на каждое движение мыши) и при выходе.
        self._layout_save_timer = QtCore.QTimer(self)
        self._layout_save_timer.setSingleShot(True)
        # Пока терминал закрывается, раскладку не перезаписываем: окна закрываются по одному, и сохранение
        # «по таймеру» посреди закрытия записало бы неполную раскладку (_layout_frozen, closeEvent).
        self._layout_frozen = False
        self._layout_save_timer.timeout.connect(
            lambda: None if self._layout_frozen else self.group.save(self.settings))
        self.group.layoutChanged.connect(lambda: self._layout_save_timer.start(1500))

        self._build_menu()
        self._build_workspace_bar_tools(self.shell)
        if not self.group.restore(self.settings):
            self.shell.add_workspace()

        self.status_label = QtWidgets.QLabel("Не подключено")
        self.statusBar().addPermanentWidget(self.status_label)

    # ---------------------------------------------------------- несколько графиков

    def _ensure_tick_manager(self) -> TickVolumeManager:
        if self.tick_volume_manager is None:
            self.tick_volume_manager = TickVolumeManager(
                self,
                InstrumentPickerDialog,
                MIC_LABELS,
                TYPE_LABELS,
                list(DEFAULT_SYMBOLS),
                _friendly_symbol,
                placer=self._place_tick_window,
                raiser=self.group.reveal,
                remover=self.group.remove_panel,
            )
        return self.tick_volume_manager

    def _link_tick_title(self, win) -> None:
        """Заголовок вкладки панели «Тики» следует за заголовком окна (инструмент в нём меняется)."""
        win.windowTitleChanged.connect(lambda title, w=win: self.group.set_dock_title(w, title))

    def _place_tick_window(self, win) -> None:
        """Новое окно «Тики» (создано менеджером) — панелью в активное пространство."""
        self._link_tick_title(win)
        self._active_shell().adopt("ticks", win, win.windowTitle())

    def _make_tick_window(self, index: int | None = None):
        """Фабрика панели «Тики» (открытие и восстановление раскладки): окно с этим номером или первое свободное."""
        win = self._ensure_tick_manager().create_window(index)
        if win is not None:
            self._link_tick_title(win)
        return win

    def open_tick_volume(self) -> None:
        """Новое окно «Тики Bid/Ask» (аналог QUIK TICK_BID_ASK_VOLUME), до tick_volume_manager.MAX_WINDOWS (25) копий."""
        self._ensure_tick_manager().open_new()

    def _make_atr_panel(self, state: dict | None = None):
        """Фабрика панели «ATR» (меню «Окна» и восстановление раскладки). Заголовок вкладки — за инструментом."""
        from atr_window import AtrPanel
        panel = AtrPanel(self, state)
        panel.windowTitleChanged.connect(lambda title, w=panel: self.group.set_dock_title(w, title))
        # Док создаётся после фабрики: заголовок с инструментом — когда панель уже стоит в доке.
        QtCore.QTimer.singleShot(0, lambda w=panel: self.group.set_dock_title(w, w.windowTitle()))
        return panel

    # ---------------------------------------------------------- меню и нижняя панель

    # «Сделки» и «Финрез» открываются из строки меню, поэтому в «Окна» их нет;
    # прежние «Позиции» / «Заявки» остались только для сохранённых раскладок.
    _WINDOW_PANELS = ("notes", "notifications")
    # «ATR» — в «Аналитике» (с 2.1.70; раньше был в «Окнах»): многоэкземплярная панель, каждое нажатие — новое окно
    _ANALYTICS_PANELS = ("order_flow", "order_flow_chart", "quotes", "cny_forward", "open_interest", "options", "atr")

    def _order_flow_chart_panel(self):
        if self._order_flow_chart is None:
            self._order_flow_chart = OrderFlowChartPanel(self.order_flow_controller)
        return self._order_flow_chart

    def _build_menu(self) -> None:
        """Строка меню: Настройки · Окна · Аналитика · Финрез · Сделки · О проекте, справа индикатор и часы."""
        bar = self.menuBar()
        bar.addAction("Настройки").triggered.connect(self.open_settings)
        windows = bar.addMenu("Окна")
        windows.aboutToShow.connect(lambda m=windows: self._populate_windows_menu(m))
        analytics = bar.addMenu("Аналитика")
        analytics.aboutToShow.connect(lambda m=analytics: self._populate_analytics_menu(m))
        bar.addAction("Финрез").triggered.connect(lambda _=False: self._active_shell().open_panel("finrez"))
        bar.addAction("Сделки").triggered.connect(lambda _=False: self._active_shell().open_panel("deals"))
        bar.addAction("О проекте").triggered.connect(self._show_about)

        # Справа: значок уведомлений «Алгоритмов» (notify_badge: колокольчик с числом новых и цветом самого
        # важного; наведение — последние уведомления и работающие роботы; щелчок — окно «Уведомления»;
        # правый щелчок — звук) и индикатор подключения с часами. До 2.0.95 — кнопка с текстом.
        self.quotes_notify_btn = notify_badge.NotifyBadgeButton(
            popup_source=lambda: self.quotes_tab.notification_popup_html())
        self.quotes_notify_btn.clicked.connect(lambda: self.quotes_tab.open_notifications())
        self.quotes_notify_btn.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.quotes_notify_btn.customContextMenuRequested.connect(self._notify_button_menu)
        # Явно удерживаем corner-widget и layout в MainWindow. Это исключает
        # потерю Python-ссылок и упрощает восстановление, если Qt уничтожил
        # corner-widget при перестройке строки меню.
        self._menu_bar_ref = bar
        self._menu_corner = QtWidgets.QWidget(bar)
        self._menu_corner_layout = QtWidgets.QHBoxLayout(self._menu_corner)
        self._menu_corner_layout.setContentsMargins(0, 0, 0, 0)
        self._menu_corner_layout.setSpacing(6)
        self._menu_corner_layout.addWidget(self.quotes_notify_btn)
        self.status_clock = StatusClock(
            self._menu_corner,
            time_source=self.finam_clock_source.now if self.finam_clock_source is not None else None,
            tz_name=self.display_tz,
        )
        self._menu_corner_layout.addWidget(self.status_clock)
        bar.setCornerWidget(self._menu_corner, QtCore.Qt.Corner.TopRightCorner)
        # Индикатор подключения следит за потоками шлюза (раньше ставился «зелёным» один раз после
        # подключения и не гас при обрыве — 29.10 все потоки переподключались, а точка горела зелёной).
        self._conn_timer = QtCore.QTimer(self)
        self._conn_timer.timeout.connect(self._poll_connection_state)
        self._conn_timer.start(CONN_POLL_MS)

    @staticmethod
    def connection_state_from_stats(stats: dict) -> tuple[str, str]:
        """(состояние индикатора, подсказка) по сводке шлюза FinamGateway.stats():
        все потоки оборваны — disconnected (красный); часть — partial (жёлтый); иначе connected (зелёный)."""
        streams, up, down = int(stats.get("streams", 0)), int(stats.get("up", 0)), int(stats.get("down", 0))
        starting = int(stats.get("starting", 0))
        if streams and down and not up:
            state = "disconnected"
        elif down:
            state = "partial"
        elif streams and starting == streams:
            state = "connecting"
        else:
            state = "connected"
        title = {"disconnected": "Нет связи с Finam — потоки переподключаются",
                 "partial": "Связь с Finam неполная — часть потоков переподключается",
                 "connecting": "Подключение к Finam…",
                 "connected": "Связь с Finam есть"}[state]
        tip = (f"{title}\nПотоков данных: {streams} — работают {up}, переподключаются {down}, запускаются "
               f"{starting}\nОбрывов за сеанс: {stats.get('reconnects', 0)}")
        return state, tip

    def _poll_connection_state(self) -> None:
        """Раз в CONN_POLL_MS: цвет индикатора по состоянию потоков шлюза (нет шлюза — не трогаем)."""
        gateway = getattr(self, "md_gateway", None)
        if gateway is None or not hasattr(gateway, "stats"):
            return
        try:
            state, tip = self.connection_state_from_stats(gateway.stats())
        except Exception:
            return
        import shiboken6
        clock = getattr(self, "status_clock", None)
        if clock is not None and shiboken6.isValid(clock):
            clock.set_state(state, tip)

    def _set_status_clock_state(self, state: str) -> None:
        """Безопасно обновляет индикатор, восстанавливая его при удалении Qt-объекта."""
        import shiboken6

        clock = getattr(self, "status_clock", None)
        if clock is None or not shiboken6.isValid(clock):
            bar = getattr(self, "_menu_bar_ref", None)
            if bar is None or not shiboken6.isValid(bar):
                return
            corner = QtWidgets.QWidget(bar)
            row = QtWidgets.QHBoxLayout(corner)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(6)
            button = getattr(self, "quotes_notify_btn", None)
            if button is not None and shiboken6.isValid(button):
                row.addWidget(button)
            clock = StatusClock(
                corner,
                time_source=self.finam_clock_source.now if self.finam_clock_source is not None else None,
                tz_name=getattr(self, "display_tz", "Europe/Moscow"),
            )
            row.addWidget(clock)
            self._menu_corner = corner
            self._menu_corner_layout = row
            self.status_clock = clock
            bar.setCornerWidget(corner, QtCore.Qt.Corner.TopRightCorner)
        clock.set_state(state)

    def _populate_windows_menu(self, menu: QtWidgets.QMenu) -> None:
        menu.clear()
        menu.addAction("График").triggered.connect(lambda _=False: self.add_chart())
        for key in self._WINDOW_PANELS:
            menu.addAction(self.group.specs[key].title).triggered.connect(
                lambda _=False, k=key: self._active_shell().open_panel(k)
            )
        menu.addSeparator()
        # Стакан и Тики: подменю = «новое окно», список открытых, «показать/закрыть все» (бывшие кнопки-сплиты).
        scalper_menu = menu.addMenu("Стакан")
        scalper_menu.aboutToShow.connect(lambda m=scalper_menu: self._populate_scalper_menu(m))
        tick_menu = menu.addMenu("Тики Bid/Ask")
        tick_menu.aboutToShow.connect(lambda m=tick_menu: self._ensure_tick_manager().populate_menu(m))
        menu.addSeparator()
        menu.addAction("Новое пространство").triggered.connect(lambda _=False: self.group.new_workspace())
        menu.addSeparator()
        # Новые окна — отдельными окнами вне терминала (2.1.75, workspace_shell.new_windows_float); прикрепить окно
        # к текущей вкладке активного пространства — подменю ниже (своё пространство — тот же пункт в его «⋮»).
        floating = menu.addAction("Новые окна — отдельным окном")
        floating.setCheckable(True)
        floating.setChecked(new_windows_float())
        floating.setToolTip("Включено — новый график, стакан и другие окна открываются вне терминала; прикрепить —\n"
                            "перетащить за заголовок в область или «Прикрепить окно сюда». Выключено — вкладкой.")
        floating.toggled.connect(lambda on: set_new_windows_float(on))
        attach = menu.addMenu("Прикрепить окно сюда")
        attach.aboutToShow.connect(lambda m=attach: self._active_shell().populate_attach_menu(m))
        menu.addSeparator()
        menu.addAction("Состояние подключения…").triggered.connect(self._show_data_status)

    def _show_data_status(self) -> None:
        """Живая сводка шлюза, хаба и LIVE-окон + журнал дня (data_status_window.py)."""
        try:
            from data_status_window import DataStatusWindow
            DataStatusWindow.show_for(self)
        except Exception:
            traceback.print_exc()

    def _populate_analytics_menu(self, menu: QtWidgets.QMenu) -> None:
        menu.clear()
        for key in self._ANALYTICS_PANELS:
            menu.addAction(self.group.specs[key].title).triggered.connect(
                lambda _=False, k=key: self._active_shell().open_panel(k)
            )

    def _show_about(self) -> None:
        """«О проекте»: версия и изменения; оттуда же — установка пакета обновления и откат (update_dialog.py).
        Выбрали установку / откат — терминал закрывается обычным путём (раскладка, заметки сохраняются),
        а gui_app._finish_process запускает updater.py (_update_command)."""
        from update_dialog import AboutDialog
        dlg = AboutDialog(self)
        dlg.exec()
        if dlg.command:
            self.run_update_command(dlg.command)

    def run_update_command(self, command: list[str]) -> bool:
        """Установка / откат согласованы (окно «О проекте» или «Доступно обновление», update_dialog): закрыть
        терминал обычным путём и запустить updater (gui_app._finish_process). False — закрытие отменено
        (например, открыта LIVE-позиция)."""
        self._update_command = command
        self._restart_requested = True           # без вопроса «Закрыть терминал?» — пользователь уже согласился
        self.close()
        if self.isVisible():                     # закрытие отменено (например, открыта LIVE-позиция)
            self._restart_requested = False
            self._update_command = None
            return False
        return True

    def _build_workspace_bar_tools(self, shell: WorkspaceShell) -> None:
        """Кнопки справа в нижней панели пространства: новый стакан, новый график, новое пространство, «⋮»
        («Открыть здесь» — «Заметки» и «Уведомления» в это пространство, переименовать вкладку, сброс раскладки).
        Вызывается для основного пространства и для каждого нового окна пространства."""
        bar = shell.bar
        bar.add_text_tool("Стакан", "Новый биржевой стакан", self.open_scalper)
        bar.add_text_tool("График", "Новый график", lambda s=shell: self.add_chart(s))
        # Новое пространство — отдельное окно со своими вкладками.
        bar.add_text_tool("Пространство", "Новое пространство", lambda: self.group.new_workspace())

        menu = QtWidgets.QMenu(shell)
        # Окна-панели («Заметки», «Уведомления») — в ЭТО пространство: у дополнительных пространств нет своей
        # строки меню, а «Окна» главного окна открывают панель там, где фокус (в основном пространстве).
        here = menu.addMenu("Открыть здесь")
        for key in self._WINDOW_PANELS:
            here.addAction(self.group.specs[key].title).triggered.connect(
                lambda _=False, s=shell, k=key: s.open_panel(k))
        attach = menu.addMenu("Прикрепить окно сюда")      # отдельное окно — вкладкой в это пространство (2.1.75)
        attach.aboutToShow.connect(lambda m=attach, s=shell: s.populate_attach_menu(m))
        menu.addSeparator()
        menu.addAction("Переименовать вкладку").triggered.connect(
            lambda s=shell: s.rename_workspace(s.bar.tabs.currentIndex())
        )
        menu.addAction("Сбросить сохранённую раскладку").triggered.connect(self._reset_workspace_layout)
        bar.add_menu_tool("⋮", "Ещё", menu)

    def _active_shell(self) -> WorkspaceShell:
        """Пространство активного окна: сюда открываются новые панели из меню."""
        return self.group.active_shell() or self.shell

    def _reset_workspace_layout(self) -> None:
        self.settings.remove(self.group.SETTINGS_KEY)
        self.settings.remove(self.shell.SETTINGS_KEY)
        QtWidgets.QMessageBox.information(
            self, "Раскладка", "Сохранённая раскладка удалена. Она применится при следующем запуске."
        )

    # ---------------------------------------------------------- окна «Стакан» (скальпер)

    def _get_scalper_manager(self, show_error: bool = True):
        """Менеджер окон стакана; модуль грузится только по первому клику (SDK и scalper_widget.py нужны лишь ему)."""
        if self._scalper_manager is not None:
            return self._scalper_manager
        try:
            from scalper_widget import ScalperManager
        except Exception as exc:  # нет scalper_widget.py / finam-sdk / protobuf
            traceback.print_exc()
            if show_error:
                QtWidgets.QMessageBox.critical(
                    self,
                    "Стакан",
                    f"Не удалось загрузить модуль стакана:\n{exc}\n\n"
                    "Файл scalper_widget.py должен лежать рядом с gui_app.py, "
                    "а пакет finam-sdk — быть установлен.",
                )
            return None
        # Окна стакана берут рыночные данные из хаба терминала, а LIVE-заявки ставят через то же
        # соединение шлюза Finam (если шлюз запущен; иначе — своё соединение окна).
        # Звуки сделок стакана (открытие / закрытие / SL / TP) — через общий SoundNotifier терминала.
        try:
            import scalper_widget
            scalper_widget.set_market_data_hub_provider(lambda: getattr(self, "md_hub", None))
            scalper_widget.set_trading_session_provider(lambda: getattr(self, "md_gateway", None))
            scalper_widget.set_trade_sound(self.sound.play_trade)
            scalper_widget.set_notice_sound(self.sound.play_notice)   # «Уведомление: …» из настроек стакана
            scalper_widget.set_notice_event(self._dom_notice)   # и строкой в «Уведомления» (2.1.84)
            # Значки «Алгоритмов» под кнопкой настроек стакана — из тех же событий, что у графиков.
            scalper_widget.set_algo_events(self._algo_events_for,
                                           lambda: getattr(self, "display_tz", "Europe/Moscow"))
        except Exception:
            traceback.print_exc()
        self._scalper_manager = ScalperManager(
            self,
            credentials=self._scalper_credentials,
            default_symbol=self._scalper_default_symbol,
            symbols=lambda: list(DEFAULT_SYMBOLS),
            catalog_symbols=lambda: [a.get("symbol", "") for a in self._active_assets if a.get("symbol")],
            pick_symbol=self._scalper_pick_instrument,
            friendly=_friendly_symbol,
            from_friendly=_from_friendly_symbol,
            hub=self.link_hub,
            # Окна «Стакан» — панели рабочих пространств: закрепляются и выносятся в плавающие окна.
            placer=self._place_scalper_window,
            swapper=self._swap_scalper_window,
            raiser=self.group.reveal,
            remover=self.group.remove_panel,
        )
        # Дневной лимит убытка LIVE (общий для всех окон стакана) — для окна «Состояние подключения».
        self.live_guard = getattr(self._scalper_manager, "guard", None)
        return self._scalper_manager

    def _link_scalper_title(self, win) -> None:
        """Заголовок вкладки панели «Стакан» следует за заголовком окна (инструмент и режим в нём меняются)."""
        if getattr(win, "_dock_title_linked", False):
            return
        win._dock_title_linked = True
        win.windowTitleChanged.connect(lambda title, w=win: self.group.set_dock_title(w, title))

    def _place_scalper_window(self, win) -> None:
        """Новое окно «Стакан» (создано менеджером) — панелью в активное пространство."""
        self._link_scalper_title(win)
        self._active_shell().adopt("scalper", win, win.windowTitle())

    def _swap_scalper_window(self, old, new) -> bool:
        """Смена инструмента или режима: новое окно встаёт в ту же панель, на то же место раскладки."""
        if not self.group.replace_widget(old, new):
            return False
        self._link_scalper_title(new)
        return True

    def _open_scalper_panel(self):
        """Фабрика панели «Стакан» для карточки и меню: окно открывается менеджером асинхронно (нужен
        шаг цены инструмента) и само встаёт панелью — поэтому здесь виджета нет."""
        self.open_scalper()
        return None

    def _restore_scalper(self, symbol):
        """Стакан из сохранённой раскладки: сначала заглушка, настоящее окно — после подключения."""
        manager = self._get_scalper_manager(show_error=False)
        if manager is None or not symbol:
            return None
        return manager.restore_placeholder(str(symbol))

    def _materialize_scalpers(self) -> None:
        manager = self._scalper_manager
        if manager is not None and self.sdk_client is not None:
            manager.materialize_placeholders()

    def open_scalper(self) -> None:
        """Новое окно «Стакан»: каждый клик открывает ещё одно (до scalper_widget.MAX_WINDOWS = 25)."""
        manager = self._get_scalper_manager()
        if manager is not None:
            manager.open_new()

    def _populate_scalper_menu(self, menu: QtWidgets.QMenu) -> None:
        manager = self._get_scalper_manager(show_error=False)
        if manager is None:
            menu.clear()
            menu.addAction("Стакан недоступен — см. сообщение при клике").setEnabled(False)
            return
        manager.populate_menu(menu)

    # ---- «Сделки» и «Финрез» (account_window.py) ----
    def _account_service(self):
        """Один источник данных счёта на оба окна; опрос Finam начинается, когда открыто первое из них."""
        service = getattr(self, "_account_svc", None)
        if service is None:
            from account_window import AccountService
            service = AccountService(
                session_provider=lambda: getattr(self, "md_gateway", None),
                account_provider=lambda: self._scalper_credentials()[1],
                settings=self.settings, friendly=_friendly_symbol,
                tz_provider=lambda: getattr(self, "display_tz", "Europe/Moscow"),
                scalper_provider=lambda: self._scalper_manager, parent=self)
            self._account_svc = service
        return service

    def _deals_panel(self):
        panel = getattr(self, "_deals_widget", None)
        if panel is None:
            from account_window import DealsPanel
            panel = self._deals_widget = DealsPanel(self._account_service())
        return panel

    def _deals_tab_panel(self, only: str):
        panels = self.__dict__.setdefault("_deals_tab_widgets", {})
        panel = panels.get(only)
        if panel is None:
            from account_window import DealsPanel
            panel = panels[only] = DealsPanel(self._account_service(), only=only)
        return panel

    def _finrez_panel(self):
        panel = getattr(self, "_finrez_widget", None)
        if panel is None:
            from account_window import FinrezPanel
            panel = self._finrez_widget = FinrezPanel(self._account_service())
        return panel

    def _scalper_credentials(self) -> tuple[str, str]:
        """(токен, id счёта) — те же, что у терминала: из «Настроек…» или переменных окружения."""
        secret = str(self.settings.value("finam/secret", os.environ.get("FINAM_SECRET", "")) or "").strip()
        account = str(getattr(getattr(self, "client", None), "account_id", "") or "").strip()
        if not account:
            account = str(self.settings.value("finam/account_id", os.environ.get("FINAM_ACCOUNT_ID", "")) or "").strip()
        return secret, account

    def _scalper_default_symbol(self) -> str:
        """Новое окно стакана открывается по инструменту текущего графика."""
        try:
            return self.current_panel()._current_symbol() or ""
        except Exception:
            return ""

    def _scalper_pick_instrument(self, parent) -> str | None:
        """«Каталог…» в окне стакана — тот же диалог выбора, что и у графиков."""
        if not self._active_assets:
            QtWidgets.QMessageBox.information(
                parent,
                "Каталог не загружен",
                "Дождитесь загрузки каталога инструментов от брокера (см. статус-бар внизу) и попробуйте снова.",
            )
            return None
        dlg = InstrumentPickerDialog(self._active_assets, MIC_LABELS, TYPE_LABELS, self.settings, parent)
        if dlg.exec() != QtWidgets.QDialog.Accepted:
            return None
        return dlg.chosen_symbol() or None

    def _tick_after_connect(self) -> None:
        """После (пере)подключения: при первом запуске — вернуть окна, затем — поднять стримы."""
        # Окна «Тики» теперь панели: при запуске их возвращает раскладка пространств, а здесь остаётся
        # только поднять стримы (и часы) на новом клиенте.
        self._ensure_tick_manager().resume()

    def _hook_notification_sound(self) -> None:
        """Каждое новое уведомление «Алгоритмов» (цена, сделка, робот, айсберг, касание линии) — со звуком.
        Тип сигнала задаёт сама вкладка (event["sound"]); дубли-повторы она отбрасывает раньше. Остановка робота
        (robot_stopped) — свой звук FX Robot End: строка робота при этом только обновляется, без event_added."""
        stopped = getattr(self.quotes_tab, "robot_stopped", None)   # робот остановился — FX Robot End (2.1.77)
        if stopped is not None:
            stopped.connect(lambda _symbol, _info: self._play_robot_end())
        signal = getattr(self.quotes_tab, "event_added", None)
        if signal is None:
            return
        signal.connect(self._play_event_sound)

    def _cleanup_logs(self) -> None:
        """Удалить старые журналы по срокам из «Настройки» → «Журналы» (log_retention.cleanup_all)."""
        try:
            import log_retention
            removed = log_retention.cleanup_all(app_paths.LOG_DIR, self.settings)
            if removed:
                print(f"[журналы] удалены старые файлы: {log_retention.report(removed)}")
        except Exception as exc:
            print(f"[журналы] очистка: {type(exc).__name__}: {exc}", file=sys.stderr)

    def _dom_notice(self, symbol, title, details, sound="pulse", price=None) -> None:
        """Уведомление окна стакана (scalper_widget.set_notice_event) — в ленту «Уведомлений» вкладки «Алгоритмы»
        (QuotesTab.add_dom_notice): у каждого звука стакана теперь есть строка. Вкладки ещё нет — пропуск."""
        tab = getattr(self, "quotes_tab", None)
        if tab is not None and hasattr(tab, "add_dom_notice"):
            tab.add_dom_notice(symbol, title, details, sound, price)

    def _play_robot_end(self) -> None:
        try:
            self.sound.play_robot_end()
        except Exception as exc:
            print(f"[звук] {type(exc).__name__}: {exc}", file=sys.stderr)

    def _play_event_sound(self, event: dict) -> None:
        try:
            if self.sound.enabled:
                self.sound.play(str(event.get("sound") or "pulse"))
        except Exception as exc:
            print(f"[звук] {type(exc).__name__}: {exc}", file=sys.stderr)

    def _toggle_sound(self, on: bool) -> None:
        self.sound.set_enabled(on)
        if on:
            self.sound.play(PULSE, force=True)

    def _notify_button_menu(self, pos) -> None:
        """Правый клик по «Уведомления»: быстро включить/выключить звук."""
        menu = QtWidgets.QMenu(self)
        action = menu.addAction("Звуковые уведомления")
        action.setCheckable(True)
        action.setChecked(self.sound.enabled)
        action.toggled.connect(self._toggle_sound)
        menu.addSeparator()
        menu.addAction("Настройки звука…").triggered.connect(self.open_settings)
        menu.exec(self.quotes_notify_btn.mapToGlobal(pos))

    def _update_quotes_toolbar(self) -> None:
        """Раз в секунду: число и важность непрочитанных — на значок «Уведомления»; открыто его всплывающее
        окно — обновить содержимое."""
        button = getattr(self, "quotes_notify_btn", None)
        if button is None or not shiboken6.isValid(button):
            return
        button.set_state(int(getattr(self.quotes_tab, "unread", 0) or 0),
                         int(getattr(self.quotes_tab, "unread_level", 0) or 0))
        button.refresh_popup()

    def show_notifications_panel(self) -> None:
        """Окно «Уведомления» со значка, горячей клавиши, «Алгоритмов»: закреплено где-то (в любом пространстве,
        даже закрытой вкладкой) — показать там и поднять его окно; нигде — открыть в текущей области, как из
        «Окна». Из меню «Окна» панель, как и другие одноэкземплярные, переносится в текущую область."""
        panel = self.quotes_tab.notifications_panel()
        panel.set_display_tz(self.display_tz)
        if not self.group.reveal(panel):
            self._active_shell().open_panel("notifications")
            self.group.reveal(panel)
        self.quotes_tab.mark_notifications_read()

    def add_quote_event_to_chart(self, event: dict) -> None:
        """Показать событие 🤖/🧊 на открытых графиках этого инструмента."""
        symbol = event.get("symbol")
        panels = list(getattr(self, "panels", []))
        # + отдельные окна графиков, открытые кнопкой из «Алгоритмов» (раньше события туда не попадали)
        panels += [w.panel for w in list(getattr(self, "_quote_chart_windows", {}).values())]
        for panel in panels:
            try:
                if panel._current_symbol() == symbol and panel._quote_events_symbol == symbol:
                    panel.add_quote_event_marker(event)
            except Exception:
                continue

    def current_panel(self) -> "ChartPanel | None":
        """График, с которым сейчас работает пользователь: где фокус, иначе любой видимый, иначе первый.
        None — открытых графиков нет (пустой стартовый экран)."""
        focus = QtWidgets.QApplication.focusWidget()
        visible = []
        for panel in self.panels:
            if not panel.isVisible():
                continue
            if focus is not None and (focus is panel or panel.isAncestorOf(focus)):
                return panel
            visible.append(panel)
        if visible:
            return visible[0]
        return self.panels[0] if self.panels else None

    def open_quote_chart_window(self, symbol: str) -> None:
        """Открыть отдельное окно графика для инструмента из «Котировок»."""
        symbol = str(symbol or "").strip()
        if not symbol:
            return

        existing = self._quote_chart_windows.get(symbol)
        if existing is not None:
            existing.show()
            existing.raise_()
            existing.activateWindow()
            return

        print(f"[АЛГОРИТМЫ] Открытие окна графика: {symbol}", file=sys.stderr)
        try:
            window = QuoteChartWindow(self, symbol)
        except Exception as exc:
            # Раньше такая ошибка улетала в консоль, а кнопка просто «молчала».
            traceback.print_exc()
            self.status_label.setText(f"Не удалось открыть график {symbol}: {exc}")
            QtWidgets.QMessageBox.warning(
                self,
                "График из «Котировок»",
                f"Не удалось открыть окно графика для {symbol}:\n{exc}\n\n"
                "Подробности — в консоли.",
            )
            return
        self._quote_chart_windows[symbol] = window
        window.show()
        window.raise_()
        window.activateWindow()

    def open_chart_for_symbol(self, symbol: str) -> None:
        """Показать инструмент symbol из вкладки «Алгоритмы» на графике: на текущем, а если графиков нет — на новом."""
        symbol = str(symbol or "").strip()
        if not symbol:
            return

        panel = self.current_panel()
        if panel is None:
            self._chart_template = (symbol, None)
            self._active_shell().open_panel("chart")
            return

        idx = panel.symbol_combo.findData(symbol)
        if idx < 0:
            panel.symbol_combo.addItem(_friendly_symbol(symbol), userData=symbol)
            idx = panel.symbol_combo.count() - 1

        # Сначала показываем рабочую область и панель с графиком — ChartPanel сам
        # запустит обновление свечей/стрим при смене инструмента.
        self.shell.reveal(panel)
        panel.symbol_combo.setCurrentIndex(idx)
        panel.setFocus()

    def _day_closed_trades(self, day) -> list:
        """Закрытые сделки дня day (LIVE, счёт Finam) — для «Дневника дня». Опрос счёта запускается, если ещё
        не шёл: первые данные придут через несколько секунд (повторный щелчок по «Дневнику дня» их добавит)."""
        from datetime import datetime
        import account_core as ac
        service = self._account_service()
        service.start()
        live = service.live
        tz = service.tz()
        start = datetime.combine(day, datetime.min.time(), tzinfo=tz).timestamp()
        fills = [f for f in (live.get("fills") or []) if start <= f.ts < start + 86400]
        snap = live.get("account")
        current = {p.symbol: p.qty for p in (snap.positions if snap is not None else [])}
        return ac.closed_trades(fills, ac.opening_positions(current, fills))

    def reveal_notes(self, focus_comment: bool = False) -> None:
        """Показать окно «Заметки»: уже стоит в раскладке — его вкладку/пространство, нет — открыть в текущем.
        focus_comment — курсор в комментарий выбранной заметки (заметка к сделке: сразу писать разбор)."""
        panel = self.notes_panel
        shown = False
        if panel.parent() is not None:
            try:
                shown = bool(self.shell.reveal(panel))   # ищет во всех пространствах (группа окон)
            except Exception:
                shown = False
        if not shown:
            self._active_shell().open_panel("notes")
        if focus_comment:
            QtCore.QTimer.singleShot(0, panel.focus_comment)

    def open_chart_at(self, symbol: str, moment: float) -> None:
        """«Показать на графике» (окно «Заметки»): инструмент на текущем графике (нет графиков — на новом),
        вид — на свече момента moment (epoch, с) с отметкой времени; свечей ещё нет — как только загрузятся."""
        self.open_chart_for_symbol(symbol)
        panel = self.current_panel()
        if panel is None:
            QtCore.QTimer.singleShot(300, lambda: self._focus_new_chart(symbol, moment))
            return
        panel.focus_time(symbol, moment)

    def _focus_new_chart(self, symbol: str, moment: float, tries: int = 10) -> None:
        panel = self.current_panel()
        if panel is not None:
            panel.focus_time(symbol, moment)
        elif tries > 0:                          # новая панель графика ещё создаётся
            QtCore.QTimer.singleShot(300, lambda: self._focus_new_chart(symbol, moment, tries - 1))

    def add_chart(self, shell=None) -> None:
        """Новый график в пространстве shell (по умолчанию — в активном): инструмент и таймфрейм —
        как у текущего графика. Аргумент может прийти от Qt как bool (clicked/triggered) — тогда игнорируется."""
        source = self.current_panel()
        if source is not None:
            self._chart_template = (source._current_symbol() or None, source.tf_combo.currentText())
        target = shell if isinstance(shell, WorkspaceShell) else self._active_shell()
        target.open_panel("chart")

    def _new_chart_panel(self) -> "ChartPanel":
        """Фабрика панели «График» для рабочих областей (в том числе при восстановлении раскладки)."""
        template, self._chart_template = self._chart_template, None
        if template is None:
            source = self.current_panel()
            template = (
                (source._current_symbol() or None, source.tf_combo.currentText())
                if source is not None else (None, None)
            )
        symbol, timeframe = template

        self._chart_counter += 1
        kwargs: dict = {"chart_number": self._chart_counter}
        if symbol:
            kwargs["symbol"] = symbol
        if timeframe:
            kwargs["timeframe"] = timeframe
        panel = ChartPanel(self, **kwargs)
        self.panels.append(panel)
        panel.title_changed.connect(lambda text, p=panel: self._update_chart_title(p, text))
        QtCore.QTimer.singleShot(0, lambda p=panel: self._update_chart_title(p, p.title()))

        # Данные и стрим — после того как панель показана. До подключения клиента (восстановление
        # раскладки на старте) стримы всех графиков поднимает _try_init_client, с паузами.
        QtCore.QTimer.singleShot(0, panel.refresh_data)
        if getattr(self, "sdk_client", None) is not None:
            QtCore.QTimer.singleShot(400, lambda p=panel: p in self.panels and p.start_stream())
        return panel

    @staticmethod
    def _chart_state(panel: "ChartPanel") -> dict:
        """Что запоминается о графике в раскладке: инструмент, таймфрейм, скрыты ли «Инструмент» и
        «Каталог», «чистый график» (кнопка «☰»), вид (масштаб и положение свечей — ChartPanel.view_state), наложения (overlay_state) и
        включённые индикаторы (indicator_state, с 2.1.11)."""
        state = {"symbol": panel._current_symbol() or "", "timeframe": panel.tf_combo.currentText(),
                 "hide_instrument": bool(getattr(panel, "_hide_instrument", False)),
                 "clean": bool(getattr(panel, "_clean_mode", False))}     # «☰» — чистый график (2.1.47)
        view = panel.view_state()
        if view is not None:
            state["view"] = view
        overlays = panel.overlay_state()             # наложенные инструменты и их шкала (chart_overlay.py)
        if overlays:
            state["overlays"] = overlays
        indicators = panel.indicator_state()         # VWAP, полосы, SMA, максимум/минимум
        if indicators:
            state["indicators"] = indicators
        return state

    def _chart_from_state(self, state: dict) -> "ChartPanel":
        """График из сохранённой раскладки — со своим инструментом и ТФ, а не как у соседнего,
        с прежним видом (применится при первой загрузке свечей) и прежними индикаторами."""
        self._chart_template = (str(state.get("symbol") or "") or None, str(state.get("timeframe") or "") or None)
        panel = self._new_chart_panel()
        panel.set_restore_view(state.get("view"))
        if state.get("overlays"):
            panel.restore_overlays(state["overlays"])
        if state.get("indicators"):
            panel.restore_indicators(state["indicators"])
        if "hide_instrument" in state:           # кнопка «Скрыть „Инструмент“ и „Каталог“» этого графика
            panel.link_set_compact(bool(state["hide_instrument"]))
        if state.get("clean"):                   # кнопка «☰» этого графика
            panel.set_clean_mode(True)
        return panel

    def _update_chart_title(self, panel: "ChartPanel", text: str) -> None:
        self.shell.set_dock_title(panel, f"{panel.chart_number}: {text}")

    def _on_chart_closed(self, panel: "ChartPanel") -> None:
        """Панель графика закрыта: остановить её потоки и убрать из списка."""
        if panel in self.panels:
            self.panels.remove(panel)
        try:
            panel.shutdown()
        except Exception:
            traceback.print_exc()

    def refresh_data(self) -> None:
        """Обновить свечи на текущем графике."""
        panel = self.current_panel()
        if panel is not None:
            panel.refresh_data()

    def refresh_all_data(self) -> None:
        for panel in list(self.panels):
            panel.refresh_data()

    def _start_finam_clock_sync(self) -> None:
        """Подключает часы к AssetsService.Clock после первичного запуска gRPC.

        Запрос идёт через соединение шлюза Finam (md_gateway) — того же, что у рыночных данных
        и заявок; если шлюз не запустился — через клиент SDK терминала, как раньше.
        Шлюз берётся на каждый запрос: после «Подключиться» источник часов пересоздаётся,
        а между остановкой шлюза и остановкой часов запрос просто не выполняется."""
        sdk = getattr(self, "sdk_client", None)
        if sdk is None and getattr(self, "md_gateway", None) is None:
            return
        # Не запускаем ещё один RPC одновременно с первыми запросами/стримами.
        try:
            if getattr(self, "md_gateway", None) is not None:
                def clock_rpc(request, timeout=None):
                    gateway = getattr(self, "md_gateway", None)
                    if gateway is None:
                        raise RuntimeError("шлюз Finam остановлен")
                    assets = gateway.client().assets
                    return assets.Clock(request) if timeout is None else assets.Clock(request, timeout=timeout)
            else:
                clock_rpc = sdk._client.assets.Clock
            source = FinamClockSource(clock_rpc, sync_interval=10.0)   # раз в 10 с: время и пинг до Finam
        except Exception as exc:
            print(f"[FinamClock] Не удалось запустить синхронизацию: {type(exc).__name__}: {exc}", file=sys.stderr)
            return

        old_source = getattr(self, "finam_clock_source", None)
        self.finam_clock_source = source
        self._set_status_clock_time_source(source.now)
        if old_source is not None:
            try:
                old_source.stop()
            except Exception:
                pass

    def _set_status_clock_time_source(self, source) -> None:
        """Безопасно назначает источник времени текущему Qt-виджету."""
        import shiboken6
        clock = getattr(self, "status_clock", None)
        if clock is not None and shiboken6.isValid(clock):
            clock.set_time_source(source)
            return
        # Восстановление самого виджета, если Qt уже уничтожил corner-widget.
        self._set_status_clock_state("connected")
        clock = getattr(self, "status_clock", None)
        if clock is not None and shiboken6.isValid(clock):
            clock.set_time_source(source)

    def _try_init_client(self) -> None:
        secret = self.settings.value("finam/secret", os.environ.get("FINAM_SECRET", ""))
        account_id = self.settings.value("finam/account_id", os.environ.get("FINAM_ACCOUNT_ID", ""))
        account_id = str(account_id or "").strip()
        if not secret:
            self.status_label.setText("Не настроено: откройте «Настройки…»")
            self._set_status_clock_state("disconnected")
            return

        # Прежде чем поднимать новые потоки/клиент — гарантированно
        # остановить предыдущие. Иначе при повторном открытии «Настроек»
        # накапливаются висящие QThread и gRPC-подключения (аудит, п. 1.3).
        self._shutdown_connections()
        self._set_status_clock_state("connecting")

        self.client = FinamClient(secret, account_id)
        self.status_label.setText("Проверка подключения…")
        self.statusBar().repaint()  # чтобы статус успел перерисоваться перед блокирующими вызовами ниже

        # ID счёта не введён — берём из TokenDetails (тот же синхронный
        # вызов в главном потоке, что и в run_account_diagnostics ниже).
        if not account_id:
            found: list[str] = []
            # api.finam.ru иногда отвечает таймаутом на первый запрос —
            # пробуем до 3 раз, прежде чем сдаваться.
            for attempt in range(1, 4):
                try:
                    details = self.client.get_token_details()
                    found = FinamStreamClient._extract_account_ids(details)
                    break
                except Exception as exc:
                    print(
                        f"[account_id] TokenDetails, попытка {attempt}/3 не удалась: {exc}",
                        file=sys.stderr,
                    )
            if not found:
                self.status_label.setText(
                    "Не удалось определить ID счёта — проверьте токен "
                    "или укажите ID вручную в «Настройках…»"
                )
                self._set_status_clock_state("disconnected")
                return
            account_id = str(found[0])
            if len(found) > 1:
                print(
                    f"[account_id] У токена несколько счетов: {found}. "
                    f"Используем первый: {account_id}. Нужен другой — "
                    "укажите его в «Настройках…».",
                    file=sys.stderr,
                )
            self.client.account_id = account_id

        # Синхронно, в главном потоке — см. подробное объяснение в
        # docstring run_account_diagnostics(): первый в процессе SSL-вызов
        # из фонового потока стабильно ронял python.exe на Windows.
        run_account_diagnostics(self.client)

        # То же самое верно и для gRPC — у него СВОЙ, отдельный от
        # urllib3/requests SSL-стек (BoringSSL), и первый вызов через него
        # падал по той же причине, только уже внутри finam_trade_api.auth
        # (см. историю падений). Поэтому соединение шлюза (connect_ — auth-хендшейк)
        # и FinamStreamClient поверх него строим синхронно здесь, а в фоновые
        # потоки передаём уже готовый, "прогретый" клиент — дальше это безопасно.
        # Сначала шлюз Finam + хаб подписок: его соединение (создаётся здесь, в GUI-потоке)
        # общее для рыночных данных, заявок и справочных запросов.
        self._start_market_data(secret, account_id)

        # FinamStreamClient — справочник, история, позиции/заявки, цепочка опционов.
        # В терминале он идёт через соединение шлюза (SharedClientProxy); если шлюз
        # не запустился — через своё соединение (без потоков данных).
        try:
            if getattr(self, "md_gateway", None) is not None:
                from finam_sdk_client import SharedClientProxy
                self.sdk_client = FinamStreamClient(
                    secret, client=SharedClientProxy(lambda: getattr(self, "md_gateway", None)))
                print("[данные] справочные запросы — через соединение шлюза", file=sys.stderr)
            else:
                self.sdk_client = FinamStreamClient(secret)
        except Exception:
            self.sdk_client = None
            print(
                "[диагностика] Создание FinamStreamClient упало:",
                file=sys.stderr,
            )
            traceback.print_exc()

            self.status_label.setText(
                "Ошибка подключения gRPC — см. консоль"
            )
            self._set_status_clock_state("disconnected")
            return
        
        self._set_status_clock_state("connected")
        # Даём первым запросам и стримам gRPC стартовать до отдельного Clock RPC.
        QtCore.QTimer.singleShot(6000, self._start_finam_clock_sync)
        # Стаканы из раскладки открываются после часов и остальных стримов, по одному (у каждого свой gRPC-канал).
        QtCore.QTimer.singleShot(7500, self._materialize_scalpers)

        # Подписки графиков на котировки (через хаб, а без шлюза — свои потоки) — с паузами
        # между стартами, чтобы не вешать несколько вызовов на свежий gRPC-канал разом.
        for i, panel in enumerate(list(self.panels)):
            QtCore.QTimer.singleShot(
                500 + i * 700,
                lambda p=panel: p in self.panels and p.start_stream(),
            )
        
        # Каталог, позиции и заявки загружает SdkInitWorker (_start_sdk_init ниже).
        # Не запускаем стрим котировки + 5 стримов сделок Order Flow + запрос
        # каталога одним залпом сразу после того, как гRPC-канал только что
        # создан — судя по crash_faulthandler.log, ~8 параллельных вызовов на
        # свежесозданном канале почти одновременно роняли python.exe access
        # violation'ом где-то в недрах grpc (channel_spin/interceptor).
        # Разносим старт по времени небольшими паузами — это не устраняет
        # первопричину внутри grpcio, но убирает сам всплеск нагрузки в
        # первые миллисекунды жизни канала.
        QtCore.QTimer.singleShot(
            300,
            lambda: self.order_flow_controller.start(self.sdk_client, getattr(self, "md_hub", None)),
        )
        QtCore.QTimer.singleShot(2200, lambda: self.quotes_tab.start())
        QtCore.QTimer.singleShot(
            2600,
            self._tick_after_connect,
        )
        QtCore.QTimer.singleShot(
            900,
            lambda: self._start_sdk_init(self.sdk_client, account_id),
        )
        # CNY Forward — своя подписка (TOM/фьючерс/ставки), отдельная
        # от котировок основного графика и Order Flow. Запускаем
        # последней и с задержкой — по той же причине, что и остальные
        # singleShot выше: не наваливать несколько параллельных вызовов
        # на только что созданный gRPC-канал одновременно.
        QtCore.QTimer.singleShot(
            1500,
            lambda: self.cny_forward_tab.start(self.sdk_client, getattr(self, "md_hub", None)),
        )
        # «Открытый интерес»: один стрим на два фьючерса, стартует после Positions/AssetsTest (3000 мс).
        QtCore.QTimer.singleShot(
            3500,
            lambda: self.open_interest_tab.start(self.sdk_client, getattr(self, "md_hub", None)),
        )
        # «Опционы»: если вкладка сейчас открыта — поднимаем цепочку заново на новом клиенте.
        # Самым последним и с большой паузой: после Котировок (2200 мс), Тиков (2600 мс),
        # Positions/AssetsTest (3000 мс) — 10–20 стримов цепочки не должны лечь на свежий канал залпом.
        QtCore.QTimer.singleShot(4000, self.options_tab.on_client_ready)

    def _start_sdk_init(self, client: FinamStreamClient, account_id: str) -> None:
        self._sdk_thread = QtCore.QThread(self)
        self._sdk_thread.setObjectName("sdk-init")   # имя видно в сообщениях Qt о потоках
        worker = SdkInitWorker(client, account_id)
        worker.moveToThread(self._sdk_thread)

        self._sdk_thread.started.connect(worker.run)
        worker.all_assets_loaded.connect(self._on_all_assets_loaded)
        worker.positions_loaded.connect(lambda rows: self._populate_table(self.positions_table, rows))
        worker.orders_loaded.connect(lambda rows: self._populate_table(self.orders_table, rows))
        worker.error.connect(self._on_data_error)
        worker.finished.connect(self._sdk_thread.quit)
        self._sdk_thread.finished.connect(worker.deleteLater)

        self._sdk_init_worker = worker  # держим ссылку от сборщика мусора
        self._sdk_thread.start()

    def _on_all_assets_loaded(self, assets: list) -> None:
        # Полный каталог брокера. Архивные инструменты исключаем.
        assets = [
            a for a in assets
            if not a.get("is_archived", False)
        ]

        self._active_assets = assets
        register_symbols(a.get("symbol", "") for a in assets)   # имена без площадки -> настоящие тикеры
        for panel in self.panels:
            panel.set_catalog_available(bool(self._active_assets))

        print(f"[каталог] активных инструментов: {len(assets)}", file=sys.stderr)

        symbols = sorted({
            a.get("symbol", "")
            for a in assets
            if a.get("symbol")
        })
        
        if not symbols:
            return

        # Сверяем сгенерированные квартальные фьючерсы с реальным каталогом:
        # если формат тикера у брокера другой, увидим это в консоли.
        missing_quarterly = [s for s in QUARTERLY_SYMBOLS if s not in symbols]
        if missing_quarterly:
            print(
                f"[КАТАЛОГ] Квартальных фьючерсов нет в каталоге: "
                f"{missing_quarterly}",
                file=sys.stderr,
            )

        self._catalog_symbols = symbols
        for panel in self.panels:
            panel.set_catalog_symbols(symbols)

        self.status_label.setText(
            f"Каталог загружен: {len(symbols)} инструментов"
        )

    @property
    def history_period(self) -> str:
        """Ключ периода загрузки истории из настроек (2w / 1m / 3m / 6m / 1y)."""
        key = str(self.settings.value(_HISTORY_SETTINGS_KEY, DEFAULT_HISTORY_PERIOD))
        valid = {k for _label, k, _offset in HISTORY_PERIODS}
        return key if key in valid else DEFAULT_HISTORY_PERIOD

    def _algo_events_for(self, symbol: str) -> list:
        """События «Алгоритмов» инструмента для значков стакана. Тикер сравнивается и без площадки
        («CRZ6@RTSX» = «CRZ6»), как у отметок стакана (mm_marks.Board). Только события этого сеанса
        (saved=False): сохранённые айсберги в столбик значков не попадают."""
        quotes = getattr(self, "quotes_tab", None)
        if quotes is None or not symbol:
            return []
        known = set(getattr(quotes, "chart_events", {}) or {}) | set(getattr(quotes, "mm_chart_events", {}) or {})
        if symbol not in known:
            base = symbol.split("@")[0].upper()
            symbol = next((s for s in known if s.split("@")[0].upper() == base), None)
            if symbol is None:
                return []
        return quotes.chart_events_for(symbol, saved=False)

    def _load_display_tz(self) -> str:
        name = str(self.settings.value(_TZ_SETTINGS_KEY, DEFAULT_DISPLAY_TZ))
        return name if _is_valid_timezone(name) else DEFAULT_DISPLAY_TZ

    def _apply_display_tz(self) -> None:
        """Применяет новый часовой пояс без перезагрузки данных."""
        self.display_tz = self._load_display_tz()
        set_cny_display_timezone(self.display_tz)
        for panel in self.panels:
            panel.apply_display_tz()
        if self.tick_volume_manager is not None:
            self.tick_volume_manager.set_timezone(self.display_tz)
        clock = getattr(self, "status_clock", None)
        if clock is not None and shiboken6.isValid(clock):
            clock.set_timezone(self.display_tz)

    def _connection_settings(self) -> tuple:
        """То, от чего зависит подключение к Finam: токен и счёт."""
        return (str(self.settings.value("finam/secret", "") or ""),
                str(self.settings.value("finam/account_id", "") or "").strip())

    def open_settings(self) -> None:
        old_theme = str(self.settings.value("appearance/theme", "dark"))
        old_font = self.settings.value("appearance/font_size", 0)
        old_conn = self._connection_settings()
        old_history = self.settings.value("data/history_period")
        dlg = SettingsDialog(self.settings, self)
        if dlg.exec() == QtWidgets.QDialog.Accepted:
            theme_name = str(self.settings.value("appearance/theme", "dark"))
            app = QtWidgets.QApplication.instance()
            # Общий стиль переприменяется ко ВСЕМ виджетам терминала — с 10 стаканами, графиками и окнами
            # «Тиков» это секунды. Раньше — на любое «ОК» в «Настройках» (29.10: интерфейс замер на 11,6 с
            # вместе с переподключением ниже). Теперь — только если сменились тема, шрифт или цвета.
            restyle = (theme_name != old_theme or self.settings.value("appearance/font_size", 0) != old_font
                       or getattr(dlg, "needs_restart", False) or getattr(dlg, "needs_restyle", False))
            if app is not None and restyle:
                app.setStyleSheet(app_stylesheet(theme_name))
                fx_theme.apply_palette(app, theme_name)
                apply_app_font_size(app)
            if theme_name != old_theme:
                QtCore.QTimer.singleShot(0, self._offer_restart_for_theme)
            elif getattr(dlg, "needs_restart", False):    # цвета/шрифт графиков, цвета приложения
                QtCore.QTimer.singleShot(0, lambda: self._offer_restart_for_theme(
                    "Цвета или шрифты изменены.",
                    "Стакан и окна уже перекрашены; графики, дашборды и шапки окон получат новые цвета "
                    "после перезапуска."))
            for panel in self.panels:
                panel.refresh_toolbar_icons()
            self._apply_display_tz()
            # Переподключение (все потоки, стаканы, шлюз заново) — только если сменились токен или счёт либо
            # подключения сейчас нет; иначе «ОК» в «Настройках» (звук, цвета, синхронизация…) рвало все потоки.
            gateway = getattr(self, "md_gateway", None)
            if gateway is not None and hasattr(gateway, "set_book_mode"):          # разбор стакана Rust / SDK
                gateway.set_book_mode(str(self.settings.value("data/book_engine", "auto")))
            if self._connection_settings() != old_conn or getattr(self, "md_gateway", None) is None:
                self._try_init_client()
                self.refresh_all_data()
            elif self.settings.value("data/history_period") != old_history:
                self.refresh_all_data()                # сменилась глубина истории — свечи заново, потоки не трогаем

    def _offer_restart_for_theme(self, text: str = "Тема изменена.",
                                 info: str = "Окна, вкладки и графики полностью перекрасятся после "
                                             "перезапуска терминала.") -> None:
        """Общий стиль меняется сразу, но графики, вкладки и окна берут цвета темы (и цвета из
        «Настройки» → «Цвета») при создании — полностью они применяются после перезапуска. Перезапуск —
        через обычное закрытие (раскладка и заметки сохраняются), новый процесс стартует уже после сохранения."""
        box = QtWidgets.QMessageBox(self)
        box.setIcon(QtWidgets.QMessageBox.Icon.Question)
        box.setWindowTitle("Цветовая тема")
        box.setText(text)
        box.setInformativeText(info + "\nПерезапустить сейчас?")
        now_btn = box.addButton("Перезапустить", QtWidgets.QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Позже", QtWidgets.QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(now_btn)
        box.exec()
        if box.clickedButton() is now_btn:
            self._restart_requested = True
            self.close()
            if self.isVisible():                 # закрытие отменено (например, открыта LIVE-позиция)
                self._restart_requested = False

    @staticmethod
    def _stop_thread(thread: QtCore.QThread | None, timeout_ms: int = 2000, name: str = "") -> None:
        """
        Останавливает поток и ЖДЁТ подтверждения, что он реально завершился
        (аудит, п. 1.2/2.3: "проверять isRunning() после wait()") — простого
        thread.quit() недостаточно, если поток застрял в блокирующем вызове.
        """
        if thread is None or not thread.isRunning():
            return
        thread.quit()
        if not thread.wait(timeout_ms):
            print(
                f"[предупреждение] поток {name or thread} не завершился за {timeout_ms} мс — "
                f"возможна утечка потока",
                file=sys.stderr,
            )

    def _start_market_data(self, secret: str, account_id) -> None:
        """FinamGateway + MarketDataHub — источник рыночных данных всех окон и соединение для заявок.
        Если шлюз не запустился, окна остаются без потоков данных (история и справочник — через sdk_client)."""
        self.md_gateway = None
        self.md_hub = None
        try:
            from brokers.finam.gateway import FinamGateway
            from services.market_data_hub import MarketDataHub
            from services.qt_dispatch import QtDispatcher

            gateway = FinamGateway(secret, account_id=str(account_id) if account_id else None)
            # Канал создаём здесь, в GUI-потоке (как и sdk_client): первый вызов через свежий
            # SSL-стек из фонового потока на Windows уже ронял python.exe.
            gateway.connect_()
            gateway.set_book_mode(str(self.settings.value("data/book_engine", "auto")))   # стакан: Rust / SDK
            self._md_dispatcher = QtDispatcher(self)
            self.md_hub = MarketDataHub(gateway, dispatcher=self._md_dispatcher)
            self.md_gateway = gateway
            print("[данные] шлюз Finam и хаб подписок запущены", file=sys.stderr)
            # Открытые окна стакана, подписанные на прежний хаб, переподписываем на новый.
            manager = getattr(self, "_scalper_manager", None)
            for window in list(getattr(manager, "windows", []) or []):
                restart = getattr(getattr(window, "engine", None), "restart", None)
                if callable(restart):
                    restart()
        except Exception:
            print("[данные] шлюз Finam не запустился — потоков данных не будет:", file=sys.stderr)
            traceback.print_exc()

    def _stop_market_data(self) -> None:
        gateway = getattr(self, "md_gateway", None)
        self.md_hub = None
        self.md_gateway = None
        if gateway is not None:
            try:
                gateway.disconnect_()
            except Exception:
                print("[shutdown] Ошибка остановки шлюза Finam:", file=sys.stderr)
                traceback.print_exc()

    def _shutdown_connections(self) -> None:
        """
        Единая точка остановки всего фонового: подписки графиков и Order Flow
        (в хабе), остальные вкладки,
        воркер инициализации SDK и последним — шлюз Finam (_stop_market_data).
        (Диагностика REST теперь синхронная в главном потоке, отдельного
        воркера/потока для неё больше нет — см. run_account_diagnostics.)
        Вызывается и перед поднятием новых подключений (открыли
        «Настройки» повторно), и при закрытии приложения — чтобы никогда
        не создавать второй набор потоков/клиентов поверх ещё живого
        первого (аудит, п. 1.3).
        """
        # Останавливаем фоновую синхронизацию часов Finam до остановки gRPC-клиента.
        clock_source = getattr(self, "finam_clock_source", None)
        self.finam_clock_source = None
        if clock_source is not None:
            try:
                clock_source.stop()
            except Exception:
                print("[shutdown] Ошибка остановки синхронизации часов Finam:", file=sys.stderr)
                traceback.print_exc()
        try:
            self._set_status_clock_time_source(None)
        except Exception:
            pass

        # 1. Сначала закрываем подписки графиков на котировки в хабе.
        for panel in self.panels:
            panel.stop_stream()

        # 1b. Окна «Тики Bid/Ask» (подписки в хабе).
        if getattr(self, "tick_volume_manager", None) is not None:
            try:
                self.tick_volume_manager.stop()
            except Exception:
                print("[shutdown] Ошибка остановки «Тики Bid/Ask»:", file=sys.stderr)
                traceback.print_exc()

        # 2. Затем Order Flow (подписки на сделки в хабе).
        if self.order_flow_controller is not None:
            try:
                self.order_flow_controller.stop()
            except Exception:
                print(
                    "[shutdown] Ошибка остановки Order Flow:",
                    file=sys.stderr,
                )
                traceback.print_exc()

        # 3. Останавливаем SDK worker (каталог, позиции, заявки).
        if self._sdk_thread is not None:
            self._stop_thread(
                self._sdk_thread,
                name="sdk-init",
            )
            self._sdk_thread = None

        # 6. Останавливаем «Котировки» (единый quote stream + trade streams).
        if getattr(self, "quotes_tab", None) is not None:
            try:
                self.quotes_tab.stop()
            except Exception:
                print("[shutdown] Ошибка остановки Котировок:", file=sys.stderr)
                traceback.print_exc()

        # 7. Останавливаем вкладку CNY Forward (свой фоновый поток —
        # см. cny_forward_tab.CnyMonitorWorker).
        if getattr(self, "cny_forward_tab", None) is not None:
            try:
                self.cny_forward_tab.stop()
            except Exception:
                print(
                    "[shutdown] Ошибка остановки CNY Forward:",
                    file=sys.stderr,
                )
                traceback.print_exc()

        # 8. Вкладка «Открытый интерес»: поток котировок. Клиент общий — его не закрываем.
        if getattr(self, "open_interest_tab", None) is not None:
            try:
                self.open_interest_tab.stop()
            except Exception:
                print("[shutdown] Ошибка остановки «Открытого интереса»:", file=sys.stderr)
                traceback.print_exc()

        # 9. Вкладка «Опционы»: стримы цепочки. Клиент общий — его не закрываем.
        if getattr(self, "options_tab", None) is not None:
            try:
                self.options_tab.stop()
            except Exception:
                print("[shutdown] Ошибка остановки «Опционов»:", file=sys.stderr)
                traceback.print_exc()

        # 10. Шлюз Finam последним: подписки окон уже закрыты выше.
        self._stop_market_data()

    @staticmethod
    def _display_value(value):
        # Числовые поля из API приходят обёрнутыми в {"value": "..."} —
        # та же decimal-обёртка, что и в свечах/котировках. Распаковываем
        # для отображения, любую другую вложенную структуру просто
        # приводим к строке как есть.
        if isinstance(value, dict) and set(value.keys()) == {"value"}:
            return value["value"]
        return value

    def _populate_table(self, table: QtWidgets.QTableWidget, rows: list[dict]) -> None:
        if not rows:
            table.setRowCount(0)
            table.setColumnCount(0)
            return

        columns = sorted({key for row in rows for key in row.keys()})
        table.setColumnCount(len(columns))
        table.setHorizontalHeaderLabels(columns)
        table.setRowCount(len(rows))

        for r, row in enumerate(rows):
            for c, col in enumerate(columns):
                value = self._display_value(row.get(col, ""))
                table.setItem(r, c, QtWidgets.QTableWidgetItem(str(value)))

        table.resizeColumnsToContents()

    @QtCore.Slot(str)
    def _on_data_error(self, message: str) -> None:
        self.status_label.setText("Ошибка загрузки данных — см. консоль")
        print(message, file=sys.stderr)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        # Подтверждение выхода («Настройки» → «Интерфейс»). При перезапуске после смены темы
        # пользователь уже согласился — не спрашиваем второй раз.
        if not getattr(self, "_restart_requested", False):
            from workspace_shell import CONFIRM_CLOSE_TERMINAL, confirm_close
            spaces = len(getattr(self.group, "windows", {}) or {})
            extra = f"\nЗакроются и дополнительные пространства ({spaces})." if spaces else ""
            if not confirm_close(self, "Закрыть FX Terminal", f"Закрыть терминал?{extra}", CONFIRM_CLOSE_TERMINAL):
                event.ignore()
                return
        try:
            self.notes_store.save()          # комментарий, набранный за последние полсекунды, тоже сохранится
        except Exception:
            traceback.print_exc()
        # Раскладку сохраняем ДО закрытия окон «Стакан»: их закрытие убирает панели из пространств.
        # Туда же — размер и положение окон дополнительных пространств; главного окна — отдельно.
        try:
            self._layout_save_timer.stop()
            self.group.save(self.settings)
            self.settings.setValue(self.GEOMETRY_KEY, self.saveGeometry())
        except Exception:
            traceback.print_exc()
        self._layout_frozen = True               # дальше окна закрываются — сохранённую раскладку не трогать
        # LIVE-окна стакана: если там остались позиция / заявки, менеджер спросит один раз до закрытия окон;
        # при отказе терминал не закрываем (иначе пользователь потеряет контроль над открытой позицией).
        if self._scalper_manager is not None and not self._scalper_manager.shutdown():
            event.ignore()
            self._layout_frozen = False
            self._layout_save_timer.start(1500)   # если какое-то окно всё же закрылось — раскладку перезапишем
            return
        # Единая точка остановки — та же, что при переоткрытии «Настроек»
        # (аудит, п. 2.3): гарантированно дожидаемся стрима, sdk-init и
        # account-check, плюс отдельно дожидаемся bars-thread, который в
        # _shutdown_connections не входит (он у REST-свечей, живёт своим
        # циклом через refresh_data/poll_timer, а не через SDK-подключение).
        started = time.monotonic()
        print("[завершение] закрываю терминал: останавливаю потоки и окна", file=sys.stderr)
        try:                                   # долгое закрытие — не зависание интерфейса
            from services import hang_watch
            hang_watch.stop()
        except Exception:
            pass
        _start_exit_watchdog(EXIT_WATCHDOG_SEC)
        self.poll_timer.stop()
        sampler = getattr(self, "perf_sampler", None)
        if sampler is not None:
            sampler.stop()                   # дописать в CSV последнюю неполную минуту
        account_svc = getattr(self, "_account_svc", None)
        if account_svc is not None:
            account_svc.stop()               # опрос счёта для «Сделок» / «Финреза»
        for name in ("drawings_sync", "notes_sync"):
            sync = getattr(self, name, None)
            if sync is not None:
                sync.stop()                  # таймеры обмена рисунками и заметками (идущий обмен — фоновый)
        self._shutdown_connections()
        if self.tick_volume_manager is not None:
            self.tick_volume_manager.shutdown()
        try:
            self.group.close_secondary()
        except Exception:
            traceback.print_exc()
        # Сначала закрываем отдельные графики из «Котировок», чтобы их
        # собственные ChartPanel успели остановить REST/gRPC потоки.
        for window in list(self._quote_chart_windows.values()):
            try:
                window.close()
            except Exception:
                pass
        self._quote_chart_windows.clear()
        for panel in self.panels:
            panel.shutdown()
        super().closeEvent(event)
        # Выходим явно, а не ждём «закрылось последнее окно»: открытое окно «Состояние подключения»,
        # уведомления или плавающая панель — тоже окна верхнего уровня, и пока они есть, Qt не
        # заканчивает цикл событий (главное окно исчезло, а процесс продолжал работать).
        print(f"[завершение] остановлено за {time.monotonic() - started:.1f} с", file=sys.stderr)
        app = QtWidgets.QApplication.instance()
        if app is not None:
            for widget in app.topLevelWidgets():       # кроме себя: повторный close() снова вызвал бы closeEvent
                if widget is not self and widget.isVisible():
                    try:
                        widget.close()
                    except Exception:
                        pass
            app.quit()
