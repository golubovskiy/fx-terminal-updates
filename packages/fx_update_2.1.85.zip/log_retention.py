# -*- coding: utf-8 -*-
"""Сколько хранить журналы терминала (2.1.85) — без Qt: «Настройки» → «Журналы» (logs_page.py).

Журналы лежат в папке журналов (app_paths.LOG_DIR: из исходников — logs\\ рядом с терминалом, у собранной
программы — %LOCALAPPDATA%\\FX_Terminal\\logs). Там же история айсбергов (iceberg_history.jsonl) — её срок тоже
здесь, но старые записи из файла убирает само окно «Алгоритмов» (records=True). До 2.1.85 сами удалялись только журнал терминала и нагрузка
(14 дней); маркет-мейкер, роботы, зависания, установка обновлений копились всегда.

Для каждой группы (GROUPS) — свой срок в настройках, ключ logs/keep/<группа>:
    AUTO (-1, по умолчанию) — срок группы по умолчанию (default_days);
    NEVER (0)               — не удалять;
    N > 0                   — удалять файлы старше N дней.
Дата файла — из имени (…_ГГГГ-ММ-ДД…), без неё — время последнего изменения. Сегодняшний файл не удаляется
никогда: в него пишут прямо сейчас. Очистка — при запуске терминала, раз в 6 часов и после «OK» в настройках
(cleanup_all); кнопка «Удалить» страницы — delete_group (всё, кроме сегодняшнего).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

AUTO = -1
NEVER = 0
KEY = "logs/keep/"                        # + ключ группы
CHOICES = (7, 14, 30, 60, 90, 180, 365)   # сроки в выпадающем списке страницы, дней
_DATE = re.compile(r"(\d{4}-\d{2}-\d{2})")


@dataclass(frozen=True)
class Group:
    key: str
    title: str
    patterns: tuple[str, ...]
    default_days: int
    hint: str
    records: bool = False      # один файл с записями (история айсбергов): по сроку чистит само окно, а не удаление файла


GROUPS: tuple[Group, ...] = (
    Group("terminal", "Журнал терминала", ("fx_terminal_*.log",), 14,
          "fx_terminal_ДАТА.log — сообщения терминала, ошибки, нагрузка по минутам"),
    Group("mm", "Маркет-мейкер и «Наращивание»", ("mm_events_*.csv",), 90,
          "mm_events_ДАТА.csv — события детекторов; по ним считается «Сводка» в настройках «Алгоритмов»"),
    Group("robots", "Роботы", ("robots_*.csv",), 90, "robots_ДАТА.csv — закончившиеся серии роботов"),
    Group("perf", "Нагрузка", ("perf_*.csv",), 14, "perf_ДАТА.csv — замеры нагрузки по минутам"),
    Group("hang", "Зависания и сбои", ("hang_*.txt", "crash_*.txt"), 30,
          "hang_ДАТА.txt — зависания интерфейса, crash_….txt — падения"),
    Group("update", "Установка обновлений", ("update_*.log",), 30, "update_ДАТА.log — что ставилось и проверки"),
    Group("diag", "Диагностика подключения", ("diagnostics_*.txt",), 30,
          "diagnostics_….txt — сохранённые результаты диагностики"),
    Group("iceberg", "История айсбергов", ("iceberg_history.jsonl",), 30,
          "iceberg_history.jsonl — крупные айсберги для графика; старые записи убирает сам терминал", records=True),
    Group("rust", "Сверка Rust", ("rust_algo_*.csv", "rust_book_*.csv"), 14,
          "rust_algo_ / rust_book_ДАТА.csv — сверка «в тени» (пишется только при отладке)"),
)
BY_KEY = {g.key: g for g in GROUPS}


def setting(key: str, settings) -> int:
    """Сохранённый выбор группы: AUTO, NEVER или число дней."""
    try:
        value = int(settings.value(KEY + key, AUTO)) if settings is not None else AUTO
    except (TypeError, ValueError):
        return AUTO
    return value if value >= AUTO else AUTO


def days(key: str, settings) -> int:
    """Сколько дней хранить группу на деле: 0 — не удалять."""
    value = setting(key, settings)
    return BY_KEY[key].default_days if value == AUTO else value


def files(folder: Path, key: str) -> list[Path]:
    found: dict[str, Path] = {}
    for pattern in BY_KEY[key].patterns:
        for path in Path(folder).glob(pattern):
            if path.is_file():
                found[str(path)] = path
    return sorted(found.values())


def file_day(path: Path) -> date:
    """День файла: дата из имени, иначе — день последнего изменения."""
    m = _DATE.search(path.name)
    if m:
        try:
            return date.fromisoformat(m.group(1))
        except ValueError:
            pass
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).date()
    except OSError:
        return date.today()


def usage(folder: Path, key: str) -> tuple[int, int]:
    """(число файлов, байт) группы."""
    count = size = 0
    for path in files(folder, key):
        try:
            size += path.stat().st_size
            count += 1
        except OSError:
            pass
    return count, size


def _remove(paths) -> int:
    removed = 0
    for path in paths:
        try:
            path.unlink()
            removed += 1
        except OSError:                    # открыт другим процессом (Windows) — в следующий раз
            pass
    return removed


def cleanup_group(folder: Path, key: str, keep_days: int, today: date | None = None) -> int:
    """Удалить файлы группы старше keep_days дней (0 — ничего). Сегодняшние — никогда. У группы записей (история
    айсбергов) файл не удаляется: старые записи по сроку отбрасывает окно (QuotesTab._ice_keep_days)."""
    if keep_days <= 0 or BY_KEY[key].records:
        return 0
    today = today or date.today()
    return _remove(p for p in files(folder, key)
                   if file_day(p) < today and (today - file_day(p)).days >= keep_days)


def delete_group(folder: Path, key: str, today: date | None = None) -> int:
    """Кнопка «Удалить»: все файлы группы, кроме сегодняшних (в них пишут прямо сейчас). Группа записей — 0:
    её историю держит открытый терминал (у айсбергов — «Очистить историю» в настройках айсбергов)."""
    if BY_KEY[key].records:
        return 0
    today = today or date.today()
    return _remove(p for p in files(folder, key) if file_day(p) < today)


def cleanup_all(folder: Path, settings, today: date | None = None) -> dict[str, int]:
    """Очистка всех групп по их срокам -> {группа: удалено файлов} (только где что-то удалено)."""
    result = {}
    for group in GROUPS:
        try:
            n = cleanup_group(folder, group.key, days(group.key, settings), today)
        except Exception:                  # noqa: BLE001 — журналы не повод мешать работе
            n = 0
        if n:
            result[group.key] = n
    return result


def human_size(size: int) -> str:
    for unit, step in (("ГБ", 1 << 30), ("МБ", 1 << 20), ("КБ", 1 << 10)):
        if size >= step:
            return f"{size / step:.1f} {unit}".replace(".", ",")
    return f"{size} Б"


def report(removed: dict[str, int]) -> str:
    return ", ".join(f"{BY_KEY[k].title.lower()} — {n}" for k, n in removed.items())
