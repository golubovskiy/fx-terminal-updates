# -*- coding: utf-8 -*-
"""Биржевой айсберг или доливка роботом (без Qt, tests/test_iceberg_kind.py).

Сам поиск айсбергов — iceberg_core.py (эталон) и fx_engine (Rust, iceberg_rust.py, с 2.1.64). restored() этого
файла — правило «объём восстановился»: его зовёт эталон, а в Rust оно повторено (algo/iceberg.rs, restored) —
правка здесь требует такой же правки там.

Мосбиржа, срочный рынок (moex.com/s3171): айсберг-заявка — безадресная лимитированная заявка с общим объёмом и
видимой частью; у видимой части есть минимум, который задаёт биржа (контрактов), видимая часть может быть
больше на случайную надбавку до 20 %, но не меньше минимума. Детектор видит объём всего уровня стакана (вместе
с чужими заявками), поэтому:
    наибольший видимый объём уровня МЕНЬШЕ биржевого минимума — биржевым айсбергом это быть не может: заявку
        доливает робот («искусственный айсберг»);
    не меньше минимума — может быть и биржевой айсберг, и робот: «возможно биржевой».
Валютный рынок (MISX): айсберги есть только у профучастников, минимумы — по инструментам в документах биржи,
здесь их нет — вид не определяем.

История айсбергов на графике (с 2.0.67, «Настройки алгоритмов» → «Айсберг» → «Сохранять в историю
графика»): закончившийся уровень (цена прошла за него или он минуту молчал; при закрытии терминала — и ещё
держащийся), на цене которого исполнено не меньше «Крупный айсберг, исполнено от» (лоты), дописывается в HISTORY_FILE
(JSON Lines, events_journal.EventsJournal, хранится HISTORY_KEEP_DAYS дней). При включённом «Показывать айсберги
на графике» график рисует сохранённые айсберги тем же пунктиром на их цене: циан — покупка (bid), розовый —
продажа (ask). history_record / history_event — запись в файл и событие графика из неё.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

# Минимальная видимая часть айсберга, контрактов (moex.com/s3171), по коду фьючерса (первые две буквы тикера).
MIN_VISIBLE = {"Si": 500, "RI": 150, "BR": 300, "SR": 250, "ED": 400, "Eu": 200, "GZ": 250, "GD": 200}
DEFAULT_MIN_VISIBLE = 100            # «для всех остальных инструментов»

ROBOT = "Айсберг (доливка роботом)"
MAYBE_EXCHANGE = "Айсберг (возможно биржевой)"
UNKNOWN = "Айсберг"

_FUTURES = re.compile(r"^([A-Za-z]{2})[FGHJKMNQUVXZ]\d$")      # SiZ6, CRZ6, GDZ6, EuZ6


def min_visible(symbol: str) -> int | None:
    """Биржевой минимум видимой части айсберга для инструмента срочного рынка (…@RTSX) или None."""
    ticker, _, board = str(symbol).partition("@")
    if board.upper() != "RTSX":
        return None
    m = _FUTURES.match(ticker)
    if m:
        return MIN_VISIBLE.get(m.group(1), DEFAULT_MIN_VISIBLE)
    return DEFAULT_MIN_VISIBLE          # вечные фьючерсы (USDRUBF…), опционы — «остальные инструменты»


def classify(symbol: str, max_visible: float) -> tuple[str, str]:
    """(название для заголовка, пояснение для подробностей) по наибольшему видимому объёму уровня."""
    need = min_visible(symbol)
    if need is None:
        return UNKNOWN, ""
    lots = f"{max_visible:,.0f}".replace(",", " ")
    if max_visible < need:
        return ROBOT, f"видно не больше {lots} лотов, а у биржевого айсберга видимая часть от {need} — доливает робот"
    return MAYBE_EXCHANGE, f"видимая часть {lots} лотов не меньше биржевого минимума {need} — может быть айсберг-заявкой биржи"


# ---- восстановление видимой части --------------------------------------------------------------
RESTORE_SHARE = 0.75     # вернуться должно не меньше 3/4 съеденного сделками


def restored(before: float, traded: float, visible: float) -> bool:
    """Видимый объём уровня после сделок восстановился (доливка), а не просто остался после частичного исполнения.

    before — объём уровня при приходе первой сделки пачки, traded — сколько лотов прошло по уровню в пачке,
    visible — объём сейчас. Без доливки на уровне осталось бы before − traded; доливкой считаем, если сверх этого
    вернулось не меньше RESTORE_SHARE съеденного. Съели уровень целиком (traded ≥ before) — нужно
    ≥ 3/4 прежнего объёма, как и раньше. До 2.0.70 условие было «visible ≥ 3/4 before» при любом traded:
    на уровне в 500 лотов сделка на 10 оставляла 490 — и это засчитывалось восстановлением, хотя никто не доливал.
    traded неизвестен (0) — считаем, что уровень съели целиком (прежнее поведение)."""
    before, visible = float(before or 0), float(visible or 0)
    if before <= 0:
        return False
    traded = float(traded or 0)
    if traded <= 0:
        traded = before
    eaten = min(traded, before)
    return visible >= (before - eaten) + RESTORE_SHARE * eaten


# ---- история айсбергов для графика ---------------------------------------------------------------
HISTORY_FILE_NAME = "iceberg_history.jsonl"     # в папке logs/ терминала
HISTORY_KEEP_DAYS = 30                          # «Авто»; свой срок — «Настройки» → «Журналы» (2.1.85)
HISTORY_MAX = 100_000                           # записей в файле (все инструменты); до 2.1.85 — 20 000: при сроке
                                                # больше месяца не хватало бы (запись ~0,4 КБ — до ~40 МБ)
HISTORY_CHART_MAX = 300                         # на график инструмента — самые свежие


def _iso(value) -> str | None:
    """Время в ISO UTC («2026-11-03T08:15:00+00:00»); pandas.Timestamp / datetime / строка."""
    if value is None:
        return None
    try:
        if isinstance(value, str):
            value = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if hasattr(value, "to_pydatetime"):
            value = value.to_pydatetime()
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    except Exception:
        return None


def history_record(symbol: str, line: dict, lot_size: float, min_lots: float, session: str) -> dict | None:
    """Запись истории по закончившейся линии айсберга (quotes_tab: rows[symbol]["iceberg_lines"]) или None —
    исполнено на цене меньше min_lots лотов или линия без времени. Оборот в рублях (исполнено × цена × лот)
    записывается для подсказки на графике."""
    try:
        price = float(line.get("price") or 0)
        executed = float(line.get("executed") or 0)
    except (TypeError, ValueError):
        return None
    turnover = executed * price * float(lot_size or 1)
    if price <= 0 or executed < float(min_lots or 0):
        return None
    first, last = _iso(line.get("first")), _iso(line.get("last"))
    if first is None or last is None:
        return None
    return {
        "ts": last, "id": f"{session}:{line.get('id')}", "session": session, "line_id": str(line.get("id")),
        "symbol": symbol, "side": "BUY" if line.get("side") == "BUY" else "SELL", "price": price,
        "first": first, "last": last, "hits": int(line.get("hits") or 0), "max_hits": int(line.get("max_hits") or 0),
        "visible": float(line.get("visible") or 0), "executed": executed, "turnover": round(turnover, 2),
        "held": float(line.get("held") or 0), "source": str(line.get("source") or ""),
        "broken": bool(line.get("broken")),
    }


def history_event(record: dict) -> dict:
    """Событие графика «iceberg» из записи истории — линия уже закончилась (active False), с пометкой saved."""
    details = {k: record.get(k) for k in ("side", "price", "first", "last", "hits", "max_hits", "visible",
                                          "executed", "turnover", "source", "held", "broken")}
    details.update(id=f"hist-{record.get('id')}", active=False, saved=True, history=True)
    return {"id": details["id"], "type": "iceberg", "symbol": record.get("symbol"), "time": record.get("first"),
            "price": float(record.get("price") or 0), "details": details}


def history_for_chart(records: list[dict], symbol: str, skip_ids=(), limit: int = HISTORY_CHART_MAX) -> list[dict]:
    """События графика из истории инструмента: самые свежие limit, без тех, что уже есть в памяти этого сеанса
    (skip_ids — (session, line_id) живых событий: их график получает напрямую)."""
    skip = set(skip_ids)
    mine = [r for r in records if r.get("symbol") == symbol and (r.get("session"), r.get("line_id")) not in skip]
    return [history_event(r) for r in mine[-limit:]]
