# -*- coding: utf-8 -*-
"""Сроки хранения журналов (2.1.85): log_retention — группы, «Авто» / дни / «Не удалять», сегодняшний файл не
трогается, история айсбергов — срок здесь, записи чистит окно; «Настройки» → «Журналы» (logs_page.LogsPage) — выбор срока, «Удалить» с подтверждением. Всё во временной
папке и временном файле настроек.  Запуск:  python tests/test_log_retention.py"""
from __future__ import annotations

import os
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import log_retention as lr  # noqa: E402

TODAY = date(2026, 11, 18)


def _settings(tmp: Path) -> QtCore.QSettings:
    return QtCore.QSettings(str(tmp / "s.ini"), QtCore.QSettings.Format.IniFormat)


def _make(folder: Path) -> None:
    for back in (0, 1, 10, 20, 40, 100, 400):
        day = TODAY - timedelta(days=back)
        for name in (f"mm_events_{day}.csv", f"fx_terminal_{day}.log", f"robots_{day}.csv", f"update_{day}.log"):
            (folder / name).write_text("x", encoding="utf-8")
    (folder / "crash_2026-01-01_10-00-00.txt").write_text("x", encoding="utf-8")
    (folder / "iceberg_history.jsonl").write_text("x", encoding="utf-8")       # не журнал — не трогается
    (folder / "connection_diagnostics.log").write_text("x", encoding="utf-8")


def test_days_and_settings():
    with tempfile.TemporaryDirectory() as tmp:
        st = _settings(Path(tmp))
        assert lr.setting("mm", st) == lr.AUTO and lr.days("mm", st) == 90 and lr.days("terminal", st) == 14
        st.setValue(lr.KEY + "mm", 30)
        st.setValue(lr.KEY + "robots", lr.NEVER)
        st.setValue(lr.KEY + "hang", "мусор")
        assert lr.days("mm", st) == 30 and lr.days("robots", st) == 0 and lr.days("hang", st) == 30
        assert lr.days("terminal", None) == 14


def test_cleanup_by_groups():
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        _make(folder)
        st = _settings(folder)
        st.setValue(lr.KEY + "robots", lr.NEVER)
        st.setValue(lr.KEY + "update", 7)
        removed = lr.cleanup_all(folder, st, today=TODAY)
        names = {p.name for p in folder.iterdir()}
        # mm — авто 90 дней: 100 и 400 дней назад удалены, 40 — нет
        assert f"mm_events_{TODAY - timedelta(days=40)}.csv" in names
        assert f"mm_events_{TODAY - timedelta(days=100)}.csv" not in names
        # журнал терминала — 14 дней; роботы — «Не удалять»; обновления — 7 дней
        assert f"fx_terminal_{TODAY - timedelta(days=10)}.log" in names
        assert f"fx_terminal_{TODAY - timedelta(days=20)}.log" not in names
        assert all(f"robots_{TODAY - timedelta(days=b)}.csv" in names for b in (0, 400))
        assert f"update_{TODAY - timedelta(days=1)}.log" in names and f"update_{TODAY - timedelta(days=10)}.log" not in names
        assert "crash_2026-01-01_10-00-00.txt" not in names                    # зависания и сбои — 30 дней
        assert {"iceberg_history.jsonl", "connection_diagnostics.log"} <= names
        assert removed["mm"] == 2 and "robots" not in removed and removed["hang"] == 1
        assert "мм" not in lr.report(removed) and "маркет-мейкер" in lr.report(removed)


def test_delete_group_keeps_today():
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        _make(folder)
        assert lr.delete_group(folder, "mm", today=TODAY) == 6
        assert [p.name for p in lr.files(folder, "mm")] == [f"mm_events_{TODAY}.csv"]
        assert lr.usage(folder, "terminal")[0] == 7
        assert lr.human_size(1536) == "1,5 КБ" and lr.human_size(10) == "10 Б"


def test_iceberg_history_is_records_group():
    """История айсбергов: срок в «Журналах», но файл не удаляется ни очисткой, ни кнопкой — записи по сроку
    отбрасывает окно (QuotesTab._ice_keep_days: «Не удалять» — 100 лет)."""
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        path = folder / "iceberg_history.jsonl"
        path.write_text("x", encoding="utf-8")
        old = (TODAY - timedelta(days=400)).strftime("%Y-%m-%d")
        os.utime(path, (1_600_000_000, 1_600_000_000))                       # файл не менялся с 2020 года
        st = _settings(folder)
        assert lr.days("iceberg", st) == 30 and lr.BY_KEY["iceberg"].records
        assert lr.cleanup_all(folder, st, today=TODAY) == {} and path.exists(), old
        assert lr.delete_group(folder, "iceberg", today=TODAY) == 0 and path.exists()
        assert lr.usage(folder, "iceberg")[0] == 1
    import quotes_tab
    import iceberg_kind
    days = quotes_tab.QuotesTab._ice_keep_days()
    assert days > 0 and iceberg_kind.HISTORY_MAX >= 100_000


def test_logs_page():
    import logs_page
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        for back in (0, 5):
            (folder / f"mm_events_{date.today() - timedelta(days=back)}.csv").write_text("x", encoding="utf-8")
        st = _settings(folder)
        st.setValue(lr.KEY + "update", 45)                                 # своего срока нет в списке
        answers = []
        page = logs_page.LogsPage(st, "#888888", folder=folder, confirm=lambda text: answers.append(text) or True)
        try:
            assert page.combos["mm"].currentData() == lr.AUTO and page.combos["update"].currentData() == 45
            assert "2 файл." in page.usage_labels["mm"].text() and page.usage_labels["robots"].text() == "нет файлов"
            assert not page.delete_buttons["robots"].isEnabled()
            (folder / "iceberg_history.jsonl").write_text("x", encoding="utf-8")
            page.refresh()
            assert not page.delete_buttons["iceberg"].isEnabled()             # историю держит терминал
            page.combos["robots"].setCurrentIndex(page.combos["robots"].findData(lr.NEVER))
            page.save()
            assert lr.setting("robots", st) == lr.NEVER and lr.setting("mm", st) == lr.AUTO
            assert page.delete_now("mm") == 1 and answers and "Маркет-мейкер" in answers[0]
            assert "1 файл." in page.usage_labels["mm"].text()
            page._confirm = lambda text: False                                # «Нет» — ничего не удалено
            assert page.delete_now("mm") == 0
        finally:
            page.deleteLater()


def test_settings_dialog_has_page():
    import settings_dialog
    with tempfile.TemporaryDirectory() as tmp:
        dlg = settings_dialog.SettingsDialog(_settings(Path(tmp)), None)
        try:
            assert "Журналы" in dlg.PAGES and dlg.pages.count() == len(dlg.PAGES)
            assert hasattr(dlg, "logs_page")
        finally:
            dlg.reject()
            dlg.deleteLater()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
