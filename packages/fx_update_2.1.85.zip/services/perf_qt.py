# -*- coding: utf-8 -*-
"""Qt-часть замера нагрузки (services/perf.py): секундный такт, задержка GUI, CSV и подробный режим.

PerfSampler — создаётся в MainWindow (GUI-поток), работает всё время, пока открыт терминал:
    * таймер 50 мс: насколько он опоздал — столько GUI-поток был занят чем-то другим
      (это и есть задержка реакции на клик, перерисовку, новые данные);
    * раз в секунду — время ЦП процесса (time.process_time) и GUI-потока (time.thread_time,
      вызывается в GUI-потоке), счётчики сообщений шлюза → PERF.sample();
    * раз в минуту — средние и пики в logs/perf_ГГГГ-ММ-ДД.csv (time,phase,metric,avg,max;
      phase: startup — первая минута после запуска, work — работа) и одна строка «[нагрузка …]»
      в журнал. CSV хранятся KEEP_DAYS дней.
      Тихий режим (2.1.65, обычный запуск; services/log_mode.py): в CSV идут только минуты аномальной нагрузки
      (services/perf.abnormal); строка «[нагрузка …]» такой минуты кончается словами «аномальная нагрузка: …» —
      по ним журнал терминала записывает её и в тихом режиме. Обычные минуты видны в консоли и в окне
      «Состояние подключения», в файлы не идут.

TimingApplication — подробный режим, включается переменной окружения FX_PERF_DETAIL=1 до запуска:
    $env:FX_PERF_DETAIL=1; python gui_app.py
QApplication.notify замеряет каждое событие Qt (отрисовку, таймеры, вызовы из очереди) по классу
получателя. Сам добавляет несколько процентов нагрузки, поэтому по умолчанию выключен;
без него GUI-поток виден целиком (cpu.gui), но без разбивки на отрисовку и таймеры.
"""
from __future__ import annotations

import csv
import os
import sys
import time
from pathlib import Path
from typing import Callable

from PySide6 import QtCore, QtWidgets

from services import log_mode
from services.perf import PERF, PerfMonitor, abnormal

HEARTBEAT_MS = 50
CSV_PREFIX = "perf_"
KEEP_DAYS = 14
DETAIL_ENV = "FX_PERF_DETAIL"


def detail_enabled() -> bool:
    return os.getenv(DETAIL_ENV, "").strip() in ("1", "true", "yes", "on")


class PerfSampler(QtCore.QObject):
    def __init__(self, folder: Path | None, messages: Callable[[], dict | None],
                 monitor: PerfMonitor = PERF, parent=None, quiet: bool | None = None):
        """folder — куда писать CSV (None — не писать); messages() — накопительные счётчики
        сообщений шлюза ({вид: число}) или None, если шлюза нет; quiet — тихий режим: в CSV только минуты
        аномальной нагрузки (None — по режиму журналов запуска, services/log_mode.py)."""
        super().__init__(parent)
        self.monitor = monitor
        self.quiet = (not log_mode.full()) if quiet is None else bool(quiet)
        self._messages = messages
        self.folder = Path(folder) if folder is not None else None
        if self.folder is not None:
            try:
                self.folder.mkdir(parents=True, exist_ok=True)
                cleanup(self.folder, _keep_days())
            except OSError:
                self.folder = None
        self._lags: list[float] = []
        now = time.perf_counter()
        self._last_beat = now
        self._interval_start = now
        self._cpu = time.process_time()
        self._gui_cpu = time.thread_time()
        self.timer = QtCore.QTimer(self)
        self.timer.setTimerType(QtCore.Qt.TimerType.PreciseTimer)
        self.timer.timeout.connect(self._beat)
        self.timer.start(HEARTBEAT_MS)

    def csv_path(self) -> Path | None:
        if self.folder is None:
            return None
        return self.folder / f"{CSV_PREFIX}{time.strftime('%Y-%m-%d')}.csv"

    def stop(self) -> None:
        """Остановить такт и дописать неполную минуту (вызывается при закрытии терминала)."""
        self.timer.stop()
        self._minute(self.monitor.minutes.flush(), say=False)

    def _beat(self) -> None:
        now = time.perf_counter()
        self._lags.append(max(0.0, (now - self._last_beat) * 1000.0 - HEARTBEAT_MS))
        self._last_beat = now
        if now - self._interval_start < 1.0:
            return
        cpu, gui_cpu = time.process_time(), time.thread_time()
        try:
            messages = self._messages()
        except Exception:
            messages = None
        _, rows = self.monitor.sample(now - self._interval_start, cpu - self._cpu, gui_cpu - self._gui_cpu,
                                      self._lags, messages)
        self._interval_start, self._cpu, self._gui_cpu, self._lags = now, cpu, gui_cpu, []
        if rows:
            self._minute(rows)

    def _minute(self, rows, say: bool = True) -> None:
        """Закрывшаяся минута: строка в журнал и строки в CSV (в тихом режиме — только аномальная минута)."""
        if not rows:
            return
        why = abnormal(rows)
        if why or not self.quiet:
            self._write(rows)
        if say or why:
            line = self.monitor.summary_line(rows)
            print(f"{line} — аномальная нагрузка: {why}" if why else line, file=sys.stderr)

    def _write(self, rows) -> None:
        path = self.csv_path()
        if path is None or not rows:
            return
        try:
            new = not path.exists()
            with path.open("a", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh)
                if new:
                    writer.writerow(["time", "phase", "metric", "avg", "max"])
                writer.writerows((stamp, phase, name, f"{avg:.3f}", f"{mx:.3f}")
                                 for stamp, phase, name, avg, mx in rows)
        except OSError:
            pass


def _keep_days() -> int:
    """Срок perf_ДАТА.csv из «Настройки» → «Журналы» (log_retention, 2.1.85); не прочиталось — KEEP_DAYS."""
    try:
        import log_retention
        return log_retention.days("perf", QtCore.QSettings("MyTradingTools", "FxTerminal"))
    except Exception:
        return KEEP_DAYS


def cleanup(folder: Path, keep_days: int = KEEP_DAYS) -> int:
    """Удалить perf_*.csv старше keep_days дней; 0 и меньше — «Не удалять» (2.1.85)."""
    if keep_days <= 0:
        return 0
    removed = 0
    limit = time.time() - keep_days * 86400
    for path in Path(folder).glob(f"{CSV_PREFIX}*.csv"):
        try:
            if path.stat().st_mtime < limit:
                path.unlink()
                removed += 1
        except OSError:
            pass
    return removed


_EVENT_NAMES: dict[int, str] = {}


def _event_name(etype) -> str:
    key = int(getattr(etype, "value", etype))
    name = _EVENT_NAMES.get(key)
    if name is None:
        name = getattr(etype, "name", None) or str(key)
        _EVENT_NAMES[key] = name
    return name


# Получатели с «общим» именем класса: по нему не понять, какое окно тратит время. К ним
# добавляем владельца — заголовок панели (докинг-вкладки) или окна: «GraphicsScene [1: USDRUBF · M5]».
GENERIC_RECEIVERS = {"GraphicsScene", "QGraphicsScene", "QWidget", "CFloatingDockContainer", "GraphicsView",
                     "PlotWidget", "QGraphicsView", "ViewBox", "PlotItem", "QTimer", "QThread",
                     "ScalperLadderWidget"}   # стаканов бывает несколько — какой из них тратит время
OWNER_TTL_SEC = 5.0          # заголовок окна меняется (сменили инструмент) — подпись обновляется


def _owner_title(obj) -> str:
    """Заголовок ближайшей панели (CDockWidget) или окна, в котором живёт obj; "" — не нашли."""
    widget = None
    if isinstance(obj, QtWidgets.QGraphicsScene):
        views = obj.views()
        widget = views[0] if views else None
    elif isinstance(obj, QtWidgets.QWidget):
        widget = obj
    else:                                            # QTimer / QThread: по родителю-виджету
        parent = obj.parent() if hasattr(obj, "parent") else None
        while parent is not None and not isinstance(parent, QtWidgets.QWidget):
            parent = parent.parent()
        widget = parent
    while widget is not None:
        if type(widget).__name__ == "CDockWidget" or widget.isWindow():
            title = widget.windowTitle().strip()
            if title:
                return title[:40]
        widget = widget.parentWidget()
    return ""


class TimingApplication(QtWidgets.QApplication):
    """QApplication с замером каждого события (подробный режим, FX_PERF_DETAIL=1).

    Вложенные события (обработчик внутри обработчика) считаются и у внешнего, и у внутреннего —
    сумма по строкам поэтому может быть больше времени GUI-потока; смотреть надо на самые тяжёлые
    строки, а не на сумму. События дешевле MIN_EVENT_SEC не записываются (их тысячи, а вклад мал).
    У получателей с общим именем класса (GENERIC_RECEIVERS) в имени строки — окно-владелец."""

    MIN_EVENT_SEC = 0.0002

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._owners: dict[int, tuple[float, str]] = {}      # id(получатель) -> (когда узнали, подпись)

    def _owner(self, receiver) -> str:
        key = id(receiver)
        now = time.monotonic()
        cached = self._owners.get(key)
        if cached is not None and now - cached[0] < OWNER_TTL_SEC:
            return cached[1]
        try:
            title = _owner_title(receiver)
        except Exception:
            title = ""
        label = f" [{title}]" if title else ""
        if len(self._owners) > 5000:
            self._owners.clear()
        self._owners[key] = (now, label)
        return label

    def notify(self, receiver, event) -> bool:                     # noqa: N802 (имя Qt)
        # Имя берём ДО обработки: событие удаления (DeferredDelete) уничтожает получателя.
        try:
            etype = event.type()
            cls = type(receiver).__name__
            name = f"Qt {_event_name(etype)} → {cls}"
            generic = cls in GENERIC_RECEIVERS and etype != QtCore.QEvent.Type.DeferredDelete
        except Exception:
            name, generic = "Qt ?", False
        start = time.perf_counter()
        try:
            return super().notify(receiver, event)
        finally:
            spent = time.perf_counter() - start
            if spent >= self.MIN_EVENT_SEC:
                if generic:                       # владельца ищем только у заметных событий — это дорого
                    name += self._owner(receiver)
                PERF.add(name, spent)
