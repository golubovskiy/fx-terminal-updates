# -*- coding: utf-8 -*-
"""Журнал терминала в файл: всё, что пишется в консоль (print, traceback, сообщения Qt),
дублируется в logs/fx_terminal_ГГГГ-ММ-ДД.log с временем у каждой строки.

    from services.log_file import install
    install(app_paths.LOG_DIR)      # в начале main() (папка журналов — app_paths, 2.1.79)

Устроено как «тройник» над sys.stdout / sys.stderr: консоль работает как раньше, а копия
идёт в файл текущего дня. Новый день — новый файл; файлы старше KEEP_DAYS удаляются при
запуске. Ошибка записи в файл никогда не мешает выводу в консоль и работе терминала.

Консоль — через отдельный поток (_ConsoleWriter): запись в консоль Windows может встать надолго (выделение
мышью в окне PowerShell — режим QuickEdit — останавливает вывод, пока выделение не снято), и раньше вместе
с ней вставал любой поток терминала, напечатавший строку, — в том числе интерфейс («Не отвечает», 30.10).
Теперь строка сразу уходит в файл, а в консоль — в очередь; пока консоль стоит, очередь копится до
CONSOLE_QUEUE_MAX строк, лишнее в консоль не выводится (в файле есть всё).

Пометка строки: «!» — ошибка или предупреждение (по содержимому: трейсбек целиком, «ошибка»,
«не удалось», обрыв потока, отказ заявки, аномальная нагрузка…), пробел — обычное сообщение. Из какого потока
пришла строка (stdout / stderr), не важно: терминал пишет в stderr и служебные сообщения.

Тихий режим (2.1.65, обычный запуск; все журналы — services/log_mode.py): в файл идут только строки с
пометкой «!». Обычные строки в файл не пишутся, но последние CONTEXT_LINES держатся в памяти: случилась ошибка —
перед ней дописываются они (со своим временем), чтобы было видно, что ей предшествовало. Первая запись в файл дня
начинается с шапки — первых HEAD_LINES строк запуска (отметка «запуск», версия, режим). Нет ошибок — нет и файла.
Консоль в тихом режиме показывает всё, как раньше.
"""
from __future__ import annotations

import os
import re
import sys
import threading
import time
from collections import deque
from datetime import date, datetime
from pathlib import Path

KEEP_DAYS = 14
CONSOLE_QUEUE_MAX = 5000          # строк в очереди к консоли (консоль стоит — дальше в консоль не пишем)
PREFIX = "fx_terminal_"
CONTEXT_LINES = 12                # тихий режим: столько обычных строк перед ошибкой дописывается в файл
HEAD_LINES = 3                    # тихий режим: первые строки запуска (отметка, версия, режим) — шапка файла

# Признаки ошибки / предупреждения в тексте строки (без учёта регистра).
_PROBLEM_RE = re.compile(
    r"traceback|error|exception|fail|warning|"
    r"ошибк|не удал|не запустил|упал|предупрежд|оборв|прерван|переподключени|нет связи|"
    r"не завершил|не успева|отклонен|отказ|неопределённый результат|недоступ|потер|теря|"
    r"аномальн|зависани",
    re.IGNORECASE)


def is_problem(line: str) -> bool:
    return bool(_PROBLEM_RE.search(line))


class _DailyFile:
    """Общий для stdout и stderr файл текущего дня (смена файла в полночь).

    quiet — тихий режим: в файл идут только строки с пометкой «!» (перед ними — до context обычных строк из
    памяти), файл создаётся при первой такой строке и начинается с шапки запуска (см. описание модуля)."""

    def __init__(self, folder: Path, quiet: bool = False, context: int = CONTEXT_LINES, head: int = HEAD_LINES):
        self.folder = folder
        self.quiet = bool(quiet)
        self._lock = threading.Lock()
        self._day: date | None = None
        self._fh = None
        self._recent: deque = deque(maxlen=max(0, int(context)))    # (время, пометка, строка) — ещё не в файле
        self._head: list[tuple] = []                                # шапка запуска: первые head строк
        self._head_size = max(0, int(head))
        self._skipped = 0                                           # обычных строк не записано с прошлой записи

    def path_for(self, day: date) -> Path:
        return self.folder / f"{PREFIX}{day:%Y-%m-%d}.log"

    @property
    def current_path(self) -> Path:
        return self.path_for(self._day or date.today())

    def write_lines(self, lines: list[str], marks: list[str] | str) -> None:
        """marks — пометка на каждую строку («!» / « ») или одна на все."""
        now = datetime.now()
        stamp = now.strftime("%H:%M:%S.%f")[:-3]
        if isinstance(marks, str):
            marks = [marks] * len(lines)
        with self._lock:
            try:
                if self.quiet:
                    self._write_quiet(now, stamp, lines, marks)
                    return
                if self._day != now.date() or self._fh is None:
                    self._reopen(now.date())
                for line, mark in zip(lines, marks):
                    self._fh.write(f"{stamp} {mark} {line}\n")
                self._fh.flush()
            except Exception:
                pass                                   # журнал — best effort

    def _write_quiet(self, now: datetime, stamp: str, lines: list[str], marks: list[str]) -> None:
        """Тихий режим: «!» — в файл (с шапкой и строками до неё), обычное — в память."""
        wrote = False
        for line, mark in zip(lines, marks):
            if mark != "!":
                if len(self._head) < self._head_size:
                    self._head.append((stamp, mark, line))            # шапка запуска: в файл попадёт при первой записи
                else:
                    if self._recent.maxlen and len(self._recent) == self._recent.maxlen:
                        self._skipped += 1
                    self._recent.append((stamp, mark, line))
                continue
            if self._day != now.date() or self._fh is None:
                self._reopen(now.date())
                for head_stamp, head_mark, head_line in self._head:
                    self._fh.write(f"{head_stamp} {head_mark} {head_line}\n")
            if self._skipped:
                self._fh.write(f"{stamp}   … обычных строк пропущено: {self._skipped} (тихий режим)\n")
                self._skipped = 0
            for old_stamp, old_mark, old_line in self._recent:
                self._fh.write(f"{old_stamp} {old_mark} {old_line}\n")
            self._recent.clear()
            self._fh.write(f"{stamp} {mark} {line}\n")
            wrote = True
        if wrote:
            self._fh.flush()

    def _reopen(self, day: date) -> None:
        if self._fh is not None:
            try:
                self._fh.close()
            except Exception:
                pass
        self.folder.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.path_for(day), "a", encoding="utf-8", errors="replace")
        self._day = day

    def close(self) -> None:
        with self._lock:
            if self._fh is not None:
                try:
                    self._fh.close()
                except Exception:
                    pass
                self._fh = None


class _ConsoleWriter:
    """Вывод в исходный поток (консоль) из своего потока: зависшая консоль не останавливает терминал."""

    def __init__(self, original):
        import queue
        self._original = original
        self._queue: "queue.Queue[str]" = queue.Queue(maxsize=CONSOLE_QUEUE_MAX)
        self.dropped = 0
        self._thread = threading.Thread(target=self._run, name="console-writer", daemon=True)
        self._thread.start()

    def put(self, text: str) -> None:
        try:
            self._queue.put_nowait(text)
        except Exception:                          # консоль давно стоит — в консоль не пишем (в файле всё есть)
            self.dropped += 1

    def _run(self) -> None:
        while True:
            text = self._queue.get()
            try:
                self._original.write(text)
                if self._queue.empty():
                    self._original.flush()
            except Exception:
                pass

    def drain(self, timeout: float = 0.5) -> None:
        """Дописать очередь в консоль (выход из терминала), но не дольше timeout."""
        end = time.monotonic() + timeout
        while not self._queue.empty() and time.monotonic() < end:
            time.sleep(0.01)


class _Tee:
    """Поток вывода: в файл — сразу, построчно с временем и пометкой; в исходный поток (консоль) — через
    _ConsoleWriter, как есть."""

    def __init__(self, original, sink: _DailyFile):
        self._original, self._sink = original, sink
        self._console = _ConsoleWriter(original) if original is not None else None
        self._buffer = ""
        self._lock = threading.Lock()
        self._in_traceback = False         # строки трейсбека помечаются все, до строки исключения

    def write(self, text) -> int:
        if not isinstance(text, str):
            text = str(text)
        if self._console is not None:
            self._console.put(text)
        with self._lock:
            self._buffer += text
            if "\n" not in self._buffer:
                return len(text)
            *lines, self._buffer = self._buffer.split("\n")
            marks = [self._mark_for(line) for line in lines]
        if lines:
            self._sink.write_lines(lines, marks)
        return len(text)

    def _mark_for(self, line: str) -> str:
        if line.startswith("Traceback (most recent call last)"):
            self._in_traceback = True
            return "!"
        if self._in_traceback:
            # Строки стека — с отступом; первая строка без отступа — само исключение (конец блока).
            if not line[:1].isspace() and line.strip() and not line.startswith("During handling") \
                    and not line.startswith("The above exception"):
                self._in_traceback = False
            return "!"
        return "!" if is_problem(line) else " "

    def flush(self) -> None:
        """Ничего не ждёт: консоль пишет свой поток (вывод при выходе дописывает drain_console)."""
        return None

    def isatty(self) -> bool:
        return bool(self._original is not None and getattr(self._original, "isatty", lambda: False)())

    def fileno(self):
        if self._original is None:
            raise OSError("нет исходного потока")
        return self._original.fileno()

    def __getattr__(self, name):                    # encoding, errors, … — как у исходного
        return getattr(self._original, name)


_installed: _DailyFile | None = None


def drain_console(timeout: float = 0.5) -> None:
    """Перед выходом из процесса: дописать в консоль то, что ещё в очереди (не дольше timeout)."""
    for stream in (sys.stdout, sys.stderr):
        console = getattr(stream, "_console", None)
        if console is not None:
            console.drain(timeout)


def install(folder: Path, keep_days: int = KEEP_DAYS, quiet: bool = False) -> Path | None:
    """Подключить журнал. quiet — тихий режим (в файл только ошибки и аномальная нагрузка, см. описание модуля).
    Возвращает путь к файлу сегодняшнего дня (в тихом режиме его может ещё не быть) или None, если не вышло."""
    global _installed
    if _installed is not None:
        return _installed.current_path
    try:
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        cleanup(folder, keep_days)
        sink = _DailyFile(folder, quiet=quiet)
        sys.stdout = _Tee(sys.stdout, sink)
        sys.stderr = _Tee(sys.stderr, sink)
        _installed = sink
        sink.write_lines([f"===== запуск FX Terminal, pid {os.getpid()} ====="], " ")
        return sink.current_path
    except Exception:
        return None


def current_log_path() -> Path | None:
    return _installed.current_path if _installed is not None else None


def cleanup(folder: Path, keep_days: int = KEEP_DAYS) -> int:
    """Удалить журналы старше keep_days дней (0 и меньше — «Не удалять», 2.1.85). Возвращает число удалённых."""
    if keep_days <= 0:
        return 0
    removed = 0
    limit = time.time() - keep_days * 86400
    for path in Path(folder).glob(f"{PREFIX}*.log"):
        try:
            if path.stat().st_mtime < limit:
                path.unlink()
                removed += 1
        except OSError:
            pass
    return removed
