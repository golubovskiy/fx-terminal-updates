# -*- coding: utf-8 -*-
"""«Настройки» → «Журналы» (2.1.85): сколько хранить каждый журнал и кнопка «Удалить» — сразу.

Строка на группу журналов (log_retention.GROUPS): название, сколько файлов и места, срок хранения
(«Авто (N дн.)» — срок по умолчанию, 7…365 дней, «Не удалять») и «Удалить» — все файлы группы, кроме
сегодняшнего (в него пишут прямо сейчас; с подтверждением, удалённое не вернуть). Сроки сохраняются по «OK»
(save), после чего терминал сразу чистит журналы по новым срокам (SettingsDialog.accept → cleanup_all).
"""
from __future__ import annotations

from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets

import app_paths
import log_retention as lr


class LogsPage(QtWidgets.QWidget):
    def __init__(self, settings: QtCore.QSettings, dim: str, folder: Path | None = None, parent=None,
                 confirm=None):
        """folder — папка журналов (по умолчанию app_paths.LOG_DIR); confirm(text) -> bool — вопрос перед
        удалением (по умолчанию окно «Да / Нет»; проверки подставляют свой)."""
        super().__init__(parent)
        self.settings = settings
        self.folder = Path(folder) if folder is not None else app_paths.LOG_DIR
        self._confirm = confirm or self._ask
        self.combos: dict[str, QtWidgets.QComboBox] = {}
        self.usage_labels: dict[str, QtWidgets.QLabel] = {}
        self.delete_buttons: dict[str, QtWidgets.QPushButton] = {}

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        box = QtWidgets.QGroupBox("Сколько хранить журналы")
        grid = QtWidgets.QGridLayout(box)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(6)
        for col, head in enumerate(("Журнал", "Сейчас", "Хранить", "")):
            label = QtWidgets.QLabel(head)
            label.setStyleSheet(f"color: {dim};")
            grid.addWidget(label, 0, col)
        for row, group in enumerate(lr.GROUPS, start=1):
            name = QtWidgets.QLabel(group.title)
            name.setToolTip(group.hint)
            grid.addWidget(name, row, 0)
            used = QtWidgets.QLabel("")
            used.setStyleSheet(f"color: {dim};")
            grid.addWidget(used, row, 1)
            combo = QtWidgets.QComboBox()
            combo.addItem(f"Авто ({group.default_days} дн.)", lr.AUTO)
            for n in lr.CHOICES:
                combo.addItem(f"{n} дн.", n)
            combo.addItem("Не удалять", lr.NEVER)
            current = lr.setting(group.key, settings)
            index = combo.findData(current)
            if index < 0:                                   # свой срок, которого нет в списке (из файла настроек)
                combo.addItem(f"{current} дн.", current)
                index = combo.count() - 1
            combo.setCurrentIndex(index)
            combo.setToolTip(group.hint)
            grid.addWidget(combo, row, 2)
            button = QtWidgets.QPushButton("Удалить")
            button.setAutoDefault(False)
            button.setToolTip("Удалить сейчас все файлы этого журнала, кроме сегодняшнего")
            if group.records:
                button.setToolTip("Историю держит открытый терминал — очищается в настройках айсбергов "
                                  "(«Очистить историю»); старое уходит само по сроку")
            button.clicked.connect(lambda _c=False, k=group.key: self.delete_now(k))
            grid.addWidget(button, row, 3)
            self.combos[group.key] = combo
            self.usage_labels[group.key] = used
            self.delete_buttons[group.key] = button
        grid.setColumnStretch(0, 1)
        lay.addWidget(box)

        bottom = QtWidgets.QHBoxLayout()
        self.total_label = QtWidgets.QLabel("")
        self.total_label.setStyleSheet(f"color: {dim};")
        bottom.addWidget(self.total_label, 1)
        open_btn = QtWidgets.QPushButton("Открыть папку")
        open_btn.setAutoDefault(False)
        open_btn.setToolTip(str(self.folder))
        open_btn.clicked.connect(self._open_folder)
        bottom.addWidget(open_btn)
        lay.addLayout(bottom)
        hint = QtWidgets.QLabel(
            "«Авто» — срок по умолчанию для этого журнала. Старые файлы удаляются при запуске терминала, "
            "раз в 6 часов и сразу после «OK». Сегодняшний файл не удаляется никогда — в него пишут сейчас. "
            "У истории айсбергов старые записи убирает сам терминал (файл один). Лента «Уведомлений» хранит "
            "2 дня — это данные окна, у неё свой срок.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {dim}; font-size: 11px;")
        lay.addWidget(hint)
        lay.addStretch(1)
        self.refresh()

    # ---- данные ------------------------------------------------------------------
    def values(self) -> dict[str, int]:
        return {key: int(combo.currentData()) for key, combo in self.combos.items()}

    def save(self) -> None:
        for key, value in self.values().items():
            self.settings.setValue(lr.KEY + key, value)

    def refresh(self) -> None:
        total = 0
        for group in lr.GROUPS:
            count, size = lr.usage(self.folder, group.key)
            total += size
            self.usage_labels[group.key].setText(f"{count} файл., {lr.human_size(size)}" if count else "нет файлов")
            self.delete_buttons[group.key].setEnabled(count > 0 and not group.records)
        self.total_label.setText(f"Всего: {lr.human_size(total)} · {self.folder}")

    def delete_now(self, key: str) -> int:
        group = lr.BY_KEY[key]
        count, size = lr.usage(self.folder, key)
        if not count or not self._confirm(f"Удалить журнал «{group.title}»: {count} файл., {lr.human_size(size)}?\n"
                                          "Сегодняшний файл останется. Удалённое не вернуть."):
            return 0
        removed = lr.delete_group(self.folder, key)
        self.refresh()
        return removed

    # ---- окно ----------------------------------------------------------------------
    def _ask(self, text: str) -> bool:
        answer = QtWidgets.QMessageBox.question(self, "Удалить журнал", text,
                                                QtWidgets.QMessageBox.StandardButton.Yes
                                                | QtWidgets.QMessageBox.StandardButton.No,
                                                QtWidgets.QMessageBox.StandardButton.No)
        return answer == QtWidgets.QMessageBox.StandardButton.Yes

    def _open_folder(self) -> None:
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(self.folder)))
