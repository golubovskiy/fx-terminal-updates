# -*- coding: utf-8 -*-
"""Уведомления окон стакана — строками в «Уведомлениях» (2.1.84). До 2.1.84 «Сигнальный уровень», «Крупный
объём», «Крупная сделка» и своя сделка из настроек стакана были только звуком и 6 секундами текста в нижней строке
стакана: звук есть, а в окне «Уведомления» и на значке ничего. Теперь каждое прозвучавшее — строка типа «Стакан»
(звук не повторяется, значок считает непрочитанные), повторы на той же цене за 5 минут — одна строка.
Без сети и без настоящих окон стакана.  Запуск:  python tests/test_dom_notices.py"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace as NS

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import notify_merge  # noqa: E402
import quotes_tab as qt  # noqa: E402


def _tab():
    """QuotesTab без Qt-виджета: ленте уведомлений нужны только эти методы и поля (как в test_notifications)."""
    class _Tab:
        pass
    for name in ("_notify", "add_dom_notice", "_live_notifications", "_update_unread", "_now_utc"):
        setattr(_Tab, name, qt.QuotesTab.__dict__[name])
    tab = _Tab()
    tab.host = None
    tab.events, tab._events_unsaved, tab._recent_events = [], [], {}
    tab.unread, tab.unread_level = 0, 0
    tab._notifications_dialog = None
    tab._save_events = lambda: None
    tab.emitted = []
    tab.event_added = NS(emit=lambda event: tab.emitted.append(event))
    return tab


def test_merge_rules():
    ev = {"type": notify_merge.DOM_TYPE, "symbol": "SiZ6@RTSX", "title": "Стакан: сигнальный уровень", "price": 83520.0}
    assert notify_merge.group_key(ev) == ("dom", "SiZ6@RTSX", "Стакан: сигнальный уровень", 83520.0)
    assert notify_merge.group_key(dict(ev, price=None)) is None          # своя сделка, лимит — отдельными строками
    assert notify_merge.merge_window(("dom",)) == notify_merge.DOM_MERGE_SEC
    old = dict(ev, details="Сигнальный уровень 83 520")
    notify_merge.start_dom(old)
    notify_merge.merge_dom(old, {"details": "Сигнальный уровень 83 520", "sound": "alert"})
    notify_merge.merge_dom(old, {"details": "Сигнальный уровень 83 520", "sound": "alert"})
    assert old["merge"]["count"] == 3 and old["details"].endswith("сработало раз: 3")


def test_dom_notice_becomes_row_without_second_sound():
    tab = _tab()
    tab.add_dom_notice("SiZ6@RTSX", "сигнальный уровень", "Сигнальный уровень 83 520", "alert", 83520.0)
    assert len(tab.events) == 1, tab.events
    ev = tab.events[0]
    assert ev["type"] == notify_merge.DOM_TYPE and ev["title"] == "Стакан: сигнальный уровень"
    assert ev["sound"] == "alert" and ev["price"] == 83520.0
    assert tab.unread == 1 and tab.unread_level == 3                      # значок: есть новое, важность «алерт»
    assert tab.emitted == []                                              # звук уже был в окне стакана
    # та же цена снова (другой текст — не отброшен как дубль) — та же строка, число срабатываний
    tab.add_dom_notice("SiZ6@RTSX", "сигнальный уровень", "Сигнальный уровень 83 520 ", "alert", 83520.0)
    assert len(tab.events) == 1 and "сработало раз: 2" in tab.events[0]["details"]
    assert tab.unread == 1 and tab.emitted == []
    # другая цена и своя сделка без цены — свои строки
    tab.add_dom_notice("SiZ6@RTSX", "сигнальный уровень", "Сигнальный уровень 83 600", "alert", 83600.0)
    tab.add_dom_notice("SiZ6@RTSX", "своя сделка", "Сделка: позиция +2", "pulse", None)
    tab.add_dom_notice("SiZ6@RTSX", "своя сделка", "Сделка: позиция +3", "pulse", None)
    assert len(tab.events) == 4 and tab.unread == 4 and tab.emitted == []
    # обычное уведомление «Алгоритмов» по-прежнему звучит через event_added
    tab._notify("SiZ6@RTSX", "Цена", "резкое движение", title="Цена: рост")
    assert len(tab.emitted) == 1 and tab.emitted[0]["sound"] == "alert"


def test_live_panel_shows_dom_row_and_filter_has_type():
    tab = _tab()
    panel = qt.QuotesNotificationsPanel(tab.events, None, "Europe/Moscow", robots_source=lambda: [], tab=tab)
    try:
        panel.resize(900, 400)
        panel.show()
        APP.processEvents()
        tab._notifications_dialog = panel
        assert panel.kind_combo.findData(notify_merge.DOM_TYPE) >= 0           # фильтр «Тип»: «📋 Стакан»
        tab.add_dom_notice("CRZ6@RTSX", "крупный объём", "Крупный объём 1,2 млн @ 12.53", "signal", 12.53)
        assert panel.table.rowCount() >= 1 and "крупный объём" in panel.table.item(0, 3).text()
        assert tab.unread == 0                                                # окно на экране — прочитано сразу
    finally:
        panel.close()
        panel.deleteLater()


def test_scalper_notify_reports_each_sounded_notice():
    import scalper_widget as sw
    got = []

    class _W:
        symbol = "SiZ6@RTSX"
        IMPORTANT_HOLD_SEC = sw.ScalperWindow.IMPORTANT_HOLD_SEC
        notify = sw.ScalperWindow.__dict__["notify"]
        _notice_event = sw.ScalperWindow.__dict__["_notice_event"]

    w = _W()
    w._last_notify, w._flash_hold_until = 0.0, 0.0
    sounds = []
    w._notice_sound = lambda kind: sounds.append(kind)
    w.flash = lambda text: None
    sw.set_notice_event(lambda *args: got.append(args))
    try:
        w.notify("Сигнальный уровень 83 520", "alert", title="сигнальный уровень", price=83520.0)
        w.notify("Сигнальный уровень 83 530", "alert", title="сигнальный уровень", price=83530.0)  # < 0,5 с — молча
        assert sounds == ["alert"] and got == [("SiZ6@RTSX", "сигнальный уровень", "Сигнальный уровень 83 520",
                                                "alert", 83520.0)]
        w.notify("Сделка: позиция +1", important=True, title="своя сделка")        # своя сделка — всегда
        assert len(got) == 2 and got[-1][1] == "своя сделка" and sounds[-1] == "pulse"
        sw.set_notice_event(None)                                                 # окно стакана без терминала
        w._last_notify = 0.0
        w._flash_hold_until = 0.0
        w.notify("Крупная сделка 50 @ 83 500", "signal", title="крупная сделка", price=83500.0)
        assert len(got) == 2 and sounds[-1] == "signal"
    finally:
        sw.set_notice_event(None)


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
