# -*- coding: utf-8 -*-
"""
Скальпер-стакан для Finam Trade API (gRPC) — окна «Стакан» FX Terminal.

    from scalper_widget import ScalperManager     (меню «Окна → Стакан»)

Данные — из MarketDataHub терминала (HubStreamEngine), заявки LIVE — через общее соединение
шлюза Finam (SharedTradingSession -> brokers/finam/live.py). Отдельного запуска нет.

Состав: модели стакана и кластеров, торговый слой (PAPER / LIVE), стакан в стиле скальперских терминалов,
диалог настроек, окно ScalperWindow; его версия для терминала TerminalScalperWindow
(выбор инструмента + «Каталог…» + переключатель PAPER / LIVE) и менеджер окон ScalperManager
(несколько окон, шаг цены инструмента берётся у брокера и кэшируется в конфиге, ключ "ticks";
лимиты LIVE — ключ "live_limits" (позиция, лот, дневной лимит убытка на весь терминал —
services/live_guard.py; один инструмент — одно LIVE-окно); связь окон по цветным группам — через window_links.LinkHub). Новые окна всегда открываются в PAPER; LIVE включается вручную
бейджем режима в шапке окна после подтверждения. Исключение — запуск терминала при открытой позиции: окно
стакана из сохранённой раскладки, которое было в LIVE при закрытии терминала и по инструменту которого у брокера
ещё есть позиция, открывается сразу в LIVE с сохранёнными лимитами (ScalperManager.materialize_placeholders,
_pick_auto_live; список LIVE-окон — ключ "live_windows" конфига).
"""
from __future__ import annotations

import copy
import json
import math
import os
import sys
import re
import threading
import time
import traceback
from bisect import bisect_left, bisect_right
from collections import deque
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from itertools import accumulate
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, QRect, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (
    QAction, QActionGroup, QColor, QFont, QFontMetrics, QGuiApplication, QIntValidator, QPainter, QPen, QPixmap,
    QStaticText, QTransform,
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QCompleter, QDialog, QDoubleSpinBox, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox, QPushButton,
    QScrollArea, QSizePolicy, QSpinBox, QSplitter, QStackedWidget, QToolButton, QToolTip, QVBoxLayout, QWidget,
)

from finam_trade_api.assets import GetAssetRequest

DEFAULT_SYMBOL = "USDRUBF@RTSX"
DEFAULT_TICK = 0.01


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def first(d, *keys, default=None):
    if not isinstance(d, dict):
        return default
    for key in keys:
        if key in d and d[key] is not None:
            return d[key]
    return default


def unwrap_value(v):
    if isinstance(v, dict):
        if "value" in v:
            return v["value"]
        for key in ("number", "amount", "size", "price"):
            if key in v and not isinstance(v[key], (dict, list)):
                return v[key]
    return v


def as_float(v, default=None):
    v = unwrap_value(v)
    try:
        return float(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


def as_int(v, default=0):
    v = unwrap_value(v)
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def side_label(side):
    side = str(side or "").upper()
    if "BUY" in side or side in ("1", "B"):
        return "BUY"
    if "SELL" in side or side in ("2", "S"):
        return "SELL"
    return side[:6] or "—"


def parse_ts(value):
    """ISO-время из API -> локальное naive datetime. Если не разобралось — now()."""
    s = str(value or "").strip()
    if not s:
        return datetime.now()
    try:
        s = s.replace("Z", "+00:00")
        s = re.sub(r"(\.\d{6})\d+", r"\1", s)
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is not None:
            dt = dt.astimezone().replace(tzinfo=None)
        return dt
    except ValueError:
        return datetime.now()


def time_text(value):
    return parse_ts(value).strftime("%H:%M:%S")


def fmt_vol(v):
    return f"{int(v):,}".replace(",", " ")


def tick_decimals(tick):
    s = f"{tick:.10f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0


def fmt_price(price, decimals):
    return f"{price:.{decimals}f}".replace(".", ",")


def dom_price_text(price, decimals, mode: str = "sep") -> str:
    """Цена в колонке стакана («Настройки» → «Шрифты» → «Цена в стакане», appearance.PRICE_FORMATS):
    sep — 82 323 / 3 938,2 / 12,2190; plain — 82323;
    lastN — только N последних цифр (как Price Digits в ATAS): 82323 → «323», 12,2190 → «190», 3938,2 → «38,2»;
    при last4 у пятизначной цены — с разделителем: «2 323»."""
    text = fmt_price(price, decimals)
    sign = "-" if text.startswith("-") else ""
    text = text.lstrip("-")
    whole, _, frac = text.partition(",")
    if mode != "plain" and len(whole) > 3:
        groups = []
        while len(whole) > 3:
            groups.insert(0, whole[-3:])
            whole = whole[:-3]
        whole = " ".join([whole] + groups)
    full = whole + ("," + frac if frac else "")
    if mode.startswith("last"):
        try:
            n = int(mode[4:])
        except ValueError:
            n = 3
        out, digits = [], 0
        for ch in reversed(full):
            if ch.isdigit():
                if digits == n:
                    break
                digits += 1
            out.append(ch)
        return "".join(reversed(out)).lstrip(" ,")
    return sign + full


def split_price_tail(text: str, digits: int) -> tuple[str, str]:
    """(начало, последние digits цифр) — для «Последние цифры цены жирным»: «82 323», 2 → («82 3», «23»)."""
    if digits <= 0:
        return text, ""
    count = 0
    for i in range(len(text) - 1, -1, -1):
        if text[i].isdigit():
            count += 1
            if count == digits:
                return text[:i], text[i:]
    return "", text


# -----------------------------------------------------------------------------
# Settings (Торговля / Стакан / Тики / Кластеры / Общие)
# -----------------------------------------------------------------------------

RULER_UNITS = ("Проценты", "Шаги цены", "Цена", "Деньги")
RULER_CHOICES = ("Нет",) + RULER_UNITS
# Линейка под курсором (2.1.67): расстояние в процентах и шагах цены и объём, который стоит в стакане от спреда до
# курсора на той стороне, через которую пойдёт цена («сколько надо съесть, чтобы цена дошла сюда») — как режимы
# «Percent + Volume» в MetaScalp и «Ликвидность» в Vataga. Только для линейки под курсором (у линеек заявок и
# ручной линейки этого режима нет).
RULER_FULL = "Проценты + шаги + объём"
RULER_HOVER_CHOICES = RULER_CHOICES + (RULER_FULL,)
RULER_REV = 2            # Settings.ruler_rev: с 2 линейка под курсором по умолчанию — RULER_FULL (см. from_dict)
CLUSTER_TEXTS = ("Сумма покупок и продаж", "Дельта", "Продажи x покупки")
CLUSTER_COLORS = ("Объем", "Дельта", "Дельта объем")
# значения из прежних версий -> текущие (в образце три формата текста и три цвета)
_MIGRATE = {
    "cluster_text": {"Покупки и продажи": "Продажи x покупки", "Покупки": "Сумма покупок и продаж",
                     "Продажи": "Сумма покупок и продаж"},
    "cluster_color": {"Без цвета": "Дельта"},
}
_ALLOWED = {"cluster_text": CLUSTER_TEXTS, "cluster_color": CLUSTER_COLORS}
CLUSTER_TFS = {"1m": 1, "5m": 5, "10m": 10, "15m": 15, "30m": 30, "60m": 60, "1d": 1440}
CLUSTER_TF_TITLES = {"60m": "1h"}       # подписи в меню ПКМ по кластерам; ключ в настройках — прежний
CONFIG_PATH = Path(os.getenv("SCALPER_CONFIG") or (Path.home() / ".scalper_widget.json"))


ACCOUNT_OPTS = {"D": "D — по версии сервера", "F": "F — от первой сделки (FIFO)",
                "L": "L — от последней сделки (LIFO)"}
_MIGRATE["pos_account"] = {"D (по версии сервера)": ACCOUNT_OPTS["D"], "F (FIFO)": ACCOUNT_OPTS["F"],
                           "L (LIFO)": ACCOUNT_OPTS["L"]}
_MIGRATE["sltp_place"] = {"На бирже": "На сервере"}
_MIGRATE["stop_trigger"] = {"По лучшей цене": "По лучшим ценам"}
_MIGRATE["profit_mode"] = {"Шаги цены": "Пункты", "Деньги": "Валюта"}
_ALLOWED["pos_account"] = tuple(ACCOUNT_OPTS.values())
_ALLOWED["sltp_place"] = ("В приложении", "На сервере")
_ALLOWED["stop_trigger"] = ("По сделкам", "По лучшим ценам")
_ALLOWED["profit_mode"] = ("Цена", "Пункты", "Проценты", "Валюта")

@dataclass
class Settings:
    # ---- Торговля
    work_lots: list = field(default_factory=lambda: [1, 2, 3, 4, 5])
    market_for_actions: bool = True      # закрытие/реверс/покупка-продажа/SL-TP в приложении — рынком
    market_for_stops: bool = True        # стоп-заявки — рынком
    limit_reach: int = 100               # дальность заброса лимитных заявок, шагов
    stop_reach: int = 0                  # дальность заброса от стоп-заявок, шагов
    stop_loss: float = 0
    stop_trailing: float = 0
    take_profit: float = 0
    sltp_unit: str = "В шагах цены"      # | В процентах
    sltp_place: str = "В приложении"     # | На сервере (TP лимиткой)
    stop_trigger: str = "По сделкам"     # | По лучшим ценам
    pos_price_mode: str = "От первой сделки"  # | Средняя цена
    pos_line: bool = True                # линия позиции: зелёная — прибыль, красная — убыток
    pos_account: str = "D — по версии сервера"  # | F — от первой сделки (FIFO) | L — от последней (LIFO)
    profit_mode: str = "Цена"            # | Пункты | Проценты | Валюта
    pos_volume_unit: str = "Лоты"        # | Деньги
    work_volume_unit: str = "Лоты"
    volume_unit: str = "Лоты"
    notify_trade: bool = False
    # ---- Стакан
    center_mode: str = "По лучшим ценам"  # | По последней сделке
    fast_scroll: int = 100
    row_fill_lots: int = 1000
    big_volume: int = 999_999
    big_volume2: int = 999_999
    notify_big: bool = False
    notify_big2: bool = False
    ruler: str = RULER_FULL              # линейка под курсором (RULER_HOVER_CHOICES); до 2.1.67 — «Проценты»
    ruler_rev: int = RULER_REV           # сохранённые настройки без него — до 2.1.67 (разовое переключение, from_dict)
    manual_ruler: str = "Сумма объемов"
    ruler_in_pos: str = "Проценты"
    ruler_out_pos: str = "Проценты"
    mid_levels_mult: int = 10
    main_levels_mult: int = 50
    notify_signal_level: bool = True
    # Айсберги стакан сам не ищет (с 2.1.31): показывает найденные детектором «Алгоритмов» (mm_marks). Прежние
    # пороги iceberg_visible / iceberg_mult из сохранённых настроек просто не читаются.
    detect_iceberg: bool = False      # показывать айсберги из «Алгоритмов» голубой полосой
    algo_icons: bool = True           # значки «Алгоритмов» (роботы, айсберги, «М», «↗») под кнопкой настроек
    # Уведомления об айсберге у стакана нет (с 2.1.34): оно дублировало уведомление «Алгоритмов» и срабатывало
    # и на мелкие айсберги, которые там отсеяны порогом. Сохранённый notify_iceberg просто не читается.
    autoscroll: bool = True
    dom_vol_w: int = 0                   # ширина колонки объёма, px (0 — обычная); тянется за левый край стакана
    # ---- Тики
    tick_min_lots: int = 0
    tick_hide_filtered: bool = False
    tick_combine_ms: int = 0
    tick_big: int = 999_999
    notify_tick_big: bool = False
    tick_style: str = "Точки и линии"    # | Точки | Линии
    tick_line_width: int = 1
    # ---- Кластеры
    cluster_fill_lots: int = 1
    cluster_panel: bool = True
    cluster_candle: bool = True
    cluster_block: bool = True
    cluster_tf: str = "5m"
    cluster_col_w: int = 50              # ширина колонки кластера, px (колёсико над панелью кластеров); 50 — «11 233» целиком
    cluster_panel_w: int = 0             # ширина панели кластеров, px (0 — авто); тянется за границу мышью
    cluster_text: str = "Сумма покупок и продаж"   # | Дельта | Продажи x покупки
    cluster_color: str = "Дельта"        # | Объем | Дельта объем
    # ---- Общие
    step_mult: int = 5                   # группировка шага цены — не реализована
    max_decimals: int = 4
    short_thousands: bool = False        # объёмы целиком («11 233»), а не «11,2K»
    short_work_thousands: bool = True
    split_digits: bool = True            # «Разделять разряды объемов в стакане»: 100 000 вместо 100000
    cluster_analysis_line: bool = True
    step_factor: int = 1                 # текущее сжатие стакана (xN), хранится между запусками
    lot_value: float = 1.0               # (доп.) деньги за 1,0 цены на 1 лот — для режимов «Деньги»

    def copy(self):
        return copy.deepcopy(self)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        s = cls()
        for f in fields(cls):
            if f.name not in d:
                continue
            default = getattr(s, f.name)
            raw = d[f.name]
            try:
                if isinstance(default, bool):
                    value = bool(raw)
                elif isinstance(default, int):
                    value = int(raw)
                elif isinstance(default, float):
                    value = float(raw)
                elif isinstance(default, str):
                    value = str(raw)
                elif isinstance(default, list):
                    value = [max(1, int(x)) for x in raw][:len(default)]
                    value += default[len(value):]
                else:
                    continue
            except (TypeError, ValueError):
                continue
            value = _MIGRATE.get(f.name, {}).get(value, value) if isinstance(value, str) else value
            if f.name in _ALLOWED and value not in _ALLOWED[f.name]:
                value = default
            setattr(s, f.name, value)
        # Разово (2.1.67): в настройках до 2.1.67 (без ruler_rev) линейка под курсором «Проценты» — прежнее умолчание —
        # становится новым умолчанием RULER_FULL. Выбранную позже «Проценты» уже не трогаем: ruler_rev сохранён.
        if "ruler_rev" not in d:
            if s.ruler == "Проценты":
                s.ruler = RULER_FULL
            s.ruler_rev = RULER_REV
        if s.ruler not in RULER_HOVER_CHOICES:
            s.ruler = RULER_FULL
        return s

    @property
    def cluster_minutes(self):
        return CLUSTER_TFS.get(self.cluster_tf, 5)


def load_config():
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def ruler_volume(view, tick, group: int = 1) -> float:
    """Объём для линейки под курсором (RULER_FULL): сколько лотов стоит в стакане от спреда до строки курсора
    включительно на той стороне, через которую пойдёт цена. Курсор выше середины спреда — продажи (ask) от лучшей
    цены продажи до строки; ниже — покупки (bid) от строки до лучшей цены покупки. Строка внутри спреда — 0.
    view — BookView кадра (bid_t / ask_t и префиксные суммы, тики), group — сжатие стакана (строка — group тиков)."""
    if view is None:
        return 0.0
    g = max(1, int(group or 1))
    lo = (int(tick) // g) * g                 # строка стакана — тики lo … lo + g − 1
    hi = lo + g - 1
    bid_t, ask_t = view.bid_t, view.ask_t
    if ask_t is not None and (bid_t is None or tick >= (bid_t + ask_t) / 2):
        return float(view.cum_ask_upto(hi)) if hi >= ask_t else 0.0
    if bid_t is not None:
        return float(view.cum_bid_from(lo)) if lo <= bid_t else 0.0
    return 0.0


def fmt_amount(v, short=False, max_dec=4, split=True):
    """Объём/сумма: «1 022», «1,0K», дробные — до max_dec знаков. split=False — без пробелов между
    разрядами («1022»; настройка стакана «Разделять разряды объемов в стакане»)."""
    sign = "-" if v < 0 else ""
    a = abs(v)
    if short and a >= 1000:
        txt = f"{a / 1_000_000:.1f}M" if a >= 1_000_000 else f"{a / 1000:.1f}K"
        return sign + txt.replace(".", ",")
    group = " " if split else ""
    if abs(a - round(a)) < 1e-9:
        return sign + f"{int(round(a)):,}".replace(",", group)
    txt = f"{a:,.{max_dec}f}".rstrip("0").rstrip(".")
    return sign + txt.replace(",", group).replace(".", ",")



# -----------------------------------------------------------------------------
# Models
# -----------------------------------------------------------------------------

@dataclass
class BookLevel:
    bid: int = 0
    ask: int = 0


class BookModel:
    """Стакан. Цены хранятся как целые тики: price == tick_index * tick."""

    def __init__(self, tick=DEFAULT_TICK):
        self.tick = tick
        self.levels: dict[int, BookLevel] = {}
        self.last: float | None = None

    def key(self, price):
        return int(round(price / self.tick))

    def price(self, key):
        return key * self.tick

    def apply(self, rows):
        for price, bid, ask in rows:
            k = self.key(price)
            if bid == 0 and ask == 0:
                self.levels.pop(k, None)
            else:
                self.levels[k] = BookLevel(bid, ask)

    def best(self):
        bid = max((k for k, lv in self.levels.items() if lv.bid > 0), default=None)
        ask = min((k for k, lv in self.levels.items() if lv.ask > 0), default=None)
        return bid, ask

    def mid(self, bid=None, ask=None):
        if bid is None and ask is None:
            bid, ask = self.best()
        if bid is not None and ask is not None:
            return (bid + ask) / 2
        if bid is not None:
            return float(bid)
        if ask is not None:
            return float(ask)
        if self.last is not None:
            return float(self.key(self.last))
        return None

    def side_volume(self, key, bid_t, ask_t):
        lv = self.levels.get(key)
        if lv is None:
            return 0, None
        if ask_t is not None and key >= ask_t and lv.ask > 0:
            return lv.ask, "ask"
        if bid_t is not None and key <= bid_t and lv.bid > 0:
            return lv.bid, "bid"
        return 0, None


class ClusterModel:
    """Объём сделок по цене в временных корзинах (колонки слева от стакана) + OHLC свечи."""

    def __init__(self, interval_min=5, keep=12):
        self.interval_min = interval_min
        self.keep = keep
        self.raw = deque(maxlen=200000)
        self.buckets: dict[datetime, dict[int, list[int]]] = {}
        self.totals: dict[datetime, int] = {}
        self.ohlc: dict[datetime, list[int]] = {}      # start -> [open, high, low, close] в тиках
        # Версия колонки: меняется с каждой сделкой в ней. По ней стакан перерисовывает только изменившиеся
        # колонки кластеров (остальные берёт из кэша картинок — ScalperLadderWidget._paint_clusters).
        self._ver: dict[datetime, int] = {}
        self._epoch = 0

    def version(self, start) -> tuple[int, int]:
        return self._epoch, self._ver.get(start, 0)

    def bucket_start(self, dt):
        minutes = dt.hour * 60 + dt.minute
        minutes -= minutes % self.interval_min
        return dt.replace(hour=minutes // 60, minute=minutes % 60, second=0, microsecond=0)

    def _put(self, tick, side, size, dt):
        start = self.bucket_start(dt)
        cell = self.buckets.setdefault(start, {}).setdefault(tick, [0, 0])
        cell[0 if side == "BUY" else 1] += size
        self._ver[start] = self._ver.get(start, 0) + 1
        self.totals[start] = self.totals.get(start, 0) + size
        o = self.ohlc.get(start)
        if o is None:
            self.ohlc[start] = [tick, tick, tick, tick]
        else:
            o[1] = max(o[1], tick)
            o[2] = min(o[2], tick)
            o[3] = tick

    def add(self, tick, side, size, dt):
        if side not in ("BUY", "SELL") or size <= 0:
            return
        self.raw.append((tick, side, size, dt))
        self._put(tick, side, size, dt)
        if len(self.buckets) > self.keep:
            for old in sorted(self.buckets)[:-self.keep]:
                self.buckets.pop(old, None)
                self.totals.pop(old, None)
                self.ohlc.pop(old, None)
                self._ver.pop(old, None)

    def _reset_buckets(self):
        self.buckets.clear()
        self.totals.clear()
        self.ohlc.clear()
        self._ver.clear()
        self._epoch += 1

    def set_interval(self, minutes):
        if minutes == self.interval_min:
            return
        self.interval_min = minutes
        self._reset_buckets()
        for tick, side, size, dt in self.raw:
            self._put(tick, side, size, dt)

    def clear(self):
        self.raw.clear()
        self._reset_buckets()

    def columns(self, count, now=None):
        cur = self.bucket_start(now or datetime.now())
        step = timedelta(minutes=self.interval_min)
        return [cur - step * (count - 1 - i) for i in range(count)]

    def cell(self, start, tick):
        return self.buckets.get(start, {}).get(tick)

    def total(self, start):
        return self.totals.get(start, 0)

    def poc(self, start):
        """Цена с максимальным объёмом в корзине."""
        b = self.buckets.get(start)
        if not b:
            return None
        return max(b, key=lambda t: b[t][0] + b[t][1])


class TickStore:
    """Лента сделок («тики») с опциональным склеиванием за период, мс."""

    def __init__(self):
        self.items = deque(maxlen=3000)
        self.combine_ms = 0

    def add(self, tick, price, side, size, ts_text):
        now = time.monotonic()
        if self.combine_ms > 0 and self.items:
            last = self.items[-1]
            if (last["tick"] == tick and last["side"] == side
                    and (now - last["t0"]) * 1000.0 <= self.combine_ms):
                last["size"] += size
                last["t"] = now
                return last
        item = dict(tick=tick, price=price, side=side, size=size, t=now, t0=now, ts=ts_text)
        self.items.append(item)
        return item


# -----------------------------------------------------------------------------
# Trading layer: own orders, position, gateways (PAPER / LIVE), Trader controller
# -----------------------------------------------------------------------------

# Горячие клавиши — в hotkeys.py («Настройки» терминала → «Горячие клавиши»): по умолчанию прежние
# (F2–F5, Esc, Space, 1–5, + / -, E) и C — Stop-loss / Take-profit на цене под мышью; их можно менять. Окно спрашивает hotkeys.REGISTRY.match()
# в keyPressEvent (ScalperWindow).


def _num(x, default=0.0):
    """float из FinamDecimal / dict / str / число."""
    if x is None:
        return default
    if hasattr(x, "value"):
        x = x.value
    x = unwrap_value(x)
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


class Gateway(QObject):
    """Единый интерфейс торговли окна: PAPER-симулятор или LIVE (Finam gRPC)."""
    orders_changed = Signal()
    position_changed = Signal()
    fill = Signal(str, float, int)      # side, price, qty — только PAPER (в LIVE позицию отдаёт брокер)
    message = Signal(str)
    name = "?"
    supports_lots = False               # знаем ли мы отдельные сделки (нужно для учёта F / L)

    def __init__(self):
        super().__init__()
        # Свои активные заявки: поля id, side, tick, qty, tag (PaperOrder в PAPER, LiveOrder в LIVE).
        self.orders: list = []
        self.pos_qty = 0
        self.pos_avg = 0.0
        self.realized = 0.0                       # в пунктах цены (PAPER)
        self.broker_unrealized: float | None = None  # деньги (LIVE)
        self.broker_daily: float | None = None

    def place_limit(self, side, tick, qty, tag="entry"):
        raise NotImplementedError

    def place_market(self, side, qty, tag="entry"):
        raise NotImplementedError

    def cancel(self, order_id):
        raise NotImplementedError

    def cancel_all(self, tag=None):
        raise NotImplementedError

    def close_position(self, reverse_lot=0, limits=None, force=False):
        """limits: {"BUY": tick, "SELL": tick} — закрывать лимиткой с забросом вместо рынка.
        force — Stop-loss: снять все заявки инструмента и закрыть, даже если какую-то снять не удалось."""
        raise NotImplementedError

    def on_trade(self, tick, size):
        pass

    def pending_qty(self, side):
        """Объём заявок, отправка которых ещё выполняется в шлюзе."""
        return 0

    def pending_count(self):
        return 0

    def shutdown(self):
        pass


class PaperGateway(Gateway):
    """PAPER: исполнение эмулирует brokers.paper.engine.PaperEngine (общий движок терминала,
    логика прежняя — рыночные и пересекающие заявки сразу по лучшей цене, лимитные в очереди
    за видимым объёмом, исполнение по принтам). Здесь — только перевод его событий в Qt-сигналы."""
    name = "PAPER"
    supports_lots = True

    def __init__(self, book):
        from brokers.paper.engine import PaperEngine
        super().__init__()
        self.book = book
        self._engine = PaperEngine(
            book,
            on_fill=self.fill.emit,                    # раньше position_changed: Trader успеет обновить лоты
            on_position=self.position_changed.emit,
            on_orders=self.orders_changed.emit,
            on_message=self.message.emit,
        )
        self.decimals = self._engine.decimals

    # Состояние живёт в движке; базовый Gateway.__init__ присваивает эти поля до создания
    # движка — такие присваивания пропускаем.
    def _engine_attr(name):
        def getter(self):
            engine = self.__dict__.get("_engine")
            return getattr(engine, name) if engine is not None else None

        def setter(self, value):
            engine = self.__dict__.get("_engine")
            if engine is not None:
                setattr(engine, name, value)
        return property(getter, setter)

    orders = _engine_attr("orders")
    pos_qty = _engine_attr("pos_qty")
    pos_avg = _engine_attr("pos_avg")
    realized = _engine_attr("realized")
    del _engine_attr

    def place_limit(self, side, tick, qty, tag="entry"):
        self._engine.place_limit(side, tick, qty, tag)

    def place_market(self, side, qty, tag="entry"):
        self._engine.place_market(side, qty, tag)

    def cancel(self, order_id):
        self._engine.cancel(order_id)

    def cancel_all(self, tag=None):
        self._engine.cancel_all(tag)

    def close_position(self, reverse_lot=0, limits=None, force=False):
        self._engine.close_position(reverse_lot, limits, force)

    def on_trade(self, tick, size):
        self._engine.on_trade(tick, size)


# -----------------------------------------------------------------------------
# Данные и соединение — из терминала (MarketDataHub, шлюз Finam)
# -----------------------------------------------------------------------------

# Разбор protobuf и ошибок gRPC — общий с торговым модулем (brokers/finam/live.py).
from brokers.finam.live import rpc_text  # noqa: E402

import hotkeys  # noqa: E402  — горячие клавиши терминала («Настройки» → «Горячие клавиши»)
import appearance  # noqa: E402  — цвета и шрифты из «Настроек» («Цвета», «Шрифты»)
from account_core import PAPER_JOURNAL  # noqa: E402  — сделки PAPER для окон «Сделки» / «Финрез»

# Звук сделок стакана (Trader.trade_event: "open" / "close" / "sl" / "tp"). Ставит главное окно —
# там SoundNotifier и галочки «Настройки» → «Звук»; без него окна стакана молчат.
_TRADE_SOUND: Callable[[str], None] | None = None


def set_trade_sound(player: Callable[[str], None] | None) -> None:
    global _TRADE_SOUND
    _TRADE_SOUND = player


# Звук «Уведомление: …» из настроек стакана (сделка, крупный объём, сигнальный уровень):
# "pulse" / "signal" / "alert" — через SoundNotifier терминала (общие вкл/выкл и громкость, «Настройки» → «Звук»).
# Не задан (окно стакана запущено отдельно от терминала) — системный сигнал Windows.
_NOTICE_SOUND: Callable[[str], None] | None = None


def set_notice_sound(player: Callable[[str], None] | None) -> None:
    global _NOTICE_SOUND
    _NOTICE_SOUND = player


# То же уведомление стакана — ещё и строкой в окне «Уведомления» терминала (2.1.84; QuotesTab.add_dom_notice):
# handler(символ, заголовок, текст, звук, цена). До 2.1.84 оно было только звуком и 6 секундами текста в нижней
# строке стакана — «звук есть, а в уведомлениях ничего». Не задан (окно стакана отдельно от терминала) — только
# звук и строка состояния, как раньше.
_NOTICE_EVENT: Callable[..., None] | None = None


def set_notice_event(handler: Callable[..., None] | None) -> None:
    global _NOTICE_EVENT
    _NOTICE_EVENT = handler


# События «Алгоритмов» по инструменту (QuotesTab.chart_events_for) и пояс показа времени — для значков под
# кнопкой настроек стакана (algo_icons, 2.1.35): те же роботы, айсберги, «М» и «↗», что в столбике графика.
# Ставит главное окно; не задано (стакан запущен отдельно от терминала) — значков нет.
_ALGO_EVENTS: Callable[[str], list] | None = None
_DISPLAY_TZ: Callable[[], str] = lambda: "Europe/Moscow"


def set_algo_events(events: Callable[[str], list] | None, display_tz: Callable[[], str] | None = None) -> None:
    global _ALGO_EVENTS, _DISPLAY_TZ
    _ALGO_EVENTS = events
    if display_tz is not None:
        _DISPLAY_TZ = display_tz


def _algo_icon_colors() -> dict:
    """Цвета значков — как на графике: стороны роботов — цвета свечей, айсберги и ММ — свои."""
    try:
        from candlestick_item import BULL_COLOR, BEAR_COLOR
        from chart_items import ICEBERG_BUY_COLOR, ICEBERG_SELL_COLOR
        return {"bull": BULL_COLOR, "bear": BEAR_COLOR, "ice_buy": ICEBERG_BUY_COLOR, "ice_sell": ICEBERG_SELL_COLOR}
    except Exception:
        return {"bull": "#00d9a3", "bear": "#ff4560", "ice_buy": "#3cc8ff", "ice_sell": "#ff6fd8"}


class StreamSignals(QObject):
    quote = Signal(dict)
    book = Signal(list, bool)       # строки (price, bid, ask), признак снимка
    trade = Signal(dict)
    error = Signal(str)
    status = Signal(str)


# Поставщик MarketDataHub терминала: gui_app задаёт его через set_market_data_hub_provider().
# Окна стакана берут котировки, стакан и сделки из хаба (одна подписка у брокера на весь
# терминал). Заявки идут через Gateway окна.
_market_data_hub_provider: Callable[[], object] | None = None


def set_market_data_hub_provider(provider: Callable[[], object] | None) -> None:
    global _market_data_hub_provider
    _market_data_hub_provider = provider


def _current_market_data_hub():
    try:
        return _market_data_hub_provider() if _market_data_hub_provider is not None else None
    except Exception:
        return None


# Поставщик общего соединения терминала для заявок: gui_app задаёт его через
# set_trading_session_provider() — он отдаёт FinamGateway (метод client(): один FinamClient
# на терминал, RetryPolicy(max_attempts=1): PlaceOrder не повторяется автоматически).
_trading_session_provider: Callable[[], object] | None = None


def set_trading_session_provider(provider: Callable[[], object] | None) -> None:
    global _trading_session_provider
    _trading_session_provider = provider


class SharedTradingSession:
    """Сессия поверх общего соединения терминала: для LiveGateway и для запроса шага цены (fetch_tick).

    client() каждый раз спрашивает у поставщика текущий шлюз: после переподключения терминала
    (новый токен, «Подключиться») заявки и торговые потоки сами переходят на новый клиент.
    Закрывать соединение — дело терминала, не окна: close() здесь ничего не делает."""

    def __init__(self, provider: Callable[[], object]):
        self._provider = provider

    def client(self):
        gateway = self._provider()
        if gateway is None:
            raise RuntimeError("соединение терминала с Finam не установлено")
        return gateway.client()

    def close(self):
        pass


def _current_trading_session():
    """SharedTradingSession, если терминал отдаёт своё соединение, иначе None."""
    provider = _trading_session_provider
    try:
        if provider is not None and provider() is not None:
            return SharedTradingSession(provider)
    except Exception:
        pass
    return None


class HubStreamEngine:
    """Данные окна стакана из MarketDataHub (signals, start, stop, running). Переподключение
    и отсев повторов делает шлюз; сюда приходят модели core.

    Стакан из хаба — полный снимок; окну нужен прежний формат «изменения строк»: первый раз
    отдаём всё со snapshot=True, дальше — только изменившиеся и исчезнувшие уровни."""

    def __init__(self, symbol, hub_provider: Callable[[], object] = _current_market_data_hub):
        self.symbol = symbol
        self.signals = StreamSignals()
        self._provider = hub_provider
        self._subs: list = []
        self._hub = None
        self._prev_book: dict[float, tuple[int, int]] | None = None
        self._streaming = False
        self._started_at = 0.0          # monotonic подписки — сколько ждали первый снимок стакана (FIRST_BOOK_LOG_SEC)

    FIRST_BOOK_LOG_SEC = 2.0            # первый снимок пришёл позже — строка в журнал (стакан «появился не сразу»)

    @property
    def running(self):
        return bool(self._subs)

    def start(self):
        if self._subs:
            return
        hub = self._provider()
        if hub is None:
            self.signals.error.emit("нет подключения к Finam (шлюз терминала не запущен)")
            return
        from core.models import InstrumentId
        iid = InstrumentId.parse(self.symbol)
        if self._hub is not hub:
            self._hub = hub
            hub.on_connection(self._on_connection)
        self._prev_book = None
        self._streaming = False
        self._started_at = time.monotonic()
        self._subs = [
            hub.subscribe_quotes(iid, self._on_quote),
            hub.subscribe_orderbook(iid, self._on_book),
            hub.subscribe_trades(iid, self._on_trade),
        ]
        self.signals.status.emit("CONNECTING")

    def stop(self):
        subs, self._subs = self._subs, []
        for sub in subs:
            sub.close()
        self._prev_book = None
        self._streaming = False
        self.signals.status.emit("STOPPED")

    def restart(self):
        """Терминал пересоздал хаб (переподключение из «Настроек») — переподписаться на новый."""
        if self._subs:
            self.stop()
            self.start()

    # ---- данные из хаба (GUI-поток) ---------------------------------------------
    def _mark_streaming(self):
        if not self._streaming:
            self._streaming = True
            self.signals.status.emit("STREAMING")

    def _on_connection(self, state):
        if not self._subs:
            return
        if state.connected:
            if self._streaming:
                self.signals.status.emit("STREAMING")
        else:
            self._streaming = False
            self.signals.status.emit("RECONNECTING")
            self.signals.error.emit(f"{state.reason or 'нет связи'} — переподключение")

    def _on_quote(self, q):
        d = {}
        for name in ("bid", "ask", "last"):
            value = getattr(q, name)
            if value is not None:
                d[name] = value
        if d:
            self._mark_streaming()
            self.signals.quote.emit({"quote": [d]})

    def _on_book(self, book):
        new = {price: (int(round(volume)), 0) for price, volume in book.bids}     # уровни — пары
        new.update({price: (0, int(round(volume))) for price, volume in book.asks})
        prev = self._prev_book
        self._prev_book = new
        if prev is None:
            rows = [(p, b, a) for p, (b, a) in new.items()]
            snapshot = True
            waited = time.monotonic() - self._started_at if self._started_at else 0.0
            if waited > self.FIRST_BOOK_LOG_SEC:
                print(f"[стакан] {self.symbol}: первый снимок стакана через {waited:.1f} с после открытия окна "
                      "(Finam долго не присылал стакан)", file=sys.stderr)
        else:
            rows = [(p, b, a) for p, (b, a) in new.items() if prev.get(p) != (b, a)]
            rows += [(p, 0, 0) for p in prev if p not in new]       # уровень исчез
            snapshot = False
        if rows or snapshot:
            self._mark_streaming()
            self.signals.book.emit(rows, snapshot)

    def _on_trade(self, t):
        self._mark_streaming()
        self.signals.trade.emit({
            "price": t.price,
            "size": int(round(t.volume)),
            "side": "BUY" if t.side is not None and t.side.value == "buy"
                    else "SELL" if t.side is not None else "",
            "trade_id": t.trade_id,
            "timestamp": datetime.fromtimestamp(t.ts, tz=timezone.utc).isoformat() if t.ts else "",
            "snapshot": t.is_snapshot,
            "lag_ms": (time.time() - t.ts) * 1000.0 if t.ts else None,
        })


class LiveGateway(Gateway):
    """LIVE: заявки, отмены, закрытие, позиция и исполнения — brokers.finam.live.FinamLiveEngine
    (торговый модуль терминала). Здесь — только перевод колбэков движка в Qt-сигналы: они
    вызываются из фоновых потоков, Qt доставит их в GUI-поток очередью.

    session — объект с методом client(): общее соединение терминала (SharedTradingSession)."""
    name = "LIVE"
    supports_lots = True        # исполнения приходят потоком; при расхождении с позицией брокера используется D

    # Значения до создания движка (базовый Gateway.__init__ присваивает поля раньше него).
    _DEFAULTS = {"orders": (), "pos_qty": 0, "pos_avg": 0.0, "realized": 0.0,
                 "broker_unrealized": None, "broker_daily": None, "last_rtt_ms": None,
                 "account_seen": False}

    def __init__(self, session, account_id, symbol, tick):
        from brokers.finam.live import FinamLiveEngine
        super().__init__()
        self.symbol, self.tick = symbol, tick
        self.decimals = tick_decimals(tick)
        self._engine = FinamLiveEngine(
            session, account_id, symbol, tick,
            on_orders=self.orders_changed.emit,
            on_position=self.position_changed.emit,
            on_fill=self.fill.emit,
            on_message=self.message.emit,
        )

    # Состояние живёт в движке (его меняют потоки движка) — окно и Trader читают его отсюда.
    def _engine_attr(name):
        def getter(self):
            engine = self.__dict__.get("_engine")
            return getattr(engine, name) if engine is not None else LiveGateway._DEFAULTS[name]

        def setter(self, value):
            engine = self.__dict__.get("_engine")
            if engine is not None:
                setattr(engine, name, value)
        return property(getter, setter)

    orders = _engine_attr("orders")
    pos_qty = _engine_attr("pos_qty")
    pos_avg = _engine_attr("pos_avg")
    realized = _engine_attr("realized")
    broker_unrealized = _engine_attr("broker_unrealized")
    broker_daily = _engine_attr("broker_daily")
    last_rtt_ms = _engine_attr("last_rtt_ms")
    account_seen = _engine_attr("account_seen")      # позиция от брокера уже получена (до этого pos_qty — не факт)
    del _engine_attr

    def place_limit(self, side, tick, qty, tag="entry"):
        self._engine.place_limit(side, tick, qty, tag)

    def place_market(self, side, qty, tag="entry"):
        self._engine.place_market(side, qty, tag)

    def cancel(self, order_id):
        self._engine.cancel(order_id)

    def cancel_all(self, tag=None):
        self._engine.cancel_all(tag)

    def close_position(self, reverse_lot=0, limits=None, force=False):
        self._engine.close_position(reverse_lot, limits, force)

    def pending_qty(self, side):
        return self._engine.pending_qty(side)

    def pending_count(self):
        return self._engine.pending_count()

    def shutdown(self):
        self._engine.shutdown()


SLTP_OFF = "off"      # Stop-loss / Take-profit снят вручную (Trader._manual_sl / _manual_tp)


class Trader(QObject):
    """Логика скальпера: лот, лимиты риска, TP / SL / трейлинг, закрытие, реверс."""
    message = Signal(str)
    changed = Signal()
    # Журнал (консоль и logs/fx_terminal_ДАТА.log): Stop-Loss / Take-Profit поставлен, перенесён, снят, сработал
    log = Signal(str)
    # Звук сделки (ScalperWindow → sound_notifier): "open" — открыта позиция (в т.ч. после переворота),
    # "close" — закрыта, "sl" / "tp" — сработал стоп / тейк (вместо "close" для этого закрытия).
    trade_event = Signal(str)
    SOUND_QUIET_SEC = 5.0      # после открытия окна: позиция, пришедшая от брокера, — не «открытие»
    STOP_CLOSE_SEC = 15.0      # закрытие в течение стольких секунд после SL / TP — это их закрытие

    def __init__(self, gateway, book, settings, max_pos, max_lot):
        super().__init__()
        self.gw = gateway
        self.book = book
        self.tick = book.tick
        self.s = settings
        self.lot = settings.work_lots[0]
        self.max_pos = max_pos
        self.max_lot = max_lot
        self._tp_req = None
        self._syncing = False
        self._trig_t = 0.0
        self._prev_q = gateway.pos_qty
        self._first = None       # цена первой сделки позиции
        self._extreme = None     # экстремум цены в сторону прибыли (для трейлинга), в тиках
        self._lots = {"F": [], "L": []}   # открытые лоты [qty, price] при закрытии FIFO / LIFO
        self._dir = 0
        self._warned_acct = False
        self._quiet_until = time.monotonic() + self.SOUND_QUIET_SEC
        self._stop_kind = None          # ("sl" | "tp", monotonic) — сработал стоп / тейк, ждём закрытия
        self._last_fill = None          # (side, price) последнего исполнения — опознать серверный TP
        # Stop-loss / Take-profit, поставленные вручную: зажать клавишу (по умолчанию C) и кликнуть
        # цену в стакане (set_level_at). Значение — тик уровня, SLTP_OFF — снят «×» / средней кнопкой
        # (cancel_range), None — по настройкам «Stop-loss / Take-profit, шагов цены». Сбрасываются, когда
        # позиция закрыта или перевёрнута (у новой позиции — снова по настройкам).
        self._manual_sl = None
        self._manual_tp = None
        # Дневной лимит убытка на весь терминал (services.live_guard.DayLossGuard), задаёт менеджер окон.
        self.guard = None
        gateway.fill.connect(self._on_fill)
        gateway.position_changed.connect(self._on_position)
        gateway.message.connect(self.message)

    # ---- settings ----------------------------------------------------------

    @property
    def lots(self):
        return self.s.work_lots

    def set_settings(self, s):
        self.s = s
        if self.lot not in s.work_lots:
            self.lot = s.work_lots[0]
        self.sync_bracket()
        self.changed.emit()

    def set_lot(self, lot):
        self.lot = lot
        self.changed.emit()

    # ---- risk --------------------------------------------------------------

    def _risk_ok(self, side, qty):
        if qty <= 0 or qty > self.max_lot:
            self.message.emit(f"Отказ: лот {qty} > лимита {self.max_lot}")
            return False
        pend = sum(o.qty for o in self.gw.orders if o.side == side and o.tag != "tp")
        # Дополнительно учитываем команды, уже отправленные в рабочий поток,
        # но ещё не отражённые в списке заявок шлюза.
        try:
            pend += self.gw.pending_qty(side)
        except (AttributeError, TypeError):
            pass
        pos = self.gw.pos_qty
        worst = pos + pend + qty if side == "BUY" else pos - pend - qty
        if abs(worst) > self.max_pos and abs(worst) > abs(pos):
            self.message.emit(f"Отказ: превысит лимит позиции {self.max_pos} (было бы {worst:+d})")
            return False
        # Дневной лимит убытка: нельзя ни увеличивать позицию, ни переходить через ноль. Раньше проверялся
        # только рост по модулю: при лонге 5 вторая продажа 5 поверх ещё не исполненной закрывающей давала
        # «5 − 5 − 5 = −5», модуль не вырос — и заявка проходила, открывая шорт при закрытом лимите.
        from services.live_guard import opens_exposure
        if opens_exposure(pos, worst) and self._entry_blocked():
            return False
        return True

    def _entry_blocked(self):
        """Дневной лимит убытка достигнут — новые входы закрыты (закрывать и снимать можно)."""
        guard = self.guard
        if guard is not None and guard.blocks_entry():
            self.message.emit(f"Отказ: дневной лимит убытка {guard.limit:.0f} ₽ — новые входы закрыты до конца дня")
            return True
        return False

    # ---- execution rules ---------------------------------------------------

    def _auto_reach(self, side, qty):
        """Дальность заброса «0 = автоматически»: шагов от лучшей цены, чтобы покрыть объём заявки."""
        lv = self.book.levels
        bid_t, ask_t = self.book.best()
        if side == "BUY" and ask_t is not None:
            levels = sorted((k, l.ask) for k, l in lv.items() if l.ask > 0 and k >= ask_t)
            best = ask_t
        elif side == "SELL" and bid_t is not None:
            levels = sorted(((k, l.bid) for k, l in lv.items() if l.bid > 0 and k <= bid_t), reverse=True)
            best = bid_t
        else:
            return 3
        acc = 0
        for k, vol in levels:
            acc += vol
            if acc >= max(1, qty):
                return abs(k - best) + 1
        return (abs(levels[-1][0] - best) + 1) if levels else 3

    def _limits(self, reach, qty=1):
        """Лимитки с забросом от спреда: покупка — выше ask, продажа — ниже bid (reach=0 — автоматически)."""
        bid_t, ask_t = self.book.best()
        if bid_t is None or ask_t is None:
            return None
        rb = reach or self._auto_reach("BUY", qty)
        rs = reach or self._auto_reach("SELL", qty)
        return {"BUY": ask_t + rb, "SELL": bid_t - rs}

    def _stop_limits(self, level, qty):
        """Заявка сработавшего SL / TP уходит от цены стопа, а не от спреда: стоп 100, заброс 10 -> 90."""
        reach = self.s.stop_reach or self._auto_reach("SELL" if self.gw.pos_qty > 0 else "BUY", qty)
        return {"SELL": level - reach, "BUY": level + reach}

    def _exec_rule(self, stop=False):
        # Рыночные для SL / TP в приложении и для действий (закрытие, реверс, маркет) — первый флажок;
        # стоп-заявки на сервере (не реализованы, у нас SL всегда виртуальный) — второй.
        if stop and self.s.sltp_place == "На сервере":
            return self.s.market_for_stops
        return self.s.market_for_actions

    def _close(self, reverse_lot=0, stop_level=None, force=False):
        """Закрыть (и развернуться на reverse_lot). force — сработал Stop-loss: снимаются все
        заявки инструмента и позиция закрывается, даже если какую-то заявку снять не удалось (LiveGateway)."""
        qty = abs(self.gw.pos_qty) + reverse_lot
        market = self._exec_rule(stop_level is not None)
        if market:
            limits = None
        elif stop_level is not None:
            limits = self._stop_limits(stop_level, qty)
        else:
            limits = self._limits(self.s.limit_reach, qty)
        self.gw.close_position(reverse_lot, limits, force=force)

    # ---- actions -----------------------------------------------------------

    def limit(self, side, tick):
        if self._risk_ok(side, self.lot):
            self.gw.place_limit(side, tick, self.lot, "entry")

    def market(self, side):
        if not self._risk_ok(side, self.lot):
            return
        if self.s.market_for_actions:
            self.gw.place_market(side, self.lot, "entry")
            return
        lim = self._limits(self.s.limit_reach, self.lot)
        if lim is None:
            self.message.emit("Нет стакана для лимитной заявки")
            return
        self.gw.place_limit(side, lim[side], self.lot, "entry")

    def close_position(self):
        if self.gw.pos_qty:
            self._close()

    def reverse(self):
        q = self.gw.pos_qty
        if q and self._entry_blocked():             # реверс открывает новую позицию
            return
        if q and self._risk_ok("SELL" if q > 0 else "BUY", self.lot):
            self._close(reverse_lot=self.lot)

    def cancel_all(self):
        self.gw.cancel_all()

    def cancel_at(self, tick):
        for o in list(self.gw.orders):
            if o.tick == tick:
                self.gw.cancel(o.id)

    def cancel_range(self, lo, hi):
        """Снять заявки в диапазоне цен [lo, hi] (в тиках) — строка сжатого стакана («×» или средняя кнопка).
        Stop-loss / Take-profit на этой строке — тоже: снятый уровень не возвращается из настроек до закрытия
        позиции (серверный TP — лимитка с меткой «tp» — не выставляется заново)."""
        sl, tp = self.sl_tick(), self.tp_tick()
        removed = False
        if sl is not None and lo <= sl <= hi:
            self._manual_sl = SLTP_OFF
            removed = True
            self.log.emit(f"SL {self._fmt(sl)} снят")
        if (tp is not None and lo <= tp <= hi) or any(o.tag == "tp" and lo <= o.tick <= hi for o in self.gw.orders):
            self._manual_tp = SLTP_OFF
            removed = True
            if tp is not None:
                self.log.emit(f"TP {self._fmt(tp)} снят")
        for o in list(self.gw.orders):
            if lo <= o.tick <= hi:
                self.gw.cancel(o.id)
        if removed:
            self.sync_bracket()
            self.changed.emit()

    # ---- position reference, SL / TP levels --------------------------------

    def _on_fill(self, side, price, qty):
        """Ведём два набора открытых лотов: закрытие с начала (FIFO) и с конца (LIFO)."""
        self._last_fill = (side, price)
        sgn = 1 if side == "BUY" else -1
        if self._dir == 0 or sgn == self._dir:
            for k in ("F", "L"):
                self._lots[k].append([qty, price])
            self._dir = sgn
            return
        left = qty
        for k in ("F", "L"):
            lots = self._lots[k]
            left = qty
            while left > 0 and lots:
                idx = 0 if k == "F" else -1
                take = min(lots[idx][0], left)
                lots[idx][0] -= take
                left -= take
                if lots[idx][0] == 0:
                    lots.pop(idx)
        if left > 0:                       # разворот: остаток открывает позицию в другую сторону
            for k in ("F", "L"):
                self._lots[k] = [[left, price]]
            self._dir = sgn
        elif not self._lots["F"]:
            self._dir = 0

    def account_mode(self):
        """D / F / L с учётом возможностей шлюза (в LIVE F и L недоступны)."""
        mode = self.s.pos_account[:1]
        if mode in ("F", "L") and not self.gw.supports_lots:
            if not self._warned_acct:
                self._warned_acct = True
                self.message.emit("F/L недоступны в LIVE (нет списка сделок) — используется D")
            return "D"
        return mode if mode in ("D", "F", "L") else "D"

    def ref_price(self):
        """Цена позиции. D — по версии сервера; F / L — средняя цена оставшихся сделок после закрытия
        FIFO (первая открытая уходит первой) или LIFO (последняя уходит первой)."""
        q = self.gw.pos_qty
        if q == 0:
            return 0.0
        mode = self.account_mode()
        if mode in ("F", "L"):
            lots = self._lots[mode]
            total = sum(x[0] for x in lots)
            if lots and total == abs(q):
                return sum(x[0] * x[1] for x in lots) / total
        if self.gw.pos_avg > 0:
            return self.gw.pos_avg
        lots = self._lots["F"]                           # у брокера средней цены нет — берём из своих исполнений
        total = sum(x[0] for x in lots)
        return (sum(x[0] * x[1] for x in lots) / total) if lots and total == abs(q) else 0.0

    def _to_ticks(self, value):
        if value <= 0:
            return 0
        if self.s.sltp_unit == "В процентах":
            ref = self.ref_price() or (self.book.last or 0.0)
            if not ref:
                return 0
            return max(1, int(round(ref * value / 100.0 / self.tick)))
        return int(round(value))

    def sl_ticks(self):
        return self._to_ticks(self.s.stop_loss)

    def tp_ticks(self):
        return self._to_ticks(self.s.take_profit)

    def set_level_at(self, tick):
        """Режим «Stop-Loss / Take-Profit» (зажата клавиша, по умолчанию C) и клик по цене стакана.
        Тип уровня — по зоне: при длинной позиции зелёная зона (покупатели, ниже середины спреда) — Stop-loss,
        красная (продавцы, выше) — Take-profit; при короткой — наоборот. Уровень такого типа уже есть —
        переносится на новую цену. Снять — «×» у метки или средней кнопкой (cancel_range).
        -> текст для строки сообщений."""
        q = self.gw.pos_qty
        if not q:
            return "Stop-Loss / Take-Profit ставятся только к открытой позиции"
        price = tick * self.tick
        mid = self.book.mid()
        if mid is None:
            return "Нет стакана — не понять, в какой зоне цена"
        if tick == mid:
            return f"{price:g} — середина спреда: кликните в зоне покупателей или продавцов"
        in_bids = tick < mid                                   # зелёная зона — покупатели
        is_sl = in_bids if q > 0 else not in_bids
        if is_sl:
            moved = isinstance(self._manual_sl, int) or self.sl_tick() is not None
            self._manual_sl = tick
            msg = f"Stop-Loss {'перенесён на' if moved else ''} {price:g}".replace("  ", " ")
        else:
            moved = isinstance(self._manual_tp, int) or self.tp_tick() is not None
            self._manual_tp = tick
            msg = (f"Take-Profit {'перенесён на' if moved else ''} {price:g}".replace("  ", " ")
                   + (" (на сервере — лимитной заявкой)" if self.s.sltp_place == "На сервере" else ""))
        self.sync_bracket()
        self.changed.emit()
        self.log.emit(f"{msg} (позиция {q:+d})")
        return msg

    def _fmt(self, tick) -> str:
        return f"{tick * self.tick:g}"

    def sl_tick(self):
        q = self.gw.pos_qty
        if q and self._manual_sl is not None:
            # поставлен вручную — без трейлинга, как есть; снят «×» — нет
            return None if self._manual_sl == SLTP_OFF else self._manual_sl
        sl = self.sl_ticks()
        if not q or sl <= 0:
            return None
        ref_t = self.ref_price() / self.tick
        base = (math.floor(ref_t + 1e-9) - sl) if q > 0 else (math.ceil(ref_t - 1e-9) + sl)
        step = int(round(self.s.stop_trailing))
        if step > 0 and self._extreme is not None:
            if q > 0:
                k = int((self._extreme - ref_t) // step) if self._extreme > ref_t else 0
                base = max(base, math.floor(ref_t + 1e-9) + k * step - sl)
            else:
                k = int((ref_t - self._extreme) // step) if self._extreme < ref_t else 0
                base = min(base, math.ceil(ref_t - 1e-9) - k * step + sl)
        return base

    def tp_tick(self):
        q = self.gw.pos_qty
        if q and self._manual_tp is not None:
            return None if self._manual_tp == SLTP_OFF else self._manual_tp
        tp = self.tp_ticks()
        if not q or tp <= 0:
            return None
        ref_t = self.ref_price() / self.tick
        return (math.ceil(ref_t - 1e-9) + tp) if q > 0 else (math.floor(ref_t + 1e-9) - tp)

    def tp_virtual_tick(self):
        return self.tp_tick() if self.s.sltp_place == "В приложении" else None

    # ---- bracket -----------------------------------------------------------

    def _on_position(self):
        q = self.gw.pos_qty
        prev = self._prev_q
        tp_req = self._tp_req                   # до sync_bracket: он сбросит заявку TP закрытой позиции
        if q == 0:
            self._first = None
            self._extreme = None
            self._manual_sl = self._manual_tp = None      # ручные уровни — только к своей позиции
        elif prev == 0 or (q > 0) != (prev > 0):
            self._first = self.gw.pos_avg
            self._extreme = None
            self._manual_sl = self._manual_tp = None
            sl, tp = self.sl_tick(), self.tp_tick()
            if sl is not None or tp is not None:            # уровни из настроек стакана — в журнал
                parts = ([f"SL {self._fmt(sl)}"] if sl is not None else []) + \
                        ([f"TP {self._fmt(tp)}"] if tp is not None else [])
                self.log.emit(f"по настройкам: {', '.join(parts)} (позиция {q:+d})")
        self._prev_q = q
        self._trade_sound(prev, q, tp_req)
        self.sync_bracket()
        self.changed.emit()

    def _trade_sound(self, prev, q, tp_req):
        """Событие для звука по смене позиции: открытие, закрытие, закрытие по SL / TP."""
        now = time.monotonic()
        if now < self._quiet_until or prev == q:
            return
        if q == 0 and prev != 0:
            kind = "close"
            if self._stop_kind and now - self._stop_kind[1] < self.STOP_CLOSE_SEC:
                kind = None                     # звук SL / TP уже был в момент срабатывания
            elif tp_req and self._last_fill:    # серверный TP: закрыла наша лимитка «tp» по её цене
                (side, tick, _qty), _t = tp_req
                last_side, last_price = self._last_fill
                if last_side == side and abs(last_price / self.tick - tick) < 0.5:
                    kind = "tp"
            self._stop_kind = None
            if kind:
                self.trade_event.emit(kind)
        elif prev == 0 or (q > 0) != (prev > 0):
            self._stop_kind = None
            self.trade_event.emit("open")

    def sync_bracket(self):
        """Режим «На сервере»: TP — лимитка на весь объём. Режим «В приложении»: TP виртуальный."""
        if self._syncing:
            return
        self._syncing = True
        try:
            gw = self.gw
            q = gw.pos_qty
            tps = [o for o in gw.orders if o.tag == "tp"]
            target = self.tp_tick()
            if q == 0 or target is None or self.s.sltp_place != "На сервере":
                if tps:
                    gw.cancel_all("tp")
                self._tp_req = None
                return
            side = "SELL" if q > 0 else "BUY"
            qty = abs(q)
            if len(tps) == 1 and tps[0].tick == target and tps[0].qty == qty and tps[0].side == side:
                return
            req = (side, target, qty)
            if self._tp_req and self._tp_req[0] == req and time.monotonic() - self._tp_req[1] < 3.0:
                return
            if tps:
                gw.cancel_all("tp")
            self._tp_req = (req, time.monotonic())
            gw.place_limit(side, target, qty, "tp")
        finally:
            self._syncing = False

    # ---- triggers ----------------------------------------------------------

    def _bump_extreme(self, price_tick):
        q = self.gw.pos_qty
        if not q:
            return
        if self._extreme is None:
            self._extreme = self.ref_price() / self.tick
        self._extreme = max(self._extreme, price_tick) if q > 0 else min(self._extreme, price_tick)

    def _check_triggers(self, price, from_trade):
        q = self.gw.pos_qty
        if not q or price is None:
            return
        if (self.s.stop_trigger == "По сделкам") != from_trade:
            return
        sl = self.sl_tick()
        tp = self.tp_virtual_tick()
        hit_sl = sl is not None and ((q > 0 and price <= sl) or (q < 0 and price >= sl))
        hit_tp = tp is not None and ((q > 0 and price >= tp) or (q < 0 and price <= tp))
        if not (hit_sl or hit_tp):
            return
        now = time.monotonic()
        if now - self._trig_t < 3.0:
            return
        self._trig_t = now
        self.message.emit("STOP-LOSS: закрываю позицию" if hit_sl else "TAKE-PROFIT: закрываю позицию")
        level = sl if hit_sl else tp
        how = "сделкой" if from_trade else "лучшей ценой"
        self.log.emit(f"{'STOP-LOSS' if hit_sl else 'TAKE-PROFIT'} сработал: {how} {self._fmt(price)} "
                      f"(уровень {self._fmt(level)}) → закрываю позицию {q:+d}")
        self._stop_kind = ("sl" if hit_sl else "tp", now)
        self.trade_event.emit(self._stop_kind[0])
        self._close(stop_level=sl if hit_sl else tp, force=hit_sl)

    def on_trade(self, tick, size):
        self.gw.on_trade(tick, size)
        self._bump_extreme(tick)
        self._check_triggers(tick, True)

    def on_quotes(self):
        """Вызывается таймером: срабатывание «По лучшим ценам»."""
        q = self.gw.pos_qty
        if not q:
            return
        bid_t, ask_t = self.book.best()
        price = bid_t if q > 0 else ask_t       # цена, по которой позицию можно закрыть
        if price is None:
            return
        self._bump_extreme(price)
        self._check_triggers(price, False)

    # ---- PnL ---------------------------------------------------------------

    def pnl_sign(self):
        """+1 — позиция в прибыли, -1 — в убытке, 0 — ноль или позиции нет.
        Считаем по цене (ref и последняя): это мгновенно и не зависит от того, прислал ли брокер PnL."""
        gw = self.gw
        q = gw.pos_qty
        if not q:
            return 0
        ref, last = self.ref_price(), self._last_price()
        if last is not None and ref > 0:
            diff = (last - ref) * (1 if q > 0 else -1)
            eps = self.tick * 1e-6
            return 1 if diff > eps else -1 if diff < -eps else 0
        u = gw.broker_unrealized
        if u is not None:
            return 1 if u > 0 else -1 if u < 0 else 0
        return 0

    def realized_text(self):
        """Реализованный результат (PAPER) или дневной PnL брокера (LIVE) — для строки состояния."""
        gw, s = self.gw, self.s
        dec = tick_decimals(self.tick)
        if gw.broker_daily is not None:
            return f"день {gw.broker_daily:+.2f}".replace(".", ",")
        r = gw.realized
        if s.profit_mode == "Цена":
            return f"реал {r:+.{dec}f}".replace(".", ",")
        if s.profit_mode == "Пункты":
            return f"реал {r / self.tick:+.0f}"
        return f"реал {r * s.lot_value:+.2f}".replace(".", ",")

    def info_cells(self):
        """Нижняя информационная панель: (цена, позиция, прибыль, знак) (293,95 | -1л | 0,01%).

        Цена: в позиции — цена входа (ref_price: по версии сервера или F / L по настройке учёта),
        без позиции — последняя цена. Позиция — со знаком: 1л лонг, -1л шорт."""
        gw, s = self.gw, self.s
        dec = tick_decimals(self.tick)
        last = self._last_price()
        price = fmt_price(last, dec) if last is not None else "—"
        q = gw.pos_qty
        if not q:
            return price, "0", "0", 0
        ref = self.ref_price()
        if ref > 0:
            price = fmt_price(ref, dec)
        vol = abs(q)
        sign = "" if q > 0 else "-"
        if s.pos_volume_unit == "Деньги":
            pos = sign + fmt_amount(vol * ref * s.lot_value, s.short_work_thousands, s.max_decimals)
        else:
            pos = sign + fmt_amount(vol, s.short_work_thousands, s.max_decimals) + "л"
        if ref <= 0 or last is None:
            return price, pos, "—", 0
        diff = (last - ref) * (1 if q > 0 else -1)
        mode = s.profit_mode
        # Пункт = шаг цены инструмента: «3п» у CNYRUB_TOM (шаг 0,0005) — это 0,0015 в режиме «Цена».
        # Раньше «Цена» подписывалась «п», а «Пункты» — «шаг»: выглядело так, будто это разные величины (29.10).
        if mode == "Цена":
            txt = f"{diff:.{dec}f}"
        elif mode == "Пункты":
            txt = f"{diff / self.tick:.0f}п"
        elif mode == "Проценты":
            txt = f"{(diff / ref * 100.0) if ref else 0.0:.3f}%"
        else:
            bu = gw.broker_unrealized
            money = bu if (bu is not None and (abs(bu) > 1e-12 or abs(diff) < 1e-12)) else diff * vol * s.lot_value
            txt = f"{money:.2f}"
        return price, pos, txt.replace(".", ","), self.pnl_sign()

    def _last_price(self):
        if self.book.last is not None:
            return self.book.last
        m = self.book.mid()
        return m * self.tick if m is not None else None

    def pnl_text(self):
        gw, s = self.gw, self.s
        q = gw.pos_qty
        dec = tick_decimals(self.tick)
        r = gw.realized
        if gw.broker_daily is not None:
            tail = f"   день {gw.broker_daily:+.2f}".replace(".", ",")
        elif s.profit_mode == "Цена":
            tail = f"   реал {r:+.{dec}f}".replace(".", ",")
        elif s.profit_mode == "Пункты":
            tail = f"   реал {r / self.tick:+.0f}"
        else:
            tail = f"   реал {r * s.lot_value:+.2f}".replace(".", ",")
        if not q:
            return "Поз 0" + tail, 0.0

        ref = self.ref_price()
        last = self._last_price()
        sign = 1 if q > 0 else -1
        vol = abs(q)
        vol_val = vol * ref * s.lot_value if s.pos_volume_unit == "Деньги" else vol
        head = f"Поз {'+' if q > 0 else '-'}{fmt_amount(vol_val, s.short_work_thousands, s.max_decimals)}" \
               f" @ {fmt_price(ref, dec)}"
        diff = (last - ref) * sign if last is not None else 0.0
        mode = s.profit_mode
        if mode == "Цена":
            val, txt = diff, f"{diff:+.{dec}f}"
        elif mode == "Пункты":
            val = diff / self.tick
            txt = f"{val:+.0f}"
        elif mode == "Проценты":
            val = (diff / ref * 100.0) if ref else 0.0
            txt = f"{val:+.2f}%"
        else:
            bu = gw.broker_unrealized
            val = bu if (bu is not None and (abs(bu) > 1e-12 or abs(diff) < 1e-12)) else diff * vol * s.lot_value
            txt = f"{val:+.2f}"
        return f"{head}   PnL {txt.replace('.', ',')}" + tail, val



# -----------------------------------------------------------------------------
# Ladder: общая логика стакана (мышь, прокрутка, сжатие, линейки); отрисовка — в скальперских терминалахLadderWidget
# -----------------------------------------------------------------------------

def _c(r, g, b, a=255):
    return QColor(r, g, b, a)


C_WHITE = _c(255, 255, 255)
C_BLACK = _c(0, 0, 0)
C_ASK_VOL = _c(255, 182, 193)
C_ASK_PRICE = _c(255, 170, 182)
C_BID_VOL = _c(144, 238, 144)
C_BID_PRICE = _c(134, 232, 134)
C_BEST_ASK = _c(250, 112, 108)
C_BEST_BID = _c(46, 204, 46)
C_ROUND_PRICE = _c(169, 169, 169)
C_BAR_ORANGE = _c(255, 165, 0)
C_BAR_GRAY = _c(176, 176, 164)
C_DEPTH_ASK = _c(255, 226, 229)
C_DEPTH_BID = _c(214, 249, 214)
C_DEPTH_EDGE = _c(232, 232, 232)
C_TOTAL_ASK = _c(255, 182, 193)
C_TOTAL_BID = _c(144, 238, 144)
C_GRID = _c(168, 168, 168)
C_GRID_MAJOR = _c(128, 128, 128)
C_CELL = _c(236, 236, 236)
C_CELL_TICK = _c(150, 150, 150)
C_HEAD = _c(214, 214, 214)
C_SPREAD_ASK = _c(232, 110, 110)
C_SPREAD_BID = _c(46, 200, 46)
C_PROFILE_BUY = _c(168, 232, 168)
C_PROFILE_SELL = _c(255, 182, 193)
C_VLINE_GRAY = _c(176, 176, 176)
C_ORD_BUY = _c(30, 100, 220)
C_ORD_SELL = _c(190, 35, 45)
C_POS = _c(242, 190, 40)
C_SL = _c(235, 120, 20)
C_TP = _c(60, 170, 90)
C_HOVER = _c(40, 40, 40)
C_LAST = _c(60, 60, 60)
C_BIG2 = _c(200, 0, 0)
C_SIGNAL = _c(40, 90, 220)
C_X = _c(255, 25, 25)          # «×» снятия заявки (ярко-красный, линиями; см. _draw_x)
C_RULER_BG = _c(255, 250, 190)
C_POC = _c(25, 55, 200)
C_UP = _c(70, 190, 90)
C_BAR_BIG = _c(236, 206, 28)          # крупный объём: жёлтая полоса вместо оранжевой
C_BAR_BIG2 = _c(190, 92, 222)         # крупный объём 2
C_BAR_ICE = _c(92, 176, 255)          # айсберг-заявка: голубая полоса
PNL_UP = _c(36, 160, 66)       # позиция в прибыли
PNL_DN = _c(190, 48, 58)       # позиция в убытке
C_DOWN = _c(225, 85, 95)

FONT_FAMILY = "Tahoma"
DEPTH_POWER = 1.0 / 3.0       # нелинейная шкала глубины: ближние уровни заметнее
DEPTH_REF_FRACTION = 0.55     # при какой доле видимой глубины заливка достигает края
BAR_ON_BEST = False           # рисовать оранжевый бар на лучших bid/ask
CLICK_GUARD_SEC = 0.15        # защита от двойного клика по одной цене
MANUAL_SCROLL_RETURN_SEC = 3.0  # автопрокрутка: возврат к цене после ручной прокрутки


def blend(base, k):
    """Смешать белый с base: k=0 — белый, k=1 — base (base: (r, g, b))."""
    return _c(*(int(255 + (b - 255) * k) for b in base))


def compression_steps(mult):
    """Ступени сжатия: 1, m, 10m, 100m … до 50 000 (m — «Множитель изменения шага цены»)."""
    m = max(1, int(mult))
    seq = [1]
    v = m
    while v <= 50000:
        if v not in seq:
            seq.append(v)
        v *= 10
    return seq


class BookView:
    """Снимок стакана для отрисовки: отсортированные уровни и префиксные суммы (быстрые суммы по диапазону цен)."""

    def __init__(self, book, bid_t, ask_t):
        lv = book.levels
        self.bid_t, self.ask_t = bid_t, ask_t
        self.asks = sorted(k for k, l in lv.items() if l.ask > 0 and ask_t is not None and k >= ask_t)
        self.ask_pref = [0] + list(accumulate(lv[k].ask for k in self.asks))
        self.bids = sorted(k for k, l in lv.items() if l.bid > 0 and bid_t is not None and k <= bid_t)
        self.bid_pref = [0] + list(accumulate(lv[k].bid for k in self.bids))
        self.total_ask = self.ask_pref[-1]
        self.total_bid = self.bid_pref[-1]

    def ask_range(self, lo, hi):
        return self.ask_pref[bisect_right(self.asks, hi)] - self.ask_pref[bisect_left(self.asks, lo)]

    def bid_range(self, lo, hi):
        return self.bid_pref[bisect_right(self.bids, hi)] - self.bid_pref[bisect_left(self.bids, lo)]

    def row_volume(self, lo, hi):
        a, b = self.ask_range(lo, hi), self.bid_range(lo, hi)
        if a and b:
            return (a, "ask") if a >= b else (b, "bid")
        if a:
            return a, "ask"
        if b:
            return b, "bid"
        return 0, None

    def cum_ask_upto(self, hi):
        return self.ask_pref[bisect_right(self.asks, hi)]

    def cum_bid_from(self, lo):
        return self.total_bid - self.bid_pref[bisect_left(self.bids, lo)]


class LadderWidget(QWidget):
    """
    Слева направо:
      профиль | кластеры | глубина | МОИ ЗАЯВКИ | объём (бар) | цена

    Мышь (колонки «заявки / объём / цена»):
      ЛКМ — BUY лимит, ПКМ — SELL лимит, СКМ / Shift+ЛКМ — снять заявки на цене,
      Ctrl+ЛКМ — сигнальный уровень, Alt+ЛКМ перетаскивание — ручная линейка.
      Зажата C + клик любой кнопкой — SL / TP на цене:
      при длинной позиции в зоне покупателей — SL, продавцов — TP (при короткой наоборот); «×» у метки
      SL / TP или СКМ — снять.
    Колесо — прокрутка, Shift+колесо — ускоренная, Ctrl+колесо — высота строки.
    «+» / «-» (мышь над стаканом) — сжатие шага цены.
    Строка = `group` шагов цены; цена строки — нижняя граница, заявка ставится по ней.
    """
    PROFILE_W = 95
    CLUSTER_W = 58
    CLUSTER_COLS = 3
    ORD_W = 46
    VOL_W = 70
    PRICE_W = 56
    HEADER_H = 16
    FOOTER_H = 16
    X_W = 12                            # ширина зоны «×» у заявки

    zoomChanged = Signal(int)
    orderClicked = Signal(str, int)     # side, tick (нижняя граница строки)
    cancelClicked = Signal(int)         # tick
    sltpClicked = Signal(int)           # tick — клик в режиме «Stop-Loss / Take-Profit» (зажата клавиша, C)
    compressionChanged = Signal(int)

    def __init__(self, book, clusters, settings, trader=None, tickstore=None):
        super().__init__()
        self.tickstore = tickstore
        self.book = book
        self.clusters = clusters
        self.trader = trader
        self.s = settings
        self.tick = book.tick
        self.decimals = tick_decimals(book.tick)
        self.row_h = 14
        self.base_row_h = 14
        self.group = 1
        self.manual_center: float | None = None
        self._manual_t = 0.0
        self._center: float | None = None       # текущий центр окна (тики): неподвижен, пока цена внутри полосы
        self._hovered = False                   # курсор над стаканом — прокрутка заморожена
        self.hover_tick: int | None = None
        self.sltp_mode = False          # зажата клавиша «Stop-Loss / Take-Profit»: клик ставит уровень, а не заявку
        self.signal_levels: set[int] = set()
        self._ruler: tuple | None = None
        self._ruler_drag = False
        self._lay: dict | None = None
        self._last_click = (None, 0.0)
        self._x_spans: dict[int, tuple[int, int]] = {}   # строка (bucket) -> (x0, x1) её «×» (снять заявку)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setContextMenuPolicy(Qt.NoContextMenu)
        self.setMinimumHeight(200)
        self.set_settings(settings)

    # ---- settings / compression --------------------------------------------

    def _cl_cols(self):
        return self.CLUSTER_COLS if self.s.cluster_panel else 0

    def set_settings(self, s):
        self.s = s
        steps = compression_steps(s.step_mult)
        if self.group not in steps:
            self.set_group(min(steps, key=lambda v: abs(v - self.group)))
        self.setMinimumWidth(self.PROFILE_W + self._cl_cols() * self.CLUSTER_W + 100
                             + self.ORD_W + self.VOL_W + self.PRICE_W)
        self.update()

    def set_group(self, g):
        g = max(1, int(g))
        if g != self.group:
            self.group = g
            self._ruler = None
            self.compressionChanged.emit(g)
        self.update()

    def step_compression(self, direction):
        steps = compression_steps(self.s.step_mult)
        idx = max((i for i, v in enumerate(steps) if v <= self.group), default=0)
        self.set_group(steps[max(0, min(len(steps) - 1, idx + direction))])

    def _levels(self):
        """Шаги линий круглых уровней в тиках с учётом сжатия: (промежуточные, основные)."""
        g = self.group
        mid = max(1, self.s.mid_levels_mult)
        main = max(1, self.s.main_levels_mult)
        if g == 1:
            return mid, main
        ratio = max(1, int(round(main / mid)))
        mid_eff = -(-mid // g) * g
        return mid_eff, mid_eff * ratio

    # ---- geometry helpers ----------------------------------------------------

    def y_center(self, tick):
        lay = self._lay
        if not lay:
            return None
        i = lay["top_b"] - tick // lay["g"]
        if 0 <= i < lay["n"]:
            return lay["y0"] + i * lay["rh"] + lay["rh"] // 2
        return None

    # ---- formatting --------------------------------------------------------

    def _fmt_lots(self, lots, tick, unit, short):
        v = lots
        if unit == "Деньги":
            v = lots * self.book.price(tick) * self.s.lot_value
        return fmt_amount(v, short, self.s.max_decimals, getattr(self.s, "split_digits", True))

    def _nearest_best_price(self, tick):
        """Ближайшая лучшая цена (ask — выше середины спреда, bid — ниже) для линеек."""
        bid_t, ask_t = self.book.best()
        if ask_t is not None and (bid_t is None or tick >= (bid_t + ask_t) / 2):
            ref = ask_t
        else:
            ref = bid_t
        return self.book.price(ref) if ref is not None else None

    def _hover_ruler_text(self, view, tick) -> str:
        """Подпись линейки под курсором (s.ruler) у строки с ценой tick: расстояние от ближайшей лучшей цены;
        в режиме RULER_FULL — «проценты · шаги · Σ объём» (объём — ruler_volume; нет его — без «Σ»)."""
        refp = self._nearest_best_price(tick)
        if not refp:
            return ""
        price = self.book.price(tick)
        if self.s.ruler != RULER_FULL:
            return self._ruler_text(self.s.ruler, refp, price)
        parts = [self._ruler_text("Проценты", refp, price), self._ruler_text("Шаги цены", refp, price)]
        volume = ruler_volume(view, tick, self.group)
        if volume > 0:
            parts.append("Σ " + fmt_amount(volume, self.s.short_thousands, self.s.max_decimals,
                                           getattr(self.s, "split_digits", True)))
        return " · ".join(part for part in parts if part)

    def _ruler_text(self, unit, p_from, p_to, qty=1):
        if unit == "Нет" or not p_from:
            return ""
        d = p_to - p_from
        if unit == "Проценты":
            txt = f"{d / p_from * 100:+.2f}%" if p_from else ""
        elif unit == "Шаги цены":
            txt = f"{d / self.book.tick:+.0f}"
        elif unit == "Цена":
            txt = f"{d:+.{self.decimals}f}"
        else:
            txt = f"{d * qty * self.s.lot_value:+.2f}"
        return txt.replace(".", ",")

    # ---- interaction -------------------------------------------------------

    def set_row_h(self, value):
        self.row_h = max(10, min(30, value))
        self.zoomChanged.emit(round(self.row_h * 100 / self.base_row_h))
        self.update()

    def recenter(self):
        self.manual_center = None
        self._center = None
        self.update()

    def _row_tick(self, y):
        lay = self._lay
        if not lay:
            return None
        i = (y - lay["y0"]) // lay["rh"]
        if y < lay["y0"] or i < 0 or i >= lay["n"]:
            return None
        return (lay["top_b"] - i) * lay["g"]

    def _hit_tick(self, pos):
        lay = self._lay
        if not lay or pos.x() < lay.get("dom_x", lay["ord_x"]):      # dom_x — левый край стакана (ScalperLadderWidget)
            return None
        return self._row_tick(pos.y())

    def _base_center(self, bid_t=None, ask_t=None):
        if self.s.center_mode == "По последней сделке" and self.book.last is not None:
            return float(self.book.key(self.book.last))
        return self.book.mid(bid_t, ask_t)

    def _resolve_center(self, base):
        """Центр окна (в тиках). Автопрокрутка: курсор над стаканом — стакан не двигается;
        курсор вне стакана — спред удерживается в видимой части (центральные ~60% окна)."""
        s = self.s
        now = time.monotonic()
        if self._center is None:
            self._center = base
        if self.manual_center is not None:                 # пользователь прокрутил колесом
            if s.autoscroll and not self._hovered and now - self._manual_t > MANUAL_SCROLL_RETURN_SEC:
                self.manual_center = None
            else:
                return self.manual_center
        if s.autoscroll and not self._hovered:
            n = (self._lay or {}).get("n", 40)
            if abs(base - self._center) > max(2, int(n * 0.3)) * self.group:
                self._center = base
        return self._center

    def enterEvent(self, event):
        self._hovered = True
        self.setFocus()          # горячие клавиши «Стакан» действуют на стакан под мышью (см. hotkeys.py)
        super().enterEvent(event)

    def wheelEvent(self, event):
        dy = event.angleDelta().y()
        if not dy:
            return
        direction = 1 if dy > 0 else -1
        notches = max(1, abs(dy) // 120)
        mods = event.modifiers()
        if mods & Qt.ControlModifier:
            self.set_row_h(self.row_h + direction)
        else:
            if self.manual_center is None:
                self.manual_center = self._center if self._center is not None else self._base_center()
            if self.manual_center is not None:
                step = self.s.fast_scroll if mods & Qt.ShiftModifier else 3
                self.manual_center += step * self.group * direction * notches
                self._manual_t = time.monotonic()
                self.update()
        event.accept()

    def mouseMoveEvent(self, event):
        pos = event.position().toPoint()
        if self._ruler_drag and self._ruler:
            t = self._row_tick(pos.y())
            if t is not None:
                self._ruler = (self._ruler[0], t)
                self.update()
        t = self._hit_tick(pos)
        if t != self.hover_tick:
            self.hover_tick = t
            self.update()

    def leaveEvent(self, event):
        self._hovered = False
        self.hover_tick = None
        self.sltp_mode = False          # режим Stop-Loss / Take-Profit — только пока мышь над стаканом
        self.update()

    def mouseReleaseEvent(self, event):
        if self._ruler_drag:
            self._ruler_drag = False
            if self._ruler and self._ruler[0] == self._ruler[1]:
                self._ruler = None
            self.update()

    def set_sltp_mode(self, on: bool) -> None:
        """Режим «Stop-Loss / Take-Profit»: пока зажата клавиша — внизу стакана надпись, клик
        любой кнопкой мыши по цене ставит или переносит уровень (sltpClicked), а не заявку."""
        on = bool(on)
        if on != self.sltp_mode:
            self.sltp_mode = on
            self.update()

    def mousePressEvent(self, event):
        self.setFocus()
        btn, mods = event.button(), event.modifiers()
        pos = event.position().toPoint()
        if self.sltp_mode and hotkeys.is_held("sltp_at_cursor") is False:
            self.sltp_mode = False      # клавишу отпустили, а отпускание до окна не дошло (фокус уходил)
        if self.sltp_mode and btn in (Qt.LeftButton, Qt.RightButton, Qt.MiddleButton):
            tick = self._hit_tick(pos)
            if tick is not None:
                self.sltpClicked.emit(tick)
            return
        if btn == Qt.LeftButton and mods & Qt.AltModifier:
            t = self._row_tick(pos.y())
            if t is not None:
                self._ruler = (t, t)
                self._ruler_drag = True
                self.update()
            return
        tick = self._hit_tick(pos)
        if tick is None:
            return
        if btn == Qt.LeftButton and mods & Qt.ControlModifier:
            self.signal_levels ^= {tick}
            self.update()
            return
        span = self._x_spans.get(tick // self.group)
        if btn == Qt.LeftButton and not mods and span and span[0] <= pos.x() < span[1]:
            self.cancelClicked.emit(tick)          # «×» у заявки — снять её
            return
        cancel = btn == Qt.MiddleButton or (btn == Qt.LeftButton and mods & Qt.ShiftModifier)
        lay = self._lay or {}
        if not cancel and "dom_x" in lay and pos.x() >= lay["ord_x"]:     # dom_x есть у скальперских терминаловLadderWidget
            # Колонка заявок справа от цены (метки заявок, позиции, TP/SL) и разделитель — не место для новой
            # заявки: 02.11 щелчок по метке позиции «+2» в LIVE выставил покупку. Заявка — щелчком по объёму
            # или цене; здесь — только «×» у своей заявки (выше) и снятие средней кнопкой / Shift+щелчком.
            return
        now = time.monotonic()
        last_tick, last_t = self._last_click
        if tick == last_tick and now - last_t < CLICK_GUARD_SEC:
            return
        self._last_click = (tick, now)
        if cancel:
            self.cancelClicked.emit(tick)
        elif btn == Qt.LeftButton:
            self.orderClicked.emit("BUY", tick)
        elif btn == Qt.RightButton:
            self.orderClicked.emit("SELL", tick)

    # ---- painting helpers --------------------------------------------------

    def _font(self, bold=False, px=None):
        f = QFont(FONT_FAMILY)
        f.setPixelSize(px or max(9, self.row_h - 3))
        f.setBold(bold)
        return f

    def _own_by_row(self):
        """bucket -> [(text, bg, fg, снимаемая), ...] маркеры: заявки, TP/SL, позиция (строки с учётом сжатия).

        Метка позиции в строке — последней: «×» рисуется сразу за снимаемыми метками (заявки, TP, SL), а позиция
        уже за ним. До 2.1.76 позиция стояла первой, и на цене открытия заявка на закрытие сдвигала «×» за край
        окна — снять её «×» было нельзя."""
        items: dict[int, list] = {}
        pos_mark = None
        tr = self.trader
        if tr is None:
            return items
        s = self.s
        g = self.group
        gw = tr.gw
        q = gw.pos_qty
        if q:
            ref = tr.ref_price()
            pb = int(round(ref / self.book.tick)) // g
            vol = abs(q) * ref * s.lot_value if s.pos_volume_unit == "Деньги" else abs(q)
            txt = ("+" if q > 0 else "-") + fmt_amount(vol, s.short_work_thousands, s.max_decimals)
            sg = tr.pnl_sign()
            pos_mark = (pb, (txt, CS["pnl_up"] if sg > 0 else CS["pnl_dn"] if sg < 0 else C_POS,
                             C_WHITE if sg else C_BLACK, False))
        agg: dict[tuple, int] = {}
        for o in gw.orders:
            key = (o.tick // g, o.side, o.tag == "tp")
            agg[key] = agg.get(key, 0) + o.qty
        for (b, side, is_tp), qty in sorted(agg.items()):
            text = self._fmt_lots(qty, b * g, s.work_volume_unit, s.short_work_thousands)
            if is_tp:
                text = "TP " + text
            items.setdefault(b, []).append((text, C_ORD_BUY if side == "BUY" else C_ORD_SELL, C_WHITE, True))
        tp = tr.tp_virtual_tick()
        if tp is not None:
            items.setdefault(tp // g, []).append(("TP", C_TP, C_BLACK, True))
        sl = tr.sl_tick()
        if sl is not None:
            items.setdefault(sl // g, []).append(("SL", C_SL, C_BLACK, True))
        if pos_mark is not None:
            items.setdefault(pos_mark[0], []).append(pos_mark[1])
        return items

    def _vol_text(self, view, lo, hi, vol):
        """Текст объёма строки; если в строке и ask, и bid (нет спреда) — «ask | bid»."""
        s = self.s
        a, b = view.ask_range(lo, hi), view.bid_range(lo, hi)
        if a and b:
            return (self._fmt_lots(a, lo, s.volume_unit, s.short_thousands) + " | "
                    + self._fmt_lots(b, lo, s.volume_unit, s.short_thousands))
        return self._fmt_lots(vol, lo, s.volume_unit, s.short_thousands)

    def _bar_color(self, vol, iceberg=False):
        s = self.s
        if iceberg:
            return CS["bar_ice"]
        if vol >= s.big_volume2:
            return CS["bar_big2"]
        if vol >= s.big_volume:
            return CS["bar_big"]
        return None                                    # обычный объём — цвет «Объем» (CS["gold"])

    def _real_order_rows(self):
        """Строки с «×»: мои заявки и Stop-loss / Take-profit (их тоже снимают «×» или средней кнопкой)."""
        tr = self.trader
        if tr is None:
            return set()
        rows = {o.tick // self.group for o in tr.gw.orders}
        for level in (tr.sl_tick(), tr.tp_virtual_tick()):
            if level is not None:
                rows.add(level // self.group)
        return rows

    def _own_tints(self):
        """bucket -> цвет подсветки строки стакана для моих заявок и виртуальных TP / SL."""
        out: dict[int, QColor] = {}
        tr = self.trader
        if tr is None:
            return out
        g = self.group
        for o in tr.gw.orders:
            out[o.tick // g] = (_c(70, 170, 100, 175) if o.tag == "tp" else
                                _c(60, 120, 220, 175) if o.side == "BUY" else _c(205, 60, 60, 190))
        tp = tr.tp_virtual_tick()
        if tp is not None:
            out.setdefault(tp // g, _c(70, 170, 100, 120))
        sl = tr.sl_tick()
        if sl is not None:
            out.setdefault(sl // g, _c(205, 90, 40, 130))
        return out

    def _pos_indicator(self):
        """(тик цены позиции, цвет) для линии «прибыль / убыток» или None."""
        tr = self.trader
        if tr is None or not self.s.pos_line or not tr.gw.pos_qty:
            return None
        ref = tr.ref_price()
        if ref <= 0:
            return None
        sg = tr.pnl_sign()
        col = CS["pnl_up"] if sg > 0 else CS["pnl_dn"] if sg < 0 else C_POS
        return int(round(ref / self.book.tick)), col

    X_MIN = 7                           # «×» не меньше стольких пикселей

    def _mark_x(self, p, b, rx, y, rh, w, x_room, font) -> int:
        """«×» снятия заявки строки b у метки (x = rx, но не правее края окна w) и зона щелчка по нему
        (_x_spans). Возвращает x, с которого рисовать следующую метку."""
        x = max(0, min(rx, w - x_room))
        xw = self._draw_x(p, x, y, rh, C_X, max_w=w - x)
        self._x_spans[b] = (x, x + max(self.X_W, xw))           # щелчок — по всей ширине креста
        p.setFont(font)
        return x + xw + 1

    def _draw_x(self, p, x, y, rh, color=C_WHITE, max_w: int | None = None) -> int:
        """«×» снятия заявки — двумя линиями толщиной 2 px со сглаживанием, квадрат высотой строки − 3 (при строке 11 px крест 8×8). До 2.0.98 — символ «×» шрифтом: на экране 4×5 px, трудно попасть.
        max_w — сколько места до края стакана: крест не обрезается краем окна. Возвращает ширину креста с полями."""
        size = max(self.X_MIN, rh - 3)
        if max_w is not None:
            size = max(self.X_MIN, min(size, max_w - 2))
        cx, cy, half = x + 1 + size / 2, y + rh / 2, size / 2 - 1
        p.save()
        p.setRenderHint(QPainter.Antialiasing, True)
        pen = QPen(color, 2.0)
        pen.setCapStyle(Qt.SquareCap)
        p.setPen(pen)
        p.drawLine(QPointF(cx - half, cy - half), QPointF(cx + half, cy + half))
        p.drawLine(QPointF(cx - half, cy + half), QPointF(cx + half, cy - half))
        p.restore()
        return size + 2

    def _agg_clusters(self, start):
        out: dict[int, list] = {}
        g = self.group
        for t, (b, sl) in self.clusters.buckets.get(start, {}).items():
            c = out.setdefault(t // g, [0, 0])
            c[0] += b
            c[1] += sl
        return out

    def _cluster_text(self, buy, sell, tick):
        s = self.s

        def f(v):
            return self._fmt_lots(v, tick, s.volume_unit, s.short_thousands)

        st = s.cluster_text
        if st == "Продажи x покупки":
            return f"{f(sell)}x{f(buy)}"
        if st == "Дельта":
            d = buy - sell
            return ("+" if d > 0 else "") + f(d)
        return f(buy + sell)



# -----------------------------------------------------------------------------
# Тёмная тема в стиле скальперских терминалов: кластеры-свечи | тики-пузырьки | стакан
# -----------------------------------------------------------------------------

# Тёмная по умолчанию — по скриншотам скальперского терминала (23.10.2026): приглушённые бордовые аски
# и тёмно-зелёные биды, насыщенные лучшие цены, коричнево-оранжевые полосы объёма, полупрозрачная
# белая сетка (одинаково видна и на фоне, и на строках стакана), серые рамки 3 px, фиолетовый разделитель.
# Фон (2.0.39) — тёмно-синий, как у графиков и окна «Тики Bid/Ask» (fx_theme.CHART_COLORS["dark"]["bg"]);
# apply_dom_theme дополнительно берёт фон графиков с учётом цвета, изменённого в «Настройках».
CS_DARK = dict(
    bg=_c(19, 23, 34), frame=_c(64, 64, 64), separator=_c(33, 26, 59),
    ask=_c(59, 27, 30), bid=_c(20, 49, 24), best_ask=_c(131, 9, 22), best_bid=_c(12, 109, 16),
    # цены и объёмы — чисто белые, как лучшие цены (best_text): раньше 240 рядом с 255 выглядело тусклее (2.1.62)
    text=_c(255, 255, 255), vol_text=_c(255, 255, 255), gold=_c(133, 89, 9),
    grid=_c(255, 255, 255, 40), grid_major=_c(255, 255, 255, 64),
    buy_fill=_c(49, 114, 45), buy_edge=_c(78, 160, 72), sell_fill=_c(119, 20, 29), sell_edge=_c(176, 44, 56),
    line=_c(95, 95, 95), up=_c(60, 150, 110), down=_c(165, 45, 72),
    delta_pos=_c(70, 135, 115), delta_neg=_c(150, 70, 90),
    btn=_c(48, 48, 48), btn_sel=_c(50, 100, 220), hint=_c(150, 150, 150),
    # подписи-метки, наведение, кластеры, лента сделок
    label_bg=_c(42, 46, 57), hover=_c(200, 200, 200), big_edge=_c(255, 255, 255), best_text=_c(255, 255, 255),
    cl_up_edge=_c(34, 78, 66), cl_dn_edge=_c(120, 44, 66), cl_up_body=_c(78, 150, 124), cl_dn_body=_c(186, 84, 110),
    cl_up_fill=_c(37, 113, 38), cl_dn_fill=_c(119, 20, 29), cl_vol_fill=_c(34, 62, 88), cl_cell=_c(27, 31, 43),
    cl_poc=_c(96, 150, 184), cl_poc_edge=_c(215, 215, 215), cl_text=_c(255, 255, 255), delta_text=_c(255, 255, 255),
    tape_bg=_c(19, 23, 34), tape_head=_c(113, 120, 135), tape_time=_c(142, 148, 162), tape_price=_c(230, 233, 239),
    tape_big=_c(50, 55, 65, 150), tape_buy=_c(53, 200, 120), tape_sell=_c(228, 91, 97), tape_other=_c(194, 198, 207),
    # полосы объёма, позиция и сигнальные уровни — одинаковы в обеих темах, но настраиваются (appearance.py)
    bar_big=C_BAR_BIG, bar_big2=C_BAR_BIG2, bar_ice=C_BAR_ICE, pnl_up=PNL_UP, pnl_dn=PNL_DN, signal=C_SIGNAL,
)

# Светлая тема терминала: белый стакан, розовые/зелёные уровни, тёмный текст. 31.10 цвета сделаны насыщеннее —
# прежние (ask 255,222,224 / bid 218,243,222, полупрозрачные полосы объёма, сетка 228) на белом выглядели блёкло:
# уровни ближе к скальперским терминалам, полосы объёма — непрозрачный оранжевый, текст и сетка контрастнее.
CS_LIGHT = dict(
    bg=_c(255, 255, 255), frame=_c(160, 160, 160), separator=_c(118, 100, 200),
    ask=_c(255, 196, 202), bid=_c(190, 236, 198), best_ask=_c(214, 36, 42), best_bid=_c(22, 150, 52),
    text=_c(15, 15, 15), vol_text=_c(20, 20, 20), gold=_c(255, 160, 0),
    grid=_c(212, 212, 212), grid_major=_c(140, 140, 140),
    buy_fill=_c(118, 204, 148), buy_edge=_c(22, 128, 70), sell_fill=_c(242, 146, 166), sell_edge=_c(186, 40, 74),
    line=_c(150, 150, 150), up=_c(30, 140, 86), down=_c(190, 40, 68),
    delta_pos=_c(30, 140, 86), delta_neg=_c(196, 52, 78),
    btn=_c(222, 222, 222), btn_sel=_c(40, 110, 210), hint=_c(95, 95, 95),
    label_bg=_c(236, 236, 236), hover=_c(70, 70, 70), big_edge=_c(20, 20, 20), best_text=_c(255, 255, 255),
    cl_up_edge=_c(70, 160, 120), cl_dn_edge=_c(200, 100, 124), cl_up_body=_c(30, 140, 86), cl_dn_body=_c(196, 52, 78),
    cl_up_fill=_c(122, 198, 162), cl_dn_fill=_c(236, 146, 166), cl_vol_fill=_c(140, 182, 224), cl_cell=_c(238, 243, 240),
    cl_poc=_c(90, 156, 214), cl_poc_edge=_c(40, 40, 40), cl_text=_c(15, 15, 15), delta_text=_c(255, 255, 255),
    tape_bg=_c(255, 255, 255), tape_head=_c(95, 95, 95), tape_time=_c(95, 95, 95), tape_price=_c(15, 15, 15),
    tape_big=_c(255, 226, 140, 220), tape_buy=_c(10, 140, 60), tape_sell=_c(200, 35, 45), tape_other=_c(75, 75, 75),
    bar_big=C_BAR_BIG, bar_big2=C_BAR_BIG2, bar_ice=C_BAR_ICE, pnl_up=PNL_UP, pnl_dn=PNL_DN, signal=C_SIGNAL,
)

CS = dict(CS_DARK)


def _light_theme() -> bool:
    """Тема терминала (fx_theme), без него — из настроек терминала."""
    try:
        import fx_theme
        return getattr(fx_theme, "_THEME", "dark") == "light"
    except Exception:
        pass
    try:
        from PySide6.QtCore import QSettings
        return str(QSettings("MyTradingTools", "FxTerminal").value("appearance/theme", "dark")).lower() == "light"
    except Exception:
        return False


FONTS = appearance.FontPrefs()     # шрифты стакана (страница «Шрифты»); обновляет apply_dom_theme
THEME_VERSION = 0                  # растёт при каждом apply_dom_theme: кэши картинок стакана перерисовываются


def apply_dom_theme() -> None:
    """Цвета стакана под тему терминала плюс цвета и шрифты, изменённые в «Настройках» (appearance.py).
    Фон стакана и ленты по умолчанию — фон графиков (как в «Тики Bid/Ask»), включая цвет, заданный
    в «Цвета графиков»; свой «Фон» стакана в «Настройках» → «Цвета» по-прежнему важнее.
    Вызывается при создании окна и после OK в настройках (appearance.NOTIFIER.changed)."""
    global FONTS, THEME_VERSION
    THEME_VERSION += 1
    CS.clear()
    CS.update(CS_LIGHT if _light_theme() else CS_DARK)
    try:
        import fx_theme
        chart_bg = QColor(fx_theme.chart_color("bg", "light" if _light_theme() else "dark"))
        if chart_bg.isValid():
            CS["bg"] = chart_bg
            CS["tape_bg"] = chart_bg
    except Exception:
        pass
    try:
        CS.update(appearance.dom_overrides("light" if _light_theme() else "dark"))
        # разово: новые умолчания шрифта (12 px — 2.1.56, жирный — 2.1.62, серое сглаживание — 2.1.63)
        if appearance.upgrade_fonts():
            print("[стакан] шрифт стакана приведён к новым умолчаниям: строка не ниже 12 px, весь текст жирным, "
                  "серое сглаживание («Настройки» → «Шрифты»)", file=sys.stderr)
        FONTS = appearance.load_fonts()
    except Exception as exc:                                   # битые настройки не должны мешать открыть стакан
        print(f"[стакан] цвета/шрифты из настроек не применены: {exc}", file=sys.stderr)


class _LotEdit(QLineEdit):
    cancelled = Signal()

    def event(self, e):
        # Esc / Enter этого поля — его собственные (отмена / назначить), не горячие клавиши окна
        if e.type() == QEvent.ShortcutOverride and e.key() in (Qt.Key_Escape, Qt.Key_Return, Qt.Key_Enter):
            e.accept()
            return True
        return super().event(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.cancelled.emit()
            return
        super().keyPressEvent(e)


class LotEditOverlay(QFrame):
    """Панель внизу стакана: «Введите объем в лотах» — назначить объём кнопке лота."""
    assigned = Signal(int, int)       # индекс кнопки, лотов
    closed = Signal()
    HEIGHT = 112

    def __init__(self, parent, min_lot=1, step=1):
        super().__init__(parent)
        self.min_lot, self.step, self.index = min_lot, step, 0
        self.setObjectName("loteditor")
        self.setStyleSheet(
            "QFrame#loteditor{background:rgba(85,85,85,228);}"
            "QLabel{color:#f0f0f0;font-size:12px;background:transparent;}"
            "QLineEdit{background:#262626;color:#fff;border:1px solid #8a5cf0;padding:2px 6px;font-size:13px;}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 8)
        lay.setSpacing(6)
        self.title = QLabel("Введите объем в лотах")
        self.edit = _LotEdit()
        self.edit.setFixedWidth(110)
        self.edit.setAlignment(Qt.AlignCenter)
        self.edit.setValidator(QIntValidator(0, 100_000_000, self))
        self.hint = QLabel()
        self.keys = QLabel("(Esc - Выйти, Enter - Назначить)")
        for lbl in (self.title, self.hint, self.keys):
            lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.title)
        lay.addWidget(self.edit, 0, Qt.AlignHCenter)
        lay.addWidget(self.hint)
        lay.addStretch(1)
        lay.addWidget(self.keys)
        self.edit.returnPressed.connect(self._commit)
        self.edit.cancelled.connect(self.close_overlay)
        self._reset_hint()
        self.hide()

    def _reset_hint(self):
        self.hint.setText(f"Мин={self.min_lot} Шаг={self.step}")
        self.hint.setStyleSheet("")

    def open_for(self, index):
        self.index = index
        self.edit.clear()
        self._reset_hint()
        self.reposition()
        self.show()
        self.raise_()
        self.edit.setFocus()

    def reposition(self):
        p = self.parentWidget()
        if p is not None:
            self.setGeometry(0, p.height() - self.HEIGHT, p.width(), self.HEIGHT)

    def _commit(self):
        try:
            v = int(self.edit.text().strip())
        except ValueError:
            v = 0
        if v < self.min_lot or (v - self.min_lot) % self.step:
            self.hint.setText(f"Недопустимое значение (мин={self.min_lot}, шаг={self.step})")
            self.hint.setStyleSheet("color:#ff8080;")
            return
        self.assigned.emit(self.index, v)
        self.close_overlay()

    def close_overlay(self):
        self.hide()
        self.closed.emit()


class ScalperLadderWidget(LadderWidget):
    """
    Слева направо: кластерные колонки (свечной бокс + объёмы по цене, внизу объём / дельта / время)
    | тики-пузырьки | мои заявки | объём | цена.
    Поверх тиков: шестерёнка, индикатор сжатия xN, кнопки учёта позиции D / F / L и лотов 1…5.
    Ширина колонки объёма: тянуть мышью левый край стакана (граница тиков и объёма), двойной
    щелчок по нему — обычная ширина; хранится в настройках инструмента (Settings.dom_vol_w).
    """
    CL_W = 34
    CL_MAX = 8
    COL_MIN = 6
    COL_MAX = 140
    MAX_COLS = 60
    TICK_MIN_W = 60                    # минимум ширины панели тиков при перетаскивании границы
    ORD_W = 22                         # колонка заявок справа от цены (у скальперских терминалов ~24 px); длинные метки заходят дальше
    X_W = 10                           # «×» снятия заявки — сразу справа от метки заявки
    VOL_W = 46                         # обычная ширина колонки объёма; у окна — своя (_fit_vol_column)
    VOL_MIN = 24                       # уже — не видно даже «3,3K»
    VOL_MAX = 600
    EDGE_GRAB = (5, 2)                 # зона захвата левого края стакана: px левее / правее границы
    PRICE_W = 54
    SEP_W = 4                          # разделитель у правого края, цвет — CS["separator"]
    # Колонки слева направо: кластеры | тики | объём | цена | заявки (ORD_W) | разделитель.
    # У окна ширина стакана пересчитывается в каждом кадре (_fit_vol_column): объём — по настройке.
    DOM_W = VOL_W + PRICE_W + ORD_W + SEP_W
    HEADER_H = 0
    FOOTER_H = 0
    STATS_H = 42
    TICK_STEP = 12

    clusterLayoutChanged = Signal()    # изменилась ширина панели / колонки кластеров или колонки объёма (сохранить)
    clusterTfChosen = Signal(str)      # ПКМ по кластерам → «Таймфрейм»: ключ CLUSTER_TFS
    lotClicked = Signal(int)
    lotAssigned = Signal(int, int)     # индекс кнопки, новый объём (из панели ввода)
    accountClicked = Signal(str)       # "D" | "F" | "L"
    settingsClicked = Signal()

    def __init__(self, *args, **kwargs):
        self._buttons: dict[str, QRect] = {}
        super().__init__(*args, **kwargs)
        self.row_h = FONTS.dom_row          # «Высота строки в стакане» («Настройки» → «Шрифты»)
        self.base_row_h = FONTS.dom_row
        self.cluster_expanded = False       # двойной клик или ПКМ → «Развернуть»: кластеры на всё место до стакана
        self._partial = False               # текущий кадр — только полоса стакана (update_book)
        self._sections: dict[str, float] = {}   # время частей кадра — в замер (paintEvent)
        self._div_drag = False              # тянем границу панели кластеров
        self._dom_drag = False              # тянем левый край стакана — ширину колонки объёма
        self.lot_editor = LotEditOverlay(self)
        self.lot_editor.assigned.connect(self.lotAssigned)
        self.lot_editor.closed.connect(self.setFocus)
        # Стакан закрашивает себя целиком (первая операция кадра — фон): Qt не нужно рисовать под ним
        # фон родителей (окно стакана, рабочее пространство со своими стилями) на каждом кадре.
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "lot_editor") and self.lot_editor.isVisible():
            self.lot_editor.reposition()

    def set_settings(self, s):
        self.s = s
        steps = compression_steps(s.step_mult)
        if self.group not in steps:
            self.set_group(min(steps, key=lambda v: abs(v - self.group)))
        self.setMinimumWidth(self._min_width())
        self.update()

    def _min_width(self) -> int:
        """Минимальная ширина окна стакана — с колонкой объёма обычной ширины: широкая колонка (dom_vol_w)
        не мешает сузить окно, она сама ужимается под место (_fit_vol_column)."""
        return ((self.CL_W if self.s.cluster_panel else 0) + 170
                + type(self).VOL_W + self.PRICE_W + self.ORD_W + self.SEP_W)

    def _fit_price_column(self, price) -> None:
        """Ширина колонки цен — под самую широкую цену (жирную, как у лучших цен) нынешним шрифтом и видом
        цены (2.0.44: с разделителем и крупным шрифтом «12,2190» и «3 938,2» перестали влезать в прежние 54 px).
        Не уже PRICE_W класса; меняется — меняется и DOM_W (ширина стакана)."""
        key = (id(FONTS), self.row_h, self.decimals, len(str(int(abs(price)))) if price is not None else 0)
        if self.__dict__.get("_price_fit_key") == key:
            return
        self._price_fit_key = key
        sample = dom_price_text(float("8" * key[3] or "8") + (0.8888888 if self.decimals else 0), self.decimals,
                                FONTS.dom_price)
        need = QFontMetrics(self._font(bold=True)).horizontalAdvance(sample) + 8
        width = max(type(self).PRICE_W, need)
        if width != self.PRICE_W:
            self.PRICE_W = width
            self.DOM_W = self.VOL_W + width + self.ORD_W + self.SEP_W
            if getattr(self, "s", None) is not None:
                self.setMinimumWidth(self._min_width())

    def _vol_width_for(self, want: int, w: int) -> int:
        """Ширина колонки объёма при ширине окна w: желаемая (want), но не уже VOL_MIN и не шире места —
        тикам остаётся TICK_MIN_W, кластерам (если включены) — 40 px, как при перетаскивании их границы."""
        fixed = self.PRICE_W + self.ORD_W + self.SEP_W
        room = w - fixed - self.TICK_MIN_W - (40 if self.s.cluster_panel else 0)
        return max(self.VOL_MIN, min(int(want), self.VOL_MAX, room))

    def _fit_vol_column(self, w: int) -> None:
        """Колонка объёма этого окна (VOL_W) и ширина стакана (DOM_W) — по настройке dom_vol_w (0 — обычная
        ширина класса) и месту в окне. Сохранённая ширина не меняется: окно сузили — колонка ужалась,
        расширили — вернулась."""
        vol = self._vol_width_for(self.s.dom_vol_w or type(self).VOL_W, w)
        self.VOL_W = vol
        self.DOM_W = vol + self.PRICE_W + self.ORD_W + self.SEP_W

    def _near_dom_edge(self, pos) -> bool:
        """Курсор у левого края стакана (граница тиков и колонки объёма) — его можно тянуть."""
        lay = self._lay
        if not lay or "dom_x" not in lay:
            return False
        left, right = self.EDGE_GRAB
        return -left <= pos.x() - lay["dom_x"] <= right and self._button_at(pos) is None

    def _drag_dom_edge(self, x: int) -> None:
        """Левый край стакана перетащили в x: колонка объёма — от x до колонки цен (цены и заявки на месте)."""
        lay = self._lay
        if not lay:                                   # стакан пропал («Ожидание стакана…») — тянуть не за что
            return
        price_x = lay["ord_x"] - self.PRICE_W
        vol = self._vol_width_for(price_x - x, self.width())
        if vol != self.s.dom_vol_w:
            self.s.dom_vol_w = vol
            self.clusterLayoutChanged.emit()          # сохранить (окно стакана пишет настройки с задержкой)
            self.update()

    def _cl_geom(self, w):
        """(ширина панели, ширина колонки, число колонок с учётом частично видимой левой)."""
        s = self.s
        if not s.cluster_panel:
            return 0, self.CL_W, 0
        dom = self.DOM_W
        if self.cluster_expanded:
            cl_w = max(40, w - dom)
        else:
            maxw = max(40, w - dom - self.TICK_MIN_W)
            base = s.cluster_panel_w or min(self.CL_MAX * self.CL_W, max(self.CL_W, w - dom - 170))
            cl_w = max(40, min(base, maxw))
        cw = max(self.COL_MIN, min(self.COL_MAX, s.cluster_col_w))
        return cl_w, cw, min(self.MAX_COLS, -(-cl_w // cw))

    def _cs_cols(self, w):
        return self._cl_geom(w)[2]

    TEXT_CACHE_MAX = 4000             # разложенных надписей в кэше стакана (цены, объёмы)

    def _draw_text_cached(self, p, x, y, w, h, align, text, font):
        """Надпись в прямоугольнике, как p.drawText(x, y, w, h, align, text), но с кэшем раскладки текста
        (QStaticText): цены и объёмы строк от кадра к кадру почти не меняются, а раскладка надписи — заметная
        часть кадра стакана (замер 29.10: 4–8 мс на кадр, 10 стаканов — ~550 мс GUI в секунду). Рисуется
        по-прежнему прямо на стакан, сглаживание то же. Шрифт уже выставлен на painter (font — он же).
        Надпись шире прямоугольника рисуется обычным drawText (он обрезает её по ширине).
        Возвращает ширину надписи (для «последних цифр цены жирным» — где кончается обычная часть)."""
        cache = self.__dict__.setdefault("_text_cache", {})
        key = (text, id(font))
        hit = cache.get(key)
        if hit is None:
            if len(cache) >= self.TEXT_CACHE_MAX:
                cache.clear()
            st = QStaticText(text)
            st.setTextFormat(Qt.PlainText)
            st.setPerformanceHint(QStaticText.AggressiveCaching)
            st.prepare(QTransform(), font)
            size = st.size()
            hit = cache[key] = (st, size.width(), size.height())
        st, tw, th = hit
        if tw > w:
            p.drawText(x, y, w, h, align, text)
            return w
        if align & Qt.AlignRight:
            tx = x + w - tw
        elif align & Qt.AlignHCenter:
            tx = x + (w - tw) / 2
        else:
            tx = x
        p.drawStaticText(QPointF(tx, y + (h - th) / 2), st)
        return tw

    def _zone_px(self, zone: str) -> int:
        """Размер шрифта области стакана, px (2.1.70): «tick» — подписи пузырьков тиков, «cluster» — кластеры;
        своя настройка (appearance.FontPrefs.tick_px / cluster_px) или, при 0, — как цифры стакана: заданный
        «Размер шрифта в стакане» или во всю высоту строки (тот же расчёт, что в _font)."""
        prefs = FONTS
        own = {"tick": getattr(prefs, "tick_px", 0), "cluster": getattr(prefs, "cluster_px", 0)}.get(zone, 0)
        return int(own or prefs.dom_size or max(10, self.row_h))

    def _font(self, bold=False, px=None, zone="dom"):
        """Шрифт стакана из «Настроек» → «Шрифты» (FONTS, appearance.FontPrefs).

        px — размер, заданный местом отрисовки (кнопки, метки, пузырьки тиков, ячейки кластеров);
        без него — «Размер шрифта в стакане»: заданный или во всю высоту строки (меняется с масштабом).
        zone — «dom» / «tick» / «cluster»: при начертании «Жирное» в этой области жирный весь текст,
        при «Обычное» жирными остаются только лучшие цены и метки."""
        prefs = FONTS
        if px is None:
            # «Авто» — во всю высоту строки (02.11: на 1 px крупнее прежнего row_h − 1, по просьбе после
            # сравнения со скальперскими терминалами); заданный в «Шрифтах» размер — как есть.
            px = prefs.dom_size or max(10, self.row_h)
        # Шрифты кэшируются: кадр стакана рисует сотни надписей, а создание QFont на каждую стоило
        # заметную часть кадра (замер 23.10: ~16 мс на кадр). Новые FONTS (после «Настроек») — новый кэш.
        key = (bold, px, zone, id(prefs))
        cache = self.__dict__.setdefault("_font_cache", {})
        f = cache.get(key)
        if f is None:
            if len(cache) > 256:
                cache.clear()
            f = QFont(prefs.dom_family)
            f.setPixelSize(px)
            weight = {"tick": prefs.tick_weight, "cluster": prefs.cluster_weight}.get(zone, prefs.dom_weight)
            f.setBold(bold or weight == "Жирное")
            if not prefs.dom_antialias:
                f.setStyleStrategy(QFont.NoAntialias)
            elif getattr(prefs, "dom_gray", False):     # «Серое сглаживание»: без цветной каймы ClearType
                f.setStyleStrategy(QFont.NoSubpixelAntialias)
            cache[key] = f
        return f

    def _draw_label(self, p, right_x, y, rh, text, bg, bold=False):
        p.setFont(self._font(bold=bold, px=max(8, rh - 2)))
        wtxt = p.fontMetrics().horizontalAdvance(text) + 8
        p.fillRect(right_x - wtxt, y + 1, wtxt, rh - 2, CS["label_bg"])
        p.setPen(CS["hint"])
        p.drawRect(right_x - wtxt, y + 1, wtxt - 1, rh - 3)
        p.setPen(CS["text"])
        p.drawText(right_x - wtxt, y + 1, wtxt, rh - 2, Qt.AlignCenter, text)

    # ---- мышь: кнопки поверх тиков ----------------------------------------

    def _near_divider(self, pos):
        lay = self._lay
        return bool(lay and self.s.cluster_panel and not self.cluster_expanded
                    and abs(pos.x() - lay.get("cl_w", -99)) <= 4)

    def wheelEvent(self, event):
        """Колёсико над панелью кластеров — ширина колонок (сжать / расширить)."""
        lay = self._lay
        pos = event.position().toPoint()
        mods = event.modifiers()
        if (lay and self.s.cluster_panel and pos.x() < lay.get("cl_w", 0)
                and not mods & (Qt.ControlModifier | Qt.ShiftModifier)):
            dy = event.angleDelta().y()
            if dy:
                cw = self.s.cluster_col_w
                for _ in range(max(1, abs(dy) // 120)):
                    nxt = round(cw * 1.12) if dy > 0 else round(cw / 1.12)
                    if nxt == cw:
                        nxt += 1 if dy > 0 else -1
                    cw = max(self.COL_MIN, min(self.COL_MAX, nxt))
                if cw != self.s.cluster_col_w:
                    self.s.cluster_col_w = cw
                    self.clusterLayoutChanged.emit()
                    self.update()
            event.accept()
            return
        super().wheelEvent(event)

    def mouseMoveEvent(self, event):
        pos = event.position().toPoint()
        if self._div_drag:
            maxw = max(40, self.width() - self.DOM_W - self.TICK_MIN_W)
            self.s.cluster_panel_w = max(40, min(pos.x(), maxw))
            self.clusterLayoutChanged.emit()
            self.update()
            return
        if self._dom_drag:
            self._drag_dom_edge(pos.x())
            return
        edge = self._near_divider(pos) or self._near_dom_edge(pos)
        self.setCursor(Qt.SizeHorCursor if edge else Qt.ArrowCursor)
        icon = self._icon_at(pos)
        if icon != getattr(self, "_icon_hover", None):         # значок «Алгоритмов» под курсором — цены в стакане
            self._icon_hover = icon
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):
        if getattr(self, "_icon_hover", None) is not None:
            self._icon_hover = None
        super().leaveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._div_drag or self._dom_drag:
            self._div_drag = self._dom_drag = False
            self.clusterLayoutChanged.emit()
            return
        super().mouseReleaseEvent(event)

    def _button_at(self, pos):
        for name, rect in self._buttons.items():
            if rect.contains(pos):
                return name
        return None

    def _in_clusters(self, pos) -> bool:
        lay = self._lay
        if not (lay and self.s.cluster_panel):
            return False
        return pos.x() < (lay.get("dom_x", lay["ord_x"]) if self.cluster_expanded else lay.get("cl_w", 0))

    def _cluster_menu(self, global_pos) -> None:
        """ПКМ внутри кластеров: «Развернуть / Свернуть» и таймфрейм столбца."""
        menu = QMenu(self)
        act_expand = menu.addAction("Свернуть" if self.cluster_expanded else "Развернуть")
        title = menu.addAction("— Таймфрейм")
        title.setEnabled(False)
        tf_actions = {}
        for key in CLUSTER_TFS:
            act = menu.addAction(CLUSTER_TF_TITLES.get(key, key))
            act.setCheckable(True)
            act.setChecked(key == self.s.cluster_tf)
            tf_actions[act] = key
        chosen = menu.exec(global_pos)
        if chosen is act_expand:
            self.cluster_expanded = not self.cluster_expanded
            self.update()
        elif chosen in tf_actions and tf_actions[chosen] != self.s.cluster_tf:
            self.clusterTfChosen.emit(tf_actions[chosen])

    def mousePressEvent(self, event):
        btn = event.button()
        pos = event.position().toPoint()
        if btn == Qt.RightButton and self._button_at(pos) is None and self._in_clusters(pos):
            self.setFocus()
            self._cluster_menu(event.globalPosition().toPoint())
            return
        if btn == Qt.LeftButton and self._near_divider(event.position().toPoint()):
            self.setFocus()
            self._div_drag = True                 # тянем границу панели кластеров
            return
        if btn == Qt.LeftButton and not event.modifiers() and self._near_dom_edge(pos):
            # Левый край стакана — ширина колонки объёма. Только без модификаторов: Alt+ЛКМ —
            # ручная линейка, Ctrl / Shift + ЛКМ — уровень и снятие заявок, как и раньше.
            self.setFocus()
            self._dom_drag = True
            return
        if btn in (Qt.LeftButton, Qt.RightButton):
            name = self._button_at(event.position().toPoint())
            if name is not None:
                self.setFocus()
                left = btn == Qt.LeftButton
                if name == "gear":
                    if left:
                        self.settingsClicked.emit()
                elif name == "acc":
                    if left:        # D -> F -> L -> D
                        cur = self.s.pos_account[:1]
                        self.accountClicked.emit("DFL"[("DFL".index(cur) + 1) % 3 if cur in "DFL" else 0])
                elif name.startswith("lot"):
                    if left:
                        self.lotClicked.emit(int(name[3:]))
                    else:           # ПКМ — назначить объём кнопке
                        self.lot_editor.open_for(int(name[3:]))
                return
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        pos = event.position().toPoint()
        name = self._button_at(pos)
        if name is not None and name.startswith("lot") and event.button() == Qt.LeftButton:
            self.lot_editor.open_for(int(name[3:]))
            return
        if event.button() == Qt.LeftButton and not event.modifiers() and self._near_dom_edge(pos):
            self._dom_drag = False
            if self.s.dom_vol_w:                       # двойной щелчок по краю стакана — обычная ширина объёма
                self.s.dom_vol_w = 0
                self.clusterLayoutChanged.emit()
                self.update()
            return
        if event.button() == Qt.LeftButton and self._in_clusters(pos):
            self.cluster_expanded = not self.cluster_expanded
            self.update()
            return
        super().mouseDoubleClickEvent(event)

    # ---- paint -------------------------------------------------------------

    def update_book(self) -> None:
        """Изменился только стакан (объёмы, лучшие цены): перерисовать одну полосу стакана (объём, цена, заявки),
        без кластеров и тиков-пузырьков — они меняются только от сделок (2.0.46: при волатильности стакан
        обновляется 100–300 раз в секунду, а полный кадр с пузырьками и кластерами — самый дорогой).
        Полный кадр — если полоса ещё не нарисована, а также при заявках, ручной линейке и мыши над
        стаканом: их подписи лежат левее стакана и зависят от лучших цен."""
        lay = self._lay
        tr = self.trader
        if (lay is None or self._ruler or self.hover_tick is not None
                or (tr is not None and tr.gw.orders)):
            self.update()
            return
        x = lay["dom_x"]
        self.update(QRect(x, 0, self.width() - x, self.height()))

    PERF_NAME = "Qt стакан"           # замер кадров в perf_*.csv («h.Qt стакан · …»): в «gui.handlers» не входит

    def paintEvent(self, event):
        t0 = time.perf_counter()
        self._sections = {}
        try:
            self._paint(event)
        except Exception:
            # Ошибка кадра не должна оставлять QPainter открытым: пока исключение с кадром _paint живо (Qt печатал
            # его сам), painter не закрывался — «QBackingStore::endPaint() called with active painter», а при
            # выходе «Cannot destroy paint device that is being painted». Ловим здесь: после except кадр
            # освобождается и painter закрывается. В журнал — не чаще раза в минуту.
            now = time.monotonic()
            if now - self.__dict__.get("_paint_err_t", -1e9) > 60.0:
                self._paint_err_t = now
                traceback.print_exc()
        finally:
            spent = time.perf_counter() - t0
            try:
                from services.perf import PERF
                kind = "полоса стакана" if self._partial else "кадр целиком"
                PERF.add(f"{self.PERF_NAME} · {kind}", spent)
                for name, sec in self._sections.items():
                    PERF.add(f"{self.PERF_NAME} · {name}", sec)
            except Exception:
                pass

    def _paint(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, FONTS.dom_antialias)   # «Сглаживание шрифта в стакане»
        # Сглаживание фигур — только там, где есть круги и наклонные линии (тики-пузырьки, кнопки): строки,
        # бары, сетка и рамки стакана — прямоугольники по целым пикселям, со сглаживанием они рисовались
        # медленным путём (и 1-px линии размывались на два пикселя).
        w, h = self.width(), self.height()
        self._partial = False
        p.fillRect(0, 0, w, h, CS["bg"])
        s = self.s
        book = self.book
        bid_t, ask_t = book.best()
        base = self._base_center(bid_t, ask_t)
        if base is None:
            self._buttons = {}
            p.setPen(CS["hint"])
            p.setFont(self._font())
            p.drawText(self.rect(), Qt.AlignCenter, "Ожидание стакана…")
            self._lay = None
            return
        center = self._resolve_center(base)
        # Образец цены для ширины колонки: лучшая цена, а если одной стороны стакана нет (обе пусты, центр — по
        # последней сделке) — центр окна. 2.0.44–2.0.55: при пустых bid и ask здесь падал кадр (None × шаг).
        ref = bid_t if bid_t is not None else ask_t if ask_t is not None else int(round(base))
        self._fit_price_column(book.price(ref))
        self._fit_vol_column(w)                       # колонка объёма — по настройке и месту (DOM_W)
        prev_lay = self._lay

        g = self.group
        rh = self.row_h
        ord_x = w - self.SEP_W - self.ORD_W          # заявки, позиция, TP/SL — справа от цены
        price_x = ord_x - self.PRICE_W
        vol_x = price_x - self.VOL_W
        dom_x = vol_x                                 # левый край стакана: левее — тики и кластеры
        cl_w, col_w, cols = self._cl_geom(w)
        n = max(1, h // rh)
        y0 = (h - n * rh) // 2
        top_b = int(round(center / g)) + n // 2
        rows = [top_b - i for i in range(n)]
        los = [b * g for b in rows]
        his = [lo + g - 1 for lo in los]
        self._lay = dict(ord_x=ord_x, dom_x=dom_x, y0=y0, rh=rh, n=n, g=g, top_b=top_b, top_tick=top_b * g, cl_w=cl_w,
                         col_w=col_w, w=w, h=h)
        # Полоса стакана (update_book): левее dom_x ничего не меняем — кластеры, тики и кнопки остаются с прошлого
        # кадра. Если с тех пор стакан сдвинулся (автоцентр, масштаб, размер) — нужен полный кадр: просим его
        # следующим, а этот дорисовываем как есть (полоса верная, слева — на кадр старое).
        self._partial = event.rect().left() >= dom_x
        if self._partial and (prev_lay is None or any(prev_lay.get(k) != self._lay[k]
                                                      for k in ("dom_x", "y0", "rh", "n", "g", "top_b", "w", "h"))):
            self.update()
        if not self._partial:
            self._buttons = {}

        def y_of(t):
            return y0 + (top_b - t // g) * rh + rh // 2

        view = BookView(book, bid_t, ask_t)
        vols = [view.row_volume(lo, hi) for lo, hi in zip(los, his)]
        mid_eff, main_eff = self._levels()
        # Айсберги — те, что подтвердил детектор «Алгоритмов» (mm_marks.iceberg_mark): он находит их по возврату
        # съеденного объёма. Своей проверки у стакана больше нет (2.1.31): она требовала исполнить на цене в
        # N раз больше наибольшего объёма, когда-либо там стоявшего, и на плотном стакане не срабатывала.
        flag_rows = self._algo_iceberg_rows(g) if s.detect_iceberg else set()

        # --- стакан: фон строк и бары. Фон — полосами: подряд идущие строки одного цвета (все продажи, все
        # покупки) — одним fillRect, а не по строке (было ~100 вызовов на кадр, стало несколько).
        row_w = self.VOL_W + self.PRICE_W
        run_bg, run_y = None, 0
        bars = []
        for i in range(n):
            lo, hi = los[i], his[i]
            y = y0 + i * rh
            vol, side = vols[i]
            if ask_t is not None and lo <= ask_t <= hi:
                bg = CS["best_ask"]
            elif bid_t is not None and lo <= bid_t <= hi:
                bg = CS["best_bid"]
            elif side == "ask":
                bg = CS["ask"]
            elif side == "bid":
                bg = CS["bid"]
            else:
                bg = None
            if bg is not run_bg:
                if run_bg is not None:
                    p.fillRect(vol_x, run_y, row_w, y - run_y, run_bg)
                run_bg, run_y = bg, y
            if bg is None:
                continue
            best = bg is CS["best_ask"] or bg is CS["best_bid"]
            if vol > 0 and (BAR_ON_BEST or not best):
                bars.append((i, y, vol))
        if run_bg is not None:
            p.fillRect(vol_x, run_y, row_w, y0 + n * rh - run_y, run_bg)
        full = max(1, s.row_fill_lots)
        for i, y, vol in bars:
            bw = max(1, int((self.VOL_W - 1) * min(1.0, vol / full)))
            col = self._bar_color(vol, rows[i] in flag_rows)
            p.fillRect(vol_x + 1, y + 1, bw, rh - 2,
                       _c(col.red(), col.green(), col.blue(), 150) if col is not None else CS["gold"])

        # --- линии уровней (поверх тиков и стакана)
        for i, lo in enumerate(los):
            if lo % mid_eff:
                continue
            yc = y0 + i * rh + rh // 2
            if lo % main_eff == 0:
                p.fillRect(cl_w, yc - 1, w - cl_w, 2, CS["grid_major"])
            else:
                p.fillRect(cl_w, yc, w - cl_w, 1, CS["grid"])
        for t in self.signal_levels:
            if top_b - n < t // g <= top_b:
                p.setPen(QPen(CS["signal"], 1, Qt.DashLine))
                p.drawLine(cl_w, y_of(t), price_x, y_of(t))
        self._paint_option_levels(p, dom_x, w - self.SEP_W, top_b, n, g, y_of)

        # --- линия позиции: зелёная — прибыль, красная — убыток (под тиками, поверх сетки)
        pos_ind = self._pos_indicator()
        pos_bar = None                        # (верх, низ, цвет) черты позиции у левого края стакана
        tints = self._own_tints()
        real_rows = self._real_order_rows()
        self._x_spans = {}                    # заполняется при рисовании меток заявок (в конце paintEvent)
        for i, b in enumerate(rows):                       # подсветка строк моих заявок и TP / SL
            tint = tints.get(b)
            if tint is not None:
                p.fillRect(vol_x, y0 + i * rh, self.VOL_W + self.PRICE_W, rh, tint)
        if pos_ind is not None:
            c = pos_ind[1]
            ycl = y_of(pos_ind[0])
            last_y = y_of(book.key(book.last)) if book.last is not None else ycl
            band_top, band_bot = min(ycl, last_y), max(ycl, last_y)
            if band_bot > band_top and not self.cluster_expanded:
                p.fillRect(cl_w + 1, band_top, dom_x - cl_w - 1, band_bot - band_top, _c(c.red(), c.green(), c.blue(), 38))
            if band_bot > band_top:
                pos_bar = (band_top, band_bot, c)
            p.fillRect(cl_w + 1, ycl - 1, w - cl_w - 1, 2, c)
            p.fillRect(vol_x, ycl - rh // 2, self.VOL_W + self.PRICE_W, rh, _c(c.red(), c.green(), c.blue(), 110))

        # --- кластеры (слева)
        partial = self._partial
        if cols and not partial:
            t_cl = time.perf_counter()
            self._paint_clusters(p, cols, cl_w, col_w, h, rows, y_of, y0, rh, top_b, los)
            self._sections["кластеры"] = time.perf_counter() - t_cl

        # --- тики-пузырьки (при развёрнутых кластерах панель тиков закрыта)
        t_ticks = time.perf_counter()
        p.save()
        p.setRenderHint(QPainter.Antialiasing)          # круги и линии между ними — со сглаживанием
        p.setClipRect(cl_w + 1, 0, max(0, dom_x - cl_w - 1), h)
        store = self.tickstore
        mm_layout = None                      # отметки ММ этого кадра (_market_marks_layout)
        if not partial:
            # Пузырьки — готовыми картинками (_tick_sprite): круг со сглаживанием и цифра внутри рисовались
            # заново на каждом кадре; при волатильности (02.11 VKCO) полный кадр идёт на каждую сделку.
            # Сначала — где они будут (_bubble_rects): подписи отметок ММ обходят пузырьки и рисуются ПОД ними
            # (2.1.8), потом линии и сами пузырьки.
            self._bubble_rects = []
            pts, sprites = [], []
            if store is not None and not self.cluster_expanded:
                items = [it for it in store.items
                         if not (it["size"] < s.tick_min_lots and s.tick_hide_filtered)]
                step = self.TICK_STEP
                right = dom_x - 16
                items = items[-max(1, (dom_x - cl_w - 20) // step):]
                pts = [(right - (len(items) - 1 - k) * step, y_of(it["tick"]), it) for k, it in enumerate(items)]
                if s.tick_style in ("Точки и линии", "Точки"):
                    for x, y, it in pts:
                        pm, cx, cy = self._tick_sprite(it["size"], side_label(it["side"]) == "BUY")
                        sprites.append((int(x - cx), int(y - cy), pm))
                        self._bubble_rects.append(QRect(int(x - cx), int(y - cy), int(2 * cx), int(2 * cy)))
            mm_layout = self._market_marks_layout(vol_x, ord_x, top_b, n, g, y0, rh)
            p.save()
            p.setRenderHint(QPainter.Antialiasing, False)     # подписи и направляющие — по целым пикселям
            self._paint_market_labels(p, mm_layout, vol_x, rh)
            p.restore()
            if s.tick_style in ("Точки и линии", "Линии") and len(pts) > 1:
                p.setPen(QPen(CS["line"], max(1, s.tick_line_width)))
                for a, b in zip(pts, pts[1:]):
                    p.drawLine(int(a[0]), int(a[1]), int(b[0]), int(b[1]))
            for x, y, pm in sprites:
                p.drawPixmap(x, y, pm)
        p.restore()
        if not partial:
            self._sections["тики"] = time.perf_counter() - t_ticks

        # --- мои заявки / объём / цена
        t_dom = time.perf_counter()
        own = self._own_by_row()
        mark_rows: list = []                          # (строка, y, метки) — см. «метки заявок» в конце
        last_b = book.key(book.last) // g if book.last is not None else None
        best_rows = [i for i in range(n) if (ask_t is not None and los[i] <= ask_t <= his[i])
                     or (bid_t is not None and los[i] <= bid_t <= his[i])]
        # Колонка цен (кроме лучших) — готовой картинкой (_price_column): цены строк меняются только при сдвиге,
        # масштабе, шрифте или лучших ценах, а надписи цен были почти половиной кадра (замер 02.11: «цены
        # и объёмы» ~116 мс/с на 11 стаканах). Лучшие цены (жирные, своим цветом) — поверх, как раньше.
        p.drawPixmap(price_x, y0, self._price_column(rows, los, n, rh, frozenset(best_rows)))
        vol_font = self._font()
        p.setFont(vol_font)
        vol_pen = None
        for i in range(n):
            vol, side = vols[i]
            if vol <= 0:
                continue
            lo, hi = los[i], his[i]
            pen = CS["best_text"] if i in best_rows else CS["vol_text"]
            if pen is not vol_pen:
                p.setPen(pen)
                vol_pen = pen
            self._draw_text_cached(p, vol_x + 3, y0 + i * rh, self.VOL_W - 3, rh, Qt.AlignLeft | Qt.AlignVCenter,
                                   self._vol_text(view, lo, hi, vol), vol_font)
        if best_rows:
            best_font = self._font(bold=True)
            p.setFont(best_font)
            p.setPen(CS["best_text"])
            for i in best_rows:
                self._draw_text_cached(p, price_x, y0 + i * rh, self.PRICE_W - 6, rh, Qt.AlignRight | Qt.AlignVCenter,
                                       dom_price_text(book.price(los[i]), self.decimals, FONTS.dom_price), best_font)
        if last_b is not None and top_b - n < last_b <= top_b:
            p.setPen(QPen(CS["hint"], 1))
            p.setBrush(Qt.NoBrush)
            p.drawRect(price_x, y0 + (top_b - last_b) * rh, self.PRICE_W - 1, rh - 1)
        if mm_layout is None:                 # кадр полосы стакана: подписи слева не перерисовываются
            mm_layout = self._market_marks_layout(vol_x, ord_x, top_b, n, g, y0, rh)
        self._paint_market_frames(p, mm_layout, vol_x, ord_x, rh)
        for i, b in enumerate(rows):
            marks = own.get(b)
            if marks:
                mark_rows.append((b, y0 + i * rh, marks))   # рисуются последними — поверх разделителя
        self._sections["цены и объёмы"] = time.perf_counter() - t_dom

        # --- линейки заявок
        tr = self.trader
        right_x = dom_x - 4                # подписи линеек — у левого края стакана, поверх тиков
        if tr is not None and tr.gw.orders:
            q = tr.gw.pos_qty
            agg_o: dict[int, int] = {}
            for o in tr.gw.orders:
                agg_o[o.tick // g] = agg_o.get(o.tick // g, 0) + o.qty
            for b, qty in agg_o.items():
                if b not in rows:
                    continue
                price = book.price(b * g)
                if q:
                    refp = tr.ref_price()
                    txt = self._ruler_text(s.ruler_in_pos, refp, price if q > 0 else 2 * refp - price, qty)
                else:
                    txt = self._ruler_text(s.ruler_out_pos, self._nearest_best_price(b * g), price, qty)
                if txt:
                    self._draw_label(p, right_x, y0 + (top_b - b) * rh, rh, txt, None)

        # --- ручная линейка
        if self._ruler:
            a, b = self._ruler
            lo_t, hi_t = min(a, b), max(a, b)
            ytop = y0 + (top_b - hi_t // g) * rh
            ybot = y0 + (top_b - lo_t // g) * rh + rh
            p.fillRect(dom_x, ytop, w - self.SEP_W - dom_x, ybot - ytop, _c(255, 220, 60, 55))
            if s.manual_ruler == "Сумма объемов":
                total = view.ask_range(lo_t, hi_t + g - 1) + view.bid_range(lo_t, hi_t + g - 1)
                txt = "Σ " + fmt_amount(total, s.short_thousands, s.max_decimals)
            else:
                txt = self._ruler_text(s.manual_ruler, book.price(a), book.price(b))
            self._draw_label(p, right_x, y0 + (top_b - b // g) * rh, rh, txt, None, bold=True)

        # --- hover
        if self.hover_tick is not None:
            i = top_b - self.hover_tick // g
            if 0 <= i < n:
                p.setPen(QPen(CS["hover"], 1))
                p.setBrush(Qt.NoBrush)
                p.drawRect(dom_x, y0 + i * rh, w - self.SEP_W - dom_x - 1, rh - 1)
                if not self._ruler_drag:
                    txt = self._hover_ruler_text(view, self.hover_tick)
                    if txt:
                        self._draw_label(p, right_x, y0 + i * rh, rh, txt, None)

        # --- цены события под курсором на значке «Алгоритмов» (как рамка на свечах у графика): рамка — только
        # по колонкам объёма и цены (2.1.37; в 2.1.36 шла через тики и весь стакан — слишком длинная)
        zone_x0, zone_x1 = min(vol_x, price_x), max(vol_x + self.VOL_W, price_x + self.PRICE_W)
        self._paint_icon_zone(p, zone_x0, zone_x1, dom_x, top_b, n, g, y0, rh)

        # --- кнопки и индикатор сжатия поверх тиков (в полосе стакана их нет — остаются с прошлого кадра)
        if not self.cluster_expanded and not partial:
            self._paint_buttons(p, cl_w, dom_x, h)

        # --- рамки колонок
        p.setBrush(Qt.NoBrush)
        p.setPen(CS["frame"])
        for x in {cl_w, ord_x, vol_x, price_x}:
            p.drawLine(x, 0, x, h)
        p.drawRect(0, 0, w - 1, h - 1)
        # --- разделитель справа: отделяет стакан от соседнего окна (поверх строк, сетки и рамки)
        p.fillRect(w - self.SEP_W, 0, self.SEP_W, h, CS["separator"])
        # --- позиция: вертикальная черта по левому краю стакана от цены позиции до
        # последней цены — цвета прибыли / убытка, поверх рамки колонки; ширина 2 px, как у линии позиции
        if pos_bar is not None:
            top, bottom, color = pos_bar
            p.fillRect(dom_x - 1, top, 2, bottom - top + 1, color)

        # --- метки заявок, TP/SL и позиции: от колонки заявок вправо, ширина по тексту
        # (длинное «2 000» заходит на разделитель). Красный «×» — сразу за снимаемыми метками (заявки, TP, SL),
        # метка позиции — после него (_own_by_row ставит её последней): «×» не уходит за край окна.
        if mark_rows:
            mark_font = self._font(bold=True, px=max(8, rh - 3))
            p.setFont(mark_font)
            fm = p.fontMetrics()
            x_room = self.X_MIN + 2                 # «×» не правее края окна, даже если метки длинные
            for b, y, marks in mark_rows:
                rx = ord_x + 1
                crossed = b not in real_rows
                for text, bg, fg, cancellable in marks:
                    if not crossed and not cancellable:
                        rx = self._mark_x(p, b, rx, y, rh, w, x_room, mark_font)
                        crossed = True
                    tw = max(14, fm.horizontalAdvance(text) + 6)
                    p.fillRect(rx, y + 1, tw, rh - 2, bg)
                    p.setPen(fg)
                    p.drawText(rx, y + 1, tw, rh - 2, Qt.AlignCenter, text)
                    rx += tw + 1
                if not crossed:
                    self._mark_x(p, b, rx, y, rh, w, x_room, mark_font)
        if self.sltp_mode:
            self._paint_sltp_hint(p, dom_x, w, h)

    TICK_SPRITES_MAX = 600            # разных пузырьков в кэше (объём × сторона); больше — кэш начинается заново

    def _tick_sprite(self, size, buy):
        """Пузырёк тика картинкой: (QPixmap, x центра, y центра) в логических пикселях. Рисуется как раньше —
        круг по объёму (мелкие — 4 px полупрозрачные, без цифры), рамка крупной сделки, объём внутри — один раз
        на объём, сторону, настройки «Тики», тему и шрифты; дальше кадр стакана только ставит картинку."""
        s = self.s
        small = size < s.tick_min_lots
        big = size >= s.tick_big
        dpr = self.devicePixelRatioF()
        text_px = self._zone_px("tick")            # «Размер шрифта в тиках» (по умолчанию — как в стакане), 2.1.70
        key = (0 if small else size, buy, small, big, THEME_VERSION, id(FONTS), dpr, text_px)
        cache = self.__dict__.setdefault("_tick_sprites", {})
        hit = cache.get(key)
        if hit is not None:
            return hit
        if len(cache) >= self.TICK_SPRITES_MAX:
            cache.clear()
        # Круг по объёму; при шрифте крупнее 12 px пузырьки пропорционально больше — подпись в них помещается,
        # а соотношение размеров по объёму остаётся (при 12 px — как до 2.1.70).
        scale = max(0.75, text_px / 12.0)
        r = (4.0 if small else min(18.0, 6.0 + 1.9 * math.log(1 + size))) * scale
        w = int(2 * r + 12)
        h = int(2 * r + 6)
        pm = QPixmap(max(1, int(w * dpr)), max(1, int(h * dpr)))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.transparent)
        cx, cy = w / 2.0, h / 2.0
        q = QPainter(pm)
        try:
            q.setRenderHint(QPainter.Antialiasing)
            q.setRenderHint(QPainter.TextAntialiasing, FONTS.dom_antialias)
            fill, edge = (CS["buy_fill"], CS["buy_edge"]) if buy else (CS["sell_fill"], CS["sell_edge"])
            if small:
                fill = _c(fill.red(), fill.green(), fill.blue(), 120)
            q.setBrush(fill)
            q.setPen(QPen(CS["big_edge"] if big else edge, 2 if big else 1))
            q.drawEllipse(QPointF(cx, cy), r, r)
            if not small:
                q.setPen(CS["text"])
                font = self._font(bold=True, px=max(8, min(text_px, int(r * 0.85))), zone="tick")
                q.setFont(font)
                self._draw_text_cached(q, int(cx - r - 4), int(cy - r), int(2 * r + 8), int(2 * r),
                                       Qt.AlignCenter, fmt_amount(size, True, 1), font)
        finally:
            q.end()
        hit = cache[key] = (pm, cx, cy)
        return hit

    def _price_column(self, rows, los, n, rh, best_rows) -> QPixmap:
        """Картинка колонки цен (прозрачный фон, текст цветом CS["text"]) для видимых строк, кроме лучших цен
        (best_rows — их номера: они рисуются поверх жирными). Пересоздаётся, только когда меняется то, что
        на ней видно: сдвиг / масштаб / высота строки, ширина колонки, шрифт и вид цены («Шрифты»), тема,
        лучшие цены. Остальные кадры — один drawPixmap вместо ~100 надписей."""
        dpr = self.devicePixelRatioF()
        key = (rows[0] if rows else None, n, self.group, rh, self.PRICE_W, id(FONTS), THEME_VERSION, self.decimals,
               FONTS.dom_price, FONTS.dom_price_bold, FONTS.dom_weight, FONTS.dom_antialias, dpr, best_rows)
        cached = self.__dict__.get("_price_pm")
        if cached is not None and cached[0] == key:
            return cached[1]
        pm = QPixmap(max(1, int(self.PRICE_W * dpr)), max(1, int(n * rh * dpr)))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.transparent)
        q = QPainter(pm)
        try:
            q.setRenderHint(QPainter.TextAntialiasing, FONTS.dom_antialias)
            q.setPen(CS["text"])
            font = self._font()
            bold_font = self._font(bold=True)
            price_mode, price_bold = FONTS.dom_price, FONTS.dom_price_bold
            split = price_bold and FONTS.dom_weight != "Жирное"
            w = self.PRICE_W - 6
            for i in range(n):
                if i in best_rows:
                    continue
                y = i * rh
                text = dom_price_text(self.book.price(los[i]), self.decimals, price_mode)
                head, tail = split_price_tail(text, price_bold) if split else (text, "")
                if tail:                              # «Последние цифры цены жирным»: хвост жирным, начало — обычным
                    q.setFont(bold_font)
                    tail_w = self._draw_text_cached(q, 0, y, w, rh, Qt.AlignRight | Qt.AlignVCenter, tail, bold_font)
                    q.setFont(font)
                    if head:
                        self._draw_text_cached(q, 0, y, int(w - tail_w), rh, Qt.AlignRight | Qt.AlignVCenter,
                                               head, font)
                else:
                    q.setFont(font)
                    self._draw_text_cached(q, 0, y, w, rh, Qt.AlignRight | Qt.AlignVCenter, text, font)
        finally:
            q.end()
        self._price_pm = (key, pm)
        return pm

    def _paint_sltp_hint(self, p, x0, w, h):
        """Надпись режима «Stop-Loss / Take-Profit» внизу стакана, пока зажата клавиша."""
        p.save()
        p.setFont(self._font(bold=True, px=13))
        text = "Stop-Loss / Take-Profit"
        tw = p.fontMetrics().horizontalAdvance(text) + 20
        th = 24
        x = max(x0, x0 + (w - self.SEP_W - x0 - tw) // 2)
        y = h - th - 52                                   # над кнопками объёмов
        p.fillRect(x, y, tw, th, QColor(20, 20, 20, 220))
        p.setPen(QColor(255, 210, 60))
        p.drawRect(x, y, tw - 1, th - 1)
        p.drawText(x, y, tw, th, Qt.AlignCenter, text)
        p.restore()

    def _paint_buttons(self, p, cl_w, dom_x, h):
        """Шестерёнка (у левого края стакана), индикатор сжатия и кнопки объёмов — поверх тиков."""
        p.save()
        p.setRenderHint(QPainter.Antialiasing)          # скруглённые кнопки — со сглаживанием
        try:
            self._paint_buttons_aa(p, cl_w, dom_x, h)
        finally:
            p.restore()

    def _paint_buttons_aa(self, p, cl_w, dom_x, h):
        gear = QRect(dom_x - 32, 8, 24, 24)
        self._buttons["gear"] = gear
        p.setPen(Qt.NoPen)
        p.setBrush(CS["btn"])
        p.drawRoundedRect(gear, 3, 3)
        p.setPen(CS["text"])
        p.setFont(self._font(px=15))
        p.drawText(gear, Qt.AlignCenter, "⚙")
        self._paint_algo_icons(p, gear)

        # индикатор сжатия
        p.setFont(self._font(bold=True, px=12))
        p.setPen(CS["text"])
        p.drawText(cl_w + 8, 8, 60, 16, Qt.AlignLeft | Qt.AlignVCenter, f"x{self.group}")

        tr = self.trader
        lots = tr.lots if tr else []
        base_y = h - 28
        for i, lot in enumerate(lots):
            r = QRect(cl_w + 8, base_y - (len(lots) - i) * 24, 20, 20)
            self._buttons[f"lot{i}"] = r
            sel = tr is not None and tr.lot == lot
            p.setBrush(CS["btn"])
            p.setPen(QPen(CS["btn_sel"], 2) if sel else Qt.NoPen)
            p.drawRoundedRect(r, 3, 3)
            p.setPen(CS["text"])
            p.setFont(self._font(px=11))
            p.drawText(r, Qt.AlignCenter, fmt_amount(lot, True, 0))

        # одна кнопка учёта позиции: показывает текущий режим D / F / L, клик — следующий
        cur = self.s.pos_account[:1]
        r = QRect(cl_w + 8, base_y - len(lots) * 24 - 30, 20, 20)
        self._buttons["acc"] = r
        p.setBrush(CS["btn"])
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(r, 3, 3)
        p.setPen(CS["text"])
        p.setFont(self._font(bold=True, px=11))
        p.drawText(r, Qt.AlignCenter, cur)

    # ---- значки «Алгоритмов» под кнопкой настроек (algo_icons, 2.1.35) ----------------------------------
    ICON_R = 9                   # радиус значка — как на графике (chart_items.RobotIconItem.RADIUS)
    ICON_STEP = 2 * ICON_R + 6   # шаг столбика

    def icon_capacity(self) -> int:
        """Сколько значков помещается между кнопкой настроек и кнопками объёмов (их рисует _paint_buttons_aa)."""
        lots = len(self.trader.lots) if self.trader is not None else 0
        top = 8 + 24 + 6
        bottom = self.height() - 28 - lots * 24 - 30 - 8
        return max(0, (bottom - top) // self.ICON_STEP)

    def set_algo_icons(self, icons: list) -> None:
        """Значки [(ключ, запись algo_icons)] сверху вниз; перерисовка — только если что-то видимое изменилось."""
        sig = [(k, e["glyph"], e["active"], e.get("count", 1), e["color"], e["tip"]) for k, e in icons]
        if sig == getattr(self, "_algo_icons_sig", None):
            return
        self._algo_icons_sig = sig
        self._algo_icons = list(icons)
        self.update()

    def _paint_algo_icons(self, p, gear):
        """Столбик значков под кнопкой настроек — как на графике: кольцо цвета стороны (идёт — яркое,
        закончилось — бледное), знак в середине, число в уголке. Подсказки — _icon_hits (event)."""
        self._icon_hits = []
        icons = getattr(self, "_algo_icons", None)
        if not icons:
            return
        r = self.ICON_R
        cx = gear.center().x()
        y = gear.bottom() + 6 + r + 1
        font = QFont()
        font.setPixelSize(11)
        small = QFont()
        small.setPixelSize(8)
        small.setBold(True)
        for _key, e in icons[:self.icon_capacity()]:
            color = QColor(e["color"])
            if not e["active"]:
                color.setAlpha(110)
            p.setBrush(QColor("#202632") if e["active"] else QColor(32, 38, 50, 170))
            p.setPen(QPen(color, 1.8 if e["active"] else 1.2))
            p.drawEllipse(QPointF(cx, y), r, r)
            p.setFont(font)
            p.setPen(QColor("#d7dae0"))
            p.setOpacity(1.0 if e["active"] else 0.55)
            p.drawText(QRectF(cx - r, y - r, 2 * r, 2 * r), Qt.AlignCenter, e["glyph"])
            p.setOpacity(1.0)
            count = int(e.get("count", 1) or 1)
            if count > 1:
                badge = QRectF(cx + r * 0.35, y - r - 3, 11, 11)
                p.setPen(Qt.NoPen)
                p.setBrush(color)
                p.drawEllipse(badge)
                p.setFont(small)
                p.setPen(QColor("#111111"))
                p.drawText(badge, Qt.AlignCenter, str(count) if count < 10 else "9+")
            self._icon_hits.append((QRect(cx - r - 2, y - r - 4, 2 * r + 6, 2 * r + 6), e["tip"]))
            if len(self._icon_hits) - 1 == getattr(self, "_icon_hover", None):    # под курсором — кольцо толще
                p.setBrush(Qt.NoBrush)
                p.setPen(QPen(QColor(e["color"]), 2.4))
                p.drawEllipse(QPointF(cx, y), r + 1, r + 1)
            y += self.ICON_STEP

    def _icon_at(self, pos):
        """Номер значка «Алгоритмов» под курсором или None."""
        for i, (rect, _tip) in enumerate(getattr(self, "_icon_hits", ())):
            if rect.contains(pos):
                return i
        return None

    def _paint_icon_zone(self, p, x0, x1, dom_x, top_b, n, g, y0, rh):
        """Курсор на значке «Алгоритмов» — его цены подсвечиваются рамкой цвета значка от x0 до x1 (колонки
        объёма и цены; на графике в это время рамкой выделяются свечи события). Цены за пределами видимого
        стакана — стрелка у верхнего или нижнего края с ценой."""
        idx = getattr(self, "_icon_hover", None)
        icons = getattr(self, "_algo_icons", None) or []
        if idx is None or idx >= len(icons):
            return
        e = icons[idx][1]
        prices = e.get("prices")
        if not prices:
            return
        try:
            b_lo, b_hi = self.book.key(prices[0]) // g, self.book.key(prices[1]) // g
        except Exception:
            return
        color = QColor(e["color"])
        top, bottom = y0, y0 + n * rh
        y_hi = y0 + (top_b - b_hi) * rh                       # верх строки самой высокой цены
        y_lo = y0 + (top_b - b_lo + 1) * rh                   # низ строки самой низкой цены
        p.save()
        if y_lo <= top or y_hi >= bottom:                     # всё за пределами — подсказка, куда смотреть
            above = y_lo <= top
            text = (f"{'↑' if above else '↓'} {fmt_price(prices[0], self.decimals)}"
                    + (f" — {fmt_price(prices[1], self.decimals)}" if prices[1] != prices[0] else ""))
            p.setFont(self._font(px=max(8, rh - 2)))
            tw = p.fontMetrics().horizontalAdvance(text) + 10
            rect = QRect(dom_x - tw - 4, top + 2 if above else bottom - rh - 2, tw, rh)
            p.fillRect(rect, CS["label_bg"])
            p.setPen(color)
            p.drawRect(rect.adjusted(0, 0, -1, -1))
            p.drawText(rect, Qt.AlignCenter, text)
            p.restore()
            return
        y_hi, y_lo = max(top, y_hi), min(bottom, y_lo)
        fill = QColor(color)
        fill.setAlpha(45)
        p.fillRect(x0, y_hi, x1 - x0, y_lo - y_hi, fill)
        p.setPen(QPen(color, 1, Qt.DashLine))
        p.setBrush(Qt.NoBrush)
        p.drawRect(x0, y_hi, x1 - x0 - 1, y_lo - y_hi - 1)
        p.restore()

    def _paint_option_levels(self, p, x0, x1, top_b, n, g, y_of):
        """Опционные уровни инструмента (option_levels.py: Max Pain, Call / Put wall, ожидаемое движение) —
        пунктиром через стакан, подпись слева от стакана. Считает вкладка «Опционы», пока она открыта."""
        self._level_hits = []                     # (область подписи и линии, подсказка) — для event(ToolTip)
        symbol = getattr(self, "symbol", "")
        if not symbol:
            return
        try:
            import option_levels as ol
            levels = ol.registry().for_symbol(symbol)
        except Exception:
            return
        if levels is None:
            return
        p.save()
        p.setFont(self._font(px=max(8, self.row_h - 2)))
        fm = p.fontMetrics()
        for keys, price, text in levels.grouped():     # уровни на одной цене — одна подпись
            key = keys[0]
            t = self.book.key(price)
            if not (top_b - n < t // g <= top_b):
                continue
            y = y_of(t)
            color = QColor(ol.color_of(key))
            p.setPen(QPen(color, 1, Qt.DotLine if key.startswith("em_") else Qt.DashLine))
            p.drawLine(x0, y, x1, y)
            tw = fm.horizontalAdvance(text) + 6
            p.fillRect(x0 - tw - 2, y - self.row_h // 2, tw, self.row_h, CS["label_bg"])
            p.setPen(color)
            p.drawText(x0 - tw - 2, y - self.row_h // 2, tw, self.row_h, Qt.AlignCenter, text)
            # подсказка — над подписью и над всей линией (±3 px), как у графика
            self._level_hits.append((QRect(x0 - tw - 2, y - max(3, self.row_h // 2), x1 - x0 + tw + 2,
                                           2 * max(3, self.row_h // 2)),
                                     "\n\n".join(ol.explain(k, levels) for k in keys)))
        p.restore()

    # Отметки детектора маркет-мейкера и «Наращивания» (mm_marks.py, 2.1.2): рамка вокруг объёма и цены строки —
    # защита уровня толще (2 px), приманка пунктиром, наращивание штрих-пунктиром, поглощение тонкой линией;
    # цвет — сторона (зелёный — покупатель / покупки, красный — продавец / продажи). Подпись — слева от стакана,
    # не ближе MM_LABEL_LIFT_ROWS строк к отметке, с направляющей к рамке (2.1.6: на строке отметки подпись
    # закрывала свежие пузырьки сделок — они как раз у текущей цены, где обычно и защита, и поглощение).
    # Выше или ниже — где ближе свободное место без пузырьков (2.1.7), не дальше MM_LABEL_SEARCH_ROWS строк.
    MM_MARK_STYLES = {"defense": (2, Qt.SolidLine), "absorb": (1, Qt.SolidLine), "bait": (1, Qt.DashLine),
                      "escalation": (1, Qt.DashDotLine)}
    MM_LABEL_LIFT_ROWS = 3
    MM_LABEL_SEARCH_ROWS = 15
    MM_GUIDE_GAP_PX = 3          # вертикаль направляющей — на столько левее края стакана (правее пузырьков)

    def _algo_iceberg_rows(self, g) -> set:
        """Строки стакана с айсбергами из «Алгоритмов» (инструмент должен быть добавлен туда)."""
        symbol = getattr(self, "symbol", "")
        if not symbol:
            return set()
        try:
            import mm_marks
            prices = mm_marks.iceberg_prices(mm_marks.board().marks_for(symbol, time.time()))
            return {self.book.key(price) // g for price in prices}
        except Exception:
            return set()

    def _market_marks_layout(self, x0, x1, top_b, n, g, y0, rh) -> list:
        """Отметки ММ / «Наращивания» у видимых цен инструмента этого стакана (их ведёт вкладка «Алгоритмы» —
        у инструментов, добавленных туда): [(строка y, цвет, толщина, линия, подпись QRect, текст)].
        Подпись — на ближайшем месте выше или ниже отметки (от MM_LABEL_LIFT_ROWS строк), где нет пузырьков
        сделок (_bubble_rects последнего полного кадра) и других подписей; при равном расстоянии — выше.
        Свободного места нет — где нет других подписей. Заодно — области подсказок (_mm_hits: рамка и подпись)."""
        self._mm_hits = []
        symbol = getattr(self, "symbol", "")
        if not symbol:
            return []
        try:
            import mm_marks
            marks = mm_marks.board().marks_for(symbol, time.time())
        except Exception:
            return []
        if not marks:
            return []
        fm = QFontMetrics(self._font(px=max(8, rh - 2)))
        guide_x = x0 - self.MM_GUIDE_GAP_PX
        bottom = y0 + n * rh
        placed: list = []                                 # прямоугольники уже поставленных подписей
        bubbles = list(getattr(self, "_bubble_rects", ()) or ())
        layout = []
        for mark in sorted(marks, key=lambda m: -float(m.get("price") or 0)):
            if mark.get("kind") == "iceberg":             # айсберг — голубая полоса объёма, без рамки и подписи
                continue
            try:
                t = self.book.key(float(mark["price"]))
            except Exception:
                continue
            b = t // g
            if not (top_b - n < b <= top_b):
                continue
            y = y0 + (top_b - b) * rh
            color = CS["tape_buy"] if mark.get("side") == "B" else CS["tape_sell"]
            width, style = self.MM_MARK_STYLES.get(mark.get("kind"), (1, Qt.SolidLine))
            text = str(mark.get("label", ""))
            tw = fm.horizontalAdvance(text) + 6
            lx = guide_x - 3 - tw
            label = fallback = None
            for dist in range(self.MM_LABEL_LIFT_ROWS, self.MM_LABEL_SEARCH_ROWS + 1):
                for sign in (-1, 1):                      # при равном расстоянии — сначала выше
                    ly = y + sign * dist * rh
                    if ly < y0 or ly + rh > bottom:
                        continue
                    rect = QRect(lx, ly, tw, rh)
                    if any(rect.intersects(other) for other in placed):
                        continue
                    if fallback is None:
                        fallback = rect                   # без других подписей, но, может, на пузырьках
                    if not any(rect.intersects(bub) for bub in bubbles):
                        label = rect
                        break
                if label is not None:
                    break
            label = label or fallback or QRect(lx, y, tw, rh)   # места нет совсем — на строке отметки
            placed.append(label)
            layout.append((y, color, width, style, label, text))
            tip = str(mark.get("tip", ""))
            self._mm_hits.append((QRect(x0, y, x1 - x0, rh), tip))
            self._mm_hits.append((label, tip))
        return layout

    def _paint_market_labels(self, p, layout, x0, rh) -> None:
        """Подписи отметок и направляющие (слева от стакана; в кадре — до пузырьков сделок, чтобы те были
        поверх): от подписи вправо, по вертикали у края стакана, к строке отметки."""
        if not layout:
            return
        p.save()
        p.setFont(self._font(px=max(8, rh - 2)))
        guide_x = x0 - self.MM_GUIDE_GAP_PX
        for y, color, _width, _style, label, text in layout:
            lyc, yc = label.top() + rh // 2, y + rh // 2
            p.setPen(QPen(color, 1))
            p.drawLine(label.left() + label.width(), lyc, guide_x, lyc)   # от подписи вправо
            p.drawLine(guide_x, lyc, guide_x, yc)                         # по вертикали к строке отметки
            p.drawLine(guide_x, yc, x0, yc)                               # в рамку
            p.fillRect(label, CS["label_bg"])
            p.setPen(color)
            p.drawText(label, Qt.AlignCenter, text)
        p.restore()

    def _paint_market_frames(self, p, layout, x0, x1, rh) -> None:
        """Рамки отметок вокруг объёма и цены строки (поверх стакана, после колонки цен)."""
        if not layout:
            return
        p.save()
        p.setBrush(Qt.NoBrush)
        for y, color, width, style, _label, _text in layout:
            p.setPen(QPen(color, width, style))
            inset = width // 2
            p.drawRect(x0 + inset, y + inset, x1 - x0 - 1 - 2 * inset, rh - 1 - 2 * inset)
        p.restore()

    def _paint_market_marks(self, p, x0, x1, top_b, n, g, y0, rh) -> None:
        """Отметки целиком — раскладка, подписи, рамки (в стакане эти части рисуются в разных местах кадра)."""
        layout = self._market_marks_layout(x0, x1, top_b, n, g, y0, rh)
        self._paint_market_labels(p, layout, x0, rh)
        self._paint_market_frames(p, layout, x0, x1, rh)

    def event(self, e):
        """Подсказка у опционного уровня (Max Pain, Call / Put wall, ожидаемое движение): что это и как читать;
        у отметки маркет-мейкера / «Наращивания» — что за событие (2.1.2)."""
        if e.type() == QEvent.ToolTip:
            pos = e.pos()
            for rect, tip in getattr(self, "_icon_hits", []):     # значки «Алгоритмов» под кнопкой настроек
                if rect.contains(pos) and tip:
                    QToolTip.showText(e.globalPos(), tip, self)
                    return True
            for rect, tip in getattr(self, "_mm_hits", []):
                if rect.contains(pos) and tip:
                    QToolTip.showText(e.globalPos(), tip, self)
                    return True
            for rect, tip in getattr(self, "_level_hits", []):
                if rect.contains(pos):
                    QToolTip.showText(e.globalPos(), tip, self)
                    return True
            QToolTip.hideText()                  # не над уровнем — обычная обработка (своих подсказок у стакана нет)
        return super().event(e)

    # Тело свечи слева от ячеек кластера (open → close), ширина в пикселях. До 2.1.55 — 4 px: полоса выглядела
    # тяжелее самих ячеек (14.11, просьба сделать тоньше). Освободившиеся 2 px достаются ячейкам.
    CANDLE_BODY_PX = 2

    def _render_cluster_column(self, start, col_w, height, rows, y_of, y0, rh, los, dpr):
        """Одна колонка кластеров в картинку шириной col_w (x от 0). None — в колонке нет сделок."""
        agg = self._agg_clusters(start)
        o = self.clusters.ohlc.get(start)
        if not agg and not o:
            return None
        s = self.s
        fill = max(1, s.cluster_fill_lots)
        pm = QPixmap(max(1, int(col_w * dpr)), max(1, int(height * dpr)))
        pm.setDevicePixelRatio(dpr)
        pm.fill(CS["bg"])
        p = QPainter(pm)
        p.setRenderHint(QPainter.TextAntialiasing, FONTS.dom_antialias)
        p.setRenderHint(QPainter.Antialiasing)
        up_edge, dn_edge = CS["cl_up_edge"], CS["cl_dn_edge"]
        up_body, dn_body = CS["cl_up_body"], CS["cl_dn_body"]
        up_fill, dn_fill, vol_fill = CS["cl_up_fill"], CS["cl_dn_fill"], CS["cl_vol_fill"]
        cell_bg = CS["cl_cell"]
        strip = self.CANDLE_BODY_PX if col_w >= 24 else 0   # тело свечи — только если колонка не слишком узкая
        x0 = 0
        up = o[3] >= o[0] if o else True
        bx = x0 + 2 + (strip + 2 if strip else 0)
        bw = max(2, x0 + col_w - 2 - bx)
        if o and s.cluster_block:
            top = y_of(o[1]) - rh // 2
            bot = y_of(o[2]) + rh // 2
            p.setPen(QPen(up_edge if up else dn_edge, 1))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(bx, top, bw, bot - top, 2, 2)
        if o and s.cluster_candle and strip:
            yo, yc = y_of(o[0]), y_of(o[3])
            p.fillRect(x0 + 3, min(yo, yc) - rh // 2 + 1, strip, abs(yc - yo) + rh - 2,
                       up_body if up else dn_body)
        if s.cluster_block:
            cx, cw = bx + 1, max(1, bw - 2)
            poc = max(agg, key=lambda k: agg[k][0] + agg[k][1]) if agg else None
            # «Размер шрифта в кластерах» (по умолчанию — как в стакане), не больше высоты строки (2.1.70; было rh − 1)
            cell_font = self._font(px=max(8, min(self._zone_px("cluster"), rh)), zone="cluster")
            p.setFont(cell_font)
            mode = s.cluster_color
            for i, b in enumerate(rows):
                cell = agg.get(b)
                if not cell:
                    continue
                y = y0 + i * rh
                buy, sell = cell
                total, d = buy + sell, buy - sell
                p.fillRect(cx, y + 1, cw, rh - 2, cell_bg)
                if mode == "Объем":
                    frac, col = min(1.0, total / fill), vol_fill
                elif mode == "Дельта":
                    frac, col = min(1.0, total / fill), (up_fill if buy > sell else dn_fill)
                else:                                   # Дельта объем
                    frac, col = min(1.0, abs(d) / fill), (up_fill if d > 0 else dn_fill)
                if frac > 0:
                    p.fillRect(cx, y + 1, max(1, int(cw * frac)), rh - 2, col)
                if b == poc and s.cluster_analysis_line:
                    if mode == "Объем":                 # ячейка максимального объёма — светло-голубая
                        p.fillRect(cx, y + 1, cw, rh - 2, CS["cl_poc"])
                    p.setPen(QPen(CS["cl_poc_edge"], 1))
                    p.setBrush(Qt.NoBrush)
                    p.drawRect(cx, y + 1, cw - 1, rh - 3)
                p.setPen(CS["cl_text"])
                self._draw_text_cached(p, cx, y, cw - 2, rh, Qt.AlignRight | Qt.AlignVCenter,
                                       self._cluster_text(buy, sell, los[i]), cell_font)
        p.end()
        return pm

    def _cluster_style_key(self):
        """Всё, от чего зависит картинка колонки кластеров, кроме самих сделок и геометрии."""
        s = self.s
        return (THEME_VERSION, id(FONTS), self._zone_px("cluster"), s.cluster_color, s.cluster_text, s.cluster_block,
                s.cluster_candle,
                s.cluster_analysis_line, s.cluster_fill_lots, s.volume_unit, s.short_thousands,
                getattr(s, "split_digits", True), s.lot_value, s.max_decimals)

    def _paint_clusters(self, p, cols, cl_w, col_w, h, rows, y_of, y0, rh, top_b, los):
        """Столбец = свеча интервала: узкое тело open→close слева, блок high→low с ячейками справа.
        Ячейка заполняется слева направо пропорционально объёму / заполнению кластеров.

        Каждая колонка рисуется в свою картинку (QPixmap) и берётся из кэша, пока в ней не было новых
        сделок и не сдвинулась сетка цен (ClusterModel.version, верх стакана, шаг, высота строки, стиль).
        Закрытые свечи почти никогда не перерисовываются — каждый кадр рисуется только текущая колонка."""
        starts = self.clusters.columns(cols)
        stats_top = h - self.STATS_H
        dpr = self.devicePixelRatioF()
        common = (top_b, len(rows), self.group, rh, y0, col_w, stats_top, dpr, self._cluster_style_key())
        old_cache = self.__dict__.get("_cl_cache", {})
        cache: dict = {}
        p.save()
        p.setClipRect(0, 0, cl_w, stats_top)
        for c, start in enumerate(starts):
            x0 = cl_w - (cols - c) * col_w                  # правый край неподвижен, лишние колонки уходят влево
            key = common + self.clusters.version(start)
            hit = old_cache.get(start)
            if hit is not None and hit[0] == key:
                pm = hit[1]
            else:
                pm = self._render_cluster_column(start, col_w, stats_top, rows, y_of, y0, rh, los, dpr)
            cache[start] = (key, pm)
            if pm is not None:
                p.drawPixmap(x0, 0, pm)
        self._cl_cache = cache
        p.restore()

        # --- две строки общего объёма за свечу (сумма сверху, дельта снизу) и время
        s = self.s
        rowh = self.STATS_H // 3
        p.save()
        p.setClipRect(0, stats_top, cl_w, self.STATS_H)
        for c, start in enumerate(starts):
            x0 = cl_w - (cols - c) * col_w
            cells = self.clusters.buckets.get(start, {})
            delta = sum(b - sl for b, sl in cells.values())
            total = self.clusters.total(start)
            ya, yb, yc = stats_top, stats_top + rowh, stats_top + 2 * rowh
            font = self._font(px=max(8, min(self._zone_px("cluster"), rowh)), zone="cluster")   # было 11 px всегда
            p.setFont(font)
            p.setPen(CS["text"])
            self._draw_text_cached(p, x0, ya, col_w - 2, rowh, Qt.AlignRight | Qt.AlignVCenter,
                                   fmt_amount(total, s.short_thousands, s.max_decimals), font)
            p.fillRect(x0 + 1, yb, col_w - 2, rowh - 1, CS["delta_neg"] if delta < 0 else CS["delta_pos"])
            p.setPen(CS["delta_text"])
            self._draw_text_cached(p, x0, yb, col_w - 2, rowh, Qt.AlignRight | Qt.AlignVCenter,
                                   fmt_amount(delta, s.short_thousands, s.max_decimals), font)
            p.setPen(CS["hint"])
            if self.clusters.interval_min >= 1440:            # дневные столбцы — дата, а не «0:00»
                label = f"{start.day:02d}.{start.month:02d}"
            elif c == 0 or start.minute < self.clusters.interval_min:
                label = f"{start.hour}:{start.minute:02d}"
            else:
                label = f":{start.minute:02d}"
            self._draw_text_cached(p, x0, yc, col_w, rowh, Qt.AlignCenter, label, font)
        p.restore()


# -----------------------------------------------------------------------------
# Тики: лента сделок и тиковый график (строки выровнены по ценам стакана)
# -----------------------------------------------------------------------------

class TapeWidget(QFrame):
    def __init__(self, store, settings):
        super().__init__()
        self.store = store
        self.s = settings
        self.setMinimumWidth(410)

    def set_settings(self, s):
        self.s = s
        self.update()

    def paintEvent(self, event):
        s = self.s
        painter = QPainter(self)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.fillRect(self.rect(), CS["tape_bg"])
        # «Размер шрифта ленты сделок» (2.1.70, px; по умолчанию — как в стакане: заданный размер или высота строки
        # при 100 %). Раньше — отдельный размер в pt, который на деле почти не менял вид. Колонки и строки
        # масштабируются от исходной разметки под 12 px.
        px = int(getattr(FONTS, "tape_px", 0) or FONTS.dom_size or FONTS.dom_row or 12)
        k = px / 12.0

        def x(v):
            return int(round(v * k))
        font = QFont("Consolas")
        font.setPixelSize(px)
        painter.setFont(font)
        head, row, step = x(28), x(21), x(23)
        painter.setPen(CS["tape_head"])
        painter.drawText(x(10), 0, x(72), head, Qt.AlignVCenter, "ВРЕМЯ")
        painter.drawText(x(84), 0, x(58), head, Qt.AlignVCenter, "SIDE")
        painter.drawText(x(148), 0, x(84), head, Qt.AlignVCenter | Qt.AlignRight, "ЦЕНА")
        painter.drawText(x(240), 0, x(82), head, Qt.AlignVCenter | Qt.AlignRight, "ОБЪЁМ")

        y = x(30)
        for it in reversed(self.store.items):
            size = it["size"]
            filtered = size < s.tick_min_lots
            if filtered and s.tick_hide_filtered:
                continue
            side = side_label(it["side"])
            color = CS["tape_buy"] if side == "BUY" else CS["tape_sell"] if side == "SELL" else CS["tape_other"]
            big = size >= s.tick_big
            if filtered:
                painter.setOpacity(0.35)
            if big:
                painter.fillRect(5, y + 1, self.width() - 10, row, CS["tape_big"])
            painter.setPen(CS["tape_time"])
            painter.drawText(x(10), y, x(72), row, Qt.AlignVCenter, time_text(it["ts"]))
            painter.setPen(color)
            painter.drawText(x(84), y, x(58), row, Qt.AlignVCenter, side)
            painter.setPen(CS["tape_price"])
            painter.drawText(x(148), y, x(84), row, Qt.AlignVCenter | Qt.AlignRight, f"{it['price']:.2f}")
            painter.setPen(color)
            painter.drawText(x(240), y, x(82), row, Qt.AlignVCenter | Qt.AlignRight,
                             fmt_amount(size, s.short_thousands, s.max_decimals))
            if big:
                painter.setPen(QColor("#d4b24c"))
                painter.drawText(x(330), y, max(0, self.width() - x(340)), row, Qt.AlignVCenter | Qt.AlignRight, "BIG")
            painter.setOpacity(1.0)
            y += step
            if y > self.height():
                break


# -----------------------------------------------------------------------------
# Диалог настроек (как «Настройки USDRUBF» в скальперских терминалах)
# -----------------------------------------------------------------------------

@dataclass
class Row:
    key: str
    label: str
    kind: str                      # int | float | combo | check
    opts: tuple = ()               # combo: варианты; int/float: (min, max)
    tip: str = ""
    idx: int | None = None         # для work_lots
    enabled: object = None         # callable(Settings) -> bool
    implemented: bool = True
    sep_before: bool = False


_UNITS = ("Лоты", "Деньги")
_LOT_MAX = 100_000_000
# Общая часть подсказки у галочек «Уведомление: …»: звук зависит от галочки «Звук» в окне «Уведомления»
# (без неё стакан молчит — это легко принять за неработающее уведомление).
_NOTICE_TIP = ("Строка в статусе окна стакана показывается всегда.\n"
               "Звук — только если в окне «Уведомления» терминала включена галочка «Звук».")

SETTINGS_SPEC = [
    ("Торговля", [
        *[Row("work_lots", f"Рабочий объем {i + 1}: Лоты", "int", (1, _LOT_MAX), idx=i,
              tip="Пресет лота; горячая клавиша — «Настройки» терминала → «Горячие клавиши»") for i in range(5)],
        Row("market_for_actions",
            "Рыночные заявки для: закрытие и переворот позиции, покупка/продажа по рынку, "
            "Stop-loss/Take-profit в приложении", "check", sep_before=True,
            tip="Снято — те же действия выполняются лимитной заявкой с «дальностью заброса»."),
        Row("market_for_stops", "Рыночные заявки для: стоп-заявок", "check",
            tip="Применяется к SL в режиме размещения «На бирже»."),
        Row("limit_reach", "Дальность заброса лимитных заявок:", "int", (0, 100000), sep_before=True,
            enabled=lambda s: not s.market_for_actions,
            tip="Шагов от спреда; лимитка пересекает стакан и исполняется как рыночная. 0 — автоматически."),
        Row("stop_reach", "Дальность заброса от стоп-заявок:", "int", (0, 100000),
            enabled=lambda s: not s.market_for_actions or not s.market_for_stops,
            tip="Шагов от ЦЕНЫ СТОПА (не от спреда): стоп 100, заброс 10 -> заявка по 90. 0 — автоматически."),
        Row("stop_loss", "Stop-loss, шагов цены:", "float", (0, 100000),
            tip="Виртуальный стоп: срабатывает при открытом окне и живом потоке. 0 — выкл."),
        Row("stop_trailing", "Stop-loss трейлинг, шагов цены:", "int", (0, 100000),
            tip="Стоп сдвигается скачками по N шагов вслед за ценой в сторону прибыли. 0 — выкл."),
        Row("take_profit", "Take-profit, шагов цены:", "float", (0, 100000), tip="0 — выкл."),
        Row("sltp_unit", "Выставление Stop-loss/Take-Profit:", "combo", ("В шагах цены", "В процентах")),
        Row("sltp_place", "Размещение Stop-loss/Take-Profit:", "combo", ("В приложении", "На сервере"),
            tip="В приложении — TP и SL «держит» терминал и отправляет заявку при срабатывании (нет связи — не сработает). "
                "На сервере — TP лимитной заявкой на бирже; стоп-заявки на сервере не реализованы, SL остаётся виртуальным."),
        Row("stop_trigger", "Срабатывание стоп-заявок:", "combo", ("По сделкам", "По лучшим ценам"),
            tip="По сделкам — только при сделке по цене стопа. По лучшим ценам — когда спред достиг цены "
                "(полезно на неликвиде: стакан ходит, сделок нет)."),
        Row("pos_account", "Отображение цены позиции:", "combo", tuple(ACCOUNT_OPTS.values()),
            tip="Как считать цену позиции при нескольких сделках. D — по версии сервера (рекомендуется, не влияет на "
                "закрытие). F — первая открытая сделка закрывается первой, цена = среднее оставшихся. L — наоборот. "
                "F и L считаются по списку сделок, только в PAPER; в LIVE используется D."),
        Row("profit_mode", "Отображение прибыли:", "combo", ("Цена", "Пункты", "Проценты", "Валюта"),
            tip="Клик по значению прибыли в нижней панели переключает режим. Цена — разница цен (0,0015). "
                "Пункты — в шагах цены инструмента, пункт = шаг (3п при шаге 0,0005 — те же 0,0015). "
                "Валюта = разница цен × лоты × стоимость пункта (Общие). В LIVE — PnL брокера."),
        Row("pos_volume_unit", "Отображение объема открытой позиции:", "combo", _UNITS),
        Row("work_volume_unit", "Отображение рабочих объемов:", "combo", _UNITS),
        Row("volume_unit", "Отображение объемов:", "combo", _UNITS),
        Row("notify_trade", "Уведомление: совершена сделка", "check", sep_before=True,
            tip="Изменилась позиция по инструменту окна: «Сделка: позиция +1».\n" + _NOTICE_TIP +
                "\nЕсли в «Настройки» → «Звук» включены звуки сделок стакана, при сделке звучат они."),
    ]),
    ("Стакан", [
        Row("center_mode", "Способ центровки:", "combo", ("По лучшим ценам", "По последней сделке")),
        Row("fast_scroll", "Ускоренная прокрутка, шагов цены:", "int", (1, 100000),
            tip="Shift + колесо мыши."),
        Row("row_fill_lots", "Заполнение строки объема: Лоты", "int", (1, _LOT_MAX), sep_before=True,
            tip="Объём, при котором оранжевый бар занимает всю ширину колонки."),
        Row("big_volume", "Крупный объем: Лоты", "int", (1, _LOT_MAX), tip="Полоса объёма становится жёлтой вместо оранжевой."),
        Row("big_volume2", "Крупный объем 2: Лоты", "int", (1, _LOT_MAX), tip="Полоса объёма другого (фиолетового) цвета."),
        Row("notify_big", "Уведомление: обнаружен крупный объем", "check", sep_before=True,
            tip="В стакане появился уровень с объёмом не меньше «Крупный объём».\n" + _NOTICE_TIP),
        Row("notify_big2", "Уведомление: обнаружен крупный объем 2", "check",
            tip="В стакане появился уровень с объёмом не меньше «Крупный объём 2».\n" + _NOTICE_TIP),
        Row("ruler", "Линейка:", "combo", RULER_HOVER_CHOICES, sep_before=True,
            tip="Подпись у строки под курсором: изменение цены от ближайшей лучшей цены. «Нет» — отключить.\n"
                f"«{RULER_FULL}» — проценты, шаги цены и сколько лотов стоит в стакане от спреда до курсора\n"
                "на той стороне, через которую пойдёт цена (сколько надо съесть, чтобы цена дошла сюда)."),
        Row("manual_ruler", "Ручная линейка:", "combo", ("Сумма объемов",) + RULER_CHOICES,
            tip="Alt + ЛКМ и протянуть по ценам."),
        Row("ruler_in_pos", "Линейка заявок в позиции:", "combo", RULER_CHOICES,
            tip="Расстояние от цены позиции до лимитной заявки. «Нет» — отключить."),
        Row("ruler_out_pos", "Линейка заявок вне позиции:", "combo", RULER_CHOICES,
            tip="Расстояние от спреда до лимитной заявки. «Нет» — отключить."),
        Row("mid_levels_mult", "Множитель промежуточных уровней:", "int", (1, 100000),
            tip="Серая цена и тонкая линия каждые N шагов."),
        Row("main_levels_mult", "Множитель основных уровней:", "int", (1, 100000),
            tip="Жирная линия каждые N шагов."),
        Row("notify_signal_level", "Уведомление: сработал сигнальный уровень", "check", sep_before=True,
            tip="Сигнальный уровень ставится Ctrl + ЛКМ по цене.\n" + _NOTICE_TIP),
        Row("detect_iceberg", "Показывать айсберги из «Алгоритмов»", "check",
            tip="Уровень, который детектор «Алгоритмов» признал айсбергом (объём съедают сделками — его возвращают),\n"
                "показывается голубой полосой. Инструмент должен быть добавлен в «Алгоритмы» с включённым айсбергом;\n"
                "пороги — там же, в настройках айсберга. Уведомления об айсбергах — в окне «Уведомления»."),
        Row("algo_icons", "Значки «Алгоритмов» под кнопкой настроек", "check",
            tip="Роботы 🤖, спредовые роботы 🔄, айсберги 🧊, маркет-мейкер «М» и «Наращивание» «↗» по инструменту\n"
                "окна — те же значки, что в правом верхнем углу графика; наведите — подробности. Инструмент должен\n"
                "быть добавлен в «Алгоритмы»; сколько держать остановившиеся — «Настройки» → «Интерфейс»."),
        Row("pos_line", "Линия позиции (зелёная — прибыль, красная — убыток)", "check",
            tip="Горизонтальная линия на цене позиции через весь стакан, подсветка строки и полоса до последней цены."),
        Row("autoscroll", "Автопрокрутка", "check",
            tip="Вкл — когда курсор не на стакане, спред удерживается в видимой части; пока курсор над стаканом, "
                "он не двигается. Выкл — стакан неподвижен, возврат клавишей «К спреду»."),
    ]),
    ("Тики", [
        Row("tick_min_lots", "Показать объем тиков от: Лоты", "int", (0, _LOT_MAX)),
        Row("tick_hide_filtered", "Скрывать отфильтрованные тики", "check", sep_before=True),
        Row("tick_combine_ms", "Складывать тики за период, мсек:", "int", (0, 600000), sep_before=True,
            tip="Подряд идущие сделки по одной цене и стороне склеиваются."),
        Row("tick_big", "Крупный объем: Лоты", "int", (1, _LOT_MAX)),
        Row("notify_tick_big", "Уведомление: обнаружен крупный объем", "check", sep_before=True,
            tip="Прошла сделка объёмом не меньше заданного для тиков.\n" + _NOTICE_TIP),
        Row("tick_style", "Стиль тиков:", "combo", ("Точки и линии", "Точки", "Линии"), sep_before=True),
        Row("tick_line_width", "Толщина линий тиков:", "int", (1, 10)),
    ]),
    ("Кластеры", [
        Row("cluster_fill_lots", "Заполнение кластеров при: Лоты", "int", (1, _LOT_MAX),
            tip="Объём, при котором ячейка заполнена цветом полностью. Пример: 300 — при 150 контрактах "
                "(покупки + продажи) ячейка заполнена наполовину. Покупок больше продаж — зелёная, иначе красная."),
        Row("cluster_panel", "Показывать панель кластеров", "check", sep_before=True,
            tip="Двойной клик по панели кластеров разворачивает её до самого стакана (тики скрываются); "
                "повторный — возвращает."),
        Row("cluster_candle", "Показывать тело свечи", "check",
            tip="Узкая полоса слева от ячеек: от цены открытия до цены закрытия интервала."),
        Row("cluster_block", "Показывать блок кластера", "check",
            tip="Прямоугольник от high до low с объёмами по ценам."),
        Row("cluster_tf", "Таймфрейм:", "combo", tuple(CLUSTER_TFS), sep_before=True,
            tip="Сколько времени показывается один столбец кластеров."),
        Row("cluster_col_w", "Ширина колонки кластера, px:", "int", (6, 140),
            tip="Колёсико мыши над панелью кластеров сжимает / расширяет колонки (правый край остаётся на месте). "
                "Границу панели можно перетащить мышью; двойной клик по панели — на всё место до стакана."),
        Row("cluster_text", "Стиль кластеров (текст):", "combo", CLUSTER_TEXTS,
            tip="Сумма покупок и продаж / разница (дельта) / «продажи x покупки»."),
        Row("cluster_color", "Стиль кластеров (цвет):", "combo", CLUSTER_COLORS,
            tip="Объем — заливка по сумме. Дельта — цвет по знаку дельты, заливка по сумме. "
                "Дельта объем — цвет по знаку, заливка по модулю дельты."),
    ]),
    ("Общие", [
        Row("step_mult", "Множитель изменения шага цены:", "int", (1, 1000),
            tip="Ступени сжатия «+» / «-»: x1, xM, x10M, x100M … до x50 000. Пример: 5 → 1, 5, 50, 500, 5000, 50000."),
        Row("max_decimals", "Макс. знаков после запятой у объемов:", "int", (0, 8)),
        Row("short_thousands", "Сокращать тысячи объемов", "check", sep_before=True),
        Row("short_work_thousands", "Сокращать тысячи рабочих объемов", "check"),
        Row("split_digits", "Разделять разряды объемов в стакане", "check",
            tip="Объёмы в стакане и кластерах — с пробелами между разрядами: 100 000 вместо 100000."),
        Row("cluster_analysis_line", "Отображать линию анализа кластеров", "check",
            tip="Рамка на цене с максимальным объёмом в колонке и линия между ними."),
        Row("lot_value", "Стоимость 1,0 цены на лот (для «Деньги»):", "float", (0, 1e9), sep_before=True,
            tip="Дополнительная настройка: деньги за 1,0 пункта цены на 1 лот."),
    ]),
]

def _dialog_qss() -> str:
    """Стиль диалога настроек стакана в общем стиле терминала (fx_theme, тёмная и светлая темы): поля, списки,
    галочки и кнопки берут оформление из общего стиля приложения, здесь — только фон, разделы слева,
    разделители и подсказки. Раньше у диалога был свой серый стиль «под скальперский терминал», а у пунктов разделов —
    отступы, из-за которых подсветка выбранного пункта наползала на соседние."""
    try:
        import fx_theme as t
        c = dict(bg=t.BG_WINDOW, panel=t.BG_PANEL, hover=t.BG_HOVER, border=t.BORDER, text=t.TEXT,
                 dim=t.TEXT_DIM, disabled=t.TEXT_DISABLED, sel=t.ACCENT_BG, sel_text=t.SELECTED_TEXT)
    except Exception:
        c = dict(bg="#1c1d20", panel="#232529", hover="#33363c", border="#383b41", text="#d3d6db",
                 dim="#8c9199", disabled="#5b5f66", sel="#1f3556", sel_text="#ffffff")
    return """
QDialog {{ background:{bg}; }}
QListWidget#settingsNav {{ background:{panel}; border:1px solid {border}; border-radius:3px; padding:4px 0; outline:0; }}
QListWidget#settingsNav::item {{ padding:0 10px; border:none; color:{text}; }}
QListWidget#settingsNav::item:hover:!selected {{ background:{hover}; }}
QListWidget#settingsNav::item:selected {{ background:{sel}; color:{sel_text}; }}
QScrollArea {{ border:none; background:{bg}; }}
QWidget#page {{ background:{bg}; }}
QFrame#sep {{ background:{border}; max-height:1px; min-height:1px; }}
QLabel#help {{ color:{dim}; }}
QLabel:disabled, QCheckBox:disabled {{ color:{disabled}; }}
QPushButton#apply {{ font-weight:bold; }}
""".format(**c)



class SettingsDialog(QDialog):
    """Вкладки: Торговля / Стакан / Тики / Кластеры / Общие. «Применить» — применить и сохранить."""
    applied = Signal(object)

    def __init__(self, parent, symbol, settings, templates):
        super().__init__(parent)
        self.setWindowTitle(f"Настройки {symbol.split('@')[0]}")
        self.setStyleSheet(_dialog_qss())
        self.resize(720, 460)
        self.templates = templates          # dict name -> settings dict (общий словарь, меняется на месте)
        self.symbol = symbol
        self.controls: dict = {}
        self.rows: list[Row] = []
        self.base = settings.copy()

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)

        top = QHBoxLayout()
        top.addWidget(QLabel("Шаблоны:"))
        self.tpl_combo = QComboBox()
        self.tpl_combo.setEditable(True)
        self.tpl_combo.setInsertPolicy(QComboBox.NoInsert)
        self.tpl_combo.setMinimumWidth(240)
        self.tpl_combo.lineEdit().setPlaceholderText("имя шаблона")
        self._reload_templates()
        self.tpl_combo.activated.connect(self._load_template)
        top.addWidget(self.tpl_combo, 1)
        b_save = QToolButton()
        b_save.setText("💾")
        b_save.setToolTip("Сохранить текущие значения как шаблон с этим именем")
        b_save.clicked.connect(self._save_template)
        b_del = QToolButton()
        b_del.setText("🗑")
        b_del.setToolTip("Удалить шаблон")
        b_del.clicked.connect(self._delete_template)
        b_reset = QToolButton()
        b_reset.setText("↺")
        b_reset.setToolTip("Значения по умолчанию")
        b_reset.clicked.connect(lambda: self.load_values(Settings()))
        for b in (b_save, b_del, b_reset):
            top.addWidget(b)
        self.btn_apply = QPushButton("Применить")
        self.btn_apply.setObjectName("apply")
        self.btn_apply.clicked.connect(self._apply)
        top.addWidget(self.btn_apply)
        root.addLayout(top)

        body = QHBoxLayout()
        self.nav = QListWidget()
        self.nav.setObjectName("settingsNav")
        self.nav.setFixedWidth(130)
        self.nav.setUniformItemSizes(True)
        self.stack = QStackedWidget()
        for title, rows in SETTINGS_SPEC:
            item = QListWidgetItem(title)
            item.setSizeHint(QSize(0, 26))         # высота пункта задана явно — подсветка не выходит за пункт
            self.nav.addItem(item)
            self.stack.addWidget(self._build_page(rows))
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        body.addWidget(self.nav)
        body.addWidget(self.stack, 1)
        root.addLayout(body, 1)

        self.load_values(settings)

    # ---- build -------------------------------------------------------------

    def _build_page(self, rows):
        page = QWidget()
        page.setObjectName("page")
        grid = QGridLayout(page)
        grid.setContentsMargins(10, 6, 10, 6)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(7)
        grid.setColumnStretch(0, 1)
        r = 0
        for row in rows:
            self.rows.append(row)
            if row.sep_before and r:
                sep = QFrame()
                sep.setObjectName("sep")
                grid.addWidget(sep, r, 0, 1, 3)
                r += 1
            if row.kind == "check":
                ctl = QCheckBox()
                ctl.setToolTip(row.tip)
                ctl.toggled.connect(self._refresh_enabled)
                label = QLabel(row.label)
                label.setWordWrap(True)
                label.setToolTip(row.tip)
                label.mousePressEvent = lambda _e, c=ctl: c.isEnabled() and c.toggle()
                holder = QWidget()
                hl = QHBoxLayout(holder)
                hl.setContentsMargins(0, 0, 0, 0)
                hl.setSpacing(8)
                hl.addWidget(ctl, 0, Qt.AlignTop)
                hl.addWidget(label, 1)
                grid.addWidget(holder, r, 0, 1, 2)
            else:
                label = QLabel(row.label)
                label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                label.setWordWrap(True)
                label.setMinimumWidth(80)
                if row.kind == "combo":
                    ctl = QComboBox()
                    ctl.addItems(list(row.opts))
                    ctl.currentIndexChanged.connect(self._refresh_enabled)
                elif row.kind == "int":
                    ctl = QSpinBox()
                    ctl.setRange(int(row.opts[0]), int(row.opts[1]))
                    ctl.setGroupSeparatorShown(True)
                    ctl.setButtonSymbols(QSpinBox.PlusMinus)
                else:
                    ctl = QDoubleSpinBox()
                    ctl.setRange(float(row.opts[0]), float(row.opts[1]))
                    ctl.setDecimals(2)
                ctl.setFixedWidth(170)
                ctl.setToolTip(row.tip)
                if hasattr(ctl, "valueChanged"):
                    ctl.valueChanged.connect(self._refresh_enabled)
                grid.addWidget(label, r, 0)
                grid.addWidget(ctl, r, 1)
            if row.tip:
                help_lbl = QLabel("ⓘ")
                help_lbl.setObjectName("help")
                help_lbl.setToolTip(row.tip)
                grid.addWidget(help_lbl, r, 2)
            ctl.setProperty("label", label)
            self.controls[(row.key, row.idx)] = ctl
            if not row.implemented:
                ctl.setEnabled(False)
                if label:
                    label.setEnabled(False)
            r += 1
        grid.setRowStretch(r, 1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(page)
        return scroll

    # ---- values ------------------------------------------------------------

    def load_values(self, s):
        self._loading = True
        self._sync_decimals(s.sltp_unit == "В процентах")
        for row in self.rows:
            ctl = self.controls[(row.key, row.idx)]
            value = getattr(s, row.key)
            if row.idx is not None:
                value = value[row.idx]
            if row.kind == "check":
                ctl.setChecked(bool(value))
            elif row.kind == "combo":
                i = ctl.findText(str(value))
                ctl.setCurrentIndex(max(0, i))
            else:
                ctl.setValue(value)
        self._loading = False
        self._sync_decimals()
        self._refresh_enabled()

    def read_values(self):
        s = self.base.copy()
        lots = list(s.work_lots)
        for row in self.rows:
            ctl = self.controls[(row.key, row.idx)]
            if row.kind == "check":
                v = ctl.isChecked()
            elif row.kind == "combo":
                v = ctl.currentText()
            elif row.kind == "int":
                v = int(ctl.value())
            else:
                v = float(ctl.value())
            if row.idx is not None:
                lots[row.idx] = v
            else:
                setattr(s, row.key, v)
        s.work_lots = lots
        return s

    def _sync_decimals(self, pct=None):
        """SL/TP: в шагах — целые, в процентах — 2 знака и суффикс «%»."""
        if pct is None:
            pct = self.controls[("sltp_unit", None)].currentText() == "В процентах"
        for key in ("stop_loss", "take_profit"):
            ctl = self.controls[(key, None)]
            ctl.setDecimals(2 if pct else 0)
            ctl.setSuffix(" %" if pct else "")

    def _refresh_enabled(self, *_):
        if getattr(self, "_loading", True):
            return
        self._sync_decimals()
        snap = self.read_values()
        for row in self.rows:
            if row.enabled is None:
                continue
            ctl = self.controls[(row.key, row.idx)]
            on = bool(row.enabled(snap)) and row.implemented
            ctl.setEnabled(on)
            lbl = ctl.property("label")
            if lbl is not None:
                lbl.setEnabled(on)

    # ---- templates ---------------------------------------------------------

    def _reload_templates(self, select=None):
        self.tpl_combo.clear()
        self.tpl_combo.addItems(sorted(self.templates))
        self.tpl_combo.setCurrentIndex(-1)
        if select:
            self.tpl_combo.setCurrentText(select)

    def _load_template(self, _index):
        name = self.tpl_combo.currentText()
        if name in self.templates:
            self.load_values(Settings.from_dict(self.templates[name]))

    def _save_template(self):
        name = self.tpl_combo.currentText().strip()
        if not name:
            QMessageBox.information(self, "Шаблон", "Введите имя шаблона.")
            return
        self.templates[name] = self.read_values().to_dict()
        self._reload_templates(select=name)
        self.applied.emit(None)          # попросить владельца сохранить конфиг

    def _delete_template(self):
        name = self.tpl_combo.currentText().strip()
        if name in self.templates:
            del self.templates[name]
            self._reload_templates()
            self.applied.emit(None)

    def _apply(self):
        self.base = self.read_values()
        self.applied.emit(self.base.copy())



# -----------------------------------------------------------------------------
# Window
# -----------------------------------------------------------------------------

# Сообщения окна о проблеме (Trader.message / шлюз): кроме строки состояния — плашкой поверх стакана (_Toast, 2.1.78).
# В узком стакане строка состояния обрезается, и 16.11 отказы брокера («Не хватает собственных бумаг») были
# видны только в журнале. Исполнения, «→ BUY 1 @ …» и прочие обычные сообщения — только строкой состояния.
PROBLEM_PREFIXES = ("Заявка отклонена", "Отказ", "Неопределённый результат", "Отмена не удалась", "Закрытие отменено",
                    "STOP-LOSS: не удалось", "LIVE: ошибка", "LIVE: не удалось", "Нет стакана")
TOAST_MS = 6000                    # плашка видна столько (щелчок по ней — убрать раньше)


def is_problem_message(text: str) -> bool:
    return str(text or "").startswith(PROBLEM_PREFIXES)


class _Toast(QLabel):
    """Плашка с сообщением о проблеме у нижнего края стакана (host): красная, текст переносится по ширине стакана,
    сама уходит через TOAST_MS; щелчок — убрать. Следит за размером стакана, пока видна."""

    def __init__(self, host: QWidget):
        super().__init__(host)
        self.setObjectName("dom_toast")
        self.setWordWrap(True)
        self.setStyleSheet("QLabel#dom_toast { background: rgba(170, 30, 30, 235); color: #fff; padding: 6px 8px;"
                           " border: 1px solid #ff6b6b; border-radius: 4px; font-weight: bold; }")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Щелчок — убрать")
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)
        host.installEventFilter(self)
        self.hide()

    def show_message(self, text: str, ms: int = TOAST_MS) -> None:
        self.setText(text)
        self.show()
        self._place()
        self.raise_()
        self._timer.start(ms)

    def _place(self) -> None:
        host = self.parentWidget()
        width = max(80, host.width() - 12)
        self.setFixedWidth(width)
        height = max(self.heightForWidth(width), self.sizeHint().height())
        self.setFixedHeight(min(height, max(24, host.height() - 12)))
        self.move(6, max(0, host.height() - self.height() - 6))

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.Resize and self.isVisible():
            self._place()
        return False

    def mousePressEvent(self, event):
        self._timer.stop()
        self.hide()


class _Led(QWidget):
    """Круглый индикатор в строке статуса стакана: цвет + подсказка при наведении.
    clicked — щелчок левой кнопкой (индикатор ошибки по щелчку сбрасывается)."""

    clicked = Signal()

    def __init__(self, color, tip=""):
        super().__init__()
        self.setFixedSize(14, 14)
        self._color = QColor(color)
        self.setToolTip(tip)

    def set_state(self, color, tip=None):
        self._color = QColor(color)
        if tip is not None:
            self.setToolTip(tip)
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor("#707070"), 1))
        p.setBrush(self._color)
        p.drawEllipse(QPointF(7, 7), 5.5, 5.5)


LED_OFF = "#9a9a9a"        # поток не идёт
LED_ON = "#2fcb2f"         # поток данных идёт
LED_NO_ERR = "#d8d8d8"     # ошибок нет
LED_ERR = "#ffa500"        # была ошибка


_STACKS: "weakref.WeakSet" = None


def _register_stack(w) -> None:
    """Открытые окна стакана (для частоты кадров: один стакан — как активный, несколько — фоновые)."""
    global _STACKS
    import weakref
    if _STACKS is None:
        _STACKS = weakref.WeakSet()
    _STACKS.add(w)


def _open_stacks() -> int:
    if _STACKS is None:
        return 0
    n = 0
    for w in list(_STACKS):
        try:
            if w.isVisible():
                n += 1
        except RuntimeError:                       # окно уже удалено Qt
            continue
    return n


# Активный стакан — тот, внутри которого фокус (стакан берёт фокус при наведении мыши — туда же идут
# горячие клавиши «Стакан»). Один на терминал: QApplication.focusChanged переносит рамку.
_ACTIVE_STACK = None
_FOCUS_HOOKED = False


def _hook_active_stack() -> None:
    global _FOCUS_HOOKED
    app = QApplication.instance()
    if _FOCUS_HOOKED or app is None:
        return
    _FOCUS_HOOKED = True
    app.focusChanged.connect(_on_focus_changed)


def _on_focus_changed(_old, new) -> None:
    global _ACTIVE_STACK
    w = new
    while w is not None and not isinstance(w, ScalperWindow):
        w = w.parentWidget()
    if w is None or w is _ACTIVE_STACK:
        return                     # фокус ушёл не в стакан (меню, график) — рамка остаётся на последнем стакане
    prev, _ACTIVE_STACK = _ACTIVE_STACK, w
    if prev is not None:
        try:
            prev.set_active(False)
        except RuntimeError:       # окно уже удалено Qt
            pass
    w.set_active(True)


class ScalperWindow(QMainWindow):
    TAPE_WIDTH = 420

    def __init__(self, symbol, secret, tick, settings, cfg, autostart=False,
                 live=False, account=None, max_pos=5, max_lot=5, embedded=False):
        super().__init__()
        _register_stack(self)                     # для частоты кадров (_paint_interval)
        # embedded=True — окно живёт панелью рабочего пространства терминала (докинг): обычный дочерний
        # виджет без своей рамки. Горячие клавиши (hotkeys.py) приходят в keyPressEvent этого окна, только
        # когда фокус внутри этого стакана (стакан берёт фокус при наведении мыши) — несколько стаканов
        # в одном окне не перебивают друг другу одинаковые клавиши.
        self._embedded = bool(embedded)
        if self._embedded:
            self.setWindowFlags(Qt.Widget)
        apply_dom_theme()              # цвета и шрифты (в т.ч. высота строки) — до создания стакана
        self.symbol = symbol
        self.secret = secret
        self.cfg = cfg
        self.templates = cfg.setdefault("templates", {})
        self.s = settings
        self.engine = HubStreamEngine(symbol)          # данные — из хаба терминала
        self.book = BookModel(tick)
        self.clusters = ClusterModel(settings.cluster_minutes, keep=60)
        self.tickstore = TickStore()
        self.tickstore.combine_ms = settings.tick_combine_ms
        self._ice_seen: set = set()       # айсберги из «Алгоритмов», о которых стакан уже знает (цена, сторона)

        if live:
            # Заявки — через общее соединение терминала (то же, что у рыночных данных хаба).
            shared = _current_trading_session()
            if shared is None:
                raise RuntimeError("нет соединения терминала с Finam — LIVE недоступен")
            self.gateway = LiveGateway(shared, account, symbol, tick)
            print(f"[стакан] {symbol}: LIVE, соединение общее (терминал)", flush=True)
        else:
            self.gateway = PaperGateway(self.book)
            # Исполнения PAPER — в общий журнал: окна «Сделки» и «Финрез» (account_window.py)
            self.gateway.fill.connect(lambda side, price, qty, sym=symbol: PAPER_JOURNAL.add(sym, side, price, qty))
        self.trader = Trader(self.gateway, self.book, settings, max_pos, max_lot)

        self.delta_interval = 0
        self.cumulative_delta = 0
        self.interval_trades = 0
        self.interval_volume = 0
        self.total_trades = 0
        self.total_volume = 0
        self.bid_price = None
        self.ask_price = None
        self._lag_ms = None                 # задержка ленты сделок (EMA), мс
        self._book_snap_prev = False
        self._status_base = "STOPPED"
        self._flash = ""
        self._last_notify = 0.0
        self._big_state: dict[int, int] = {}
        self._prev_last_tick: int | None = None
        self._pos_seen = self.gateway.pos_qty
        # LIVE: до первого ответа брокера позиция шлюза — «ещё не знаем»; первая известная позиция — не сделка.
        self._pos_known = bool(getattr(self.gateway, "account_seen", True))
        self._flash_hold_until = 0.0       # до этого времени строку важного уведомления не заменяют обычные
        self._dialog = None
        self.decimals = tick_decimals(tick)

        self.setWindowTitle(f"{symbol} [{self.gateway.name}]")
        self.resize(700, 940)

        root = QWidget()
        root.setObjectName("stackroot")
        root.setAttribute(Qt.WA_StyledBackground, True)   # рамка активного стакана рисуется стилем root
        self._root = root
        self._active = False
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(*(appearance.ACTIVE_FRAME_PX,) * 4)   # место под рамку — всегда, без скачков
        layout.setSpacing(0)

        layout.addWidget(self._build_tab_header())

        self.splitter = QSplitter(Qt.Horizontal)
        self.ladder = self._make_ladder()
        self.ladder.symbol = symbol                  # опционные уровни инструмента (option_levels.py)
        self.tape = TapeWidget(self.tickstore, settings)
        for wdg in (self.tape, self.ladder):
            self.splitter.addWidget(wdg)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.tape.hide()
        layout.addWidget(self.splitter, 1)

        layout.addWidget(self._build_info_panel())
        layout.addWidget(self._build_status_bar())
        self._toast = _Toast(self.ladder)          # отказ брокера и другие проблемы — плашкой поверх стакана

        self._apply_qss()

        # trader / gateway
        self.trader.message.connect(self.flash)
        self.trader.trade_event.connect(self._on_trade_event)
        self.trader.changed.connect(self.refresh_panel)
        self.gateway.orders_changed.connect(self._schedule_paint)
        self.gateway.position_changed.connect(self.refresh_panel)
        self.gateway.position_changed.connect(self._on_position_notify)
        # Stop-Loss / Take-Profit (поставлен, перенесён, снят, сработал) — в журнал и в PAPER, и в LIVE
        self.trader.log.connect(self._log_live)
        if live:
            # LIVE: сообщения торгового слоя (заявки, снятия, отказы, исполнения, закрытие) и позиция —
            # ещё и в консоль с временем: строка статуса показывает только последнее сообщение.
            self.gateway.message.connect(self._log_live)
            self.gateway.position_changed.connect(
                lambda: self._log_live(f"позиция {self.gateway.pos_qty} @ {self.gateway.pos_avg:g}"))

        self.engine.signals.quote.connect(self.on_quote)
        self.engine.signals.book.connect(lambda rows, snap: self.on_book(rows, snap))
        self.engine.signals.trade.connect(self.on_trade)
        self.engine.signals.error.connect(self.on_error)
        self.engine.signals.status.connect(self.on_status)

        # Горячие клавиши — hotkeys.REGISTRY (keyPressEvent); подписи в меню обновляются при смене назначений.
        if not hasattr(self, "_hk_menu_actions"):        # обычно уже заведён пунктами меню (_add_hotkey_action)
            self._hk_menu_actions: list[tuple[QAction, str, str]] = []
        hotkeys.REGISTRY.changed.connect(self._refresh_hotkey_texts)
        appearance.NOTIFIER.changed.connect(self._on_appearance_changed)   # OK в «Настройках» → «Цвета»/«Шрифты»
        try:
            import option_levels
            option_levels.registry().changed.connect(self._on_option_levels)   # уровни из вкладки «Опционы»
        except Exception:
            pass
        self.set_active(False)
        _hook_active_stack()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(100)

        self.flow_timer = QTimer(self)
        self.flow_timer.timeout.connect(self.reset_interval)
        self.flow_timer.start(1000)

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self.save)

        self.flash_timer = QTimer(self)
        self.flash_timer.setSingleShot(True)
        self.flash_timer.timeout.connect(self._clear_flash)

        self.refresh_panel()
        if autostart:
            QTimer.singleShot(0, self.start)

    # ---- ladder factory ------------------------------------------------------

    def _make_ladder(self):
        ld = ScalperLadderWidget(self.book, self.clusters, self.s, self.trader, self.tickstore)
        ld.group = self.s.step_factor if self.s.step_factor in compression_steps(self.s.step_mult) else 1
        ld.zoomChanged.connect(lambda z: self.zoom_label.setText(f"{z}%"))
        ld.orderClicked.connect(self.trader.limit)
        ld.cancelClicked.connect(lambda t, ld=ld: self.trader.cancel_range(t, t + ld.group - 1))
        ld.sltpClicked.connect(lambda t: self.flash(self.trader.set_level_at(t)))
        ld.compressionChanged.connect(self._on_compression)
        ld.clusterTfChosen.connect(self._set_cluster_tf)
        ld.lotClicked.connect(self._on_lot_clicked)
        ld.lotAssigned.connect(self._on_lot_assigned)
        ld.accountClicked.connect(self._on_account_clicked)
        ld.settingsClicked.connect(self.open_settings)
        ld.clusterLayoutChanged.connect(self._schedule_save)
        return ld

    def _schedule_save(self):
        self._save_timer.start(400)         # колёсико / перетаскивание шлют много событий — пишем раз

    def _set_cluster_tf(self, tf: str):
        """Таймфрейм кластеров из меню ПКМ: то же, что «Таймфрейм» в настройках инструмента
        (сохраняется; столбцы пересчитываются из уже принятых сделок)."""
        new = copy.copy(self.s)
        new.cluster_tf = tf
        self.apply_settings(new)
        self.flash(f"Кластеры: {CLUSTER_TF_TITLES.get(tf, tf)}")

    def _toggle_volume_unit(self):
        """Горячая клавиша «Объёмы в стакане: лоты / валюта» (hotkeys.py): лоты <-> валюта."""
        self.s.volume_unit = "Деньги" if self.s.volume_unit == "Лоты" else "Лоты"
        self.save()
        self.ladder.update()
        self.flash(f"Объёмы: {'валюта' if self.s.volume_unit == 'Деньги' else 'лоты'}")

    def _on_info_click(self, idx):
        """Клик по ячейкам нижней панели: позиция — лоты <-> валюта, прибыль — следующий режим."""
        s = self.s
        if idx == 1:
            s.pos_volume_unit = "Деньги" if s.pos_volume_unit == "Лоты" else "Лоты"
        elif idx == 2:
            modes = ("Цена", "Пункты", "Проценты", "Валюта")
            s.profit_mode = modes[(modes.index(s.profit_mode) + 1) % len(modes)] if s.profit_mode in modes else modes[0]
        else:
            return
        self.save()
        self.refresh_panel()

    def _on_compression(self, g):
        self.s.step_factor = g
        self.save()
        self.flash(f"Сжатие стакана: x{g}")

    def _on_account_clicked(self, letter):
        self.s.pos_account = ACCOUNT_OPTS[letter]
        self.trader._warned_acct = False
        self.trader.account_mode()           # предупредит, если F/L недоступны (LIVE)
        self._sync_account_menu()
        self.save()
        self.refresh_panel()

    def _on_lot_assigned(self, i, value):
        lots = list(self.s.work_lots)
        if not 0 <= i < len(lots):
            return
        was_selected = self.trader.lot == lots[i]
        lots[i] = value
        self.s.work_lots = lots
        if was_selected:
            self.trader.lot = value
        self.trader.set_settings(self.s)
        self.save()
        self.refresh_panel()
        warn = (f" (внимание: лимит --max-lot={self.trader.max_lot}, заявки такого размера будут отклонены)"
                if value > self.trader.max_lot else "")
        self.flash(f"Лот {i + 1} = {value}{warn}")

    def _on_lot_clicked(self, i):
        if i < len(self.trader.lots):
            self.trader.set_lot(self.trader.lots[i])

    def _apply_qss(self):
        if _light_theme():
            self.setStyleSheet("""
            QMainWindow, QWidget#statusbar { background:#e4e4e4; color:#1e1e1e; }
            QWidget#statusbar QLabel { color:#2a2a2a; font-family:Tahoma; font-size:11px; }
            QWidget#statusbar QPushButton {
                background:#ececec; border:1px solid #a8a8a8; padding:2px 8px; color:#1e1e1e;
                font-family:Tahoma; font-size:11px; }
            QWidget#statusbar QPushButton:hover { background:#d8d8d8; }
            QMenu { background:#ececec; color:#1e1e1e; } QMenu::item:selected { background:#cddff5; }
            QWidget#tabheader { background:#dcdcdc; border-bottom:1px solid #2a8a80; }
            QLabel#tabname { color:#1e1e1e; font-family:Tahoma; font-size:12px; font-weight:bold;
                border-bottom:3px solid #7aa300; padding-bottom:1px; }
            """)
            return
        self.setStyleSheet("""
            QMainWindow, QWidget#statusbar { background:#1c1c1c; color:#ddd; }
            QWidget#statusbar QLabel { color:#cfcfcf; font-family:Tahoma; font-size:11px; }
            QWidget#statusbar QPushButton {
                background:#333; border:1px solid #585858; padding:2px 8px; color:#eee;
                font-family:Tahoma; font-size:11px; }
            QWidget#statusbar QPushButton:hover { background:#444; }
            QMenu { background:#2a2a2a; color:#eee; } QMenu::item:selected { background:#444; }
            QWidget#tabheader { background:#14202c; border-bottom:1px solid #2a8a80; }
            QLabel#tabname { color:#ffffff; font-family:Tahoma; font-size:12px; font-weight:bold;
                border-bottom:3px solid #a6d608; padding-bottom:1px; }
        """)

    # ---- settings ----------------------------------------------------------

    def save(self):
        self.cfg.setdefault("settings", {})[self.symbol] = self.s.to_dict()
        save_config(self.cfg)

    def apply_settings(self, new):
        self.s = new
        self.trader.set_settings(new)
        self.ladder.set_settings(new)
        self.tape.set_settings(new)
        self.tickstore.combine_ms = new.tick_combine_ms
        self.clusters.set_interval(new.cluster_minutes)
        self._sync_account_menu()
        self.refresh_panel()
        self.save()

    def open_settings(self):
        if self._dialog is not None and self._dialog.isVisible():
            self._dialog.raise_()
            self._dialog.activateWindow()
            return
        self._dialog = SettingsDialog(self, self.symbol, self.s, self.templates)
        self._dialog.applied.connect(self._on_dialog_applied)
        self._dialog.show()

    def _on_dialog_applied(self, new):
        if new is None:          # изменились только шаблоны
            self.save()
        else:
            self.apply_settings(new)
            self.flash("Настройки применены")

    # ---- notifications -----------------------------------------------------

    def _log_live(self, text):
        """Строка журнала торговли окна: [LIVE SiZ6@RTSX 12:23:31.401] … (в PAPER — [PAPER …])."""
        stamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        name = getattr(self.gateway, "name", "LIVE") or "LIVE"
        print(f"[{name} {self.symbol} {stamp}] {text}", flush=True)

    IMPORTANT_HOLD_SEC = 4.0     # столько строка важного уведомления (своя сделка) не заменяется обычными

    def notify(self, text, kind="pulse", important=False, title=None, price=None):
        """Уведомление из настроек стакана: текст в строке статуса и звук kind ("pulse" — сделка,
        "signal" — крупный объём / крупная сделка, "alert" — сигнальный уровень). Чаще 2 раз в секунду — молча.
        Каждое прозвучавшее уведомление — ещё и строка в окне «Уведомления» (2.1.84, _notice_event): title —
        её заголовок («Сигнальный уровень»), price — цена (повторы на той же цене там склеиваются в одну строку).

        important=True — своя сделка: проходит всегда. Раньше её глушило общее ограничение частоты: при
        включённом «крупном объёме» уведомления идут почти непрерывно, сделка попадала в те же полсекунды и
        пропадала — и звук, и строка; а если проходила, строку тут же заменяло следующее обычное уведомление."""
        now = time.monotonic()
        if not important:
            if now - self._last_notify < 0.5:
                return
            if now < self._flash_hold_until:              # на экране ещё строка о своей сделке — только звук
                self._last_notify = now
                self._notice_sound(kind)
                self._notice_event(text, kind, title, price)
                return
        else:
            self._flash_hold_until = now + self.IMPORTANT_HOLD_SEC
        self._last_notify = now
        self._notice_sound(kind)
        self._notice_event(text, kind, title, price)
        self.flash(text)

    def _notice_event(self, text, kind, title, price):
        """Прозвучавшее уведомление — строкой в «Уведомления» терминала (set_notice_event)."""
        handler = _NOTICE_EVENT
        if handler is None:
            return
        try:
            handler(self.symbol, title or "уведомление", text, kind, price)
        except Exception as exc:
            print(f"[уведомления] {self.symbol}: {type(exc).__name__}: {exc}", file=sys.stderr)

    def _notice_sound(self, kind):
        player = _NOTICE_SOUND
        if player is None:
            QApplication.beep()
        else:
            try:
                player(kind)
            except Exception as exc:
                print(f"[звук] {self.symbol}: {type(exc).__name__}: {exc}", file=sys.stderr)

    def _on_trade_event(self, kind: str):
        """Звук сделки: открытие / закрытие позиции, SL / TP — проигрывает терминал (set_trade_sound)."""
        player = _TRADE_SOUND
        if player is not None:
            try:
                player(kind)
            except Exception as exc:
                print(f"[звук] {self.symbol}: {type(exc).__name__}: {exc}", file=sys.stderr)

    def _on_position_notify(self):
        q = self.gateway.pos_qty
        if not self._pos_known:                           # LIVE: позиция, с которой окно открылось, — не сделка
            self._pos_known = bool(getattr(self.gateway, "account_seen", True))
            self._pos_seen = q
            return
        if self.s.notify_trade and q != self._pos_seen:
            self.notify(f"Сделка: позиция {q:+d}", important=True, title="своя сделка")
            print(f"[{self.gateway.name} {self.symbol}] уведомление: сделка, позиция {self._pos_seen:+d} → {q:+d}",
                  file=sys.stderr)
        self._pos_seen = q

    # ---- trade panel -------------------------------------------------------

    def _build_info_panel(self):
        """Нижняя панель последняя цена | позиция | прибыль (зелёная / красная)."""
        panel = QWidget()
        panel.setObjectName("infopanel")
        self.info_panel = panel
        panel.setVisible(False)                  # показывается только пока есть позиция по инструменту
        row = QHBoxLayout(panel)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(2)
        self.info_cells = []
        for stretch in (3, 2, 3):
            lbl = QLabel("—")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setMinimumHeight(30)
            row.addWidget(lbl, stretch)
            self.info_cells.append(lbl)
        self.info_cells[0].setToolTip(self.INFO_PRICE_TIP_ENTRY)   # панель видна только в позиции (_update_info_panel)
        self.info_cells[1].setToolTip("Позиция: л — лонг, ш — шорт. Клик — лоты / валюта")
        self.info_cells[2].setToolTip("Прибыль / убыток по позиции. Клик — переключить цена / пункты / проценты / валюта")
        for i in (1, 2):
            self.info_cells[i].setCursor(Qt.PointingHandCursor)
            self.info_cells[i].mousePressEvent = lambda _e, i=i: self._on_info_click(i)
        self._info_style = None
        return panel

    # Левая ячейка нижней панели: в позиции — цена входа (Trader.info_cells), без позиции — последняя цена.
    # До 2.1.41 подсказка всегда была «Последняя цена», хотя в позиции там цена входа (12.11, VKCO: 220,18 при
    # рынке 231).
    INFO_PRICE_TIP_ENTRY = ("Цена входа в позицию (средняя: по данным брокера или по своим сделкам — D / F / L\n"
                            "в настройке учёта позиции)")
    INFO_PRICE_TIP_LAST = "Последняя цена"

    def _update_info_panel(self):
        in_position = self.trader.gw.pos_qty != 0
        if self.info_panel.isVisible() != in_position:
            self.info_panel.setVisible(in_position)
        if not in_position:
            return
        price, pos, pnl, sign = self.trader.info_cells()
        self.info_cells[0].setText(price)
        tip = self.INFO_PRICE_TIP_ENTRY if self.trader.ref_price() > 0 else self.INFO_PRICE_TIP_LAST
        if self.info_cells[0].toolTip() != tip:
            self.info_cells[0].setToolTip(tip)
        self.info_cells[1].setText(pos)
        self.info_cells[2].setText(pnl)
        # позиция — цветом стороны (лонг зелёный, шорт красный), прибыль — цветом знака.
        green, red, grey = "#24963f", "#c0392b", "#2b2b2b"
        pos_bg = green if self.trader.gw.pos_qty > 0 else red
        pnl_bg = grey if sign == 0 else (green if sign > 0 else red)
        style = (pos_bg, pnl_bg)
        if style != self._info_style:
            self._info_style = style
            base = "color:#ffffff;font-family:Tahoma;font-size:17px;font-weight:bold;"
            self.info_cells[0].setStyleSheet(base + "background:#262626;")
            self.info_cells[1].setStyleSheet(base + f"background:{pos_bg};")
            self.info_cells[2].setStyleSheet(base + f"background:{pnl_bg};")

    def _build_tab_header(self):
        """Вкладка: инструмент и режим PAPER / LIVE. Состояние потоков — в строке статуса внизу
        (индикатор слева и надпись STREAMING), в шапке его больше нет."""
        bar = QWidget()
        bar.setObjectName("tabheader")
        bar.setFixedHeight(26)
        row = QHBoxLayout(bar)
        row.setContentsMargins(8, 0, 8, 0)
        row.setSpacing(8)
        name = QLabel(self.symbol.split("@")[0])
        name.setObjectName("tabname")
        row.addWidget(name)
        live = self.gateway.name == "LIVE"
        mode = QLabel(self.gateway.name)
        mode.setStyleSheet(
            "font-weight:bold;padding:1px 8px;color:#fff;font-family:Tahoma;font-size:11px;"
            f"background:{'#c0272d' if live else '#2e8b3a'};")
        mode.setToolTip("LIVE — реальные заявки" if live else "PAPER — симуляция, заявки на биржу не уходят")
        row.addWidget(mode)
        row.addStretch(1)
        self.tab_header = bar
        return bar

    # ---- горячие клавиши (hotkeys.py) ------------------------------------------

    def keyPressEvent(self, event):
        """Клавиши, не обработанные стаканом и полями окна, — горячие клавиши из «Настроек».
        Поля ввода (лот, инструмент) свои символы забирают сами и сюда их не пропускают."""
        if event.isAutoRepeat() and getattr(self.ladder, "sltp_mode", False):
            event.accept()                        # зажатая C — режим уже включён
            return
        action = hotkeys.REGISTRY.match(event)
        if action is None:
            super().keyPressEvent(event)
            return
        event.accept()
        if hotkeys.ACTION_BY_ID[action].group == hotkeys.GLOBAL:
            hotkeys.REGISTRY.run_global(action)
        else:
            self.run_hotkey(action)

    def keyReleaseEvent(self, event):
        """Отпустили клавишу «Stop-Loss / Take-Profit» — режим выключен (работает, пока зажата)."""
        if not event.isAutoRepeat() and getattr(self.ladder, "sltp_mode", False):
            if hotkeys.REGISTRY.match(event) == "sltp_at_cursor":
                self.ladder.set_sltp_mode(False)
                event.accept()
                return
        super().keyReleaseEvent(event)

    def run_hotkey(self, action: str) -> None:
        """Действие группы «Стакан» для этого окна."""
        t = self.trader
        if action == "market_buy":
            t.market("BUY")
        elif action == "market_sell":
            t.market("SELL")
        elif action in ("limit_best_buy", "limit_best_sell"):
            self._limit_at_best("BUY" if action == "limit_best_buy" else "SELL")
        elif action == "close":
            t.close_position()
        elif action == "reverse":
            t.reverse()
        elif action == "cancel_all":
            t.cancel_all()
        elif action.startswith("volume_"):
            self._on_lot_clicked(int(action[-1]) - 1)
        elif action == "center":
            self.ladder.recenter()
        elif action == "step_up":
            self.ladder.step_compression(+1)
        elif action == "step_down":
            self.ladder.step_compression(-1)
        elif action == "toggle_units":
            self._toggle_volume_unit()
        elif action == "instrument_settings":
            self.open_settings()
        elif action == "sltp_at_cursor":
            self.ladder.set_sltp_mode(True)        # пока зажата: клик по цене — Stop-Loss / Take-Profit

    def _limit_at_best(self, side: str) -> None:
        """Лимитная заявка «по лучшей»: на шаг лучше лучшей цены своей стороны, если между
        bid и ask есть место; иначе — на саму лучшую цену (в очередь)."""
        bid_t, ask_t = self.book.best()
        if bid_t is None or ask_t is None:
            self.flash("Нет стакана для заявки по лучшей цене")
            return
        if side == "BUY":
            tick = bid_t + 1 if bid_t + 1 < ask_t else bid_t
        else:
            tick = ask_t - 1 if ask_t - 1 > bid_t else ask_t
        self.trader.limit(side, tick)

    def _add_hotkey_action(self, menu, base: str, action_id: str, fn) -> QAction:
        """Пункт меню с подписью назначенной клавиши («Закрыть позицию (F4)»); сам клавишу не ловит."""
        act = QAction(base + hotkeys.REGISTRY.hint(action_id), self)
        act.triggered.connect(lambda _=False, fn=fn: fn())
        menu.addAction(act)
        # Меню строится в _build_ui раньше, чем __init__ доходит до подписки на REGISTRY.changed, —
        # список заводим здесь, при первом пункте (иначе AttributeError при открытии окна).
        if not hasattr(self, "_hk_menu_actions"):
            self._hk_menu_actions = []
        self._hk_menu_actions.append((act, base, action_id))
        return act

    def _refresh_hotkey_texts(self) -> None:
        for act, base, action_id in list(self._hk_menu_actions):
            try:
                act.setText(base + hotkeys.REGISTRY.hint(action_id))
            except RuntimeError:              # окно уже удалено
                pass

    def refresh_panel(self):
        self._update_info_panel()
        self._schedule_paint()

    PAINT_MS = 20                     # активный стакан: не чаще 50 кадров в секунду (2.1.49; было 33 мс — ~30 кадров)
    # Остальные стаканы на экране — реже: кадр стакана 4–8 мс, и при 10 открытых стаканах их отрисовка
    # занимала ~550 мс GUI в секунду, интерфейс отвечал с опозданием 60–200 мс (замер 29.10). Активный
    # (с фокусом, в рамке) рисуется как раньше; фоновые — до 10 кадров в секунду, а когда GUI не успевает
    # (средняя задержка таймера GUI за последнюю секунду больше BUSY_LAG_MS) — до 4.
    PAINT_BG_MS = 100
    PAINT_BUSY_MS = 250
    BUSY_LAG_MS = 30.0

    def _paint_interval(self) -> int:
        """Пауза до следующего кадра стакана (мс): активный — PAINT_MS, фоновый — PAINT_BG_MS, а при
        перегрузке GUI — PAINT_BUSY_MS. Пока активный не выбран (фокус ни разу не заходил в стакан),
        единственный открытый стакан рисуется как активный, а при нескольких — все как фоновые
        (замер 29.10: 10 стаканов без выбранного — все по 30 кадров, ~650 мс GUI в секунду)."""
        if _ACTIVE_STACK is self:
            return self.PAINT_MS
        if _ACTIVE_STACK is None and _open_stacks() <= 1:
            return self.PAINT_MS
        try:
            from services.perf import PERF
            last = PERF.last
            busy = last is not None and last.lag_avg_ms > self.BUSY_LAG_MS
        except Exception:
            busy = False
        return self.PAINT_BUSY_MS if busy else self.PAINT_BG_MS

    def _on_option_levels(self, _underlying: str) -> None:
        self._schedule_paint()

    def _schedule_paint(self, book_only: bool = False):
        """Перерисовка стакана и ленты от данных (стакан, сделки, заявки, таймер панели) — одним кадром
        не чаще _paint_interval() (активный стакан — PAINT_MS, фоновые — реже). Мышь, прокрутка и
        настройки перерисовывают сразу (ladder.update()). book_only — изменился только стакан: если до кадра
        не пришло ничего другого, перерисуется одна полоса стакана (ladder.update_book)."""
        timer = self.__dict__.get("_paint_timer")
        if timer is None:
            timer = self._paint_timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._paint_now)
        if not book_only:
            self._paint_full = True
        if not timer.isActive():
            timer.start(self._paint_interval())

    def _paint_now(self):
        """Кадр: если с прошлого кадра менялся только стакан — одна полоса стакана (ladder.update_book),
        иначе (сделки, заявки, панель) — весь стакан и лента."""
        full, self._paint_full = self.__dict__.get("_paint_full", True), False
        if not full:
            self.ladder.update_book()
            return
        self.ladder.update()
        if self.tape.isVisible():
            self.tape.update()

    # ---- status bar --------------------------------------------------------

    def _build_status_bar(self):
        bar = QWidget()
        bar.setObjectName("statusbar")
        bar.setFixedHeight(24)
        row = QHBoxLayout(bar)
        row.setContentsMargins(4, 2, 6, 2)
        row.setSpacing(8)

        # Индикаторы: поток данных Finam по этому стакану и последняя ошибка (подробности — в подсказке).
        self.led_conn = _Led(LED_OFF, "Поток данных: не идёт")    # подсказка: поток, пинг до Finam, лаг (_conn_tip_text)
        self.led_err = _Led(LED_NO_ERR, "Ошибок нет")
        self.led_err.clicked.connect(self._clear_error_led)
        self._last_error = None            # (время, текст) последней ошибки — для подсказки
        row.addWidget(self.led_conn)
        row.addWidget(self.led_err)

        self.menu_button = QPushButton("меню")
        self.menu_button.setFocusPolicy(Qt.NoFocus)
        self.menu_button.setMenu(self._build_menu())
        row.addWidget(self.menu_button)

        self.zoom_label = QLabel("100%")
        row.addWidget(self.zoom_label)

        self.status_label = QLabel("STOPPED")
        # Длинные сообщения (ошибки потоков, LIVE) не должны раздвигать окно: текст обрезается по доступной
        # ширине, полностью он виден во всплывающей подсказке.
        self.status_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.status_label.setMinimumWidth(0)
        row.addWidget(self.status_label, 1)

        self.info_label = QLabel("")
        row.addWidget(self.info_label)
        return bar

    def _build_menu(self):
        menu = QMenu(self)

        self.act_start = QAction("▶ Старт потоков", self)
        self.act_stop = QAction("■ Стоп потоков", self)
        self.act_stop.setEnabled(False)
        self.act_start.triggered.connect(self.start)
        self.act_stop.triggered.connect(self.stop)
        menu.addAction(self.act_start)
        menu.addAction(self.act_stop)
        menu.addSeparator()

        act_settings = QAction("⚙ Настройки…", self)
        act_settings.triggered.connect(self.open_settings)
        menu.addAction(act_settings)

        trade = menu.addMenu("Торговля")
        for text, action_id, fn in (("BUY по рынку", "market_buy", lambda: self.trader.market("BUY")),
                                    ("SELL по рынку", "market_sell", lambda: self.trader.market("SELL")),
                                    ("Закрыть позицию", "close", lambda: self.trader.close_position()),
                                    ("Реверс", "reverse", lambda: self.trader.reverse()),
                                    ("Снять все заявки", "cancel_all", lambda: self.trader.cancel_all())):
            self._add_hotkey_action(trade, text, action_id, fn)

        self.act_tape = QAction("Лента сделок", self, checkable=True)
        self.act_tape.toggled.connect(lambda on: self._toggle_panel(self.tape, self.TAPE_WIDTH, on))
        menu.addAction(self.act_tape)

        sub = menu.addMenu("Учёт позиции (D / F / L)")
        self._acct_group = QActionGroup(self)
        self._acct_actions = {}
        for letter, text in ACCOUNT_OPTS.items():
            act = QAction(text, self, checkable=True)
            act.triggered.connect(lambda _=False, l=letter: self._on_account_clicked(l))
            self._acct_group.addAction(act)
            sub.addAction(act)
            self._acct_actions[letter] = act
        self._sync_account_menu()

        menu.addSeparator()
        self._add_hotkey_action(menu, "К спреду", "center", lambda: self.ladder.recenter())

        act_reset = QAction("Сбросить кластеры", self)
        act_reset.triggered.connect(self.reset_history)
        menu.addAction(act_reset)

        menu.addSeparator()
        act_help = QAction("Управление…", self)
        act_help.triggered.connect(self.show_help)
        menu.addAction(act_help)
        return menu

    def _sync_account_menu(self):
        cur = self.s.pos_account[:1]
        for letter, act in getattr(self, "_acct_actions", {}).items():
            act.setChecked(letter == cur)

    def show_help(self):
        hk = hotkeys.REGISTRY.bindings()
        on = [(a.title, hk[a.id].text) for a in hotkeys.ACTIONS if hk[a.id].enabled and hk[a.id].assigned]
        keys = ("\n".join(f"  {key} — {title}" for title, key in on) if on else
                "  не назначены — «Настройки» терминала → «Горячие клавиши»")
        QMessageBox.information(self, "Управление", (
            "Мышь (колонки заявок / объёма / цены):\n"
            "  ЛКМ — BUY лимит лотом, ПКМ — SELL лимит\n"
            "  СКМ или Shift+ЛКМ — снять мои заявки на этой цене\n"
            "  Ctrl+ЛКМ — поставить / убрать сигнальный уровень\n"
            "  Alt+ЛКМ и протянуть — ручная линейка\n"
            "  Колесо — прокрутка, Shift+колесо — ускоренная, Ctrl+колесо — высота строки\n"
            "  Клик по позиции / прибыли в нижней панели — сменить единицы\n\n"
            "Горячие клавиши (действуют на стакан под мышью):\n"
            f"{keys}\n\n"
            "Остальное — в «⚙ Настройки» (шаблоны сохраняются в "
            f"{CONFIG_PATH}).\nРежим: {self.gateway.name}."))

    # ---- menu handlers -----------------------------------------------------

    def _toggle_panel(self, widget, width, on):
        if on == widget.isVisible():
            return
        widget.setVisible(on)
        if on:
            widget.setMinimumWidth(min(widget.minimumWidth(), width))
            self.resize(self.width() + width, self.height())
        else:
            self.resize(max(self.minimumWidth(), self.width() - width), self.height())

    def reset_history(self):
        self.clusters.clear()
        self.tickstore.items.clear()
        self.ladder.update()

    # ---- stream control ----------------------------------------------------

    def start(self):
        if _current_market_data_hub() is None:
            self.on_error("Нет подключения к Finam (шлюз терминала не запущен).")
            return
        self.engine.start()
        self.act_start.setEnabled(False)
        self.act_stop.setEnabled(True)

    def stop(self):
        self.engine.stop()
        self.act_start.setEnabled(True)
        self.act_stop.setEnabled(False)

    # ---- status text -------------------------------------------------------

    def _update_status(self):
        text = self._status_base + (f"   ·   {self._flash}" if self._flash else "")
        self.status_label.setText(text)
        self.status_label.setToolTip(text)

    def flash(self, message):
        """Сообщение окна — в строку состояния на 6 с; о проблеме (is_problem_message) — ещё и плашкой поверх
        стакана: строка состояния в узком окне обрезается."""
        self._flash = message
        self._update_status()
        self.flash_timer.start(6000)
        toast = getattr(self, "_toast", None)
        if toast is not None and is_problem_message(message):
            toast.show_message(message)

    def _clear_flash(self):
        self._flash = ""
        self._update_status()

    # ---- stream handlers ---------------------------------------------------

    def on_quote(self, msg):
        quotes = msg.get("quote") or []
        if not quotes:
            quotes = [msg]
        for q in quotes:
            if not isinstance(q, dict):
                continue
            bid = as_float(first(q, "bid", "bid_price"))
            ask = as_float(first(q, "ask", "ask_price"))
            last = as_float(first(q, "last", "last_price"))
            if last is not None:
                self.book.last = last
            if bid is not None:
                self.bid_price = bid
            if ask is not None:
                self.ask_price = ask

    def on_book(self, rows, snapshot=False):
        if snapshot and not self._book_snap_prev:          # полный снимок стакана заменяет прежнее состояние
            self.book.levels.clear()
            self._big_state.clear()
        self._book_snap_prev = snapshot
        self.book.apply(rows)
        s = self.s
        if s.notify_big or s.notify_big2:
            quiet = snapshot          # полный снимок (подключение): уже стоящие объёмы запоминаем без звука
            for price, _b, _a in rows:
                k = self.book.key(price)
                lv = self.book.levels.get(k)
                vol = (lv.bid or lv.ask) if lv else 0
                now = 2 if vol >= s.big_volume2 else 1 if vol >= s.big_volume else 0
                was = self._big_state.get(k, 0)
                if not quiet and now > was and ((s.notify_big and now >= 1 > was) or (s.notify_big2 and now == 2)):
                    self.notify(f"Крупный объём {fmt_amount(vol, True)} @ {fmt_price(price, self.decimals)}",
                                "signal", title="крупный объём", price=price)
                if now:
                    self._big_state[k] = now
                else:
                    self._big_state.pop(k, None)
        self._schedule_paint(book_only=not snapshot)

    def on_trade(self, trade):
        s = self.s
        side = side_label(trade.get("side"))
        size = as_int(trade.get("size", 0))
        price = as_float(trade.get("price"))

        snapshot = bool(trade.get("snapshot"))
        lag = trade.get("lag_ms")
        if lag is not None and not snapshot:
            self._lag_ms = lag if self._lag_ms is None else 0.8 * self._lag_ms + 0.2 * lag
        if snapshot and price is not None and size > 0:      # история при подключении: только кластеры и тики
            tick = self.book.key(price)
            self.clusters.add(tick, side, size, parse_ts(trade.get("timestamp")))
            self.tickstore.add(tick, price, side, size, trade.get("timestamp", ""))
            self._schedule_paint()
            return
        if price is not None and size > 0:
            tick = self.book.key(price)
            self.book.last = price
            dt = parse_ts(trade.get("timestamp"))
            self.clusters.add(tick, side, size, dt)
            self.tickstore.add(tick, price, side, size, trade.get("timestamp", ""))
            if s.notify_tick_big and size >= s.tick_big:
                self.notify(f"Крупная сделка {size} @ {fmt_price(price, self.decimals)}", "signal",
                            title="крупная сделка", price=price)
            prev = self._prev_last_tick
            if prev is not None and s.notify_signal_level:
                for lvl in self.ladder.signal_levels:
                    if (prev < lvl <= tick) or (prev > lvl >= tick):
                        level = self.book.price(lvl)
                        self.notify(f"Сигнальный уровень {fmt_price(level, self.decimals)}", "alert",
                                    title="сигнальный уровень", price=level)
            self._prev_last_tick = tick
            self.trader.on_trade(tick, size)

        if side == "BUY":
            self.delta_interval += size
            self.cumulative_delta += size
        elif side == "SELL":
            self.delta_interval -= size
            self.cumulative_delta -= size

        self.interval_trades += 1
        self.interval_volume += size
        self.total_trades += 1
        self.total_volume += size
        self._schedule_paint()

    def on_status(self, status):
        self._status_base = status
        self._update_status()
        live = status == "STREAMING"
        self._conn_tip = "Поток данных: идёт" if live else f"Поток данных: не идёт ({status})"
        self.led_conn.set_state(LED_ON if live else LED_OFF, self._conn_tip_text())
        if live and self._last_error is not None:      # поток снова пошёл — ошибка в прошлом, индикатор гаснет
            self._clear_error_led()

    def on_error(self, message):
        self._status_base = "ERROR: " + message
        self._update_status()
        self.status_label.setToolTip(message)
        self._last_error = (datetime.now().strftime("%H:%M:%S"), message)
        self.led_err.set_state(LED_ERR, f"Ошибка в {self._last_error[0]}:\n{message}\n\nЩелчок — сбросить")

    def _clear_error_led(self):
        """Погасить индикатор ошибки (щелчок по нему или поток снова пошёл); текст последней — в подсказке."""
        tip = "Ошибок нет"
        if self._last_error is not None:
            tip = f"Сейчас ошибок нет.\nПоследняя — в {self._last_error[0]}:\n{self._last_error[1]}"
        self.led_err.set_state(LED_NO_ERR, tip)

    def set_active(self, on: bool) -> None:
        """Рамка вокруг активного стакана (того, где мышь / фокус и куда идут горячие клавиши).
        Цвет — «Настройки» → «Цвета» → «Выделение активного стакана»; галочка там же выключает рамку."""
        self._active = bool(on)
        try:
            color = appearance.active_frame_color() if on and appearance.active_frame_enabled() else "transparent"
        except Exception:
            color = "transparent"
        self._root.setStyleSheet(f"QWidget#stackroot {{ border: {appearance.ACTIVE_FRAME_PX}px solid {color}; }}")

    def _on_appearance_changed(self):
        """Сохранены цвета или шрифты («Настройки»): перечитать и перерисовать стакан, тики, кластеры и ленту.
        Высота строки меняется, только если её поменяли в настройках (масштаб колесом иначе сохраняется)."""
        old_row = self.ladder.base_row_h
        apply_dom_theme()
        self.set_active(self._active)            # цвет рамки / вкл-выкл
        if FONTS.dom_row != old_row:
            self.ladder.base_row_h = FONTS.dom_row
            self.ladder.set_row_h(FONTS.dom_row)
        self.ladder.update()
        self.tape.update()

    def _conn_tip_text(self) -> str:
        """Подсказка зелёного индикатора: поток данных, пинг до Finam, лаг ленты, отклик заявки."""
        lines = [getattr(self, "_conn_tip", "Поток данных: не идёт")]
        try:
            import status_clock
            ping = status_clock.ping_stats()
        except Exception:
            ping = None
        if ping and "last" in ping:
            lines.append(f"Пинг до Finam: {ping['last']:.0f} мс")
            lines.append(f"   средний {ping['avg']:.0f} · лучший {ping['min']:.0f} · худший {ping['max']:.0f} мс "
                         f"(последние {ping['n']}, раз в 10 с)")
            if ping["age"] > 60:
                lines.append(f"   последний замер {ping['age']:.0f} с назад")
        elif ping and ping.get("error"):
            lines.append(f"Пинг до Finam: нет ответа ({ping['error']})")
        else:
            lines.append("Пинг до Finam: ещё не измерен")
        if self._lag_ms is not None:
            lines.append(f"Лента сделок: лаг {self._lag_ms:.0f} мс" if self._lag_ms >= 0
                         else "Лента сделок: лаг не определить (часы ПК и биржи расходятся)")
        rtt = getattr(self.gateway, "last_rtt_ms", None)
        if rtt is not None:
            lines.append(f"Последняя заявка: ответ за {rtt:.0f} мс")
        return "\n".join(lines)

    def _net_text(self):
        """Задержка ленты (локальное время − время биржи; точна при синхронных часах) и отклик заявки."""
        parts = []
        if self._lag_ms is not None:
            parts.append(f"лаг {self._lag_ms:.0f} мс" if self._lag_ms >= 0 else "лаг ? (часы)")
        rtt = getattr(self.gateway, "last_rtt_ms", None)
        if rtt is not None:
            parts.append(f"заявка {rtt:.0f} мс")
        return ("  /  " + "  /  ".join(parts)) if parts else ""

    def reset_interval(self):
        self.delta_interval = 0
        self.interval_trades = 0
        self.interval_volume = 0

    def _check_algo_icebergs(self):
        """Раз в секунду: айсберги из «Алгоритмов» по инструменту окна. Набор изменился — кадр стакана
        (полоса появляется и снимается без ожидания сделки). Уведомления о них даёт сама вкладка «Алгоритмы»."""
        if not self.s.detect_iceberg:
            return
        try:
            import mm_marks
            marks = [m for m in mm_marks.board().marks_for(self.symbol, time.time())
                     if m.get("kind") == mm_marks.ICEBERG]
        except Exception:
            return
        current = {(round(float(m["price"]), 8), m.get("side")) for m in marks}
        if current == self._ice_seen:
            return
        self._ice_seen = current
        self._schedule_paint()

    def _refresh_algo_icons(self):
        """Раз в секунду: значки «Алгоритмов» по инструменту окна (те же, что в столбике графика) — стакану."""
        icons = []
        if self.s.algo_icons and _ALGO_EVENTS is not None:
            try:
                import algo_icons
                icons = algo_icons.from_events(
                    _ALGO_EVENTS(self.symbol), algo_icons.clock_in(_DISPLAY_TZ()), _algo_icon_colors(),
                    keep_sec=appearance.icons_keep_sec(), capacity=self.ladder.icon_capacity())
            except Exception as exc:                      # noqa: BLE001 — значки не должны мешать стакану
                if not getattr(self, "_algo_icons_error", False):
                    self._algo_icons_error = True
                    print(f"[стакан {self.symbol}] значки «Алгоритмов»: {type(exc).__name__}: {exc}", file=sys.stderr)
                icons = []
        self.ladder.set_algo_icons(icons)

    def refresh(self):
        bid_t, ask_t = self.book.best()
        if bid_t is not None and ask_t is not None:
            spread = fmt_price((ask_t - bid_t) * self.book.tick, self.decimals)
        else:
            spread = "—"
        self.info_label.setText(
            f"спред {spread}  /  Δ/с {self.delta_interval:+,}  /  ΣΔ {self.cumulative_delta:+,}  /  "
            f"{self.interval_trades} сд/с  /  {self.trader.realized_text()}{self._net_text()}"
        )
        self.trader.on_quotes()
        now = time.monotonic()
        if now - getattr(self, "_conn_tip_at", 0.0) >= 1.0:   # подсказка с пингом — не чаще раза в секунду
            self._conn_tip_at = now
            self.led_conn.setToolTip(self._conn_tip_text())
            self._check_algo_icebergs()
            self._refresh_algo_icons()
        # Раньше каждый тик этого таймера (10 раз в секунду) заказывал и кадр стакана — у тихого инструмента
        # стакан перерисовывался 10 раз в секунду без единого изменения (10 стаканов — сотни лишних кадров).
        # Стакан и сделки заказывают кадр сами (on_book / on_trade); отсюда — только когда изменились
        # заявки / позиция / TP-SL (их может поменять on_quotes) и раз в REFRESH_FRAME_SEC на всякий случай.
        # (2.0.98: было раз в секунду — ночью 10 стаканов без единого изменения ~25 мс GUI в секунду.)
        self._update_info_panel()
        sig = self._trader_sig()
        now = time.monotonic()
        if sig != self.__dict__.get("_last_trader_sig") or now - self.__dict__.get("_last_refresh_frame", 0.0) >= self.REFRESH_FRAME_SEC:
            self._last_trader_sig = sig
            self._last_refresh_frame = now
            self._schedule_paint()

    REFRESH_FRAME_SEC = 5.0

    def _trader_sig(self):
        """Всё, что стакан рисует от заявок и позиции: если не изменилось — кадр по таймеру не нужен."""
        tr = self.trader
        gw = tr.gw
        try:
            tp, sl = tr.tp_virtual_tick(), tr.sl_tick()
        except Exception:
            tp = sl = None
        return (gw.pos_qty, tuple((o.tick, o.qty) for o in gw.orders), tp, sl,
                getattr(gw, "broker_unrealized", None))

    def live_exposure(self) -> str:
        """LIVE: что останется на счёте при закрытии окна — «позиция +1, активных заявок 2…»; иначе ""."""
        if getattr(self.gateway, "name", "") != "LIVE":
            return ""
        active_orders = list(getattr(self.gateway, "orders", []))
        position = int(getattr(self.gateway, "pos_qty", 0) or 0)
        try:
            pending_submits = int(self.gateway.pending_count())
        except Exception:
            pending_submits = 0
        if not (active_orders or position or pending_submits):
            return ""
        parts = [f"{getattr(self, 'symbol', '')}: позиция {position:+d}"]
        if active_orders:
            parts.append(f"активных заявок {len(active_orders)}")
        if pending_submits:
            parts.append(f"не подтверждённых отправок {pending_submits}")
        return ", ".join(parts)

    def closeEvent(self, event):
        global _ACTIVE_STACK
        if _ACTIVE_STACK is self:
            _ACTIVE_STACK = None
        # В LIVE не закрываем окно молча, если есть риск оставить позицию или работающие заявки на сервере.
        # Само закрытие окна ничего не отменяет. При выходе из терминала менеджер спрашивает один раз за все
        # окна (ScalperManager.shutdown) и ставит _exit_confirmed — тогда второй раз не спрашиваем.
        exposure = self.live_exposure()
        if exposure and not getattr(self, "_exit_confirmed", False):
            answer = QMessageBox.warning(
                self, "LIVE: проверка перед выходом",
                f"{exposure}\n\nЗакрытие НЕ закрывает позицию и НЕ гарантирует снятие заявок.\n"
                "Всё равно закрыть?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                event.ignore()
                return
        self.save()
        self.engine.stop()
        self.gateway.shutdown()
        event.accept()


# -----------------------------------------------------------------------------
# Внутри FX Terminal: окно с выбором инструмента, шаг цены у брокера, несколько окон
# -----------------------------------------------------------------------------
#
# TerminalScalperWindow — ScalperWindow (PAPER) + в шапке «Инструмент» с автодополнением и «Каталог…».
# Смена инструмента заменяет окно новым на том же месте (стакан, кластеры, тики и торговая логика
# строятся заново под инструмент и его шаг цены).
# ScalperManager — несколько окон одновременно, шаг цены инструмента берётся у брокера
# (GetAsset: min_step / 10^decimals) и кэшируется в конфиге (ключ "ticks", значение можно править вручную).

# Окон стакана одновременно. Потоки у брокера от числа окон почти не растут (окна на один инструмент
# делят поток через MarketDataHub); растёт отрисовка — её видно в «Состояние подключения» → «Нагрузка».
MAX_WINDOWS = 25
TICK_TIMEOUT_MS = 20_000

_HEADER_QSS_DARK = (
    "QComboBox{background:#0e1620;color:#eef2f6;border:1px solid #2f4658;padding:0 6px;"
    "min-height:18px;max-height:20px;font-family:Tahoma;font-size:11px;}"
    "QComboBox:hover{border-color:#4a8a80;}"
    "QComboBox QAbstractItemView{background:#14202c;color:#eef2f6;"
    "selection-background-color:#2a6a60;outline:0;}"
    "QPushButton{background:#1d2c3a;color:#eef2f6;border:1px solid #2f4658;padding:0 10px;"
    "min-height:18px;max-height:20px;font-family:Tahoma;font-size:11px;}"
    "QPushButton:hover{background:#27394a;}"
    "QPushButton:disabled{color:#6b7684;}"
)
_HEADER_QSS_LIGHT = (
    "QComboBox{background:#f6f6f6;color:#1e1e1e;border:1px solid #b4b4b4;padding:0 6px;"
    "min-height:18px;max-height:20px;font-family:Tahoma;font-size:11px;}"
    "QComboBox:hover{border-color:#2a8a80;}"
    "QComboBox QAbstractItemView{background:#f6f6f6;color:#1e1e1e;"
    "selection-background-color:#cddff5;selection-color:#0f3d73;outline:0;}"
    "QPushButton{background:#e4e4e4;color:#1e1e1e;border:1px solid #b4b4b4;padding:0 10px;"
    "min-height:18px;max-height:20px;font-family:Tahoma;font-size:11px;}"
    "QPushButton:hover{background:#d6d6d6;}"
    "QPushButton:disabled{color:#a0a0a0;}"
)


def _header_qss() -> str:
    return _HEADER_QSS_LIGHT if _light_theme() else _HEADER_QSS_DARK


# -----------------------------------------------------------------------------
# Шаг цены инструмента
# -----------------------------------------------------------------------------

def fetch_tick(secret: str, account_id: str, symbol: str) -> float:
    """Шаг цены из каталога брокера: min_step / 10^decimals (блокирующий вызов — только из потока).

    Через общее соединение терминала (то же, что у хаба и заявок)."""
    session = _current_trading_session()
    if session is None:
        raise RuntimeError("нет соединения терминала с Finam")
    resp = session.client().assets.GetAsset(
        GetAssetRequest(symbol=symbol, account_id=account_id or ""))
    step, decimals = int(resp.min_step), int(resp.decimals)
    if step <= 0 or decimals < 0:
        raise ValueError(f"брокер вернул шаг цены min_step={step}, decimals={decimals}")
    return float(Decimal(step).scaleb(-decimals))


def pick_position(avail: QRect, size: QSize, taken: list) -> QPoint:
    """
    Куда поставить новое окно: стаканы удобнее держать рядом, поэтому сначала ищем свободную
    «колонку» слева направо вдоль верхнего края экрана; если все заняты — каскад со сдвигом 30 px.
    taken — левые верхние углы уже открытых окон.
    """
    w, h = size.width(), size.height()
    y = max(avail.top(), min(avail.top() + 30, avail.bottom() - h))
    x = avail.left() + 20
    while x + w <= avail.right() + 1:
        if not any(abs(p.x() - x) < 60 and abs(p.y() - y) < 60 for p in taken):
            return QPoint(x, y)
        x += w + 10
    off = (len(taken) % 8) * 30
    return QPoint(min(avail.left() + 20 + off, max(avail.left(), avail.right() - w)),
                  min(y + off, max(avail.top(), avail.bottom() - h)))


def _fmt_tick(tick: float) -> str:
    return f"{tick:.{tick_decimals(tick)}f}".replace(".", ",")


# -----------------------------------------------------------------------------
# Окно
# -----------------------------------------------------------------------------

class LiveConfirmDialog(QDialog):
    """Подтверждение включения LIVE: реальные заявки, счёт, инструмент, лимиты риска (как --max-pos / --max-lot)."""

    def __init__(self, parent, symbol_text, tick, account, max_pos=5, max_lot=5, max_daily_loss=0.0):
        super().__init__(parent)
        self.setWindowTitle("Включить LIVE?")
        self.setModal(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(8)
        head = QLabel("Будут выставляться РЕАЛЬНЫЕ заявки.")
        head.setStyleSheet("color:#d9363e;font-weight:bold;font-size:13px;")
        info = QLabel(f"Счёт: {account}\nИнструмент: {symbol_text}\nШаг цены: {_fmt_tick(tick)}")
        info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(head)
        lay.addWidget(info)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        self.spin_pos = QSpinBox()
        self.spin_pos.setRange(1, 100_000)
        self.spin_pos.setValue(max(1, int(max_pos)))
        self.spin_lot = QSpinBox()
        self.spin_lot.setRange(1, self.spin_pos.value())
        self.spin_lot.setValue(max(1, min(int(max_lot), self.spin_pos.value())))
        self.spin_pos.valueChanged.connect(self._sync_lot_limit)
        grid.addWidget(QLabel("Лимит позиции, контрактов:"), 0, 0)
        grid.addWidget(self.spin_pos, 0, 1)
        grid.addWidget(QLabel("Максимальный лот одной заявки:"), 1, 0)
        grid.addWidget(self.spin_lot, 1, 1)
        # Общий для всех LIVE-окон терминала: при убытке дня больше лимита новые входы закрываются.
        self.spin_loss = QSpinBox()
        self.spin_loss.setRange(0, 100_000_000)
        self.spin_loss.setSingleStep(1000)
        self.spin_loss.setSuffix(" ₽")
        self.spin_loss.setSpecialValueText("без лимита")
        self.spin_loss.setValue(max(0, int(max_daily_loss or 0)))
        self.spin_loss.setToolTip("Один на весь терминал. Достигнут — новые входы закрыты до конца дня "
                                  "(по Москве); закрывать позиции и снимать заявки можно.")
        grid.addWidget(QLabel("Дневной лимит убытка (все окна):"), 2, 0)
        grid.addWidget(self.spin_loss, 2, 1)
        lay.addLayout(grid)
        note = QLabel("Закрытие окна НЕ закрывает позицию и НЕ снимает заявки на бирже.")
        note.setWordWrap(True)
        lay.addWidget(note)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn_ok = QPushButton("Включить LIVE")
        self.btn_ok.setAutoDefault(False)
        self.btn_ok.setStyleSheet("QPushButton{background:#b3262d;color:#fff;font-weight:bold;padding:4px 14px;}"
                                  "QPushButton:hover{background:#cf3037;}")
        self.btn_cancel = QPushButton("Отмена")
        self.btn_cancel.setDefault(True)                     # Enter / Esc по умолчанию — отмена
        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_ok)
        row.addWidget(self.btn_cancel)
        lay.addLayout(row)

    def _sync_lot_limit(self, pos):
        self.spin_lot.setMaximum(max(1, pos))                # лот не может быть больше лимита позиции

    def limits(self):
        return self.spin_pos.value(), self.spin_lot.value()

    def max_daily_loss(self):
        return float(self.spin_loss.value())


class _SymbolLineEdit(QLineEdit):
    """Esc / Enter в поле инструмента — его собственные (отмена / выбор), не горячие клавиши окна."""
    cancelled = Signal()

    def event(self, e):
        if e.type() == QEvent.ShortcutOverride and e.key() in (Qt.Key_Escape, Qt.Key_Return, Qt.Key_Enter):
            e.accept()
            return True
        return super().event(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.cancelled.emit()
            return
        super().keyPressEvent(e)


class TerminalScalperWindow(ScalperWindow):
    """ScalperWindow с выбором инструмента, каталогом и переключателем PAPER / LIVE в шапке."""
    closed = Signal(object)

    def __init__(self, manager: "ScalperManager", symbol, secret, tick, settings, cfg, account=None,
                 live=False, max_pos=5, max_lot=5, embedded=False):
        super().__init__(symbol, secret, tick, settings, cfg, autostart=True, live=live, account=account,
                         max_pos=max_pos, max_lot=max_lot, embedded=embedded)
        self._mgr = manager
        self.tick_size = tick
        self.live = bool(live)
        self.limits = (max_pos, max_lot)
        self._dead = False
        self.setWindowTitle(f"Стакан {manager.friendly(symbol)} [{self.gateway.name}] · шаг {_fmt_tick(tick)}")
        # Со связью окон квадрат группы живёт в заголовке окна (иконка | квадрат | название): системная шапка
        # виджеты не принимает, поэтому её заменяет собственная строка заголовка (window_links.install_link_titlebar).
        self._chrome = None
        self._replacing = False        # окно заменяется новым (смена инструмента/режима): его место в докинге сохраняется
        if manager.hub is not None and not embedded:     # панель докинга: заголовок рисует докинг, квадрат — в строке шапки
            try:
                from window_links import install_link_titlebar
                self._chrome = install_link_titlebar(self, manager.hub, self, live=self.live)
            except ImportError:
                self._chrome = None
        self._build_instrument_controls()
        self._build_mode_badge()

    # ---- шапка: переключатель PAPER / LIVE ----------------------------------------

    def _build_mode_badge(self):
        """Бейдж режима вместо прежней подписи: клик — переключить PAPER <-> LIVE (LIVE — после подтверждения)."""
        row = self.tab_header.layout()
        old = None
        for i in range(row.count()):
            w = row.itemAt(i).widget()
            if isinstance(w, QLabel) and w.text() == self.gateway.name:
                old = w
                break
        color, hover = ("#c0272d", "#d6333a") if self.live else ("#2e8b3a", "#38a447")
        badge = QPushButton(self.gateway.name)
        badge.setFocusPolicy(Qt.NoFocus)
        badge.setCursor(Qt.PointingHandCursor)
        badge.setStyleSheet(
            f"QPushButton{{background:{color};color:#fff;border:none;padding:1px 10px;font-family:Tahoma;"
            f"font-size:11px;font-weight:bold;min-height:18px;max-height:20px;}}"
            f"QPushButton:hover{{background:{hover};}}")
        badge.setToolTip(
            ("LIVE — реальные заявки. Клик — вернуться в PAPER (симуляцию)." if self.live else
             "PAPER — симуляция, заявки на биржу не уходят. Клик — включить LIVE (реальные заявки), потребуется подтверждение."))
        badge.clicked.connect(self._on_mode_clicked)
        if self._chrome is not None:                       # со своей шапкой переключатель режима — в строке заголовка
            if old is not None:
                old.hide()
            self._chrome.titlebar.set_accessory(badge)
        elif old is not None:
            row.insertWidget(row.indexOf(old), badge)
            old.hide()
        else:
            row.insertWidget(2, badge)
        self.mode_btn = badge
        if self.live:                                      # LIVE виден издалека: красная шапка
            self.tab_header.setStyleSheet("QWidget#tabheader{background:#2a1015;border-bottom:2px solid #c0272d;}")
            if self._chrome is not None:
                self._chrome.titlebar.set_live(True)       # и красная строка заголовка окна

    def _on_mode_clicked(self):
        self.ladder.setFocus()
        self._mgr.switch_mode(self, not self.live)

    # ---- связь окон по цветным группам (window_links.LinkHub) ----------------------------

    def link_symbol(self):
        return self.symbol

    def link_apply(self, symbol):
        """Переключить инструмент по команде хаба: тот же путь, что и выбор в списке (для LIVE — с подтверждением)."""
        if symbol and symbol != self.symbol and not self._dead:
            self._mgr.switch_symbol(self, symbol, from_link=True)

    def link_widget(self):
        return self

    def link_set_compact(self, compact):
        """Настройка «Скрывать инструмент и каталог». Со своей шапкой прячется вся строка с полем инструмента —
        её высота достаётся стакану (переключатель режима живёт в заголовке). С системной шапкой прячутся только
        поле инструмента и «Каталог…»: в строке остаётся бейдж режима."""
        self._compact = bool(compact)
        if self._chrome is not None:
            self.tab_header.setVisible(not compact)
        else:
            self.sym_combo.setVisible(not compact)
            self.catalog_btn.setVisible(not compact)

    # ---- шапка: инструмент + каталог --------------------------------------------

    def _build_instrument_controls(self):
        row = self.tab_header.layout()
        for i in range(row.count()):                       # прежняя подпись с названием не нужна — есть список
            w = row.itemAt(i).widget()
            if w is not None and w.objectName() == "tabname":
                w.hide()

        combo = QComboBox()
        combo.setEditable(True)
        combo.setLineEdit(_SymbolLineEdit())
        combo.setInsertPolicy(QComboBox.NoInsert)
        combo.setFixedWidth(178)
        combo.setToolTip("Инструмент: выберите из списка или введите тикер (например CNYRUB_TOM@MISX) и нажмите Enter")
        combo.setStyleSheet(_header_qss())
        symbols = list(self._mgr.symbols())
        if self.symbol not in symbols:
            symbols.insert(0, self.symbol)
        for s in symbols:
            combo.addItem(self._mgr.friendly(s), userData=s)
        combo.view().setMinimumWidth(210)
        catalog = self._mgr.catalog_symbols()
        if catalog:
            completer = QCompleter(catalog, combo)
            completer.setCaseSensitivity(Qt.CaseInsensitive)
            completer.setFilterMode(Qt.MatchContains)
            completer.setCompletionMode(QCompleter.PopupCompletion)
            combo.setCompleter(completer)
        self.sym_combo = combo
        self._restore_combo()

        btn = QPushButton("Каталог…")
        btn.setToolTip("Выбрать инструмент из каталога брокера")
        btn.setFocusPolicy(Qt.NoFocus)
        btn.setStyleSheet(_header_qss())
        btn.clicked.connect(self._on_catalog)
        self.catalog_btn = btn

        row.insertWidget(0, combo)
        row.insertWidget(1, btn)
        hub = self._mgr.hub
        if hub is not None and self._chrome is None:       # системная шапка: квадратик группы — сразу за полем инструмента
            self.link_btn = hub.make_button(self)
            row.insertWidget(1, self.link_btn)

        combo.activated.connect(self._on_combo_activated)
        combo.lineEdit().returnPressed.connect(self._on_combo_enter)
        combo.lineEdit().cancelled.connect(self._restore_combo)

    def _restore_combo(self):
        combo = self.sym_combo
        combo.blockSignals(True)
        idx = combo.findData(self.symbol)
        if idx < 0:
            combo.addItem(self._mgr.friendly(self.symbol), userData=self.symbol)
            idx = combo.count() - 1
        combo.setCurrentIndex(idx)
        combo.blockSignals(False)

    def _on_combo_activated(self, index):
        sym = self.sym_combo.itemData(index)
        if sym:
            self._request_symbol(str(sym))

    def _on_combo_enter(self):
        text = self.sym_combo.currentText().strip()
        idx = self.sym_combo.findText(text)
        sym = str(self.sym_combo.itemData(idx)) if idx >= 0 and self.sym_combo.itemData(idx) else self._mgr.from_friendly(text)
        if "@" not in sym:
            self.flash(f"«{text}»: введите тикер вида TICKER@MIC или выберите инструмент в каталоге")
            self._restore_combo()
            return
        self._request_symbol(sym)

    def _on_catalog(self):
        sym = self._mgr.pick_symbol(self)
        if sym:
            self._request_symbol(sym)

    def _request_symbol(self, sym: str):
        sym = sym.strip()
        self.ladder.setFocus()
        if not sym or sym == self.symbol:
            self._restore_combo()
            return
        self._mgr.switch_symbol(self, sym)

    # ---- закрытие ---------------------------------------------------------------------

    def closeEvent(self, event):
        super().closeEvent(event)
        if event.isAccepted() and not self._dead:
            self._dead = True
            self.closed.emit(self)


class ScalperPlaceholder(QLabel):
    """Заглушка на месте стакана при восстановлении раскладки: настоящее окно открывается после подключения
    к Finam (оно поднимает собственные gRPC-потоки — на старте терминала этого делать не нужно)."""

    def __init__(self, symbol: str, friendly: str):
        super().__init__(f"Стакан {friendly}\nоткроется после подключения к Finam")
        self.symbol = symbol
        self.dead = False
        self.setAlignment(Qt.AlignCenter)

    def closeEvent(self, event):
        self.dead = True
        event.accept()


# -----------------------------------------------------------------------------
# Менеджер окон
# -----------------------------------------------------------------------------

class _GuardRelay(QObject):
    """Исполнения и позиция LIVE-окна -> дневной лимит убытка менеджера (в GUI-потоке)."""

    def __init__(self, manager, win):
        super().__init__(win)
        self._manager, self._win = manager, win
        # Шлюз сообщает о позиции только при смене количества или средней цены, а нереализованный результат
        # меняется постоянно. Без опроса лимит считал открытую позицию по значению на момент последней
        # сделки и растущего убытка не видел.
        from services.live_guard import POLL_MS
        self._poll = QTimer(self)
        self._poll.timeout.connect(self.on_position)
        self._poll.start(POLL_MS)
        win.closed.connect(lambda *_: self._poll.stop())      # окно закрыто — его шлюз остановлен

    def on_fill(self, side, price, qty):
        guard = self._manager.guard
        was = guard.blocked
        guard.on_fill(self._win.symbol, side, price, qty)
        self._manager._after_guard_event(was)

    def on_position(self):
        # Пока шлюз не получил позицию от брокера, его pos_qty == 0 — это «ещё не знаем». Раньше этот ноль
        # уходил в лимит как стартовая позиция (окно открыли или терминал перезапустили при открытой
        # позиции), и её закрытие считалось открытием встречной: убыток в дневной лимит не попадал.
        from services.live_guard import feed_position
        guard = self._manager.guard
        was = guard.blocked
        feed_position(guard, self._win.symbol, self._win.gateway)
        self._manager._after_guard_event(was)


class ScalperManager(QObject):
    """Несколько окон «Стакан»: открытие, смена инструмента, меню открытых окон, закрытие всех."""

    _tick_ready = Signal(int, float, str)    # id запроса, шаг (0 — ошибка), текст ошибки
    _positions_ready = Signal(int, object, str)   # id запроса, {инструмент: позиция} у брокера, текст ошибки
    _multiplier_ready = Signal(str, float)   # символ, множитель (для дневного лимита убытка)

    def __init__(self, host, *, credentials: Callable[[], tuple[str, str]],
                 default_symbol: Callable[[], str], symbols: Callable[[], list],
                 catalog_symbols: Callable[[], list], pick_symbol: Callable[[QObject], str | None],
                 friendly: Callable[[str], str], from_friendly: Callable[[str], str],
                 max_windows: int = MAX_WINDOWS, hub=None,
                 placer=None, swapper=None, raiser=None, remover=None):
        super().__init__(host)
        self.host = host
        self.hub = hub                           # window_links.LinkHub или None (отдельный запуск без связи окон)
        # Режим докинга (задан placer): окна — панели рабочих пространств терминала.
        #   placer(win)        — поставить новое окно панелью;
        #   swapper(old, new)  — новое окно встаёт на место прежнего (смена инструмента/режима), True — получилось;
        #   raiser(win)        — показать окно (переключить вкладку, поднять пространство);
        #   remover(win)       — окно закрылось само: убрать его панель.
        self._placer, self._swapper, self._raiser, self._remover = placer, swapper, raiser, remover
        self._placeholders: list[ScalperPlaceholder] = []
        self._credentials = credentials
        self._default_symbol = default_symbol
        self._symbols = symbols
        self._catalog_symbols = catalog_symbols
        self._pick_symbol = pick_symbol
        self._friendly = friendly
        self._from_friendly = from_friendly
        self.max_windows = max_windows
        self.cfg = load_config()             # один словарь на все окна: иначе их сохранения затирали бы друг друга
        self.windows: list[TerminalScalperWindow] = []
        self._pending: dict[int, dict] = {}
        self._pending_windows: set[int] = set()
        self._req_seq = 0
        self._tick_ready.connect(self._on_tick_ready)
        # Восстановление раскладки: позиции у брокера на момент подключения. Окно стакана инструмента с открытой
        # позицией открывается сразу в LIVE (materialize_placeholders), остальные — как всегда, в PAPER.
        self._positions_ready.connect(self._on_positions_ready)
        self._positions_req = 0                      # id текущего запроса позиций (0 — запроса нет)
        self._restore_stagger_ms = 1500
        self._auto_live: dict[str, int] = {}         # инструмент -> позиция: открыть в LIVE без диалога
        self._auto_live_taken: set[str] = set()      # инструменты, для которых LIVE-окно уже открывается
        # Дневной лимит убытка LIVE — один на все окна; состояние дня — рядом с конфигом стакана.
        from services.live_guard import DayLossGuard
        self.guard = DayLossGuard(
            float((self.cfg.get("live_limits") or {}).get("max_daily_loss", 0) or 0),
            state_path=CONFIG_PATH.with_name(".fx_live_guard.json"))
        self._multiplier_ready.connect(self.guard.set_multiplier)

    # ---- доступ для окон ----------------------------------------------------------

    def symbols(self):
        return self._symbols()

    def catalog_symbols(self):
        return self._catalog_symbols()

    def friendly(self, symbol):
        return self._friendly(symbol)

    def from_friendly(self, text):
        return self._from_friendly(text)

    def pick_symbol(self, parent):
        return self._pick_symbol(parent)

    # ---- открытие / смена инструмента ----------------------------------------------

    def open_new(self, symbol: str | None = None):
        """Новое окно стакана (клик по кнопке). Каждый клик — ещё одно окно, до max_windows."""
        if len(self._alive()) >= self.max_windows:
            QMessageBox.information(self.host, "Стакан", f"Открыто максимальное число окон: {self.max_windows}.")
            return
        self._open(str(symbol or self._default_symbol() or DEFAULT_SYMBOL), template=None, replace=None)

    def switch_symbol(self, window: TerminalScalperWindow, symbol: str, from_link: bool = False):
        """Заменить инструмент в окне: новое окно встаёт на то же место, прежнее закрывается. Режим сохраняется
        (для LIVE подтверждение запрашивается заново — инструмент другой). from_link — смену запросил хаб связи
        окон, тогда остальным окнам группы её повторно не рассылаем."""
        if id(window) in self._pending_windows:
            return
        self._open(symbol, template=window, replace=window, live=window.live, propagate=not from_link)

    def switch_mode(self, window: TerminalScalperWindow, live: bool):
        """PAPER <-> LIVE: окно заменяется новым в нужном режиме (для LIVE — после подтверждения и с лимитами риска)."""
        if live == window.live or id(window) in self._pending_windows:
            return
        secret, account = self._credentials()
        if not secret:
            QMessageBox.warning(self.host, "Стакан", "Не задан токен Finam. Укажите его в «Настройки…» и подключитесь.")
            return
        self._finish_open(window.symbol, window.tick_size, window, window, secret, account, live, propagate=False)

    def _saved_live_limits(self) -> tuple[int, int]:
        """(лимит позиции, макс. лот) из последнего подтверждения LIVE; ничего не сохранено — 5 и 5."""
        saved = self.cfg.get("live_limits") or {}
        try:
            return int(saved.get("max_pos", 5)), int(saved.get("max_lot", 5))
        except (TypeError, ValueError):
            return 5, 5

    def _confirm_live(self, parent, symbol, tick, account):
        """Диалог подтверждения LIVE. Возвращает (лимит позиции, макс. лот) или None, если пользователь отказался."""
        max_pos, max_lot = self._saved_live_limits()
        dlg = LiveConfirmDialog(parent, self._friendly(symbol), tick, account, max_pos, max_lot,
                                max_daily_loss=self.guard.limit)
        if dlg.exec() != QDialog.Accepted:
            return None
        max_pos, max_lot = dlg.limits()
        self.guard.set_limit(dlg.max_daily_loss())
        self.cfg["live_limits"] = {"max_pos": max_pos, "max_lot": max_lot, "max_daily_loss": self.guard.limit}
        self.cfg.pop("live_engine", None)                 # ключ прежней версии (выбор торгового модуля)
        save_config(self.cfg)
        return max_pos, max_lot

    # ---- восстановление раскладки (докинг) ----------------------------------------------

    def restore_placeholder(self, symbol: str) -> ScalperPlaceholder:
        """Заглушка вместо стакана для раскладки; настоящее окно — после подключения (materialize_placeholders)."""
        placeholder = ScalperPlaceholder(symbol, self._friendly(symbol))
        self._placeholders.append(placeholder)
        return placeholder

    POSITIONS_TIMEOUT_MS = 5000      # сколько ждать позиции от брокера перед восстановлением окон

    def materialize_placeholders(self, stagger_ms: int = 1500) -> None:
        """Открывает настоящие окна на местах заглушек, по одному с паузой (у каждого окна свой gRPC-канал).

        Сначала у брокера запрашиваются открытые позиции счёта: окно инструмента, которое было в LIVE при
        закрытии терминала и по которому позиция ещё есть (_pick_auto_live), открывается сразу в LIVE — без
        диалога подтверждения, с сохранёнными лимитами (иначе после перезапуска
        терминала позиция осталась бы без Stop-Loss / Take-Profit окна и без учёта в дневном лимите, пока LIVE
        не включат вручную). Нет счёта, нет ответа за POSITIONS_TIMEOUT_MS или ошибка — все окна в PAPER,
        в журнале строка, почему."""
        self._restore_stagger_ms = stagger_ms
        if not self._placeholders:
            return
        secret, account = self._credentials()
        session = _current_trading_session()
        if not secret or not account or session is None:
            self._on_positions_ready(0, {}, "" if not account else "нет соединения терминала с Finam")
            return
        self._req_seq += 1
        req = self._positions_req = self._req_seq

        def work():
            try:
                from brokers.finam.live import fetch_open_positions
                self._positions_ready.emit(req, fetch_open_positions(session, account), "")
            except Exception as exc:                     # noqa: BLE001
                self._positions_ready.emit(req, {}, rpc_text(exc))

        threading.Thread(target=work, daemon=True, name="scalper-positions").start()
        QTimer.singleShot(self.POSITIONS_TIMEOUT_MS,
                          lambda r=req: self._on_positions_ready(r, {}, "нет ответа от брокера (таймаут)"))

    def _on_positions_ready(self, req: int, positions, error: str) -> None:
        """Позиции получены (или нет): расставить окна на места заглушек."""
        if req != self._positions_req:                    # уже обработан (ответ или таймаут)
            return
        self._positions_req = 0
        if error:
            print(f"[LIVE] позиции у брокера при запуске не получены ({error}) — окна стакана открываются "
                  "в PAPER; если позиция есть, включите LIVE вручную", file=sys.stderr)
        self._auto_live = self._pick_auto_live(dict(positions or {}))
        self._auto_live_taken = set()
        if not error:
            # Список приводится к тому, что сейчас вернётся в LIVE: окно, оставшееся в PAPER (позиции уже нет),
            # из него уходит. Позиции получить не удалось — список не трогаем: LIVE включат вручную.
            keep = sorted(self._auto_live)
            if self.cfg.get(self.LIVE_WINDOWS_KEY) != keep:
                self.cfg[self.LIVE_WINDOWS_KEY] = keep
                save_config(self.cfg)
        for i, placeholder in enumerate(list(self._placeholders)):
            QTimer.singleShot(i * self._restore_stagger_ms, lambda p=placeholder: self._materialize(p))

    LIVE_WINDOWS_KEY = "live_windows"      # конфиг стакана: инструменты, окна которых сейчас в LIVE

    def _pick_auto_live(self, positions: dict) -> dict:
        """Какие инструменты из восстановленной раскладки открыть в LIVE: окно этого инструмента было в LIVE,
        когда терминал закрыли (или он завис / упал), и позиция у брокера ещё есть.

        До 2.1.38 хватало позиции у брокера. Но на счёте бывают и долгосрочные бумаги (11.11 — шесть позиций,
        которыми стакан никогда не торговал): окажись их стакан в раскладке, он открылся бы в LIVE сам, и
        Stop-Loss / Take-Profit из настроек стакана применились бы к этим бумагам. Теперь LIVE возвращается
        только туда, где он был включён руками. Списка в конфиге ещё нет (первый запуск после обновления) —
        один раз действует прежнее правило, чтобы уже открытое LIVE-окно не потерялось."""
        symbols = {p.symbol for p in self._placeholders}
        was_live = self.cfg.get(self.LIVE_WINDOWS_KEY)
        if was_live is None:
            return {s: q for s, q in positions.items() if s in symbols}
        return {s: q for s, q in positions.items() if s in symbols and s in set(was_live)}

    def _remember_live(self, symbol: str, live: bool) -> None:
        """Отметить в конфиге, что окно инструмента в LIVE (или уже нет) — для _pick_auto_live после перезапуска."""
        current = set(self.cfg.get(self.LIVE_WINDOWS_KEY) or [])
        changed = current | {symbol} if live else current - {symbol}
        if changed != current or self.LIVE_WINDOWS_KEY not in self.cfg:
            self.cfg[self.LIVE_WINDOWS_KEY] = sorted(changed)
            save_config(self.cfg)

    def _materialize(self, placeholder: ScalperPlaceholder) -> None:
        if placeholder not in self._placeholders:
            return
        self._placeholders.remove(placeholder)
        try:
            from shiboken6 import isValid
            if not isValid(placeholder):                  # пространство закрыли вместе с заглушкой
                return
        except Exception:
            pass
        if placeholder.dead or len(self._alive()) >= self.max_windows:
            return                                    # заглушку закрыли до подключения / окон уже максимум
        # Позиция у брокера — первое окно этого инструмента открывается в LIVE (один инструмент — одно LIVE-окно).
        # Окно открывается не мгновенно (шаг цены запрашивается у брокера), поэтому «занято» помечаем сразу.
        live = (placeholder.symbol in self._auto_live and placeholder.symbol not in self._auto_live_taken
                and not any(w.live and w.symbol == placeholder.symbol for w in self._alive()))
        if live:
            self._auto_live_taken.add(placeholder.symbol)
        self._open(placeholder.symbol, template=None, replace=None, live=live, slot=placeholder)

    def _open(self, symbol, template, replace, live=False, propagate=True, slot=None):
        secret, account = self._credentials()
        if not secret:
            QMessageBox.warning(self.host, "Стакан",
                                "Не задан токен Finam. Укажите его в «Настройки…» и подключитесь.")
            if replace is not None:
                replace._restore_combo()
            return
        tick = (self.cfg.get("ticks") or {}).get(symbol)
        try:
            tick = float(tick) if tick else None
        except (TypeError, ValueError):
            tick = None
        if tick and tick > 0:
            self._finish_open(symbol, tick, template, replace, secret, account, live, propagate, slot=slot)
            return
        self._req_seq += 1
        req = self._req_seq
        self._pending[req] = dict(symbol=symbol, template=template, replace=replace, secret=secret, account=account,
                                  live=live, propagate=propagate, slot=slot)
        if replace is not None:
            self._pending_windows.add(id(replace))
        QApplication.setOverrideCursor(Qt.BusyCursor)

        def work():
            try:
                self._tick_ready.emit(req, fetch_tick(secret, account, symbol), "")
            except Exception as exc:                     # noqa: BLE001 — показываем пользователю как есть
                self._tick_ready.emit(req, 0.0, rpc_text(exc))

        threading.Thread(target=work, daemon=True, name="scalper-tick").start()
        QTimer.singleShot(TICK_TIMEOUT_MS, lambda r=req: self._on_tick_ready(r, 0.0, "нет ответа от брокера (таймаут)"))

    def _on_tick_ready(self, req: int, tick: float, error: str):
        job = self._pending.pop(req, None)
        if job is None:                                   # уже обработан (ответ или таймаут)
            return
        QApplication.restoreOverrideCursor()
        replace = job["replace"]
        if replace is not None:
            self._pending_windows.discard(id(replace))
        if error or tick <= 0:
            QMessageBox.warning(
                replace or self.host, "Стакан",
                f"Не удалось определить шаг цены для {job['symbol']}:\n{error or 'пустой ответ'}\n\n"
                "Окно не открыто. Шаг можно задать вручную в ~/.scalper_widget.json (ключ \"ticks\").")
            if replace is not None:
                replace._restore_combo()
            return
        self.cfg.setdefault("ticks", {})[job["symbol"]] = tick
        save_config(self.cfg)
        self._finish_open(job["symbol"], tick, job["template"], replace, job["secret"], job["account"], job["live"],
                          job["propagate"], slot=job.get("slot"))

    def _finish_open(self, symbol, tick, template, replace, secret, account, live=False, propagate=True, slot=None):
        embedded = self._placer is not None
        max_pos, max_lot = 5, 5
        group = self.hub.group_of(replace) if (self.hub is not None and replace is not None) else 0
        if live:
            other = next((w for w in self._alive()
                          if w is not replace and w.live and w.symbol == symbol), None)
            if other is not None:
                # Два LIVE-окна одного инструмента видят одну позицию брокера, но каждое со своими
                # лимитами и TP/SL — они мешали бы друг другу.
                QMessageBox.warning(replace or self.host, "Стакан",
                                    f"{self._friendly(symbol)} уже торгуется в LIVE в другом окне стакана.\n"
                                    "Один инструмент — одно LIVE-окно.")
                if replace is not None:
                    replace._restore_combo()
                self.raise_window(other)
                return
            if not account:
                QMessageBox.warning(replace or self.host, "Стакан",
                                    "Для LIVE нужен id счёта: укажите его в «Настройки…» терминала.")
                if replace is not None:
                    replace._restore_combo()
                return
            # slot без replace — только восстановление раскладки (_materialize); всё остальное — с диалогом
            auto_qty = self._auto_live.get(symbol) if (slot is not None and replace is None) else None
            if auto_qty is not None:
                # Восстановление раскладки при открытой позиции: LIVE без диалога, лимиты — сохранённые.
                max_pos, max_lot = self._saved_live_limits()
                print(f"[LIVE] {self._friendly(symbol)}: у брокера позиция {auto_qty:+d} — окно стакана открыто "
                      f"сразу в LIVE (лимит позиции {max_pos}, макс. лот {max_lot}, дневной лимит убытка "
                      f"{self.guard.limit:.0f} ₽)", file=sys.stderr)
            else:
                limits = self._confirm_live(replace or self.host, symbol, tick, account)
                if limits is None:                            # пользователь отказался — остаёмся как были
                    if replace is not None:
                        replace._restore_combo()
                    return
                max_pos, max_lot = limits
        old_closed = False
        if replace is not None and replace.gateway.name == "LIVE":
            # Из LIVE-окна выходим ДО создания нового: если остались позиция или заявки, оно спросит
            # подтверждение (closeEvent), и при отказе мы остаёмся в нём.
            replace._replacing = True                     # его панель не убираем: на этом месте встанет новое окно
            if not replace.close():
                replace._replacing = False
                replace._restore_combo()
                return
            old_closed = True
        saved = (self.cfg.get("settings") or {}).get(symbol)
        if saved:
            settings = Settings.from_dict(saved)
        elif template is not None:                        # новый инструмент: берём настройки прежнего окна
            settings = template.s.copy()
            settings.step_factor = 1                      # сжатие стакана зависит от шага — сбрасываем
        else:
            settings = Settings()
        try:
            win = TerminalScalperWindow(self, symbol, secret, tick, settings, self.cfg, account,
                                        live=live, max_pos=max_pos, max_lot=max_lot, embedded=embedded)
        except Exception as exc:                          # noqa: BLE001
            QMessageBox.critical(self.host, "Стакан", f"Не удалось открыть окно стакана:\n{exc}")
            if replace is not None and not old_closed:
                replace._restore_combo()
            return
        if not embedded:
            if replace is not None:
                win.resize(replace.size())
                win.move(replace.pos())
            else:
                self._place_new(win)
        win.closed.connect(self._on_closed)
        self.windows.append(win)
        if live:
            self._attach_guard(win)
            self._remember_live(symbol, True)
        if self.hub is not None:                          # группа связи переходит новому окну
            if replace is not None:
                self.hub.unregister(replace)
            self.hub.register(win, group)

        if embedded:
            # Докинг: новое окно встаёт на место заглушки или прежнего окна; иначе — новой панелью.
            holder = slot if slot is not None else replace
            if not (holder is not None and self._swapper is not None and self._swapper(holder, win)):
                self._placer(win)
        else:
            win.show()

        if replace is not None and not old_closed:
            replace._replacing = True
            if not replace.close():                       # прежнее окно отказалось закрыться (LIVE: позиция/заявки)
                replace._replacing = False
                if embedded and self._swapper is not None:
                    self._swapper(win, replace)           # возвращаем прежнее окно на его место
                win.close()
                replace._restore_combo()
                if self.hub is not None:
                    self.hub.register(replace, group)
                return
        if self.hub is not None and propagate:            # инструмент выбрал пользователь — сообщаем группе
            self.hub.symbol_changed(win, symbol)

    def _place_new(self, win):
        screen = (self.host.screen() if self.host is not None else None) or QGuiApplication.primaryScreen()
        avail = screen.availableGeometry()
        h = min(win.height(), max(400, avail.height() - 40))
        win.resize(win.width(), h)
        win.move(pick_position(avail, win.size(), [w.pos() for w in self._alive()]))

    # ---- список окон ----------------------------------------------------------------

    def _alive(self):
        return [w for w in self.windows if not w._dead]

    def _on_closed(self, win):
        if self.hub is not None:
            self.hub.unregister(win)
        # LIVE-окно закрыли или перевели в PAPER руками — после перезапуска оно в LIVE само не вернётся.
        # При закрытии терминала (_exit_confirmed) отметка остаётся: по ней окно и возвращается в LIVE.
        if getattr(win, "live", False) and not getattr(win, "_exit_confirmed", False):
            self._remember_live(win.symbol, False)
        if self._remover is not None and not getattr(win, "_replacing", False):
            self._remover(win)                            # окно закрылось само — убираем его панель
        # Не удаляем ссылку прямо внутри closeEvent этого же окна — иначе объект может быть уничтожен посреди обработки.
        QTimer.singleShot(0, lambda w=win: self.windows.remove(w) if w in self.windows else None)

    def raise_window(self, win):
        if self._raiser is not None:
            self._raiser(win)
            return
        if win.isMinimized():
            win.showNormal()
        win.show()
        win.raise_()
        win.activateWindow()

    def populate_menu(self, menu):
        menu.clear()
        menu.addAction("Новое окно стакана", lambda _=False: self.open_new())
        alive = self._alive()
        if alive:
            menu.addSeparator()
            for w in alive:
                act = menu.addAction(f"{self._friendly(w.symbol)} [{w.gateway.name}]  ·  шаг {_fmt_tick(w.tick_size)}")
                act.triggered.connect(lambda _=False, w=w: self.raise_window(w))
            menu.addSeparator()
            menu.addAction("Закрыть все", lambda _=False: self.shutdown())
        live = [w for w in alive if w.live]
        menu.addSeparator()
        act = menu.addAction("⛔ Снять все заявки и закрыть все LIVE-позиции…",
                             lambda _=False: self.flatten_all(self.host))
        act.setEnabled(bool(live))
        status = menu.addAction(self.guard.status_text())
        status.setEnabled(False)

    # ---- защита LIVE на весь терминал -----------------------------------------------

    def _attach_guard(self, win):
        """LIVE-окно -> дневной лимит убытка: исполнения, позиция, множитель инструмента."""
        gw, symbol = win.gateway, win.symbol
        win.trader.guard = self.guard
        # Сигналы шлюза приходят из его потоков: получатель — QObject в GUI-потоке (relay),
        # тогда Qt доставит их очередью в GUI, как и Trader'у.
        relay = _GuardRelay(self, win)
        win._guard_relay = relay
        gw.fill.connect(relay.on_fill)
        gw.position_changed.connect(relay.on_position)
        relay.on_position()

        def fetch(s=symbol):
            provider = _trading_session_provider
            try:
                gateway = provider() if provider is not None else None
                if gateway is None or not hasattr(gateway, "get_instrument"):
                    return
                from core.models import InstrumentId
                instrument = gateway.get_instrument(InstrumentId.parse(s))
                self._multiplier_ready.emit(s, float(instrument.multiplier))
            except Exception as exc:                  # noqa: BLE001
                print(f"[LIVE] {s}: множитель для лимита убытка не получен: {exc}", file=sys.stderr)
        threading.Thread(target=fetch, daemon=True, name=f"live-guard-{symbol}").start()

    def _after_guard_event(self, was_blocked):
        if self.guard.blocked and not was_blocked:
            for w in self._alive():
                if w.live:
                    w.notify(f"Дневной лимит убытка {self.guard.limit:.0f} ₽ достигнут — новые входы закрыты",
                             title="дневной лимит убытка")

    def flatten_all(self, parent=None, confirm: bool = True, live_only: bool = True):
        """Снять все заявки и закрыть все позиции по рынку — во всех окнах стакана.

        Из меню (по умолчанию): только LIVE-окна и с подтверждением. Горячая клавиша
        «Закрыть все позиции…» (hotkeys.py): confirm=False, live_only=False — все окна сразу,
        это кнопка срочного выхода."""
        wins = [w for w in self._alive() if w.live or not live_only]
        if not wins:
            return
        if confirm:
            lines = "\n".join(f"{self._friendly(w.symbol)}: позиция {w.gateway.pos_qty:+d}, "
                               f"заявок {len(w.gateway.orders)}" for w in wins)
            answer = QMessageBox.warning(
                parent or self.host, "Закрыть всё в LIVE",
                f"Снять все заявки и закрыть все позиции ПО РЫНКУ?\n\n{lines}",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                return
        for w in wins:
            gw = w.gateway
            if not gw.pos_qty and not gw.orders:
                continue
            print(f"[{gw.name}] {w.symbol}: закрыть всё — позиция {gw.pos_qty:+d}, заявок {len(gw.orders)}",
                  file=sys.stderr)
            if gw.pos_qty:
                gw.close_position(0, None)            # сначала подтверждённое снятие заявок, потом рынок
            else:
                gw.cancel_all()

    def cancel_all_windows(self):
        """Снять все свои заявки во всех окнах стакана (горячая клавиша «Все стаканы»); позиции остаются."""
        for w in self._alive():
            if w.gateway.orders:
                print(f"[{w.gateway.name}] {w.symbol}: снять все заявки ({len(w.gateway.orders)})", file=sys.stderr)
                w.gateway.cancel_all()

    def shutdown(self) -> bool:
        """Закрыть все окна. Сначала — ОДИН вопрос про все LIVE-окна с позицией или заявками, и только потом
        закрытие: раньше окна закрывались по очереди, а вопрос задавало окно с заявкой посреди этого — пока
        вопрос висел, таймер раскладки успевал сохранить её уже без закрытых стаканов (01.11: из 10 стаканов
        в пространстве после перезапуска остался один). False — пользователь отказался выходить (ничего не закрыто)."""
        windows = list(self._alive())
        exposures = [text for text in (self._exposure_of(w) for w in windows) if text]
        if exposures:
            parent = windows[0] if windows else None
            answer = QMessageBox.warning(
                parent, "LIVE: проверка перед выходом",
                "На счёте остаётся:\n" + "\n".join(exposures)
                + "\n\nЗакрытие терминала НЕ закрывает позицию и НЕ гарантирует снятие заявок.\nВсё равно выйти?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                return False
        for w in windows:
            try:
                w._exit_confirmed = True
            except Exception:
                pass
        ok = True
        for w in windows:
            try:
                if not w.close():
                    ok = False
            except Exception:
                ok = False
        return ok

    @staticmethod
    def _exposure_of(window) -> str:
        try:
            return window.live_exposure() if hasattr(window, "live_exposure") else ""
        except Exception:
            return ""
