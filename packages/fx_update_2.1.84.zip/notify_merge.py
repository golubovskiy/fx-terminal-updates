# -*- coding: utf-8 -*-
"""Склейка уведомлений «Алгоритмов» — одна строка на одно явление (без Qt, tests/test_notify_merge.py).

02.11 за 25 минут в окне «Уведомления» было 83 строки: 14 строк «Робот: покупка» по CNY-12.26 за минуту
(объёмы 30…100 лотов — один-два алгоритма с плавающим объёмом) и у каждого айсберга две строки — «Айсберг:
покупка» и «Айсберг закончился». Теперь:

    робот     — серии одного инструмента и одной стороны, пока между ними не больше ROBOT_MERGE_SEC, — одна
                строка: «Робот: покупка · 11 серий» и «30–100 лотов, интервал 0,2–7 с, оборот 38,1 млн ₽ за 1 мин»;
                02.11 10:45–11:00 Si «8 сделок × 10–16 лотов» приходил раз в 1–3 минуты — окно 3 минуты;
    айсберг   — начало и конец айсберга одного инструмента, одной стороны и ОДНОЙ цены, пока между событиями не больше
                ICEBERG_MERGE_SEC, — одна строка «Айсберг: покупка (bid) · закончился» (как держался → чем кончился).
                У айсберг-заявки цена фиксированная (Мосбиржа: безадресная лимитированная заявка с общим и видимым
                объёмом; новая видимая часть встаёт в конец очереди на том же уровне), поэтому айсберги на разных
                ценах — разные заявки и разные строки. До 2.0.47 они склеивались в «Айсберги · N уровней» с
                диапазоном цен — это вводило в заблуждение (02.11: «цены 12,374–12,382 · 9 уровней»).

    спредовый — появления спредового робота одного инструмента и одной стороны, пока между ними не больше
                SPREAD_MERGE_SEC, — одна строка: «Спредовый робот: покупка (bid) · 9 появлений», «~500–800 лотов,
                цены 455,9–457, до 12 перестановок за минуту, за 4 мин» (02.11 12:45–12:49 CCX6 — 15 отдельных
                строк одного маркет-мейкера, который то пропадал, то появлялся снова).

    стакан    — уведомления окон стакана (2.1.84: «Сигнальный уровень», «Крупный объём», «Крупная сделка» — у них
                свой звук, и до 2.1.84 в ленте их не было): одного инструмента, одного заголовка и ОДНОЙ цены, пока
                между ними не больше DOM_MERGE_SEC, — одна строка с числом срабатываний («· сработало раз: 4»).

Склеенная строка поднимается наверх ленты (время — последнего обновления) и сохраняется в журнал с тем же id
(при чтении журнала остаётся последняя версия — events_journal.dedupe).
Кандидаты айсбергов «по сделкам» (без подтверждения стаканом) в ленту не идут — только в журнал терминала.
"""
from __future__ import annotations

import re
import uuid

ROBOT_MERGE_SEC = 180.0         # серии одного робота (инструмент + сторона) ближе этого — одна строка
ICEBERG_MERGE_SEC = 180.0       # начало и конец айсберга (инструмент, сторона, цена) ближе этого — одна строка
SPREAD_MERGE_SEC = 300.0        # появления спредового робота (инструмент + сторона) ближе этого — одна строка
DOM_MERGE_SEC = 300.0           # уведомления стакана (инструмент, заголовок, цена) ближе этого — одна строка
DOM_TYPE = "Стакан"             # тип события ленты для уведомлений окон стакана (quotes_tab.add_dom_notice)
CANDIDATE_TITLE = "Айсберг: кандидат (по сделкам)"
_ICE_PRICE = re.compile(r"^Цена\s+([0-9.eE+-]+)")


def new_id() -> str:
    return uuid.uuid4().hex[:12]


def _num(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def group_key(event: dict) -> tuple | None:
    """Ключ склейки или None (событие всегда отдельной строкой)."""
    typ, title, symbol = str(event.get("type", "")), str(event.get("title", "")), str(event.get("symbol", ""))
    if typ == "Robot" and title.startswith("Робот:"):
        side = "BUY" if "покупка" in title else "SELL"
        return ("robot", symbol, side)
    if typ == "🧊 Iceberg" and title.startswith("Айсберг") and title != CANDIDATE_TITLE:
        side = "BUY" if "покупка" in title else "SELL"
        price = ice_price(event)                       # у айсберга цена одна: другая цена — другой айсберг
        return ("ice", symbol, side, None if price is None else round(price, 8))
    if typ == "Спред" and title.startswith("Спредовый робот:"):
        side = "BUY" if "покупка" in title else "SELL"
        return ("spread", symbol, side)
    if typ == DOM_TYPE:                                # своя сделка, лимит — без цены, всегда отдельной строкой
        price = _num(event.get("price"))
        return None if price is None else ("dom", symbol, title, round(price, 8))
    return None


def ice_price(event: dict) -> float | None:
    """Цена айсберга: поле price (новые события) или «Цена 12.156…» в начале подробностей."""
    p = _num(event.get("price"))
    if p is not None:
        return p
    m = _ICE_PRICE.match(str(event.get("details", "")))
    try:
        return float(m.group(1)) if m else None
    except ValueError:
        return None


def merge_window(key: tuple) -> float:
    return {"robot": ROBOT_MERGE_SEC, "spread": SPREAD_MERGE_SEC, "dom": DOM_MERGE_SEC}.get(key[0], ICEBERG_MERGE_SEC)


def start_dom(event: dict) -> None:
    """Первое уведомление стакана на этой цене — запомнить текст (к нему потом дописывается число срабатываний)."""
    event["merge"] = {"count": 1}


def merge_dom(old: dict, new: dict) -> None:
    """То же уведомление стакана (инструмент, заголовок, цена) снова — в старую строку: свежий текст и сколько
    раз сработало."""
    m = old.get("merge") or {}
    m["count"] = int(m.get("count", 1)) + 1
    old["merge"] = m
    old["details"] = f"{new.get('details', '')} · сработало раз: {m['count']}"
    old["sound"] = new.get("sound", old.get("sound"))


def fmt_range(lo: float, hi: float, digits: int = 0) -> str:
    def f(v):
        text = f"{v:,.{digits}f}".replace(",", " ")
        return text.replace(".", ",")
    return f(lo) if abs(hi - lo) < 10 ** -digits / 2 else f"{f(lo)}–{f(hi)}"


def fmt_span(seconds: float) -> str:
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds} с"
    m, s = divmod(seconds, 60)
    return f"{m} мин" if not s or m >= 10 else f"{m} мин {s} с"


def start_robot(event: dict, mono: float) -> None:
    """Первая серия робота — запомнить числа для будущей склейки."""
    size, interval, turnover = _num(event.get("size")), _num(event.get("interval")), _num(event.get("turnover"))
    cv = _num(event.get("cv"))
    event["merge"] = {"series": 1, "first": mono, "smin": size, "smax": size, "imin": interval, "imax": interval,
                      "turnover": turnover or 0.0, "cmin": cv, "cmax": cv}


def merge_robot(old: dict, new: dict, mono: float, money) -> None:
    """Ещё одна серия того же робота — в старую строку. money(₽) -> «38,1 млн ₽»."""
    m = old.get("merge") or {}
    size, interval, turnover = _num(new.get("size")), _num(new.get("interval")), _num(new.get("turnover"))
    m["series"] = int(m.get("series", 1)) + 1
    for lo, hi, v in (("smin", "smax", size), ("imin", "imax", interval), ("cmin", "cmax", _num(new.get("cv")))):
        if v is not None:
            m[lo] = v if m.get(lo) is None else min(m[lo], v)
            m[hi] = v if m.get(hi) is None else max(m[hi], v)
    m["turnover"] = float(m.get("turnover") or 0.0) + (turnover or 0.0)
    m.setdefault("first", mono)
    old["merge"] = m
    old["turnover"] = m["turnover"]
    side = "покупка" if "покупка" in str(old.get("title", "")) else "продажа"
    old["title"] = f"Робот: {side} · {m['series']} серий" if m["series"] >= 5 else f"Робот: {side} · {m['series']} серии"
    parts = []
    if m.get("smin") is not None:
        parts.append(f"{fmt_range(m['smin'], m['smax'])} лотов")
    if m.get("imin") is not None:
        parts.append(f"интервал {fmt_range(m['imin'], m['imax'], 1)} с")
    parts.append(f"оборот {money(m['turnover'])} за {fmt_span(mono - m['first'])}")
    if m.get("cmin") is not None:                     # темп серий: разброс пауз (robot_notes.tempo_text)
        lo, hi = m["cmin"] * 100, m["cmax"] * 100
        verdict = (" — ровный темп" if m["cmax"] <= 0.25 else
                   " — темп неровный, похоже на ручные клики" if m["cmin"] > 0.50 else "")
        parts.append(f"разброс пауз {fmt_range(lo, hi)} %{verdict}")
    old["details"] = ", ".join(parts)


def _plural(n: int, one: str, few: str, many: str) -> str:
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return one
    return few if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14 else many


def start_spread(event: dict, mono: float) -> None:
    """Первое появление спредового робота — запомнить объём, цену и темп (extra: size / price / per_minute)."""
    size, price, rate = _num(event.get("size")), _num(event.get("price")), _num(event.get("per_minute"))
    event["merge"] = {"count": 1, "first": mono, "smin": size, "smax": size, "pmin": price, "pmax": price,
                      "rate": rate}


def merge_spread(old: dict, new: dict, mono: float) -> None:
    """Спредовый робот той же стороны появился снова — в старую строку."""
    m = old.get("merge") or {}
    m["count"] = int(m.get("count", 1)) + 1
    for lo, hi, v in (("smin", "smax", _num(new.get("size"))), ("pmin", "pmax", _num(new.get("price")))):
        if v is not None:
            m[lo] = v if m.get(lo) is None else min(m[lo], v)
            m[hi] = v if m.get(hi) is None else max(m[hi], v)
    rate = _num(new.get("per_minute"))
    if rate is not None:
        m["rate"] = rate if m.get("rate") is None else max(m["rate"], rate)
    m.setdefault("first", mono)
    old["merge"] = m
    side = "покупка (bid)" if "покупка" in str(old.get("title", "")) else "продажа (ask)"
    n = m["count"]
    old["title"] = f"Спредовый робот: {side} · {n} {_plural(n, 'появление', 'появления', 'появлений')}"
    parts = []
    if m.get("smin") is not None:
        parts.append(f"~{fmt_range(m['smin'], m['smax'])} лотов")
    if m.get("pmin") is not None:
        parts.append(f"цена {_price_text(m['pmin'])}" if abs(m["pmax"] - m["pmin"]) < 1e-12
                     else f"цены {_price_text(m['pmin'])}–{_price_text(m['pmax'])}")
    if m.get("rate") is not None:
        parts.append(f"до {m['rate']:.0f} перестановок за минуту")
    parts.append(f"за {fmt_span(mono - m['first'])}")
    old["details"] = ", ".join(parts)


def start_iceberg(event: dict) -> None:
    """Первое событие группы айсбергов — запомнить цену, исполнение, время удержания."""
    price = ice_price(event)
    event["merge"] = {"prices": [price] if price is not None else [],
                      "executed": _num(event.get("executed")) or 0.0, "hold": _num(event.get("hold")) or 0.0,
                      "turnover": _num(event.get("turnover")) or 0.0}
    event["start_details"] = str(event.get("details", ""))
    # «Айсберг» / «Айсберг (доливка роботом)» / «Айсберг (возможно биржевой)» — iceberg_kind; остаётся и в конце
    event["ice_name"] = str(event.get("title", "")).split(":", 1)[0] or "Айсберг"


def _price_text(v: float) -> str:
    return f"{v:.8g}".replace(".", ",")


def merge_iceberg(old: dict, new: dict, money=None) -> None:
    """Следующее событие того же айсберга (инструмент, сторона, цена — group_key) — в его строку: объявлен снова —
    свежие числа, закончился — «как держался → чем кончился». Ветка «Айсберги · N уровней» осталась для строк
    старого журнала (до 2.0.47), новые события на разных ценах сюда не попадают."""
    if "merge" not in old:
        start_iceberg(old)
    m = old["merge"]
    new_title, new_details = str(new.get("title", "")), str(new.get("details", ""))
    side = "покупка (bid)" if "покупка" in new_title else "продажа (ask)"
    ended = "закончился" in new_title
    price = ice_price(new)
    if price is not None and all(abs(price - p) > 1e-9 for p in m["prices"]):
        m["prices"].append(price)
    if not ended:
        m["executed"] = float(m.get("executed", 0)) + (_num(new.get("executed")) or 0.0)
        m["turnover"] = float(m.get("turnover", 0)) + (_num(new.get("turnover")) or 0.0)
    m["hold"] = max(float(m.get("hold", 0)), _num(new.get("hold")) or 0.0)
    if m["turnover"]:
        old["turnover"] = m["turnover"]
    if ended and _num(new.get("turnover")):           # конец айсберга несёт итог (с 2.0.69) — оборот строки по нему
        old["turnover"] = max(float(old.get("turnover") or 0), _num(new.get("turnover")))
    tail = new_details.split(":", 1)[1].strip() if ended and ":" in new_details else new_details
    if len(m["prices"]) <= 1:                         # одна цена — как раньше: начало → конец
        start = old.get("start_details") or str(old.get("details", ""))
        name = old.get("ice_name") or "Айсберг"
        if ended:
            old["title"] = f"{name}: {side} · закончился"
            old["details"] = f"{start} → {tail}"
        else:                                         # объявлен снова — свежие числа, та же строка
            old["title"] = f"{str(new_title).split(':', 1)[0] or name}: {side}"
            old["ice_name"] = str(new_title).split(":", 1)[0] or name
            old["details"] = new_details
            old["start_details"] = new_details
        return
    n = len(m["prices"])
    word = "уровня" if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14 else "уровней" if n % 10 != 1 or n % 100 == 11 else "уровень"
    old["title"] = f"Айсберги: {side} · {n} {word}"
    lo, hi = min(m["prices"]), max(m["prices"])
    parts = [f"цены {_price_text(lo)}–{_price_text(hi)}"]
    if m["executed"]:
        parts.append(f"исполнено {m['executed']:,.0f} лотов".replace(",", " "))
    if m["turnover"] and money is not None:
        parts.append(money(m["turnover"]))
    if m["hold"]:
        parts.append(f"дольше всех {m['hold']:.0f} с")
    last = (f"{_price_text(price)}: " if ended and price is not None else "") + tail
    old["details"] = ", ".join(parts) + f"; последний: {'закончился — ' if ended else ''}{last}"


def passes_filter(event: dict, kind: str | None = None, symbol: str | None = None,
                  min_turnover: float = 0.0) -> bool:
    """Фильтр окна «Уведомления»: тип (как в EVENT_TYPE_LABELS), инструмент, оборот от min_turnover ₽ —
    у событий с известным оборотом (роботы, крупные сделки, айсберги — исполненное по ним); у остальных
    оборот не проверяется."""
    if kind and str(event.get("type", "")) != kind:
        return False
    if symbol and str(event.get("symbol", "")) != symbol:
        return False
    if min_turnover > 0:
        t = _num(event.get("turnover"))
        if t is not None and t < min_turnover:
            return False
    return True
