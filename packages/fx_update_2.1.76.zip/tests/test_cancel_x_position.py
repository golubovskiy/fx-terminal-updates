# -*- coding: utf-8 -*-
"""«×» заявки на цене позиции (2.1.76): заявка на закрытие, поставленная на цену открытия, снимается своим «×».
До 2.1.76 метка позиции стояла в строке первой, и «×» за меткой заявки уходил за правый край стакана — щёлкнуть
по нему было нельзя. Теперь «×» сразу за снимаемыми метками и не правее края окна, позиция — после него.
PAPER, без сделок через движок; настройки терминала и стаканов не трогаются.
Запуск:  python tests/test_cancel_x_position.py"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):           # offscreen-Qt не видит шрифты Windows без подсказки
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))
os.environ["SCALPER_CONFIG"] = os.path.join(tempfile.mkdtemp(prefix="fx_scalper_cfg_"), "scalper.json")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import appearance  # noqa: E402

_INI = os.path.join(tempfile.mkdtemp(prefix="fx_paint_"), "settings.ini")
appearance._settings = lambda: QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)

import scalper_widget as sw  # noqa: E402

SYM = "CRZ6@RTSX"


class FakeManager:
    hub = None
    friendly = staticmethod(lambda s: s)
    from_friendly = staticmethod(lambda t: t)
    symbols = staticmethod(lambda: [SYM])
    catalog_symbols = staticmethod(lambda: [])


def _iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _window():
    s = sw.Settings()
    s.cluster_panel = True
    win = sw.TerminalScalperWindow(FakeManager(), SYM, "", 0.01, s, {}, embedded=True)
    win.ladder.resize(640, 820)
    rows = [(round(100 - i * 0.01, 2), 50 + i * 7, 0) for i in range(1, 61)]
    rows += [(round(100 + i * 0.01, 2), 0, 40 + i * 9) for i in range(0, 60)]
    win.on_book(rows, snapshot=True)
    now = datetime.now(timezone.utc)
    for m in range(40):                       # 40 минут сделок — несколько колонок кластеров
        for k in range(25):
            price = round(100 + ((k * 7 + m) % 21 - 10) * 0.01, 2)
            win.on_trade({"price": price, "size": 1 + (k % 5), "side": "BUY" if k % 2 else "SELL",
                          "timestamp": _iso(now - timedelta(minutes=m, seconds=k))})
    return win


from brokers.paper.engine import PaperOrder  # noqa: E402


def _click(lad, x, y):
    from PySide6 import QtGui
    Qt = QtCore.Qt
    ev = QtGui.QMouseEvent(QtCore.QEvent.Type.MouseButtonPress, QtCore.QPointF(x, y), Qt.MouseButton.LeftButton,
                           Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    lad.mousePressEvent(ev)


def _row_y(lad, tick):
    x = lad._lay["ord_x"] + 2
    for y in range(lad.height()):
        if lad._hit_tick(QtCore.QPoint(x, y)) == tick:
            return y + lad._lay["rh"] // 2
    raise AssertionError(f"строки {tick} нет на экране")


def _check(side_pos, order_side, tag):
    win = _window()
    try:
        lad = win.ladder
        gw = win.gateway
        tick = int(round(100.0 / win.book.tick))
        gw.pos_qty, gw.pos_avg = side_pos, 100.0                 # позиция открыта по 100,00
        gw.orders.append(PaperOrder("t1", order_side, tick, 1, tag))   # заявка на закрытие — на ту же цену
        lad.grab()
        b = tick // lad.group
        span = lad._x_spans.get(b)
        assert span is not None, "у заявки нет «×»"
        assert lad._lay["ord_x"] <= span[0] and span[0] + lad.X_MIN <= lad.width(), f"«×» за краем: {span}, {lad.width()}"
        cancelled = []
        lad.cancelClicked.connect(lambda t: cancelled.append(t))
        _click(lad, (span[0] + min(span[1], lad.width())) // 2, _row_y(lad, tick))
        assert cancelled == [tick], f"щелчок по «×» не снял заявку: {cancelled}"
        assert gw.orders == [], "заявка осталась"
        lad.grab()
        assert b not in lad._x_spans, "«×» остался без заявки"
    finally:
        win.close()
        win.deleteLater()


def test_close_order_at_long_entry():
    _check(1, "SELL", "close")


def test_close_order_at_short_entry():
    _check(-1, "BUY", "close")


def test_take_profit_order_at_entry_with_big_position():
    _check(12345, "SELL", "tp")                       # длинные метки «+12 345» и «TP 1» — «×» всё равно в окне


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
