# -*- coding: utf-8 -*-
"""Страницы «Цвета» и «Шрифты» диалога «Настройки» (settings_dialog.py).

Значения хранит appearance.py; здесь только редактирование. Ничего не сохраняется до «OK» в диалоге:
страницы отдают values(), диалог пишет их через appearance.save_overrides / save_fonts.
"""
from __future__ import annotations

from PySide6 import QtCore, QtGui, QtWidgets

import appearance

SWATCH_W, SWATCH_H = 24, 18


class ColorSwatch(QtWidgets.QToolButton):
    """Квадратик-образец цвета: щелчок — выбор цвета (с прозрачностью), ПКМ — «По умолчанию».
    Изменённый цвет помечается точкой в подписи (ColorsPage)."""

    changed = QtCore.Signal()

    def __init__(self, key: str, title: str, default: str, value: str | None, parent=None):
        super().__init__(parent)
        self.key, self.title, self.default = key, title, default
        self.value = value                       # None — цвет по умолчанию
        self.setFixedSize(SWATCH_W, SWATCH_H)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)
        self.clicked.connect(self._pick)
        self._paint()

    def current(self) -> str:
        return self.value or self.default

    def set_value(self, value: str | None) -> None:
        self.value = value if value and value.lower() != self.default.lower() else None
        self._paint()
        self.changed.emit()

    def _paint(self) -> None:
        color = QtGui.QColor(self.current())
        pix = QtGui.QPixmap(SWATCH_W, SWATCH_H)
        pix.fill(QtGui.QColor("#ffffff"))
        p = QtGui.QPainter(pix)
        if color.alpha() < 255:                  # прозрачный цвет — поверх «шахматки»
            for x in range(0, SWATCH_W, 6):
                for y in range(0, SWATCH_H, 6):
                    if (x + y) // 6 % 2:
                        p.fillRect(x, y, 6, 6, QtGui.QColor("#c8c8c8"))
        p.fillRect(pix.rect(), color)
        p.setPen(QtGui.QColor("#808080"))
        p.drawRect(0, 0, SWATCH_W - 1, SWATCH_H - 1)
        p.end()
        self.setIcon(QtGui.QIcon(pix))
        self.setIconSize(QtCore.QSize(SWATCH_W, SWATCH_H))
        self.setStyleSheet("QToolButton { border: none; padding: 0; background: transparent; }")
        self.setToolTip(f"{self.title}: {self.current()}"
                        + ("" if self.value is None else f"\nпо умолчанию {self.default} (ПКМ — вернуть)"))

    def _pick(self) -> None:
        color = QtWidgets.QColorDialog.getColor(
            QtGui.QColor(self.current()), self, f"Цвет: {self.title}",
            QtWidgets.QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if color.isValid():
            self.set_value(appearance.color_hex(color))

    def _menu(self, pos) -> None:
        menu = QtWidgets.QMenu(self)
        act = menu.addAction("По умолчанию")
        act.setEnabled(self.value is not None)
        if menu.exec(self.mapToGlobal(pos)) is act:
            self.set_value(None)


class ColorsPage(QtWidgets.QWidget):
    """Все цвета appearance.COLOR_GROUPS для одной темы (той, что сохранена при открытии настроек)."""

    COLUMNS = 2

    def __init__(self, theme: str, dim: str, parent=None):
        super().__init__(parent)
        self.theme = theme
        self.swatches: list[ColorSwatch] = []
        saved = appearance.overrides(theme)
        self._initial = dict(saved)

        body = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(body)
        lay.setContentsMargins(4, 0, 12, 0)
        lay.setSpacing(12)
        theme_title = "светлой" if theme == "light" else "тёмной"
        note = QtWidgets.QLabel(
            f"Цвета для {theme_title} темы. Щелчок по образцу — выбрать цвет, ПКМ — вернуть по умолчанию. "
            "Стакан, кластеры и лента перекрашиваются сразу, цвета приложения — полностью после перезапуска, "
            "графики — после перезапуска терминала.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {dim}; font-size: 11px;")
        lay.addWidget(note)
        # Рамка вокруг стакана, на котором мышь / фокус (горячие клавиши «Стакан» действуют на него).
        self.active_check = QtWidgets.QCheckBox("Подсвечивать активный стакан рамкой (цвет — «Выделение активного стакана»)")
        self.active_check.setChecked(appearance.active_frame_enabled())
        self._active_initial = self.active_check.isChecked()
        lay.addWidget(self.active_check)
        for group_title, items in appearance.COLOR_GROUPS:
            box = QtWidgets.QGroupBox(group_title)
            grid = QtWidgets.QGridLayout(box)
            grid.setHorizontalSpacing(10)
            grid.setVerticalSpacing(8)
            for i, (key, title) in enumerate(items):
                try:
                    default = appearance.default_color(key, theme)
                except Exception:
                    default = "#808080"
                swatch = ColorSwatch(key, title, default, saved.get(key), self)
                label = QtWidgets.QLabel(title)
                label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
                swatch.changed.connect(lambda lab=label, sw=swatch: self._mark(lab, sw))
                self._mark(label, swatch)
                row, col = divmod(i, self.COLUMNS)
                grid.addWidget(label, row, col * 2)
                grid.addWidget(swatch, row, col * 2 + 1)
                self.swatches.append(swatch)
            for col in range(self.COLUMNS):
                grid.setColumnStretch(col * 2, 1)
            lay.addWidget(box)
        reset = QtWidgets.QPushButton("Сброс")
        reset.setAutoDefault(False)
        reset.setToolTip("Вернуть все цвета этой темы по умолчанию (сохранится по «OK»)")
        reset.clicked.connect(self.reset_all)
        reset_row = QtWidgets.QHBoxLayout()
        reset_row.addWidget(reset)
        reset_row.addStretch(1)
        lay.addLayout(reset_row)
        lay.addStretch(1)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        scroll.setWidget(body)
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    @staticmethod
    def _mark(label: QtWidgets.QLabel, swatch: ColorSwatch) -> None:
        label.setText(swatch.title + (" •" if swatch.value is not None else ""))

    def reset_all(self) -> None:
        for swatch in self.swatches:
            swatch.set_value(None)

    def values(self) -> dict[str, str]:
        return {sw.key: sw.value for sw in self.swatches if sw.value is not None}

    def changed_areas(self) -> set[str]:
        """Области с изменёнными цветами: {"app", "dom", "chart"} — что перерисовать или перезапустить."""
        now = self.values()
        keys = {k for k in set(now) | set(self._initial) if now.get(k) != self._initial.get(k)}
        # рамка активного стакана перекрашивается сразу, как сам стакан, — перезапуск не нужен
        return {"dom" if k == "app.active_frame" else k.split(".", 1)[0] for k in keys}


class FontsPage(QtWidgets.QWidget):
    """Шрифты стакана, тиков, кластеров, ленты и графиков (appearance.FontPrefs)."""

    def __init__(self, dim: str, parent=None):
        super().__init__(parent)
        appearance.upgrade_fonts()                  # разовые новые умолчания шрифта стакана (12 px, жирный, серое сглаживание)
        prefs = appearance.load_fonts()
        self._initial = prefs
        box = QtWidgets.QGroupBox("Шрифты")
        form = QtWidgets.QFormLayout(box)
        form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)

        self.family = QtWidgets.QFontComboBox()
        self.family.setCurrentFont(QtGui.QFont(prefs.dom_family))
        self.dom_size = self._combo([("Авто (по высоте строки)" if v == 0 else f"{v} px", v)
                                     for v in appearance.DOM_SIZES], prefs.dom_size)
        self.dom_size.setToolTip("Авто — размер меняется вместе с масштабом стакана (колесо с Ctrl)")
        self.dom_row = QtWidgets.QSpinBox()
        self.dom_row.setRange(appearance.ROW_HEIGHTS[0], appearance.ROW_HEIGHTS[-1])
        self.dom_row.setSuffix(" px")
        self.dom_row.setValue(prefs.dom_row)
        self.dom_row.setToolTip("Высота строки при 100 % масштаба: у новых окон и в открытых — сразу после «OK»")
        weights = [(w, w) for w in appearance.WEIGHTS]
        self.dom_weight = self._combo(weights, prefs.dom_weight)
        self.tick_weight = self._combo(weights, prefs.tick_weight)
        self.cluster_weight = self._combo(weights, prefs.cluster_weight)
        for combo in (self.dom_weight, self.tick_weight, self.cluster_weight):
            combo.setToolTip("Обычное — жирными остаются только лучшие цены и метки; Жирное — весь текст.\n"
                             "В стакане по умолчанию «Жирное»: все цены и объёмы выглядят как лучшие цены.")
        same = [("Как в стакане" if v == 0 else f"{v} px", v) for v in appearance.TEXT_SIZES]
        self.tick_px = self._combo(same, prefs.tick_px)
        self.tick_px.setToolTip("Подписи объёма в пузырьках тиков — наибольший размер: в мелком пузырьке мельче.\n"
                                "Пузырьки растут вместе со шрифтом. «Как в стакане» — тот же размер, что цифры стакана.")
        self.cluster_px = self._combo(same, prefs.cluster_px)
        self.cluster_px.setToolTip("Ячейки кластеров и итоги под ними; не больше высоты строки стакана.\n"
                                   "«Как в стакане» — тот же размер, что цифры стакана.")
        self.tape_px = self._combo(same, prefs.tape_px)
        self.tape_px.setToolTip("Лента сделок — панель справа от стакана (меню стакана → «Лента сделок»).\n"
                                "Строки становятся выше вместе со шрифтом. «Как в стакане» — тот же размер.")
        self.chart_size = self._combo([("Как в теме" if v == 0 else f"{v} pt", v)
                                       for v in appearance.CHART_SIZES], prefs.chart_size)
        self.chart_size.setToolTip("Подписи осей графиков свечей: у новых графиков и после перезапуска")
        self.antialias = QtWidgets.QCheckBox("Сглаживание шрифта в стакане")
        self.antialias.setChecked(prefs.dom_antialias)
        self.gray = QtWidgets.QCheckBox("Серое сглаживание — без цветной каймы вокруг цифр")
        self.gray.setToolTip("Обычное сглаживание Windows (ClearType) раскрашивает края букв: на цветном фоне ячеек\n"
                             "стакана вокруг цифр видна сине-жёлтая кайма. Серое сглаживание её убирает — цифры\n"
                             "чище, как в Ватаге; на части мониторов текст при этом выглядит чуть мягче.")
        self.gray.setChecked(prefs.dom_gray)
        self.gray.setEnabled(prefs.dom_antialias)
        self.antialias.toggled.connect(lambda on: self.gray.setEnabled(on))
        self.dom_price = self._combo([(t, k) for k, t in appearance.PRICE_FORMATS], prefs.dom_price)
        self.dom_price.setToolTip("С разделителем тысяч. «Последние цифры» — как короткая цена\n"
                                  "в ATAS и Quantower: старшие цифры за день почти не меняются, колонка уже")
        self.dom_price_bold = self._combo([("Нет" if v == 0 else f"{v}", v) for v in appearance.PRICE_BOLD],
                                          prefs.dom_price_bold)
        self.dom_price_bold.setToolTip("Последние цифры цены жирным — глаз быстрее находит нужный уровень\n"
                                       "(лучшие цены и так жирные целиком).\n"
                                       "Работает при начертании шрифта в стакане «Обычное».")

        form.addRow("Шрифт в стакане:", self.family)
        form.addRow("Размер шрифта в стакане:", self.dom_size)
        form.addRow("Высота строки в стакане:", self.dom_row)
        form.addRow("Начертание шрифта в стакане:", self.dom_weight)
        form.addRow("Цена в стакане:", self.dom_price)
        form.addRow("Последние цифры цены жирным:", self.dom_price_bold)
        form.addRow("Размер шрифта в тиках:", self.tick_px)
        form.addRow("Начертание шрифта в тиках:", self.tick_weight)
        form.addRow("Размер шрифта в кластерах:", self.cluster_px)
        form.addRow("Начертание шрифта в кластерах:", self.cluster_weight)
        form.addRow("Размер шрифта ленты сделок:", self.tape_px)
        form.addRow("Размер шрифта на графике:", self.chart_size)
        form.addRow("", self.antialias)
        form.addRow("", self.gray)
        hint = QtWidgets.QLabel("Стакан, тики, кластеры и лента меняются сразу после «OK». "
                                "Шрифт окон, меню и таблиц — «Интерфейс» → «Размер шрифта».")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {dim}; font-size: 11px;")
        form.addRow("", hint)
        reset = QtWidgets.QPushButton("Сброс")
        reset.setAutoDefault(False)
        reset.setToolTip("Вернуть шрифты по умолчанию (сохранится по «OK»)")
        reset.clicked.connect(lambda: self._load(appearance.FontPrefs()))
        form.addRow("", reset)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.addWidget(box)
        lay.addStretch(1)

    @staticmethod
    def _combo(items, current) -> QtWidgets.QComboBox:
        combo = QtWidgets.QComboBox()
        for text, data in items:
            combo.addItem(text, data)
        idx = combo.findData(current)
        if idx < 0:                              # значение не из списка (правили вручную) — показать как есть
            combo.addItem(str(current), current)
            idx = combo.count() - 1
        combo.setCurrentIndex(idx)
        return combo

    def _load(self, prefs: appearance.FontPrefs) -> None:
        self.family.setCurrentFont(QtGui.QFont(prefs.dom_family))
        for combo, value in ((self.dom_size, prefs.dom_size), (self.dom_weight, prefs.dom_weight),
                             (self.tick_weight, prefs.tick_weight), (self.cluster_weight, prefs.cluster_weight),
                             (self.tick_px, prefs.tick_px), (self.cluster_px, prefs.cluster_px),
                             (self.tape_px, prefs.tape_px), (self.chart_size, prefs.chart_size),
                             (self.dom_price, prefs.dom_price), (self.dom_price_bold, prefs.dom_price_bold)):
            combo.setCurrentIndex(max(0, combo.findData(value)))
        self.dom_row.setValue(prefs.dom_row)
        self.antialias.setChecked(prefs.dom_antialias)
        self.gray.setChecked(prefs.dom_gray)

    def values(self) -> appearance.FontPrefs:
        return appearance.FontPrefs(
            dom_family=self.family.currentFont().family(),
            dom_size=int(self.dom_size.currentData()),
            dom_row=self.dom_row.value(),
            dom_weight=str(self.dom_weight.currentData()),
            tick_weight=str(self.tick_weight.currentData()),
            cluster_weight=str(self.cluster_weight.currentData()),
            tape_size=self._initial.tape_size,             # прежняя настройка ленты (pt) — не используется, не трогаем
            tick_px=int(self.tick_px.currentData()),
            cluster_px=int(self.cluster_px.currentData()),
            tape_px=int(self.tape_px.currentData()),
            chart_size=int(self.chart_size.currentData()),
            dom_antialias=self.antialias.isChecked(),
            dom_gray=self.gray.isChecked(),
            dom_price=str(self.dom_price.currentData()),
            dom_price_bold=int(self.dom_price_bold.currentData()),
        )

    def chart_changed(self) -> bool:
        return self.values().chart_size != self._initial.chart_size
