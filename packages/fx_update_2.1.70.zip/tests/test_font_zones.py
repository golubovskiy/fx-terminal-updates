# -*- coding: utf-8 -*-
"""Размеры шрифта тиков, кластеров и ленты сделок (2.1.70, appearance.FontPrefs.tick_px / cluster_px / tape_px):
по умолчанию — как в стакане, своя настройка меняет вид; кнопки «О проекте» не обрезают текст; «ATR» — в
«Аналитике». Настройки терминала не трогаются.  Запуск:  python tests/test_font_zones.py"""
from __future__ import annotations

import os
import sys
import tempfile
from datetime import datetime, timezone
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform.startswith("win"):           # offscreen-Qt не видит шрифты Windows без подсказки
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))
os.environ["SCALPER_CONFIG"] = os.path.join(tempfile.mkdtemp(prefix="fx_scalper_cfg_"), "scalper.json")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import appearance  # noqa: E402

_INI = os.path.join(tempfile.mkdtemp(prefix="fx_zones_"), "settings.ini")
appearance._settings = lambda: QtCore.QSettings(_INI, QtCore.QSettings.Format.IniFormat)

import scalper_widget as sw  # noqa: E402

SYM = "CRZ6@RTSX"


def test_defaults_and_loading():
    prefs = appearance.FontPrefs()
    assert (prefs.tick_px, prefs.cluster_px, prefs.tape_px) == (0, 0, 0)          # все — как в стакане
    st = appearance._settings()
    st.clear()
    appearance.save_fonts(appearance.FontPrefs(tick_px=14, cluster_px=11, tape_px=13))
    got = appearance.load_fonts()
    assert (got.tick_px, got.cluster_px, got.tape_px) == (14, 11, 13)
    st.setValue("fonts/tick_px", "99")
    st.setValue("fonts/cluster_px", "-3")
    got = appearance.load_fonts()
    assert (got.tick_px, got.cluster_px) == (32, 0)                              # в пределах; отрицательное — как в стакане
    st.clear()
    st.setValue("fonts/tape_size", 11)                                          # прежняя настройка (pt) не мешает
    assert appearance.load_fonts().tape_px == 0


def test_zone_sizes_follow_dom():
    saved = sw.FONTS
    try:
        ladder = SimpleNamespace(row_h=12)
        zone = lambda z: sw.ScalperLadderWidget._zone_px(ladder, z)              # noqa: E731
        sw.FONTS = appearance.FontPrefs()
        assert zone("tick") == zone("cluster") == 12                             # авто: высота строки
        ladder.row_h = 18                                                        # масштаб колесом — вместе со стаканом
        assert zone("tick") == zone("cluster") == 18
        sw.FONTS = appearance.FontPrefs(dom_size=13)
        assert zone("tick") == zone("cluster") == 13
        sw.FONTS = appearance.FontPrefs(dom_size=13, tick_px=16, cluster_px=10)
        assert (zone("tick"), zone("cluster")) == (16, 10)
    finally:
        sw.FONTS = saved


class FakeManager:
    hub = None
    friendly = staticmethod(lambda s: s)
    from_friendly = staticmethod(lambda t: t)
    symbols = staticmethod(lambda: [SYM])
    catalog_symbols = staticmethod(lambda: [])


def test_frames_with_custom_sizes():
    """Стакан с кластерами и тиками и лента сделок рисуются без ошибки при разных размерах; пузырёк тика при
    шрифте 16 px крупнее, чем при 12 px."""
    saved = sw.FONTS
    s = sw.Settings()
    s.cluster_panel = True
    win = sw.TerminalScalperWindow(FakeManager(), SYM, "", 0.001, s, {}, embedded=True)
    try:
        win.ladder.resize(700, 700)
        rows = [(round(12.300 - i * 0.001, 3), 10 + i, 0) for i in range(40)]
        rows += [(round(12.302 + i * 0.001, 3), 0, 12 + i) for i in range(40)]
        win.on_book(rows, snapshot=True)
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        for k in range(30):
            win.on_trade({"price": 12.301 + (k % 5 - 2) * 0.001, "size": 1 + k * 7, "side": "BUY" if k % 2 else "SELL",
                          "timestamp": now})
        sizes = {}
        for prefs in (appearance.FontPrefs(), appearance.FontPrefs(tick_px=16, cluster_px=9, tape_px=16)):
            sw.FONTS = prefs
            win.ladder._tick_sprites = {}
            win.ladder.grab()
            assert "_paint_err_t" not in win.ladder.__dict__, "кадр стакана упал"
            pm, _cx, _cy = win.ladder._tick_sprite(500, True)
            sizes[prefs.tick_px] = pm.width()
            win.tape.resize(420, 300)
            win.tape.grab()
        assert sizes[16] > sizes[0], sizes
    finally:
        sw.FONTS = saved
        win.close()
        win.deleteLater()
        APP.processEvents()


def test_about_buttons_fit_text_and_atr_in_analytics():
    import update_dialog
    dlg = update_dialog.AboutDialog()
    try:
        for button in dlg.findChildren(QtWidgets.QPushButton):
            need = button.fontMetrics().horizontalAdvance(button.text())
            assert button.minimumWidth() >= need + 20, (button.text(), button.minimumWidth(), need)
    finally:
        dlg.deleteLater()
    import main_window
    assert "atr" in main_window.MainWindow._ANALYTICS_PANELS


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
