# -*- coding: utf-8 -*-
"""Окна обновлений FX Terminal: «О проекте» (версия, список изменений, кнопки), подтверждение установки
пакета, выбор бэкапа для отката, итог последней установки.

Сами файлы ставит и возвращает updater.py отдельным процессом после закрытия терминала. Здесь — только
показать, что поменяется, и вернуть команду запуска updater (её выполняет gui_app._finish_process после
обычного закрытия терминала: раскладка и заметки к этому моменту уже сохранены).

Обновления через интернет (2.1.68, update_online.py — репозиторий github.com/golubovskiy/fx-terminal-updates):
    AutoChecker — проверка через FIRST_CHECK_MS после запуска и дальше раз в CHECK_EVERY_MS, в отдельном потоке;
        нашлась новая версия (пакеты уже скачаны и проверены) — окно OnlineUpdateDialog. Окно появляется, не
        забирая фокус, и без кнопки по умолчанию: Enter или пробел, нажатые в стакане, не запустят установку.
        «Позже» — до следующего запуска терминала (более новая версия — спросит снова). Галочка «Проверять
        обновления автоматически» в этом окне (QSettings update/auto_check) выключает проверку по таймеру.
    «О проекте» → «Проверить обновления» — то же сразу, с ответом и тогда, когда обновлений нет.
"""
from __future__ import annotations

import html
import sys
import threading
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets

import update_online
import updater

ROOT = Path(__file__).resolve().parent
PACKAGE_FILTER = "Пакет обновления FX Terminal (fx_update_*.zip);;Все архивы zip (*.zip)"
LAST_DIR_KEY = "update/last_dir"
UPDATES_PAGE = f"https://github.com/{update_online.REPO}"   # страница репозитория обновлений (кнопка в «О проекте»)
AUTO_KEY = "update/auto_check"            # проверять обновления через интернет по таймеру (по умолчанию — да)
FIRST_CHECK_MS = 90 * 1000                # первая проверка — после запуска (терминал уже подключился)
CHECK_EVERY_MS = 60 * 60 * 1000           # дальше — раз в час


def open_updates_page() -> bool:
    """Открыть страницу репозитория обновлений в браузере (кнопка «GitHub ↗» в «О проекте»)."""
    return QtGui.QDesktopServices.openUrl(QtCore.QUrl(UPDATES_PAGE))


def fit_buttons(*buttons: QtWidgets.QPushButton, pad: int = 36) -> None:
    """Ширина кнопки не меньше её текста (2.1.70): «таблетки» диалогов (app_common, поля 12 px и рамка) в узком
    окне сжимались, и текст обрезался с обеих сторон («роверить обновлени»)."""
    for button in buttons:
        width = button.fontMetrics().horizontalAdvance(button.text()) + pad
        button.setMinimumWidth(max(button.minimumWidth(), width))


def _settings() -> QtCore.QSettings:
    return QtCore.QSettings("MyTradingTools", "FxTerminal")


def auto_check_enabled() -> bool:
    return str(_settings().value(AUTO_KEY, True)).lower() not in ("false", "0", "no")


def _changes_html(changes) -> str:
    """CHANGES из version.py -> HTML для окна «О проекте»."""
    parts = []
    for ver, day, lines in changes:
        items = "".join(f"<li>{html.escape(line)}</li>" for line in lines)
        parts.append(f"<p style='margin:8px 0 2px 0'><b>{html.escape(ver)}</b> · {html.escape(day)}</p>"
                     f"<ul style='margin-top:0'>{items}</ul>")
    return "".join(parts) or "<p>Список изменений пуст.</p>"


def _load_version():
    """version.py читаем заново с диска: после обновления в памяти мог остаться старый модуль."""
    import importlib
    import version
    return importlib.reload(version)


class AboutDialog(QtWidgets.QDialog):
    """«О проекте»: версия, сборка, история изменений; «Установить обновление…», «Откатить обновление…».
    После закрытия command — команда updater (терминал закроется и запустит её) или None."""

    def __init__(self, parent=None, root: Path = ROOT):
        super().__init__(parent)
        self.root = Path(root)
        self.command: list[str] | None = None
        self.setWindowTitle("О проекте")
        self.resize(680, 520)
        ver = _load_version()
        lay = QtWidgets.QVBoxLayout(self)
        head = QtWidgets.QLabel(
            f"<b style='font-size:15px'>FX Terminal {html.escape(ver.VERSION)}</b>"
            f"<br>сборка {html.escape(ver.BUILD_DATE)} · терминал для валюты и валютных фьючерсов на Finam Trade API")
        head.setTextFormat(QtCore.Qt.TextFormat.RichText)
        top = QtWidgets.QHBoxLayout()
        top.addWidget(head, 1)
        # Небольшая кнопка-ссылка на репозиторий обновлений (2.1.71): там README, latest.json и пакеты
        self.page_btn = QtWidgets.QPushButton("GitHub ↗")
        self.page_btn.setToolTip(f"Страница обновлений: {UPDATES_PAGE}\nОткроется в браузере")
        self.page_btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.page_btn.setAutoDefault(False)
        self.page_btn.setStyleSheet("QPushButton { padding: 1px 8px; min-width: 0; font-size: 11px; }")
        self.page_btn.clicked.connect(lambda: open_updates_page())
        self.page_btn.ensurePolished()               # ширина — по шрифту из стиля кнопки (11 px)
        fit_buttons(self.page_btn, pad=24)          # и она не уже своего текста (2.1.72: в 2.1.71 было min-width 0)
        top.addWidget(self.page_btn, 0, QtCore.Qt.AlignmentFlag.AlignTop)
        lay.addLayout(top)
        log = QtWidgets.QTextBrowser()
        log.setHtml(_changes_html(ver.CHANGES))
        lay.addWidget(log, 1)
        row = QtWidgets.QHBoxLayout()
        self.check_btn = QtWidgets.QPushButton("Проверить обновления")
        self.check_btn.setToolTip("Есть ли новая версия в " + update_online.REPO + " (GitHub)")
        self.check_btn.clicked.connect(lambda: self._check_online())
        install = QtWidgets.QPushButton("Установить обновление…")
        install.setToolTip("Пакет fx_update_*.zip с диска")
        install.clicked.connect(self._install)
        back = QtWidgets.QPushButton("Откатить обновление…")
        back.setEnabled(any(not b["restored"] for b in updater.list_backups(self.root)))
        back.clicked.connect(self._rollback)
        close = QtWidgets.QPushButton("Закрыть")
        close.clicked.connect(self.reject)
        row.addWidget(self.check_btn)
        row.addWidget(install)
        row.addWidget(back)
        row.addStretch(1)
        row.addWidget(close)
        lay.addLayout(row)
        fit_buttons(self.check_btn, install, back, close)

    def _check_online(self) -> None:
        """«Проверить обновления»: проверка в отдельном потоке; нашлось — окно с изменениями, нет — ответ словами."""
        self.check_btn.setEnabled(False)
        self.check_btn.setText("Проверяю…")              # короче прежнего текста — ширина кнопки та же
        run_check(self, self.root, lambda res: self._checked(res))

    def _checked(self, res: "update_online.Result") -> None:
        try:
            self.check_btn.setEnabled(True)
            self.check_btn.setText("Проверить обновления")
        except RuntimeError:                       # окно «О проекте» уже закрыли
            return
        if res.status != update_online.OK:
            box = QtWidgets.QMessageBox.information if res.status in (update_online.NONE, update_online.NO_KEY) \
                else QtWidgets.QMessageBox.warning
            box(self, "Обновления", res.message[:1].upper() + res.message[1:])
            return
        dlg = OnlineUpdateDialog(self, res)
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted and dlg.command:
            self.command = dlg.command
            self.accept()

    def _install(self) -> None:
        cmd = choose_and_confirm_update(self, self.root)
        if cmd:
            self.command = cmd
            self.accept()

    def _rollback(self) -> None:
        cmd = confirm_rollback(self, self.root)
        if cmd:
            self.command = cmd
            self.accept()


class UpdateConfirmDialog(QtWidgets.QDialog):
    """Что поставит пакет: версия, изменения, файлы; правленные вами файлы — с галочкой «заменить»."""

    def __init__(self, parent, plan: dict, package: str):
        super().__init__(parent)
        self.plan = plan
        self.setWindowTitle("Установка обновления")
        self.resize(600, 520)
        lay = QtWidgets.QVBoxLayout(self)
        files = plan["files"]
        counts = {k: sum(1 for f in files if f["action"] == k) for k in ("add", "replace", "same")}
        extra = []
        if plan["pip"]:
            extra.append("пакеты Python: " + ", ".join(plan["pip"]))
        if plan["build_rust"]:
            extra.append("пересборка модуля fx_engine (несколько минут, нужен Rust)")
        info = (f"<b>FX Terminal {html.escape(plan['from'])} → {html.escape(plan['to'])}</b>"
                f"<br>пакет: {html.escape(Path(package).name)}"
                f"<br>файлов: заменится {counts['replace']}, добавится {counts['add']}, без изменений {counts['same']}"
                + (f", удалится {len(plan['delete'])}" if plan["delete"] else "")
                + "".join(f"<br>{html.escape(e)}" for e in extra))
        for w in plan["warnings"]:
            info += f"<br><span style='color:#e05a5a'>{html.escape(w)}</span>"
        label = QtWidgets.QLabel(info)
        label.setTextFormat(QtCore.Qt.TextFormat.RichText)
        label.setWordWrap(True)
        lay.addWidget(label)
        changes = QtWidgets.QTextBrowser()
        changes.setHtml(_changes_html([(plan["to"], "что нового", plan["changes"])]))
        lay.addWidget(changes, 1)

        self.modified = QtWidgets.QListWidget()
        mods = [f for f in files if f.get("modified")]
        if mods:
            note = QtWidgets.QLabel("Эти файлы вы меняли сами. С галочкой — заменить (ваш файл останется в бэкапе); "
                                    "без галочки — оставить ваш, новый ляжет рядом как .new:")
            note.setWordWrap(True)
            lay.addWidget(note)
            for f in mods:
                item = QtWidgets.QListWidgetItem(f["path"])
                item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(QtCore.Qt.CheckState.Checked)
                self.modified.addItem(item)
            self.modified.setMaximumHeight(110)
            lay.addWidget(self.modified)

        # С родителем сразу: setVisible(True) у виджета без родителя на миг показывал бы его отдельным окном
        self.downgrade = QtWidgets.QCheckBox("Да, поставить более старую версию", self)
        self.downgrade.setVisible(plan["downgrade"])
        lay.addWidget(self.downgrade)
        tail = QtWidgets.QLabel("Терминал закроется (раскладка и заметки сохранятся), обновление поставится, "
                                "пройдут проверки, и терминал запустится снова. Если проверки не пройдут — "
                                "файлы вернутся сами.")
        tail.setWordWrap(True)
        lay.addWidget(tail)
        buttons = QtWidgets.QDialogButtonBox()
        self.ok = buttons.addButton("Установить и перезапустить", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.addButton("Отмена", QtWidgets.QDialogButtonBox.ButtonRole.RejectRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)
        nothing = counts["add"] == 0 and counts["replace"] == 0 and not plan["delete"]
        self.ok.setEnabled(plan["requires_ok"] and not nothing and not plan["downgrade"])
        if nothing:
            self.ok.setText("Уже установлено")
        self.downgrade.toggled.connect(lambda on: self.ok.setEnabled(plan["requires_ok"] and on))

    def keep(self) -> list[str]:
        """Правленные файлы без галочки — не заменять."""
        out = []
        for i in range(self.modified.count()):
            item = self.modified.item(i)
            if item.checkState() != QtCore.Qt.CheckState.Checked:
                out.append(item.text())
        return out


class OnlineUpdateDialog(QtWidgets.QDialog):
    """Найдено обновление в интернете: версии, изменения всех пакетов цепочки, «Установить и перезапустить» /
    «Позже». command — команда updater после «Установить» (иначе None)."""

    def __init__(self, parent, res: "update_online.Result", root: Path = ROOT):
        super().__init__(parent)
        self.res = res
        self.command: list[str] | None = None
        self.setWindowTitle("Доступно обновление")
        self.resize(600, 500)
        lay = QtWidgets.QVBoxLayout(self)
        lines = [f"<b>FX Terminal {html.escape(res.current)} → {html.escape(res.target)}</b>"]
        if len(res.steps) > 1:
            lines.append(f"пакетов: {len(res.steps)} — поставятся по очереди")
        if any(step.get("build_rust") for step in res.steps):
            lines.append("будет пересборка модуля fx_engine (несколько минут, нужен Rust)")
        if res.status == update_online.OK and "дальше" in res.message:
            lines.append(html.escape(res.message.split("; дальше — ", 1)[-1]))
        head = QtWidgets.QLabel("<br>".join(lines))
        head.setTextFormat(QtCore.Qt.TextFormat.RichText)
        head.setWordWrap(True)
        lay.addWidget(head)
        changes = QtWidgets.QTextBrowser()
        changes.setHtml(_changes_html(res.changes()))
        lay.addWidget(changes, 1)
        self.auto = QtWidgets.QCheckBox("Проверять обновления автоматически (при запуске и раз в час)", self)
        self.auto.setChecked(auto_check_enabled())
        self.auto.toggled.connect(lambda on: _settings().setValue(AUTO_KEY, bool(on)))
        lay.addWidget(self.auto)
        tail = QtWidgets.QLabel("Пакеты уже скачаны и проверены (подпись и контрольные суммы). Терминал закроется "
                                "(раскладка и заметки сохранятся; при позиции LIVE он спросит), обновление поставится, "
                                "пройдут проверки, и терминал запустится снова. Если проверки не пройдут — файлы "
                                "вернутся сами.")
        tail.setWordWrap(True)
        lay.addWidget(tail)
        row = QtWidgets.QHBoxLayout()
        self.ok = QtWidgets.QPushButton("Установить и перезапустить")
        later = QtWidgets.QPushButton("Позже")
        for button in (self.ok, later):           # без кнопки по умолчанию: Enter / пробел из стакана сюда не попадут
            button.setAutoDefault(False)
            button.setDefault(False)
            button.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        self.ok.clicked.connect(lambda: self._install(root))
        later.clicked.connect(self.reject)
        row.addStretch(1)
        row.addWidget(self.ok)
        row.addWidget(later)
        lay.addLayout(row)
        fit_buttons(self.ok, later)

    def _install(self, root: Path) -> None:
        self.command = update_online.install_command(root, self.res)
        if self.command:
            self.accept()


class _Relay(QtCore.QObject):
    """Ответ проверки из рабочего потока — в поток интерфейса (сигнал между потоками идёт очередью)."""
    done = QtCore.Signal(object)


def run_check(owner: QtCore.QObject, root: Path, callback) -> None:
    """update_online.check в отдельном потоке; callback(Result) — в потоке интерфейса. owner держит связь живой."""
    relay = _Relay(owner)
    relay.done.connect(lambda res: (callback(res), relay.deleteLater()),
                       QtCore.Qt.ConnectionType.QueuedConnection)       # всегда в потоке интерфейса

    def work() -> None:
        res = update_online.check(root)
        try:
            relay.done.emit(res)
        except RuntimeError:                       # owner (а с ним relay) уже удалён — ответ некому
            pass

    threading.Thread(target=work, name="update-check", daemon=True).start()


class AutoChecker(QtCore.QObject):
    """Проверка обновлений по таймеру (см. описание файла). install(cmd) — как поставить: обычно
    MainWindow.run_update_command (закрыть терминал и запустить updater)."""

    def __init__(self, window, root: Path = ROOT, install=None):
        super().__init__(window)
        self.window, self.root = window, Path(root)
        self._install = install
        self._busy = False
        self._postponed: set[str] = set()          # «Позже» в этом запуске
        self._dialog: OnlineUpdateDialog | None = None
        self._last_status: str | None = None
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(CHECK_EVERY_MS)
        self.timer.timeout.connect(lambda: self.check())
        QtCore.QTimer.singleShot(FIRST_CHECK_MS, lambda: self.check())
        self.timer.start()

    def check(self) -> None:
        if self._busy or not auto_check_enabled() or (self._dialog is not None and self._dialog.isVisible()):
            return
        self._busy = True
        run_check(self, self.root, lambda res: self._done(res))

    def _done(self, res: "update_online.Result") -> None:
        self._busy = False
        status = res.status
        if status != self._last_status or status == update_online.OK:     # в журнал — только перемены
            if status == update_online.ERROR:
                print(f"[обновления] проверка через интернет не удалась: {res.message}", file=sys.stderr)
            elif status in (update_online.OK, update_online.GAP):
                print(f"[обновления] {res.message}", file=sys.stderr)
            elif status == update_online.NONE and self._last_status == update_online.ERROR:
                print("[обновления] проверка снова проходит: " + res.message, file=sys.stderr)
        self._last_status = status
        if status != update_online.OK or res.target in self._postponed:
            return
        self.show(res)

    def show(self, res: "update_online.Result") -> None:
        dlg = OnlineUpdateDialog(self.window, res, self.root)
        dlg.setModal(False)
        dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_ShowWithoutActivating, True)   # не забирать фокус у стакана
        dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.finished.connect(lambda code: self._closed(dlg, code))
        self._dialog = dlg
        dlg.show()

    def _closed(self, dlg: OnlineUpdateDialog, code: int) -> None:
        self._dialog = None
        if code == QtWidgets.QDialog.DialogCode.Accepted and dlg.command and self._install is not None:
            self._install(dlg.command)
        else:
            self._postponed.add(dlg.res.target)


def start_auto_check(window, root: Path = ROOT) -> AutoChecker | None:
    """Запустить проверку по таймеру (из gui_app после показа окна). Ключа подписи нет — не запускается."""
    if not update_online.known_keys():
        return None
    install = getattr(window, "run_update_command", None)
    checker = AutoChecker(window, root, install)
    window._update_checker = checker
    return checker


def choose_and_confirm_update(parent, root: Path = ROOT) -> list[str] | None:
    """Выбрать пакет, показать план -> команда updater (или None — отменено / пакет не годится)."""
    settings = QtCore.QSettings("MyTradingTools", "FxTerminal")
    start = str(settings.value(LAST_DIR_KEY, str(Path.home() / "Downloads")))
    path, _ = QtWidgets.QFileDialog.getOpenFileName(parent, "Пакет обновления FX Terminal", start, PACKAGE_FILTER)
    if not path:
        return None
    settings.setValue(LAST_DIR_KEY, str(Path(path).parent))
    try:
        manifest = updater.read_package(path)
        updater.ensure_baseline(root)
        plan = updater.plan(root, manifest)
    except (updater.UpdateError, OSError) as exc:
        QtWidgets.QMessageBox.warning(parent, "Обновление", f"Пакет не подходит: {exc}")
        return None
    dlg = UpdateConfirmDialog(parent, plan, path)
    if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
        return None
    args = [path]
    for rel in dlg.keep():
        args += ["--keep", rel]
    if plan["downgrade"]:
        args.append("--allow-downgrade")
    return updater.updater_command(root, "apply", *args)


def confirm_rollback(parent, root: Path = ROOT) -> list[str] | None:
    """Выбрать бэкап (по умолчанию последний) -> команда отката (или None)."""
    backups = [b for b in updater.list_backups(root) if not b["restored"]]
    if not backups:
        QtWidgets.QMessageBox.information(parent, "Откат", "Бэкапов нет — откатывать нечего.")
        return None
    items = [f"вернуть {b['from']} (обновление до {b['to']} от {b['time']})" for b in backups]
    choice, ok = QtWidgets.QInputDialog.getItem(parent, "Откатить обновление",
                                                "Терминал закроется, файлы вернутся из бэкапа, и он запустится "
                                                "снова.\nЧто вернуть:", items, 0, False)
    if not ok:
        return None
    backup = backups[items.index(choice)]["dir"]
    return updater.updater_command(root, "rollback", "--backup", backup)


def show_last_result(parent, root: Path = ROOT) -> None:
    """Итог установки / отката, сделанных до этого запуска (показывается один раз)."""
    res = updater.take_last_result(root)
    if not res:
        return
    text = res.get("message") or "Обновление завершено"
    log_hint = "\n\nПодробности — logs\\update_ДАТА.log"
    if res.get("status") in ("ok", "rollback"):
        QtWidgets.QMessageBox.information(parent, "Обновление", text)
    else:
        QtWidgets.QMessageBox.warning(parent, "Обновление", text + log_hint)
