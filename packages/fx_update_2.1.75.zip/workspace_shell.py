# -*- coding: utf-8 -*-
"""Рабочие области терминала.

  * WorkspacePage — одна рабочая область: докинг-панели (QtAds) или, пока панелей нет,
    пустой стартовый экран с карточками быстрого запуска;
  * WorkspaceBar  — нижняя панель: вкладки рабочих областей, «+», кнопки действий справа;
  * WorkspaceShell — стопка областей + нижняя панель, реестр панелей, сохранение раскладки.

Панели регистрируются через PanelSpec. Одноэкземплярные (single=True: Позиции, Заявки, CNY Forward,
Открытый интерес, Опционы…) живут в одной области: повторное открытие переносит панель
в текущую область вместе с её виджетом, потоки и накопленные данные не пересоздаются.
Многоэкземплярные (графики, тики) создаются заново при каждом открытии.

Новые окна (2.1.75) открываются отдельными окнами вне терминала и пространств (new_windows_float, настройка
NEW_WINDOWS_KEY, по умолчанию — да): перетащите окно за заголовок в область, где оно открыто, — QtAds покажет места
вставки; в другую вкладку или другое пространство — «Прикрепить окно сюда» в меню «Окна» или в «⋮» нижней панели
нужного пространства (WorkspaceShell.attach_floating). Сохранённая раскладка при запуске восстанавливается как
была: отдельными окнами открываются только новые.

Цвета берутся из текущей темы терминала (fx_theme.py), палитра не меняется.
"""
from __future__ import annotations

import base64
import json
import sys
from dataclasses import dataclass
from typing import Callable

from PySide6 import QtCore, QtGui, QtWidgets

import docking

try:
    import fx_theme
except Exception:
    fx_theme = None


def _c(name: str, default: str) -> str:
    return str(getattr(fx_theme, name, default)) if fx_theme is not None else default


@dataclass
class PanelSpec:
    key: str                                   # идентификатор («chart», «positions», …)
    title: str                                 # заголовок вкладки панели
    factory: Callable[[], QtWidgets.QWidget]   # создаёт содержимое панели
    single: bool = False                       # одноэкземплярная панель
    on_close: Callable[[QtWidgets.QWidget], None] | None = None   # многоэкземплярная панель закрыта: остановить потоки
    on_show: Callable[[], None] | None = None  # панель стала видимой (ленивый запуск содержимого)
    # Закрытие с подтверждением (LIVE-стакан с позицией или заявками): вызывается ДО закрытия панели,
    # True — можно закрывать. При отказе панель остаётся открытой.
    confirm_close: Callable[[QtWidgets.QWidget], bool] | None = None
    # Состояние содержимого, которое нужно пережить перезапуск (инструмент и ТФ графика):
    save_state: Callable[[QtWidgets.QWidget], dict] | None = None
    restore_factory: Callable[[dict], QtWidgets.QWidget] | None = None   # создать панель из сохранённого состояния


# (ключ панели, заголовок, подпись, значок) — карточки стартового экрана
CARDS = (
    ("chart", "Открыть график", "Анализируйте рынок\nв один клик", "chart"),
    ("trade", "Торговля", "Быстрый доступ\nк заявкам", "trade"),
    ("portfolio", "Портфель", "Контроль позиций\nи P&L", "portfolio"),
    ("algos", "Алгоритмы", "Автоматизируйте\nстратегии", "algos"),
)


# ============================================================ стартовый экран

def _glyph_pixmap(kind: str, size: int = 40) -> QtGui.QPixmap:
    """Монохромный значок карточки в цветах текущей темы."""
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
    p.setPen(QtGui.QPen(QtGui.QColor(_c("BORDER_STRONG", "#4a4d54")), 1))
    p.setBrush(QtGui.QColor(_c("BG_INPUT", "#18191c")))
    p.drawRoundedRect(QtCore.QRectF(0.5, 0.5, size - 1, size - 1), 9, 9)

    pen = QtGui.QPen(QtGui.QColor(_c("TEXT", "#d7dae0")), 1.8)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
    s = size / 40.0
    p.scale(s, s)

    if kind == "chart":
        p.drawPolyline([QtCore.QPointF(9, 27), QtCore.QPointF(16, 19), QtCore.QPointF(21, 23), QtCore.QPointF(30, 11)])
        p.drawLine(QtCore.QPointF(9, 31), QtCore.QPointF(31, 31))
    elif kind == "trade":
        p.drawLine(QtCore.QPointF(10, 16), QtCore.QPointF(29, 16))
        p.drawPolyline([QtCore.QPointF(25, 12), QtCore.QPointF(29, 16), QtCore.QPointF(25, 20)])
        p.drawLine(QtCore.QPointF(30, 25), QtCore.QPointF(11, 25))
        p.drawPolyline([QtCore.QPointF(15, 21), QtCore.QPointF(11, 25), QtCore.QPointF(15, 29)])
    elif kind == "screener":
        p.drawPolygon([QtCore.QPointF(10, 12), QtCore.QPointF(30, 12), QtCore.QPointF(22, 21),
                       QtCore.QPointF(22, 29), QtCore.QPointF(18, 27), QtCore.QPointF(18, 21)])
    elif kind == "portfolio":
        p.drawRoundedRect(QtCore.QRectF(9, 15, 22, 15), 2, 2)
        p.drawRect(QtCore.QRectF(15, 11, 10, 4))
        p.drawLine(QtCore.QPointF(9, 22), QtCore.QPointF(31, 22))
    else:  # algos
        p.drawEllipse(QtCore.QPointF(20, 20), 9, 9)
        p.drawEllipse(QtCore.QPointF(20, 20), 2.5, 2.5)
        p.drawLine(QtCore.QPointF(20, 8), QtCore.QPointF(20, 11))
        p.drawLine(QtCore.QPointF(20, 29), QtCore.QPointF(20, 32))
    p.end()
    return pm


def tool_icon(kind: str, size: int = 20) -> QtGui.QIcon:
    """Монохромный значок кнопки нижней панели: спокойный цвет, на наведении — основной цвет текста."""
    icon = QtGui.QIcon()
    states = (
        (QtGui.QIcon.Mode.Normal, _c("TEXT_DIM", "#8b9098")),
        (QtGui.QIcon.Mode.Active, _c("TEXT", "#d7dae0")),
    )
    for mode, color in states:
        pm = QtGui.QPixmap(size, size)
        pm.fill(QtCore.Qt.GlobalColor.transparent)
        p = QtGui.QPainter(pm)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        pen = QtGui.QPen(QtGui.QColor(color), 1.6)
        pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        p.scale(size / 20.0, size / 20.0)
        if kind == "book":          # биржевой стакан: полосы глубины разной длины
            for y, half in ((3.5, 3), (7, 5), (10.5, 7), (14, 5), (17.5, 3)):
                p.drawLine(QtCore.QPointF(10 - half, y), QtCore.QPointF(10 + half, y))
        elif kind == "chart":       # график
            p.drawPolyline([QtCore.QPointF(3, 15), QtCore.QPointF(8, 10), QtCore.QPointF(11, 13), QtCore.QPointF(17, 5)])
            p.drawLine(QtCore.QPointF(3, 18), QtCore.QPointF(17, 18))
        else:                       # workspace: окно с плюсом — новое пространство
            p.drawRoundedRect(QtCore.QRectF(2.5, 4, 15, 12), 2, 2)
            p.drawLine(QtCore.QPointF(10, 7.5), QtCore.QPointF(10, 12.5))
            p.drawLine(QtCore.QPointF(7.5, 10), QtCore.QPointF(12.5, 10))
        p.end()
        icon.addPixmap(pm, mode)
    return icon


class _Card(QtWidgets.QFrame):
    clicked = QtCore.Signal()

    def __init__(self, glyph: str, title: str, subtitle: str):
        super().__init__()
        self.setObjectName("card")
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(196, 132)

        icon = QtWidgets.QLabel()
        icon.setPixmap(_glyph_pixmap(glyph))
        arrow = QtWidgets.QLabel("›")
        arrow.setObjectName("cardArrow")
        top = QtWidgets.QHBoxLayout()
        top.addWidget(icon)
        top.addStretch(1)
        top.addWidget(arrow, 0, QtCore.Qt.AlignmentFlag.AlignTop)

        title_lbl = QtWidgets.QLabel(title)
        title_lbl.setObjectName("cardTitle")
        sub_lbl = QtWidgets.QLabel(subtitle)
        sub_lbl.setObjectName("cardSub")

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(2)
        layout.addLayout(top)
        layout.addSpacing(8)
        layout.addWidget(title_lbl)
        layout.addWidget(sub_lbl)
        layout.addStretch(1)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class _DropZone(QtWidgets.QFrame):
    """Рамка пустой области: штриховая линия (QSS рисует dashed мелкими точками, поэтому рисуем сами)."""

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        pen = QtGui.QPen(QtGui.QColor(_c("BORDER_STRONG", "#4a4d54")), 1.2)
        pen.setDashPattern([6.0, 5.0])
        p.setPen(pen)
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1), 16, 16)
        p.end()


class EmptyState(QtWidgets.QWidget):
    """Пустая рабочая область: рамка пунктиром и карточки быстрого запуска."""
    cardClicked = QtCore.Signal(str)

    def __init__(self, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QFrame#dropZone {{ border: none; background: transparent; }}
            QFrame#card {{ background: {_c('BG_PANEL', '#232427')}; border: 1px solid {_c('BORDER', '#34363b')}; border-radius: 8px; }}
            QFrame#card:hover {{ background: {_c('BG_HOVER', '#2f3035')}; border-color: {_c('BORDER_STRONG', '#4a4d54')}; }}
            QFrame#card QLabel {{ background: transparent; }}
            QLabel#cardTitle {{ font-size: 14px; font-weight: 600; }}
            QLabel#cardSub {{ color: {_c('TEXT_DIM', '#8b9098')}; font-size: 11px; }}
            QLabel#cardArrow {{ color: {_c('TEXT_DIM', '#8b9098')}; font-size: 16px; }}
        """)
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(14)
        row.addStretch(1)
        for key, title, subtitle, glyph in CARDS:
            card = _Card(glyph, title, subtitle)
            card.clicked.connect(lambda _=False, k=key: self.cardClicked.emit(k))
            row.addWidget(card)
        row.addStretch(1)

        zone = _DropZone()
        zone.setObjectName("dropZone")
        zone_layout = QtWidgets.QVBoxLayout(zone)
        zone_layout.addStretch(1)
        zone_layout.addLayout(row)
        zone_layout.addStretch(1)

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(60, 40, 60, 40)
        outer.addStretch(1)
        outer.addWidget(zone, 4)
        outer.addStretch(1)


# ============================================================ рабочая область

class WorkspacePage(QtWidgets.QWidget):
    changed = QtCore.Signal()      # раскладка поменялась (для автосохранения)

    def __init__(self, shell: "WorkspaceShell"):
        super().__init__()
        self.shell = shell
        self.manager = docking.create_manager(self)
        self.empty = EmptyState()
        self.empty.cardClicked.connect(shell.open_card)
        self._handled: set[str] = set()      # многоэкземплярные панели, закрытие которых уже обработано
        self._removing: set[str] = set()     # панели, удаление которых уже запланировано

        self._stack = QtWidgets.QStackedLayout(self)
        self._stack.setContentsMargins(0, 0, 0, 0)
        self._stack.addWidget(self.manager)
        self._stack.addWidget(self.empty)

        for signal_name in ("dockWidgetAdded", "dockWidgetRemoved", "stateRestored"):
            signal = getattr(self.manager, signal_name, None)
            if signal is not None:
                try:
                    signal.connect(self._on_layout_changed)
                except Exception as exc:
                    print(f"[workspace] сигнал {signal_name}: {exc}", file=sys.stderr)

        # Страховка от пропущенного сигнала (например, панель удалена при закрытии).
        self._sync_timer = QtCore.QTimer(self)
        self._sync_timer.timeout.connect(self._sync)
        self._sync_timer.start(1000)
        self._sync()

    # ---- служебное -----------------------------------------------------------
    def _on_layout_changed(self, *_args) -> None:
        QtCore.QTimer.singleShot(0, self._sync)
        self.changed.emit()

    def _sync(self) -> None:
        # Страховка: закрытая многоэкземплярная панель обрабатывается, даже если сигнал closed пропущен.
        for name, dock in list(docking.docks(self.manager).items()):
            spec = self.shell.specs.get(self.key_of(name))
            if spec is not None and not spec.single and dock.isClosed():
                self._on_multi_closed(spec, dock)
        has_docks = bool(docking.open_docks(self.manager))
        self._stack.setCurrentWidget(self.manager if has_docks else self.empty)

    def _watch(self, dock, spec: PanelSpec | None = None) -> None:
        for signal_name in ("viewToggled", "visibilityChanged"):
            signal = getattr(dock, signal_name, None)
            if signal is None:
                continue
            try:
                if signal_name == "viewToggled":
                    signal.connect(self._on_layout_changed)
                if spec is not None and spec.on_show is not None:
                    signal.connect(lambda visible, f=spec.on_show: f() if visible else None)
            except Exception as exc:
                print(f"[workspace] сигнал {signal_name}: {exc}", file=sys.stderr)
        closed = getattr(dock, "closed", None)
        if closed is not None and spec is not None and not spec.single:
            try:
                closed.connect(lambda s=spec, d=dock: self._on_multi_closed(s, d))
            except Exception as exc:
                print(f"[workspace] сигнал closed: {exc}", file=sys.stderr)

    def _on_multi_closed(self, spec: PanelSpec, dock) -> None:
        """Многоэкземплярная панель закрыта: остановить её потоки (on_close) и убрать из менеджера."""
        name = dock.objectName()
        if name in self._handled:
            return
        self._handled.add(name)
        widget = dock.widget()
        if widget is not None and spec.confirm_close is not None:
            try:
                allowed = bool(spec.confirm_close(widget))
            except Exception as exc:
                print(f"[workspace] confirm_close({spec.key}): {type(exc).__name__}: {exc}", file=sys.stderr)
                allowed = False
            if not allowed:
                # Окно отказалось закрываться (LIVE: позиция/заявки) — панель возвращаем на экран.
                self._handled.discard(name)
                docking.show_dock(dock)
                return
        if widget is not None and spec.on_close is not None:
            try:
                spec.on_close(widget)
            except Exception as exc:
                print(f"[workspace] on_close({spec.key}): {type(exc).__name__}: {exc}", file=sys.stderr)
        self.discard_dock(dock)

    def discard_dock(self, dock) -> None:
        """Убрать панель (после остановки её содержимого); повторные вызовы безопасны."""
        name = dock.objectName()
        if name in self._removing:
            return
        self._removing.add(name)
        QtCore.QTimer.singleShot(0, lambda d=dock: self._remove_dock(d))

    def _remove_dock(self, dock) -> None:
        name = dock.objectName()
        self._removing.discard(name)
        if name not in docking.docks(self.manager):
            return
        widget = docking.release(self.manager, dock)
        if widget is not None:
            widget.deleteLater()
        self._handled.discard(name)
        self._on_layout_changed()

    def swap_widget(self, dock, widget, title: str | None = None):
        """Поставить другой виджет на место прежнего в той же панели; прежний возвращается (уже вне панели)."""
        old = docking.swap_widget(dock, widget)
        if title:
            dock.setWindowTitle(title)
        self._on_layout_changed()
        return old

    def confirm_dispose(self) -> bool:
        """Перед закрытием области: панели с подтверждением (LIVE-стаканы) закрываются через него.
        False — одна из них отказалась (остаётся открытой), область закрывать нельзя."""
        for name, dock in list(docking.docks(self.manager).items()):
            spec = self.shell.specs.get(self.key_of(name))
            if spec is None or spec.single or spec.confirm_close is None or dock.isClosed():
                continue
            widget = dock.widget()
            if widget is None:
                continue
            try:
                if not spec.confirm_close(widget):
                    return False
            except Exception as exc:
                print(f"[workspace] confirm_close({spec.key}): {type(exc).__name__}: {exc}", file=sys.stderr)
                return False
        return True

    def dock_by_name(self, name: str):
        return docking.docks(self.manager).get(name)

    @staticmethod
    def key_of(name: str) -> str:
        return name.split("#")[0]

    def _next_name(self, key: str) -> tuple[str, int]:
        used = set(docking.docks(self.manager))
        n = 1
        while f"{key}#{n}" in used:
            n += 1
        return f"{key}#{n}", n

    # ---- открытие панелей -------------------------------------------------------
    def open_panel(self, spec: PanelSpec, widget: QtWidgets.QWidget | None = None, floating: bool | None = None):
        """Открыть панель в этой области; floating — отдельным окном (None — по настройке new_windows_float)."""
        if spec.single:
            existing = self.dock_by_name(spec.key)
            if existing is not None:
                docking.show_dock(existing)
                return existing
            widget = widget or self.shell.parked.pop(spec.key, None) or spec.factory()
            name, title = spec.key, spec.title
        else:
            widget = spec.factory()
            name, n = self._next_name(spec.key)
            title = spec.title if n == 1 else f"{spec.title} {n}"
        if widget is None:          # фабрика отказала (например, достигнут лимит окон «Тики»)
            return None
        return self._place(spec, widget, name, title, floating)

    def adopt_panel(self, spec: PanelSpec, widget: QtWidgets.QWidget, title: str | None = None,
                    floating: bool | None = None):
        """Поставить уже созданный виджет (окно «Тики» или «Стакан») как новую многоэкземплярную панель."""
        name, n = self._next_name(spec.key)
        return self._place(spec, widget, name, title or (spec.title if n == 1 else f"{spec.title} {n}"), floating)

    def _place(self, spec: PanelSpec, widget: QtWidgets.QWidget, name: str, title: str,
               floating: bool | None = None):
        """Новая панель: отдельным окном (floating; None — по настройке new_windows_float) или вкладкой области."""
        # Многоэкземплярные панели убираем сами (_on_multi_closed), чтобы сначала остановить потоки.
        dock = docking.create_dock(self.manager, title, widget, name, delete_on_close=False)
        self._watch(dock, spec)
        if new_windows_float() if floating is None else floating:
            size, pos = float_geometry(spec.key, widget, self.window())
            if docking.add_dock_floating(self.manager, dock, size, pos) is None and dock.dockAreaWidget() is None:
                docking.add_dock(self.manager, dock, docking.first_area(self.manager))
        else:
            docking.add_dock(self.manager, dock, docking.first_area(self.manager))
        self._on_layout_changed()
        return dock

    def floating_docks(self) -> list:
        """Панели этой области, открытые отдельными окнами: [(имя, панель)]."""
        return [(name, dock) for name, dock in docking.docks(self.manager).items() if docking.is_floating(dock)]

    def release_single(self, key: str):
        """Достать виджет панели по имени (одноэкземплярной — для переноса в другую область; любой — чтобы
        прикрепить отдельное окно к другой вкладке, attach_floating). Панель убирается, виджет живёт дальше."""
        dock = self.dock_by_name(key)
        if dock is None:
            return None
        widget = docking.release(self.manager, dock)
        self._on_layout_changed()
        return widget

    def park_singles(self) -> None:
        """Перед закрытием области: одноэкземплярные панели не уничтожаются, а паркуются в оболочке."""
        for name in list(docking.docks(self.manager)):
            spec = self.shell.specs.get(self.key_of(name))
            if spec is not None and spec.single:
                widget = self.release_single(name)
                if widget is not None:
                    self.shell.parked[spec.key] = widget

    def dispose_multi(self) -> None:
        """Область закрывается: многоэкземплярным панелям (графики) сообщаем об этом — остановить потоки."""
        for name, dock in list(docking.docks(self.manager).items()):
            spec = self.shell.specs.get(self.key_of(name))
            if spec is None or spec.single or name in self._handled:
                continue
            self._handled.add(name)
            widget = dock.widget()
            if widget is not None and spec.on_close is not None:
                try:
                    spec.on_close(widget)
                except Exception as exc:
                    print(f"[workspace] on_close({spec.key}): {type(exc).__name__}: {exc}", file=sys.stderr)

    # ---- сохранение/восстановление ----------------------------------------------
    def snapshot(self) -> dict:
        docks = []
        for name, dock in docking.docks(self.manager).items():
            item = {"name": name, "title": dock.windowTitle()}
            spec = self.shell.specs.get(self.key_of(name))
            widget = dock.widget()
            if spec is not None and spec.save_state is not None and widget is not None:
                try:
                    item["state"] = spec.save_state(widget)
                except Exception as exc:
                    print(f"[workspace] save_state({spec.key}): {type(exc).__name__}: {exc}", file=sys.stderr)
            docks.append(item)
        try:
            state = base64.b64encode(docking.save_state(self.manager)).decode("ascii")
        except Exception as exc:
            print(f"[workspace] saveState: {exc}", file=sys.stderr)
            state = ""
        return {"docks": docks, "state": state}

    def restore(self, data: dict) -> None:
        # Сначала создаём все панели вкладками в одной области — так ADS ожидает их перед restoreState.
        for item in data.get("docks", []):
            name = str(item.get("name", ""))
            spec = self.shell.specs.get(self.key_of(name))
            if spec is None:
                continue
            if spec.single:
                if self.shell.find_single_owner(spec.key) is not None:
                    continue    # уже восстановлена в другой области
                widget = self.shell.parked.pop(spec.key, None) or spec.factory()
            elif spec.restore_factory is not None:
                widget = spec.restore_factory(item.get("state") or {})
            else:
                widget = spec.factory()
            if widget is None:
                continue
            # Одноэкземплярные панели всегда под актуальным именем (иначе после переименования,
            # например «Котировки» → «Алгоритмы», из старой раскладки возвращалось бы прежнее);
            # у многоэкземплярных в заголовке инструмент — его берём из сохранённого.
            title = spec.title if spec.single else str(item.get("title") or spec.title)
            dock = docking.create_dock(self.manager, title, widget, name, delete_on_close=False)
            self._watch(dock, spec)
            docking.add_dock(self.manager, dock, docking.first_area(self.manager))
        state = data.get("state")
        if state:
            try:
                if not docking.restore_state(self.manager, base64.b64decode(state)):
                    print("[workspace] restoreState вернул False — оставлена раскладка по умолчанию", file=sys.stderr)
            except Exception as exc:
                print(f"[workspace] restoreState: {exc}", file=sys.stderr)
        self._sync()


# ============================================================ нижняя панель

class _TightTabBar(QtWidgets.QTabBar):
    """QTabBar ровно по ширине вкладок. Обычный резервирует место под кнопки прокрутки и растягивается,
    из-за чего между последней вкладкой и кнопкой «+» остаётся пустое место."""

    def sizeHint(self) -> QtCore.QSize:
        count = self.count()
        width = sum(self.tabSizeHint(i).width() for i in range(count))
        height = max([self.tabSizeHint(i).height() for i in range(count)] or [super().sizeHint().height()])
        return QtCore.QSize(width + 2, height)

    def minimumSizeHint(self) -> QtCore.QSize:
        return self.sizeHint()


class WorkspaceBar(QtWidgets.QWidget):
    currentChanged = QtCore.Signal(int)
    closeRequested = QtCore.Signal(int)
    addRequested = QtCore.Signal()
    renameRequested = QtCore.Signal(int)

    def __init__(self, parent: QtWidgets.QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("workspaceBar")
        self.setStyleSheet(f"""
            QWidget#workspaceBar {{ background: {_c('BG_PANEL', '#232427')}; border-top: 1px solid {_c('BORDER', '#34363b')}; }}
            QTabBar {{ background: transparent; }}
            QTabBar::tab {{ background: transparent; color: {_c('TEXT_DIM', '#8b9098')}; padding: 3px 14px;
                           margin-right: 4px; border: none; border-bottom: 2px solid transparent; }}
            QTabBar::tab:selected {{ color: {_c('TEXT', '#d7dae0')}; background: {_c('BG_PRESSED', '#2b2c30')};
                                    border-bottom: 2px solid {_c('ACCENT', '#5b8def')}; }}
            QTabBar::tab:hover:!selected {{ color: {_c('TEXT', '#d7dae0')}; background: {_c('BG_HOVER', '#2f3035')}; }}
            QToolButton {{ background: transparent; color: {_c('TEXT_DIM', '#8b9098')}; border: none; padding: 2px 8px; border-radius: 4px; }}
            QToolButton:hover {{ color: {_c('TEXT', '#d7dae0')}; background: {_c('BG_HOVER', '#2f3035')}; }}
            QToolButton::menu-indicator {{ image: none; }}
            QToolButton#tabClose {{ padding: 0; font-size: 15px; border-radius: 3px; }}
            QPushButton#barAction {{ background: transparent; color: {_c('TEXT', '#d7dae0')};
                                    border: 1px solid {_c('BORDER_STRONG', '#4a4d54')}; border-radius: 10px; padding: 0 14px; }}
            QPushButton#barAction:hover {{ background: {_c('BG_HOVER', '#2f3035')}; border-color: {_c('TEXT_DIM', '#8b9098')}; }}
            QPushButton#barAction:pressed {{ background: {_c('BG_PRESSED', '#2b2c30')}; }}
        """)
        self.tabs = _TightTabBar()
        self.tabs.setSizePolicy(QtWidgets.QSizePolicy.Policy.Maximum, QtWidgets.QSizePolicy.Policy.Preferred)
        self.tabs.setTabsClosable(False)      # кнопки «×» ставим свои (_sync_close_buttons) — в цветах темы
        self.tabs.setMovable(True)
        self.tabs.setExpanding(False)
        self.tabs.setDrawBase(False)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.currentChanged.connect(self.currentChanged)
        self.tabs.tabBarDoubleClicked.connect(self._on_double_click)

        self.add_btn = QtWidgets.QToolButton()
        self.add_btn.setText("+")
        self.add_btn.setToolTip("Новая вкладка")
        self.add_btn.clicked.connect(self.addRequested)

        self._tools = QtWidgets.QHBoxLayout()
        self._tools.setSpacing(8)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(8, 2, 8, 2)
        layout.setSpacing(2)
        layout.addWidget(self.tabs)
        layout.addWidget(self.add_btn)
        layout.addStretch(1)
        layout.addLayout(self._tools)

    def _on_double_click(self, index: int) -> None:
        if index >= 0:
            self.renameRequested.emit(index)

    def _index_of(self, page_id: int) -> int:
        for i in range(self.tabs.count()):
            if self.tabs.tabData(i) == page_id:
                return i
        return -1

    def _make_close_button(self, page_id: int) -> QtWidgets.QToolButton:
        close = QtWidgets.QToolButton()
        close.setObjectName("tabClose")
        close.setText("×")
        close.setToolTip("Закрыть вкладку")
        close.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        close.setFixedSize(16, 16)
        # Индекс вкладки меняется при перетаскивании и закрытии соседних — ищем его по page_id.
        close.clicked.connect(lambda _=False, pid=page_id: self.closeRequested.emit(self._index_of(pid)))
        return close

    def _sync_close_buttons(self) -> None:
        """«×» у вкладок есть, только когда вкладок больше одной: единственную закрывать нечем и незачем.
        Кнопку именно снимаем, а не прячем — спрятанная всё равно занимала бы место в вкладке."""
        side = QtWidgets.QTabBar.ButtonPosition.RightSide
        show = self.tabs.count() > 1
        for i in range(self.tabs.count()):
            has = self.tabs.tabButton(i, side) is not None
            if show and not has:
                self.tabs.setTabButton(i, side, self._make_close_button(self.tabs.tabData(i)))
            elif not show and has:
                self.tabs.setTabButton(i, side, None)

    def add_tab(self, name: str, page_id: int) -> int:
        index = self.tabs.addTab(name)
        self.tabs.setTabData(index, page_id)
        self._sync_close_buttons()
        return index

    def remove_tab(self, index: int) -> None:
        self.tabs.removeTab(index)
        self._sync_close_buttons()

    def add_tool(self, text: str, tooltip: str, callback) -> QtWidgets.QToolButton:
        """Кнопка действия справа (набор значков уточняется отдельно)."""
        button = QtWidgets.QToolButton()
        button.setText(text)
        button.setToolTip(tooltip)
        button.clicked.connect(lambda _=False: callback())
        self._tools.addWidget(button)
        return button

    def add_text_tool(self, text: str, tooltip: str, callback) -> QtWidgets.QPushButton:
        """Кнопка с текстом в скруглённой рамке (образец — кнопки диалогов Photoshop)."""
        button = QtWidgets.QPushButton(text)
        button.setObjectName("barAction")
        button.setToolTip(tooltip)
        button.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        button.setFixedHeight(20)
        button.clicked.connect(lambda _=False: callback())
        self._tools.addWidget(button)
        return button

    def add_icon_tool(self, kind: str, tooltip: str, callback) -> QtWidgets.QToolButton:
        """Кнопка со значком ('book' | 'chart' | 'workspace') для действия справа в нижней панели."""
        button = QtWidgets.QToolButton()
        button.setIcon(tool_icon(kind))
        button.setIconSize(QtCore.QSize(20, 20))
        button.setToolTip(tooltip)
        button.setAutoRaise(True)
        button.clicked.connect(lambda _=False: callback())
        self._tools.addWidget(button)
        return button

    def add_menu_tool(self, text: str, tooltip: str, menu: QtWidgets.QMenu) -> QtWidgets.QToolButton:
        button = QtWidgets.QToolButton()
        button.setText(text)
        button.setToolTip(tooltip)
        button.setMenu(menu)
        button.setPopupMode(QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup)
        self._tools.addWidget(button)
        return button


# ============================================================ оболочка и пространства

class ShellGroup(QtCore.QObject):
    """Общее для всех рабочих пространств терминала.

    Пространство — отдельное окно со своими вкладками: работа в одном не влияет
    на другое, у каждого своя нижняя панель. Основное пространство — центр главного окна, остальные —
    самостоятельные окна (отдельные кнопки на панели задач, переключение по Alt+Tab).
    Здесь живёт то, что у них общее: реестр панелей, припаркованные виджеты, цели карточек,
    поиск одноэкземплярной панели (она существует в одном месте на все окна)."""

    MAX_WORKSPACES = 10
    SETTINGS_KEY = "workspaces/group_json"
    layoutChanged = QtCore.Signal()

    def __init__(self, parent: QtCore.QObject | None = None):
        super().__init__(parent)
        self.specs: dict[str, PanelSpec] = {}
        self.parked: dict[str, QtWidgets.QWidget] = {}
        self.card_targets: dict[str, str] = {}
        self.shells: list[WorkspaceShell] = []
        self.windows: dict[int, WorkspaceWindow] = {}          # дополнительные пространства: номер -> окно
        self.tools_builder: Callable[[WorkspaceShell], None] | None = None   # наполняет нижнюю панель кнопками
        self.main_window: QtWidgets.QWidget | None = None

    # ---- реестр и поиск ---------------------------------------------------------------
    def register(self, spec: PanelSpec) -> None:
        self.specs[spec.key] = spec

    def main_shell(self) -> "WorkspaceShell | None":
        return self.shells[0] if self.shells else None

    def find_single_owner(self, key: str):
        """(пространство, область), где сейчас открыта одноэкземплярная панель, или (None, None)."""
        for shell in self.shells:
            for page in shell.pages.values():
                if page.dock_by_name(key) is not None:
                    return shell, page
        return None, None

    def dock_of(self, widget):
        """(пространство, область, панель) по виджету содержимого; (None, None, None), если он нигде не открыт."""
        for shell in self.shells:
            for page in shell.pages.values():
                for dock in docking.docks(page.manager).values():
                    if dock.widget() is widget:
                        return shell, page, dock
        return None, None, None

    def reveal(self, widget) -> bool:
        """Показать панель: переключить вкладку, сделать панель текущей и поднять окно пространства."""
        shell, page, dock = self.dock_of(widget)
        if page is None:
            return False
        for page_id, candidate in shell.pages.items():
            if candidate is page:
                index = shell._index_of(page_id)
                if index >= 0:
                    shell.bar.tabs.setCurrentIndex(index)
        docking.show_dock(dock)
        window = shell.window()
        if window is not None:
            window.show()
            window.raise_()
            window.activateWindow()
        return True

    def set_dock_title(self, widget, title: str) -> None:
        _shell, _page, dock = self.dock_of(widget)
        if dock is not None:
            dock.setWindowTitle(title)

    def replace_widget(self, old, new) -> bool:
        """Новое окно встаёт в панель прежнего (смена инструмента/режима стакана). False — прежнее нигде не закреплено."""
        _shell, page, dock = self.dock_of(old)
        if page is None:
            return False
        try:
            title = new.windowTitle()
        except Exception:
            title = None
        page.swap_widget(dock, new, title or None)
        return True

    def floating_docks(self) -> list:
        """Отдельные окна всех пространств: [(пространство, область, панель)]."""
        return [(shell, page, dock) for shell in self.shells for page in shell.pages.values()
                for _name, dock in page.floating_docks()]

    def remove_panel(self, widget) -> None:
        """Окно закрылось само — убрать его панель из пространства."""
        _shell, page, dock = self.dock_of(widget)
        if page is not None:
            page.discard_dock(dock)

    def active_shell(self) -> "WorkspaceShell | None":
        """Пространство активного окна (куда по умолчанию открываются новые панели)."""
        active = QtWidgets.QApplication.activeWindow()
        for shell in self.shells:
            if shell.window() is active:
                return shell
        return self.main_shell()

    # ---- окна пространств -----------------------------------------------------------------
    def workspace_count(self) -> int:
        return 1 + len(self.windows)

    def new_workspace(self, with_tab: bool = True, geometry: str | None = None, number: int | None = None):
        """Новое пространство — отдельное окно. Не более MAX_WORKSPACES вместе с основным."""
        if self.workspace_count() >= self.MAX_WORKSPACES:
            QtWidgets.QMessageBox.information(None, "FX Terminal", "Максимум рабочих пространств")
            return None
        if number is None or number in self.windows or number < 2:
            number = 2
            while number in self.windows:
                number += 1
        window = WorkspaceWindow(self, number)
        self.windows[number] = window
        if with_tab:
            window.shell.add_workspace()
        restored = False
        if geometry:
            try:
                restored = bool(window.restoreGeometry(QtCore.QByteArray(base64.b64decode(geometry))))
            except Exception:
                restored = False
        if not restored:
            main = self.main_window
            if main is not None:
                shift = 32 * (number - 1)
                window.setGeometry(main.geometry().translated(shift, shift))
            else:
                window.resize(1200, 800)
        window.show()
        return window

    def forget_window(self, window: "WorkspaceWindow") -> None:
        self.windows.pop(window.number, None)
        if window.shell in self.shells:
            self.shells.remove(window.shell)
        self.layoutChanged.emit()

    def close_secondary(self) -> None:
        """Выход из терминала: дополнительные пространства закрываются без вопросов."""
        for window in list(self.windows.values()):
            window.force_close()

    # ---- сохранение раскладки всех пространств -------------------------------------------------------
    def save(self, settings: QtCore.QSettings) -> None:
        main = self.main_shell()
        if main is None:
            return
        windows = []
        for number, window in sorted(self.windows.items()):
            geometry = ""
            try:
                geometry = base64.b64encode(bytes(window.saveGeometry())).decode("ascii")
            except Exception:
                pass
            windows.append({"number": number, "geometry": geometry, "shell": window.shell.snapshot()})
        settings.setValue(self.SETTINGS_KEY, json.dumps({"main": main.snapshot(), "windows": windows}, ensure_ascii=False))

    def restore(self, settings: QtCore.QSettings) -> bool:
        main = self.main_shell()
        if main is None:
            return False
        payload = None
        raw = settings.value(self.SETTINGS_KEY, "")
        if raw:
            try:
                payload = json.loads(str(raw))
            except ValueError:
                payload = None
        if payload is None:
            legacy = settings.value(WorkspaceShell.SETTINGS_KEY, "")     # прежний формат: только основное окно
            if legacy:
                try:
                    payload = {"main": json.loads(str(legacy)), "windows": []}
                except ValueError:
                    payload = None
        if not isinstance(payload, dict):
            return False
        restored = main.restore_snapshot(payload.get("main") or {})
        for item in payload.get("windows", []):
            window = self.new_workspace(with_tab=False, geometry=item.get("geometry"), number=item.get("number"))
            if window is None:
                break
            if not window.shell.restore_snapshot(item.get("shell") or {}):
                window.shell.add_workspace()
            restored = True
        return restored



# Подтверждения закрытия («Настройки» → «Интерфейс» → «Подтверждения»; по умолчанию включены).
CONFIRM_CLOSE_TERMINAL = "ui/confirm_close_terminal"
NEW_WINDOWS_KEY = "workspace/new_windows_float"     # новые окна — отдельными окнами (True) или вкладкой (False)
# Размер отдельного окна по виду панели; остальные — по размеру содержимого в пределах FLOAT_MIN … FLOAT_MAX
FLOAT_SIZES = {"chart": (960, 620), "scalper": (560, 860), "ticks": (900, 520), "atr": (900, 560)}
FLOAT_MIN, FLOAT_MAX = (480, 340), (1200, 900)
FLOAT_CASCADE = 32                                  # следующее новое окно — на столько ниже и правее
_cascade = [0]


def new_windows_float() -> bool:
    """Открывать новые окна отдельными окнами вне терминала (настройка NEW_WINDOWS_KEY, по умолчанию — да)."""
    value = QtCore.QSettings("MyTradingTools", "FxTerminal").value(NEW_WINDOWS_KEY, True)
    return str(value).lower() not in ("false", "0", "no")


def set_new_windows_float(on: bool) -> None:
    QtCore.QSettings("MyTradingTools", "FxTerminal").setValue(NEW_WINDOWS_KEY, bool(on))


def float_geometry(key: str, widget: QtWidgets.QWidget, anchor: QtWidgets.QWidget | None):
    """(размер, место) нового отдельного окна: размер по виду панели, место — каскадом от левого верхнего угла
    окна-владельца (anchor), в пределах экрана, на котором оно стоит."""
    if key in FLOAT_SIZES:
        w, h = FLOAT_SIZES[key]
    else:
        hint = widget.sizeHint() if widget is not None else QtCore.QSize()
        w = min(FLOAT_MAX[0], max(FLOAT_MIN[0], hint.width() if hint.isValid() else 0))
        h = min(FLOAT_MAX[1], max(FLOAT_MIN[1], hint.height() if hint.isValid() else 0))
    offset = FLOAT_CASCADE * (_cascade[0] % 8)
    _cascade[0] += 1
    screen = anchor.screen() if anchor is not None else QtWidgets.QApplication.primaryScreen()
    avail = screen.availableGeometry() if screen is not None else QtCore.QRect(0, 0, 1600, 900)
    w, h = min(w, avail.width()), min(h, avail.height())
    base = anchor.frameGeometry().topLeft() if anchor is not None else avail.topLeft()
    # Правый/нижний край: left + width - w (QRect.right() = left + width - 1, на экран во всю ширину дал бы −1).
    x = max(avail.left(), min(base.x() + 80 + offset, avail.left() + avail.width() - w))
    y = max(avail.top(), min(base.y() + 80 + offset, avail.top() + avail.height() - h))
    return QtCore.QSize(w, h), QtCore.QPoint(x, y)
CONFIRM_CLOSE_SPACE = "ui/confirm_close_space"


def confirm_enabled(key: str) -> bool:
    value = QtCore.QSettings("MyTradingTools", "FxTerminal").value(key, True)
    return str(value).lower() not in ("false", "0", "no")


def confirm_close(parent, title: str, text: str, key: str) -> bool:
    """Вопрос «Закрыть…?» с галочкой «Больше не спрашивать» (она выключает подтверждение key —
    вернуть его можно в «Настройках»). True — закрывать; если подтверждение выключено — сразу True."""
    if not confirm_enabled(key):
        return True
    box = QtWidgets.QMessageBox(parent)
    box.setIcon(QtWidgets.QMessageBox.Icon.Question)
    box.setWindowTitle(title)
    box.setText(text)
    box.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok | QtWidgets.QMessageBox.StandardButton.Cancel)
    box.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Cancel)     # Enter по ошибке не закрывает
    check = QtWidgets.QCheckBox("Больше не спрашивать (вернуть — «Настройки» → «Интерфейс»)")
    box.setCheckBox(check)
    ok = box.exec() == QtWidgets.QMessageBox.StandardButton.Ok
    if ok and check.isChecked():
        QtCore.QSettings("MyTradingTools", "FxTerminal").setValue(key, False)
    return ok

class WorkspaceWindow(QtWidgets.QMainWindow):
    """Дополнительное рабочее пространство: отдельное окно со своими вкладками и нижней панелью."""

    def __init__(self, group: ShellGroup, number: int):
        super().__init__()
        self.group = group
        self.number = number
        self._force_close = False
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle(f"FX Terminal — Пространство {number}")
        if group.main_window is not None:
            self.setWindowIcon(group.main_window.windowIcon())
        self.shell = WorkspaceShell(group=group)
        self.setCentralWidget(self.shell)
        if group.tools_builder is not None:
            group.tools_builder(self.shell)

    def force_close(self) -> None:
        self._force_close = True
        self.close()

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        if not self._force_close and self.shell.has_content():
            if not confirm_close(self, "Закрыть рабочее пространство",
                                 "Закрыть рабочее пространство и все связанные окна?", CONFIRM_CLOSE_SPACE):
                event.ignore()
                return
        if not self._force_close and not self.shell.confirm_dispose():
            event.ignore()                  # LIVE-стакан с позицией не позволил закрыть пространство
            return
        self.shell.dispose()
        self.group.forget_window(self)
        event.accept()


class WorkspaceShell(QtWidgets.QWidget):
    """Вкладки одного пространства: стопка областей + нижняя панель."""
    SETTINGS_KEY = "workspaces/layout_json"      # прежний ключ (только основное окно) — читается для совместимости
    layoutChanged = QtCore.Signal()

    def __init__(self, parent: QtWidgets.QWidget | None = None, group: ShellGroup | None = None):
        super().__init__(parent)
        self.group = group or ShellGroup()
        self.group.shells.append(self)
        self.layoutChanged.connect(self.group.layoutChanged)
        # Общие для всех пространств словари (одни и те же объекты).
        self.specs = self.group.specs
        self.parked = self.group.parked
        self.pages: dict[int, WorkspacePage] = {}
        self._next_id = 1

        self.stack = QtWidgets.QStackedWidget()
        self.bar = WorkspaceBar()
        self.bar.currentChanged.connect(self._on_tab_changed)
        self.bar.closeRequested.connect(self.close_workspace)
        self.bar.addRequested.connect(lambda: self.add_workspace())
        self.bar.renameRequested.connect(self.rename_workspace)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.stack, 1)
        layout.addWidget(self.bar)

    # ---- реестр панелей (общий на все пространства) ----------------------------------------
    @property
    def card_targets(self) -> dict[str, str]:
        return self.group.card_targets

    @card_targets.setter
    def card_targets(self, value: dict[str, str]) -> None:
        # Присваивание не должно отрывать словарь от группы: его читают все пространства.
        self.group.card_targets.clear()
        self.group.card_targets.update(value)

    def register(self, spec: PanelSpec) -> None:
        self.group.register(spec)

    def find_single_owner(self, key: str) -> WorkspacePage | None:
        _shell, page = self.group.find_single_owner(key)
        return page

    def open_panel(self, key: str):
        """Открыть панель в текущей вкладке этого пространства (одноэкземплярную — перенести сюда,
        даже из другого пространства)."""
        spec = self.specs.get(key)
        if spec is None:
            QtWidgets.QMessageBox.information(self, "FX Terminal", "Этот раздел пока не подключён.")
            return None
        page = self.current_page() or self.add_workspace()
        if spec.single:
            _owner_shell, owner = self.group.find_single_owner(key)
            if owner is not None and owner is not page:
                return page.open_panel(spec, widget=owner.release_single(key))
        return page.open_panel(spec)

    def open_card(self, card_key: str):
        """Карточка стартового экрана -> открыть связанную с ней панель."""
        return self.open_panel(self.card_targets.get(card_key, card_key))

    def adopt(self, key: str, widget: QtWidgets.QWidget, title: str | None = None):
        """Поставить уже созданное окно (например, «Тики») панелью в текущую вкладку этого пространства."""
        spec = self.specs.get(key)
        if spec is None or widget is None:
            return None
        page = self.current_page() or self.add_workspace()
        return page.adopt_panel(spec, widget, title)

    def attach_floating(self, src_page: "WorkspacePage", dock):
        """Прикрепить отдельное окно (панель dock из области src_page — любой вкладки любого пространства) к
        текущей вкладке этого пространства, вкладкой. Содержимое не пересоздаётся: виджет переносится вместе
        с потоками и данными. -> новая панель (или None)."""
        spec = self.specs.get(src_page.key_of(dock.objectName()))
        if spec is None:
            return None
        title = dock.windowTitle()
        target = self.current_page() or self.add_workspace()
        widget = src_page.release_single(dock.objectName())
        if widget is None:
            return None
        if spec.single:
            return target.open_panel(spec, widget=widget, floating=False)
        return target.adopt_panel(spec, widget, title, floating=False)

    def populate_attach_menu(self, menu: QtWidgets.QMenu) -> None:
        """Подменю «Прикрепить окно сюда»: все отдельные окна всех пространств; выбранное встаёт вкладкой в
        текущую вкладку этого пространства. Отдельных окон нет — пункт-подсказка."""
        menu.clear()
        found = self.group.floating_docks()
        for shell, page, dock in found:
            where = shell.page_label(page)
            action = menu.addAction(f"{dock.windowTitle()}  ·  {where}")
            action.triggered.connect(lambda _=False, p=page, d=dock: self.attach_floating(p, d))
        if not found:
            hint = menu.addAction("Отдельных окон нет")
            hint.setEnabled(False)

    def page_label(self, page: "WorkspacePage") -> str:
        """«Основное · Вкладка (1)» — где находится область (для меню)."""
        space = "Основное" if self is self.group.main_shell() else self.window().windowTitle() or "Пространство"
        for page_id, candidate in self.pages.items():
            if candidate is page:
                index = self._index_of(page_id)
                if index >= 0:
                    return f"{space} · {self.bar.tabs.tabText(index)}"
        return space

    def dock_of(self, widget):
        """(область, панель) по виджету в любом из пространств; (None, None), если он нигде не открыт."""
        _shell, page, dock = self.group.dock_of(widget)
        return page, dock

    def reveal(self, widget) -> bool:
        return self.group.reveal(widget)

    def set_dock_title(self, widget, title: str) -> None:
        self.group.set_dock_title(widget, title)

    def populate_windows_menu(self, menu: QtWidgets.QMenu) -> None:
        menu.clear()
        for spec in self.specs.values():
            action = menu.addAction(spec.title)
            action.triggered.connect(lambda _=False, k=spec.key: self.open_panel(k))

    def has_content(self) -> bool:
        """Есть ли в этом пространстве хотя бы одна открытая панель (для вопроса при закрытии)."""
        return any(docking.open_docks(page.manager) for page in self.pages.values())

    def confirm_dispose(self) -> bool:
        """Можно ли закрыть всё пространство: LIVE-стаканы могут отказаться."""
        return all(page.confirm_dispose() for page in list(self.pages.values()))

    def dispose(self) -> None:
        """Пространство закрывается: одноэкземплярные панели паркуются, графики и окна получают on_close."""
        for page in list(self.pages.values()):
            page.park_singles()
            page.dispose_multi()

    # ---- вкладки пространства ---------------------------------------------------------------
    def current_page(self) -> WorkspacePage | None:
        widget = self.stack.currentWidget()
        return widget if isinstance(widget, WorkspacePage) else None

    def _index_of(self, page_id: int) -> int:
        for i in range(self.bar.tabs.count()):
            if self.bar.tabs.tabData(i) == page_id:
                return i
        return -1

    def _free_name(self) -> str:
        used = {self.bar.tabs.tabText(i) for i in range(self.bar.tabs.count())}
        n = 1
        while f"Вкладка ({n})" in used:
            n += 1
        return f"Вкладка ({n})"

    def add_workspace(self, name: str | None = None) -> WorkspacePage:
        """Новая вкладка (область) в этом пространстве."""
        page = WorkspacePage(self)
        page.changed.connect(self.layoutChanged)
        page_id = self._next_id
        self._next_id += 1
        self.pages[page_id] = page
        self.stack.addWidget(page)
        index = self.bar.add_tab(name or self._free_name(), page_id)
        self.bar.tabs.setCurrentIndex(index)
        self._on_tab_changed(index)
        self.layoutChanged.emit()
        return page

    def _on_tab_changed(self, index: int) -> None:
        page_id = self.bar.tabs.tabData(index) if index >= 0 else None
        page = self.pages.get(page_id) if page_id is not None else None
        if page is not None:
            self.stack.setCurrentWidget(page)

    def close_workspace(self, index: int) -> None:
        page_id = self.bar.tabs.tabData(index)
        page = self.pages.get(page_id)
        if page is None:
            return
        if not page.confirm_dispose():
            return                         # LIVE-стакан остался открытым — вкладку не закрываем
        if self.bar.tabs.count() == 1:
            self.add_workspace()           # последнюю вкладку не теряем: вместо неё появляется пустая
            index = self._index_of(page_id)
        page.park_singles()
        page.dispose_multi()
        self.pages.pop(page_id, None)
        self.stack.removeWidget(page)
        page.deleteLater()
        self.bar.remove_tab(index)
        self.layoutChanged.emit()

    def rename_workspace(self, index: int) -> None:
        old = self.bar.tabs.tabText(index)
        text, ok = QtWidgets.QInputDialog.getText(self, "Вкладка", "Название:", text=old)
        if ok and text.strip():
            self.bar.tabs.setTabText(index, text.strip())
            self.layoutChanged.emit()

    # ---- сохранение раскладки этого пространства -------------------------------------------------
    def snapshot(self) -> dict:
        workspaces = []
        for i in range(self.bar.tabs.count()):
            page = self.pages.get(self.bar.tabs.tabData(i))
            if page is not None:
                workspaces.append({"name": self.bar.tabs.tabText(i), **page.snapshot()})
        return {"current": self.bar.tabs.currentIndex(), "workspaces": workspaces}

    def restore_snapshot(self, payload: dict) -> bool:
        items = payload.get("workspaces", []) if isinstance(payload, dict) else []
        if not items:
            return False
        for item in items:
            page = self.add_workspace(str(item.get("name") or "") or None)
            page.restore(item)
        current = int(payload.get("current", 0) or 0)
        if 0 <= current < self.bar.tabs.count():
            self.bar.tabs.setCurrentIndex(current)
        return True

    def save(self, settings: QtCore.QSettings) -> None:
        """Только это пространство (для одиночного использования и тестов; терминал сохраняет группу)."""
        settings.setValue(self.SETTINGS_KEY, json.dumps(self.snapshot(), ensure_ascii=False))

    def restore(self, settings: QtCore.QSettings) -> bool:
        raw = settings.value(self.SETTINGS_KEY, "")
        if not raw:
            return False
        try:
            payload = json.loads(str(raw))
        except ValueError:
            return False
        return self.restore_snapshot(payload)
