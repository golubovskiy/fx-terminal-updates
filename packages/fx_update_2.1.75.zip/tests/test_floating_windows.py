# -*- coding: utf-8 -*-
"""Новые окна — отдельными окнами вне терминала (2.1.75, workspace_shell.new_windows_float): панель открывается
отдельным окном, «Прикрепить окно сюда» переносит её вкладкой в любую вкладку любого пространства (виджет тот же,
не пересоздаётся), с выключенной настройкой — вкладкой, как раньше. Настройки терминала не меняются: настройка
в проверке подменяется.  Запуск:  python tests/test_floating_windows.py"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import docking  # noqa: E402
import workspace_shell as ws  # noqa: E402


def _wait(ms: int = 150) -> None:
    end = time.monotonic() + ms / 1000.0
    while time.monotonic() < end:
        APP.processEvents()
        time.sleep(0.01)


class _Mode:
    """Подменить настройку «Новые окна — отдельным окном» на время проверки."""

    def __init__(self, on: bool):
        self.on = on

    def __enter__(self):
        self.saved = ws.new_windows_float
        ws.new_windows_float = lambda: self.on
        return self

    def __exit__(self, *exc):
        ws.new_windows_float = self.saved
        return False


def _shells():
    group = ws.ShellGroup()
    made = []
    group.register(ws.PanelSpec("multi", "Окно", lambda: (made.append(QtWidgets.QLabel("multi")), made[-1])[1]))
    group.register(ws.PanelSpec("single", "Одно", lambda: QtWidgets.QLabel("single"), single=True))
    first, second = ws.WorkspaceShell(group=group), ws.WorkspaceShell(group=group)
    for shell in (first, second):
        shell.resize(900, 600)
        shell.show()
        if shell.current_page() is None:
            shell.add_workspace()
    _wait()
    return group, first, second, made


def test_geometry_of_new_window():
    anchor = QtWidgets.QWidget()
    anchor.setGeometry(100, 100, 800, 600)
    avail = APP.primaryScreen().availableGeometry()
    ws._cascade[0] = 0
    size, pos = ws.float_geometry("chart", QtWidgets.QLabel("x"), anchor)
    assert size.width() == min(ws.FLOAT_SIZES["chart"][0], avail.width())
    assert size.height() == min(ws.FLOAT_SIZES["chart"][1], avail.height())
    size2, pos2 = ws.float_geometry("other", QtWidgets.QLabel("x"), anchor)     # вид без своего размера
    assert min(ws.FLOAT_MIN[0], avail.width()) <= size2.width() <= ws.FLOAT_MAX[0]
    assert min(ws.FLOAT_MIN[1], avail.height()) <= size2.height() <= ws.FLOAT_MAX[1]
    for sz, pt in ((size, pos), (size2, pos2)):                                  # целиком на экране
        assert avail.left() <= pt.x() and pt.x() + sz.width() <= avail.right() + 1
        assert avail.top() <= pt.y() and pt.y() + sz.height() <= avail.bottom() + 1
    assert ws._cascade[0] == 2                                                   # следующее — со сдвигом


def test_new_window_floats_and_attaches_anywhere():
    group, first, second, made = _shells()
    try:
        with _Mode(True):
            dock = first.open_panel("multi")
            _wait()
            assert docking.is_floating(dock), "новое окно не отдельное"
            assert [d for _s, _p, d in group.floating_docks()] == [dock]
            menu = QtWidgets.QMenu()
            second.populate_attach_menu(menu)
            assert len(menu.actions()) == 1 and menu.actions()[0].text().startswith("Окно")
            widget = dock.widget()
            src = first.current_page()
            moved = second.attach_floating(src, dock)                  # в другое пространство
            _wait()
            assert moved is not None and moved.widget() is widget and widget is made[0]
            assert not docking.is_floating(moved) and group.floating_docks() == []
            assert docking.open_docks(src.manager) == [] and len(made) == 1          # не пересоздано
            single = first.open_panel("single")                              # одноэкземплярное — тоже
            _wait()
            assert docking.is_floating(single)
            moved = first.attach_floating(first.current_page(), single)      # в ту же вкладку
            _wait()
            assert moved is not None and not docking.is_floating(moved) and moved.objectName() == "single"
            second.populate_attach_menu(menu)
            assert [a.text() for a in menu.actions()] == ["Отдельных окон нет"] and not menu.actions()[0].isEnabled()
        with _Mode(False):                                                   # выключено — вкладкой, как раньше
            tab = first.open_panel("multi")
            _wait()
            assert tab is not None and not docking.is_floating(tab)
    finally:
        for shell in (first, second):
            shell.close()
            shell.deleteLater()
        _wait()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
