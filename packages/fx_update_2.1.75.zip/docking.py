# -*- coding: utf-8 -*-
"""Тонкий слой над PySide6-QtAds (Qt Advanced Docking System).

ВСЁ, что зависит от конкретной версии библиотеки, живёт здесь: остальной код терминала
(workspace_shell.py, gui_app.py) про QtAds ничего не знает. Имена перечислений и
сигнатуры разных версий отличаются (nested-enum / module-level, конструктор CDockWidget
с менеджером или без), поэтому поиск имён защитный: что не нашлось — пропускается
с предупреждением «[docking] …» в stderr, а не роняет терминал.

Установка:  pip install PySide6-QtAds
"""
from __future__ import annotations

import sys

from PySide6 import QtCore, QtGui, QtWidgets

try:
    import PySide6QtAds as ads
    IMPORT_ERROR: Exception | None = None
except Exception as exc:          # библиотека не установлена / не подходит к версии PySide6
    ads = None
    IMPORT_ERROR = exc

try:
    import fx_theme
except Exception:
    fx_theme = None

_warned: set[str] = set()
_configured = False


def _warn(message: str) -> None:
    if message not in _warned:
        _warned.add(message)
        print(f"[docking] {message}", file=sys.stderr)


def available() -> bool:
    return ads is not None


def ensure_available() -> None:
    if ads is None:
        raise RuntimeError(
            "Не загружен PySide6-QtAds. Установите: pip install PySide6-QtAds\n"
            f"Причина: {IMPORT_ERROR}"
        )


def _find(name: str, *owners):
    """Первый объект из owners, у которого есть атрибут name (None-владельцы пропускаются)."""
    for owner in owners:
        if owner is not None and hasattr(owner, name):
            return getattr(owner, name)
    return None


def area(name: str):
    """'left' | 'right' | 'top' | 'bottom' | 'center' -> значение перечисления DockWidgetArea."""
    full = f"{name.capitalize()}DockWidgetArea"
    value = _find(full, ads, getattr(ads, "DockWidgetArea", None))
    if value is None:
        raise AttributeError(f"QtAds: не найдено {full}")
    return value


# ------------------------------------------------------------------ настройка

# (флаг, включён) — поведение как в скальперских терминалах: вкладки видны у закреплённых панелей (за вкладку
# панель можно тащить), закрытие у вкладки, «открепить» и меню вкладок у области.
_CONFIG_FLAGS = (
    ("ActiveTabHasCloseButton", True),
    ("AllTabsHaveCloseButton", True),
    ("DockAreaHasCloseButton", False),       # закрывает сразу все вкладки области — не нужно
    ("DockAreaHasUndockButton", True),
    ("DockAreaHasTabsMenuButton", True),
    ("OpaqueSplitterResize", True),
    ("EqualSplitOnInsertion", True),
    # False: у вынесенного в отдельное окно одиночного окна (Тики, Стакан, график) полоса вкладок
    # внутри скрыта — заголовок уже есть у самого окна. В закреплённых областях вкладки видны как прежде.
    ("AlwaysShowTabs", False),
    ("XmlCompressionEnabled", True),
)


def configure() -> None:
    """Глобальные флаги менеджера. Вызывается один раз до создания первого CDockManager."""
    global _configured
    ensure_available()
    if _configured:
        return
    _configured = True
    manager_cls = ads.CDockManager
    enum_owner = getattr(manager_cls, "eConfigFlag", None)
    for name, on in _CONFIG_FLAGS:
        flag = _find(name, enum_owner, manager_cls, ads)
        if flag is None:
            _warn(f"флаг конфигурации {name} не найден в этой версии QtAds — пропущен")
            continue
        try:
            manager_cls.setConfigFlag(flag, on)
        except Exception as exc:
            _warn(f"не удалось выставить {name}: {type(exc).__name__}: {exc}")


def describe() -> str:
    """Строка диагностики для консоли при старте: версия и какие имена нашлись."""
    if ads is None:
        return f"QtAds не загружен: {IMPORT_ERROR}"
    version = getattr(ads, "__version__", None) or getattr(ads, "version", "?")
    enum_owner = getattr(ads.CDockManager, "eConfigFlag", None)
    found = [n for n, _ in _CONFIG_FLAGS if _find(n, enum_owner, ads.CDockManager, ads) is not None]
    return f"QtAds {version}; флагов найдено {len(found)} из {len(_CONFIG_FLAGS)}"


def _c(name: str, default: str) -> str:
    return str(getattr(fx_theme, name, default)) if fx_theme is not None else default


def dock_stylesheet() -> str:
    """QSS докинг-панелей в текущей палитре терминала (цвета не меняем, только раскладка)."""
    window = _c("BG_WINDOW", "#1c1d20")
    panel = _c("BG_PANEL", "#232427")
    hover = _c("BG_HOVER", "#2f3035")
    border = _c("BORDER", "#34363b")
    strong = _c("BORDER_STRONG", "#4a4d54")
    text = _c("TEXT", "#d7dae0")
    dim = _c("TEXT_DIM", "#8b9098")
    tint = _c("HOVER_TINT", "255, 255, 255")
    accent = _c("ACCENT", "#5b8def")
    # Вкладки как у документов Photoshop: полоса вкладок темнее содержимого, активная вкладка
    # того же цвета, что и панель под ней, прямые углы; у активной — синяя черта снизу (ACCENT,
    # 2 px — как у вкладок рабочих областей внизу окна, workspace_shell.WorkspaceBar). У неактивных
    # на её месте прозрачная черта той же толщины, чтобы текст не прыгал при переключении.
    # Вкладка на 1 px ниже полосы (TAB_HEIGHT - 1): у полосы снизу своя линия 1 px, и вкладка высотой
    # во всю полосу обрезалась снизу — вместе с синей чертой;
    # неактивные — без фона, с приглушённым текстом и тонким разделителем справа;
    # тонкий «×» без рамки (иконка рисуется в _tab_close_icon).
    # Плавающее окно — тоже цвета окна: если какой-то кусок не успел перерисоваться (изменение размера,
    # «развернуть»), он тёмный, а не белый системный (с 2.0.96).
    return f"""
        ads--CFloatingDockContainer {{ background: {window}; }}
        ads--CDockContainerWidget {{ background: {window}; }}
        ads--CDockContainerWidget > QSplitter {{ padding: 1px; }}
        ads--CDockSplitter::handle {{ background: {border}; }}
        ads--CDockSplitter::handle:hover {{ background: {strong}; }}
        ads--CDockAreaWidget {{ background: {panel}; border: 1px solid {border}; }}
        ads--CDockAreaTitleBar {{ background: {window}; border: none; border-bottom: 1px solid {border};
                                  min-height: {TAB_HEIGHT}px; max-height: {TAB_HEIGHT}px; }}
        ads--CDockWidgetTab {{ background: {window}; border: none; border-right: 1px solid {border};
                               border-bottom: 2px solid transparent;
                               padding: 0 6px 0 12px; min-height: {TAB_HEIGHT - 1}px; max-height: {TAB_HEIGHT - 1}px; }}
        ads--CDockWidgetTab:hover {{ background: {hover}; }}
        ads--CDockWidgetTab[activeTab="true"] {{ background: {panel}; border-bottom: 2px solid {accent}; }}
        ads--CDockWidgetTab QLabel {{ color: {dim}; background: transparent; padding: 0; }}
        ads--CDockWidgetTab:hover QLabel {{ color: {text}; }}
        ads--CDockWidgetTab[activeTab="true"] QLabel {{ color: {text}; }}
        ads--CDockWidgetTab #tabCloseButton, ads--CDockWidgetTab QAbstractButton {{
            background: transparent; border: none; padding: 0; margin: 0 0 0 8px;
            min-width: 14px; max-width: 14px; min-height: 14px; max-height: 14px;
            border-radius: 3px; qproperty-iconSize: 10px 10px;
        }}
        ads--CDockWidgetTab #tabCloseButton:hover, ads--CDockWidgetTab QAbstractButton:hover {{
            background: rgba({tint}, 0.10);
        }}
        ads--CDockWidgetTab #tabCloseButton:pressed, ads--CDockWidgetTab QAbstractButton:pressed {{
            background: rgba({tint}, 0.18);
        }}
        ads--CDockAreaTitleBar QAbstractButton {{ background: transparent; border: none; border-radius: 3px; }}
        ads--CDockAreaTitleBar QAbstractButton:hover {{ background: {hover}; }}
        ads--CDockWidget {{ background: {panel}; }}
    """


TAB_HEIGHT = 24          # px — высота полосы вкладок панелей (как у вкладок документов Photoshop)

_close_pixmaps: "tuple | None" = None


def _tab_close_icon() -> "QtGui.QIcon":
    """Тонкий «×» без рамки: приглушённый в покое, светлый при наведении (вместо значка Fusion в квадрате).

    Каждый раз — НОВЫЙ QIcon: QtAds забирает переданный ему значок себе (registerCustomIcon),
    и общий объект после этого становится «удалённым». Кэшируются только картинки."""
    global _close_pixmaps

    def draw(color: str) -> QtGui.QPixmap:
        dpr = 2.0
        app = QtWidgets.QApplication.instance()
        screen = app.primaryScreen() if app is not None else None
        if screen is not None:
            dpr = max(dpr, float(screen.devicePixelRatio()))
        size = 12
        pixmap = QtGui.QPixmap(int(size * dpr), int(size * dpr))
        pixmap.setDevicePixelRatio(dpr)
        pixmap.fill(QtCore.Qt.GlobalColor.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        pen = QtGui.QPen(QtGui.QColor(color), 1.3)
        pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(QtCore.QPointF(3, 3), QtCore.QPointF(9, 9))
        painter.drawLine(QtCore.QPointF(9, 3), QtCore.QPointF(3, 9))
        painter.end()
        return pixmap

    if _close_pixmaps is None:
        _close_pixmaps = (draw(_c("TEXT_DIM", "#8b9098")), draw(_c("TEXT", "#d7dae0")))
    normal, bright = _close_pixmaps
    icon = QtGui.QIcon()
    icon.addPixmap(normal, QtGui.QIcon.Mode.Normal)
    icon.addPixmap(bright, QtGui.QIcon.Mode.Active)
    icon.addPixmap(bright, QtGui.QIcon.Mode.Selected)
    return icon


def _register_icons() -> None:
    """Значок закрытия вкладки для всего QtAds (если версия умеет iconProvider)."""
    try:
        provider = ads.CDockManager.iconProvider()
        icon_id = _find("TabCloseIcon", getattr(ads, "eIcon", None), ads)
        if provider is not None and icon_id is not None:
            provider.registerCustomIcon(icon_id, _tab_close_icon())
    except Exception as exc:
        _warn(f"iconProvider: {type(exc).__name__}: {exc} — значок закрытия ставится на каждую вкладку")


def _style_tab(dock) -> None:
    """Запасной путь: поставить тонкий «×» прямо на кнопку закрытия вкладки панели."""
    try:
        tab = dock.tabWidget()
        for button in tab.findChildren(QtWidgets.QAbstractButton):
            button.setIcon(_tab_close_icon())
            button.setIconSize(QtCore.QSize(10, 10))
            button.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
    except Exception as exc:
        _warn(f"кнопка закрытия вкладки: {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------- менеджер/панели

def create_manager(parent):
    """Менеджер докинга для одной рабочей области."""
    configure()
    _register_icons()
    manager = ads.CDockManager(parent)
    manager.setStyleSheet(dock_stylesheet())
    return manager


def create_dock(manager, title: str, widget, name: str, delete_on_close: bool = False):
    """Панель с виджетом. name — уникальный идентификатор (по нему сохраняется раскладка).

    delete_on_close=False — закрытая панель остаётся в менеджере (одноэкземплярные окна:
    потоки и накопленные данные живут дальше); True — закрытие уничтожает панель."""
    try:
        dock = ads.CDockWidget(manager, title)        # новые версии: менеджер первым аргументом
    except TypeError:
        dock = ads.CDockWidget(title)
    dock.setObjectName(name)

    insert_mode = _find("ForceNoScrollArea", getattr(ads.CDockWidget, "eInsertMode", None), ads.CDockWidget)
    try:
        if insert_mode is not None:
            dock.setWidget(widget, insert_mode)       # свои панели сами решают, как скроллиться
        else:
            dock.setWidget(widget)
    except TypeError:
        dock.setWidget(widget)

    features = getattr(ads.CDockWidget, "DockWidgetFeature", None)
    for fname, on in (
        ("DockWidgetClosable", True),
        ("DockWidgetMovable", True),
        ("DockWidgetFloatable", True),
        ("DockWidgetDeleteOnClose", delete_on_close),
    ):
        feature = _find(fname, features, ads.CDockWidget, ads)
        if feature is None:
            _warn(f"свойство панели {fname} не найдено — пропущено")
            continue
        try:
            dock.setFeature(feature, on)
        except Exception as exc:
            _warn(f"не удалось выставить {fname}: {type(exc).__name__}: {exc}")
    _style_tab(dock)
    return dock


def add_dock(manager, dock, target_area=None):
    """Добавить панель вкладкой в target_area (или создать первую область)."""
    center = area("center")
    if target_area is None:
        return manager.addDockWidget(center, dock)
    return manager.addDockWidget(center, dock, target_area)


def add_dock_floating(manager, dock, size: "QtCore.QSize | None" = None, pos: "QtCore.QPoint | None" = None):
    """Панель отдельным окном (2.1.75): своё окно вне рабочей области (CFloatingDockContainer QtAds). Из него
    панель перетаскивается за заголовок в любую часть этой области — QtAds показывает места вставки. size / pos —
    размер и место окна на экране. Возвращает окно (или None, если эта версия QtAds так не умеет — тогда панель
    встаёт вкладкой, как раньше)."""
    container = None
    adder = getattr(manager, "addDockWidgetFloating", None)
    if adder is not None:
        try:
            container = adder(dock)
        except Exception as exc:
            _warn(f"addDockWidgetFloating: {type(exc).__name__}: {exc}")
    if container is None:
        add_dock(manager, dock, first_area(manager))
        try:
            dock.setFloating()
            container = dock.floatingDockContainer()
        except Exception as exc:
            _warn(f"отдельное окно панели не создано ({type(exc).__name__}: {exc}) — панель вкладкой")
            return None
    try:
        if size is not None:
            container.resize(size)
        if pos is not None:
            container.move(pos)
        if not container.isVisible():          # область ещё не показана — QtAds показал бы окно только вместе с ней
            container.show()
    except Exception as exc:
        _warn(f"размер отдельного окна: {type(exc).__name__}: {exc}")
    return container


def _in_floating(dock) -> bool:
    """Панель стоит в отдельном окне — одна или вместе с другими. CDockWidget.isFloating() QtAds отвечает True,
    только когда панель в окне одна, поэтому сначала isInFloatingContainer()."""
    check = getattr(dock, "isInFloatingContainer", None)
    return bool(check()) if check is not None else bool(dock.isFloating())


def is_floating(dock) -> bool:
    """Панель открыта отдельным окном (а не вкладкой рабочей области), в том числе окном из нескольких вкладок."""
    try:
        return _in_floating(dock) and not dock.isClosed()
    except Exception:
        return False


def docks(manager) -> dict:
    """{имя: панель} — все панели менеджера, включая закрытые."""
    return dict(manager.dockWidgetsMap())


def open_docks(manager) -> list:
    return [d for d in docks(manager).values() if not d.isClosed()]


def first_area(manager):
    """Область для вкладочной вставки: первая не плавающая открытая панель."""
    for dock in open_docks(manager):
        if _in_floating(dock):          # не во вкладки отдельного окна
            continue
        dock_area = dock.dockAreaWidget()
        if dock_area is not None:
            return dock_area
    return None


def show_dock(dock) -> None:
    """Открыть закрытую панель и сделать её текущей вкладкой."""
    try:
        dock.toggleView(True)
    except Exception as exc:
        _warn(f"toggleView: {type(exc).__name__}: {exc}")
    try:
        dock.setAsCurrentTab()
    except Exception:
        pass


def release(manager, dock):
    """Достать виджет из панели и убрать панель (для переноса окна в другую область или вкладку). Панель была
    отдельным окном и в нём больше ничего нет — окно тоже убирается (2.1.75)."""
    container = None
    try:
        container = dock.floatingDockContainer() if _in_floating(dock) else None
    except Exception:
        container = None
    widget = dock.takeWidget()
    manager.removeDockWidget(dock)
    dock.deleteLater()
    if container is not None:
        try:
            if not list(container.dockWidgets()):
                container.hide()
                container.deleteLater()
        except RuntimeError:                       # QtAds уже убрал опустевшее окно сам
            pass
        except Exception as exc:
            _warn(f"пустое отдельное окно не убрано: {type(exc).__name__}: {exc}")
    return widget


def swap_widget(dock, widget):
    """Подменить содержимое панели (панель и её место в раскладке остаются). Возвращает прежний виджет."""
    old = dock.takeWidget()
    insert_mode = _find("ForceNoScrollArea", getattr(ads.CDockWidget, "eInsertMode", None), ads.CDockWidget)
    try:
        if insert_mode is not None:
            dock.setWidget(widget, insert_mode)
        else:
            dock.setWidget(widget)
    except TypeError:
        dock.setWidget(widget)
    return old


def save_state(manager) -> bytes:
    return bytes(manager.saveState())


def restore_state(manager, data: bytes) -> bool:
    return bool(manager.restoreState(QtCore.QByteArray(data)))
