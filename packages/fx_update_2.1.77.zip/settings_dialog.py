# -*- coding: utf-8 -*-
"""Диалог «Настройки…» терминала: токен и счёт, тема, шрифт, часовой пояс, период истории,
цвета и шрифты стакана и графиков (appearance.py, appearance_pages.py), звук, горячие клавиши
(hotkeys.py), диагностика соединения, синхронизация рисунков графиков по WebDAV (sync_page.py).

Часть gui_app.py, вынесенная в отдельный модуль; запуск терминала — по-прежнему python gui_app.py.
"""
from __future__ import annotations

import faulthandler
import json
import os
import re
import ssl
import sys
import traceback
from datetime import date, timedelta
from pathlib import Path
from zoneinfo import available_timezones

import pandas as pd
import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6
import pyqtgraph as pg
import fx_theme
import hotkeys
import appearance
import appearance_pages
import sync_page

from candlestick_item import CandlestickItem, TimeAxisItem, BULL_COLOR, BEAR_COLOR
from finam_terminal import (
    FinamClient,
    enrich_with_indicators,
    INSTRUMENTS,
    to_friendly_symbol,
    from_friendly_symbol,
    register_symbols,
    sma,
    vwap,
)
from finam_sdk_client import FinamStreamClient
from quotes_tab import QuotesTab, QuotesEventMarker
from instrument_picker import InstrumentPickerDialog
from tick_volume_manager import TickVolumeManager
from window_links import LinkHub, install_link_titlebar
from order_flow import (
    OrderFlowController,
    OrderFlowTab,
    ORDER_FLOW_SYMBOLS,
    resolve_quarterly_symbols,
)
from connection_diagnostics import ConnectionDiagnosticsDialog
from cny_forward_tab import CnyForwardMonitorTab, set_display_timezone as set_cny_display_timezone
import docking
from open_interest_tab import OpenInterestTab
from options_tab import OptionsTab
from status_clock import StatusClock, FinamClockSource
from notes_panel import NotesStore, NotesPanel
from sound_notifier import (SoundNotifier, PULSE, SIGNAL, ALERT, ROBOT, ROBOT_SETTING, ROBOT_END, ROBOT_END_SETTING, TITLES as SOUND_TITLES,
                            TRADE_KINDS, TRADE_SETTING)
from workspace_shell import PanelSpec, ShellGroup, WorkspaceShell
import candle_cache

from app_common import (  # noqa: F401
    DEFAULT_DISPLAY_TZ,
    DEFAULT_HISTORY_PERIOD,
    FONT_SIZES,
    FONT_SIZE_KEY,
    HISTORY_PERIODS,
    _HISTORY_SETTINGS_KEY,
    _TZ_SETTINGS_KEY,
    _is_valid_timezone,
    _list_timezones,
    _saved_font_size,
)

BOOK_ENGINE_KEY = "data/book_engine"      # разбор стакана: auto / sdk / rust (FinamGateway.set_book_mode)


class SettingsDialog(QtWidgets.QDialog):
    """Настройки по разделам, как «Установки» в Photoshop: список слева, страница раздела справа,
    кнопки OK / Отмена — столбиком справа."""

    PAGES = ("Основные", "Интерфейс", "Цвета", "Шрифты", "Подключение", "Звук", "Горячие клавиши",
             "Синхронизация")
    THEMES = (("dark", "Тёмная", "#2b2c30"), ("light", "Светлая", "#e9e9e9"))

    def __init__(self, settings: QtCore.QSettings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки")
        self.settings = settings
        self.resize(820, 560)
        dim = str(getattr(fx_theme, "TEXT_DIM", "#8b9098"))

        def hint(text: str) -> QtWidgets.QLabel:
            label = QtWidgets.QLabel(text)
            label.setWordWrap(True)
            label.setStyleSheet(f"color: {dim}; font-size: 11px;")
            return label

        def group(title: str) -> tuple[QtWidgets.QGroupBox, QtWidgets.QFormLayout]:
            box = QtWidgets.QGroupBox(title)
            form = QtWidgets.QFormLayout(box)
            form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            form.setHorizontalSpacing(12)
            form.setVerticalSpacing(10)
            return box, form

        def page(*widgets) -> QtWidgets.QWidget:
            w = QtWidgets.QWidget()
            lay = QtWidgets.QVBoxLayout(w)
            lay.setContentsMargins(4, 0, 4, 0)
            lay.setSpacing(12)
            for item in widgets:
                lay.addWidget(item)
            lay.addStretch(1)
            return w

        # ================= Основные =================
        self.tz_combo = QtWidgets.QComboBox(self)
        self.tz_combo.setEditable(True)
        self.tz_combo.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        self.tz_combo.addItems(_list_timezones())
        self.tz_combo.setCurrentText(str(settings.value(_TZ_SETTINGS_KEY, DEFAULT_DISPLAY_TZ)))
        self.tz_combo.setToolTip("Часовой пояс IANA, например Europe/Moscow, UTC, Asia/Yekaterinburg")
        self.history_combo = QtWidgets.QComboBox(self)
        for label, key, _offset in HISTORY_PERIODS:
            self.history_combo.addItem(label, userData=key)
        current_period = str(settings.value(_HISTORY_SETTINGS_KEY, DEFAULT_HISTORY_PERIOD))
        self.history_combo.setCurrentIndex(max(0, self.history_combo.findData(current_period)))
        self.history_combo.setToolTip("Сколько истории подгружать при открытии графика и обновлении")
        general_box, general_form = group("Время и история")
        general_form.addRow("Часовой пояс:", self.tz_combo)
        general_form.addRow("Период загрузки истории:", self.history_combo)
        general_form.addRow("", hint(
            "Finam отдаёт не глубже: M1 — 7 дней, M5/M15/H1 — 30 дней, D1 — 365 дней. "
            "Более длинный период на этих таймфреймах будет обрезан до лимита."))
        # Стакан через Rust (этап 2): auto — Rust с самостоятельным переходом на SDK при сбое.
        self.book_engine_combo = QtWidgets.QComboBox(self)
        for title, key in (("Авто: Rust, при сбое — SDK", "auto"), ("Только SDK (как раньше)", "sdk"),
                           ("Только Rust (проверка)", "rust")):
            self.book_engine_combo.addItem(title, userData=key)
        self.book_engine_combo.setCurrentIndex(
            max(0, self.book_engine_combo.findData(str(settings.value(BOOK_ENGINE_KEY, "auto")))))
        self.book_engine_combo.setToolTip(
            "Как разбирать поток стакана Finam.\n"
            "Авто — сообщения стакана приходят байтами и разбираются модулем Rust (fx_engine): меньше нагрузки\n"
            "на интерфейс. Если быстрый путь не открылся, Rust не разобрал сообщение или поток замолчал —\n"
            "этот стакан сам переходит на SDK и через 10 минут снова пробует Rust. Всё — в журнале.\n"
            "Только SDK — как было до 30.10. Только Rust — без перехода на SDK (для проверки).\n"
            "Переменная FX_BOOK_ENGINE важнее этой настройки.")
        general_form.addRow("Разбор стакана:", self.book_engine_combo)

        # ================= Интерфейс =================
        self._theme = str(settings.value("appearance/theme", "dark"))
        swatches = QtWidgets.QHBoxLayout()
        swatches.setSpacing(8)
        self._theme_buttons = QtWidgets.QButtonGroup(self)
        self._theme_buttons.setExclusive(True)
        accent = str(getattr(fx_theme, "ACCENT", "#5b8def"))
        for key, title, color in self.THEMES:
            btn = QtWidgets.QPushButton()
            btn.setCheckable(True)
            btn.setFixedSize(40, 30)
            btn.setToolTip(title)
            btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
            # как в Photoshop: квадраты-образцы, выбранный — в рамке акцента
            btn.setStyleSheet(
                f"QPushButton {{ background: {color}; border: 1px solid #55585f; border-radius: 3px; min-width: 0; padding: 0; }}"
                f"QPushButton:checked {{ border: 2px solid {accent}; }}"
                f"QPushButton:hover:!checked {{ border-color: #8b9098; }}"
            )
            btn.setChecked(key == self._theme)
            btn.clicked.connect(lambda _=False, k=key: self._pick_theme(k))
            self._theme_buttons.addButton(btn)
            swatches.addWidget(btn)
        self.theme_name_label = QtWidgets.QLabel(dict((k, t) for k, t, _c in self.THEMES).get(self._theme, ""))
        self.theme_name_label.setStyleSheet(f"color: {dim};")
        swatches.addSpacing(6)
        swatches.addWidget(self.theme_name_label)
        swatches.addStretch(1)
        self.font_combo = QtWidgets.QComboBox(self)
        for size in FONT_SIZES:
            self.font_combo.addItem("Как в теме" if size == 0 else f"{size} pt", size)
        self.font_combo.setCurrentIndex(max(0, self.font_combo.findData(_saved_font_size())))
        self.font_combo.setToolTip("Размер шрифта окон, меню, таблиц и кнопок терминала")
        look_box, look_form = group("Внешний вид")
        look_form.addRow("Цветовая тема:", swatches)
        look_form.addRow("Размер шрифта:", self.font_combo)
        look_form.addRow("", hint("Шрифт меняется во всём интерфейсе терминала; подписи на графиках остаются прежними."))
        self.icons_keep_combo = QtWidgets.QComboBox(self)
        for minutes, title in appearance.ICONS_KEEP_CHOICES:
            self.icons_keep_combo.addItem(title, minutes)
        self.icons_keep_combo.setCurrentIndex(max(0, self.icons_keep_combo.findData(
            int(appearance.icons_keep_sec(settings) // 60))))
        self.icons_keep_combo.setToolTip("Столбик значков в правом верхнем углу графика: работающие роботы и айсберги\n"
                                         "видны всегда, остановившиеся — столько после остановки (бледные)")
        look_form.addRow("Остановившиеся роботы на графике:", self.icons_keep_combo)

        # Подтверждения закрытия (workspace_shell.confirm_close; галочка «Больше не спрашивать» в вопросе
        # выключает то же самое).
        from workspace_shell import CONFIRM_CLOSE_SPACE, CONFIRM_CLOSE_TERMINAL, confirm_enabled
        self.confirm_terminal_check = QtWidgets.QCheckBox("Спрашивать перед закрытием терминала", self)
        self.confirm_terminal_check.setChecked(confirm_enabled(CONFIRM_CLOSE_TERMINAL))
        self.confirm_space_check = QtWidgets.QCheckBox("Спрашивать перед закрытием дополнительного пространства", self)
        self.confirm_space_check.setChecked(confirm_enabled(CONFIRM_CLOSE_SPACE))
        confirm_box, confirm_form = group("Подтверждения")
        confirm_form.addRow(self.confirm_terminal_check)
        confirm_form.addRow(self.confirm_space_check)
        confirm_form.addRow(hint("Пустое пространство закрывается без вопроса. Открытая позиция или заявки в LIVE "
                                 "спрашиваются всегда — это не отключается."))
        self._confirm_keys = ((self.confirm_terminal_check, CONFIRM_CLOSE_TERMINAL),
                              (self.confirm_space_check, CONFIRM_CLOSE_SPACE))

        # ================= Подключение =================
        self.secret_edit = QtWidgets.QLineEdit(self)
        self.secret_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.secret_edit.setText(settings.value("finam/secret", os.environ.get("FINAM_SECRET", "")))
        self.show_secret = QtWidgets.QCheckBox("Показать токен")
        self.show_secret.toggled.connect(lambda on: self.secret_edit.setEchoMode(
            QtWidgets.QLineEdit.Normal if on else QtWidgets.QLineEdit.Password))
        self.account_edit = QtWidgets.QLineEdit(self)
        self.account_edit.setPlaceholderText("определяется автоматически по токену")
        self.account_edit.setToolTip(
            "Можно оставить пустым — ID счёта будет получен по токену.\n"
            "Заполняйте, только если у токена несколько счетов и нужен не первый."
        )
        self.account_edit.setText(settings.value("finam/account_id", os.environ.get("FINAM_ACCOUNT_ID", "")))
        conn_box, conn_form = group("Finam Trade API")
        conn_form.addRow("Secret-токен:", self.secret_edit)
        conn_form.addRow("", self.show_secret)
        conn_form.addRow("ID счёта (необязательно):", self.account_edit)
        diag_box, diag_form = group("Диагностика")
        diagnostics_btn = QtWidgets.QPushButton("Диагностика соединения…")
        diagnostics_btn.setAutoDefault(False)
        diagnostics_btn.clicked.connect(self._open_diagnostics)
        diag_row = QtWidgets.QHBoxLayout()
        diag_row.addWidget(diagnostics_btn)
        diag_row.addStretch(1)
        diag_form.addRow(diag_row)
        diag_form.addRow(hint("Проверка токена, счёта и потоков котировок Finam: что доступно и где ошибка."))

        # ================= Звук =================
        self._sound = getattr(parent, "sound", None)
        self._sound_volume_before = self._sound.volume if self._sound is not None else 70
        self.sound_check = QtWidgets.QCheckBox("Включить звуковые уведомления", self)
        self.sound_check.setChecked(self._sound.enabled if self._sound is not None else True)
        self.volume_slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal, self)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(self._sound_volume_before)
        self.volume_label = QtWidgets.QLabel(f"{self._sound_volume_before}%", self)
        self.volume_label.setMinimumWidth(36)
        self.volume_slider.valueChanged.connect(lambda v: self.volume_label.setText(f"{v}%"))
        volume_row = QtWidgets.QHBoxLayout()
        volume_row.addWidget(self.volume_slider, 1)
        volume_row.addWidget(self.volume_label)
        preview_row = QtWidgets.QHBoxLayout()
        preview_row.setSpacing(6)
        for kind, caption in ((PULSE, "FX Pulse"), (SIGNAL, "FX Signal"), (ROBOT, "FX Robot"), (ALERT, "FX Alert")):
            btn = QtWidgets.QPushButton(f"▶  {caption}", self)
            btn.setAutoDefault(False)
            btn.setToolTip(SOUND_TITLES[kind])
            btn.clicked.connect(lambda _=False, k=kind: self._preview_sound(k))
            btn.setEnabled(self._sound is not None)
            preview_row.addWidget(btn)
        preview_row.addStretch(1)
        missing = self._sound.missing_files() if self._sound is not None else []
        self.robot_sound_check = QtWidgets.QCheckBox("Свой звук для роботов (FX Robot)", self)
        self.robot_sound_check.setToolTip("Обнаружен робот (обычный и спредовый) — короткий сигнал FX Robot:\n"
                                          "четыре восходящие ноты.\n"
                                          "Снято — роботы звучат FX Signal, как айсберги и крупные сделки.")
        self.robot_sound_check.setChecked(self._sound.robot_own if self._sound is not None
                                          else str(settings.value(ROBOT_SETTING, True)).lower() not in ("false", "0"))
        # Остановка робота (2.1.77): своя галочка и «▶» рядом — в ряд «Прослушать» пятая кнопка не помещается
        self.robot_end_check = QtWidgets.QCheckBox("Звук при остановке робота (FX Robot End)", self)
        self.robot_end_check.setToolTip("Робот, о котором было уведомление, остановился (молчит дольше «Пауза робота,\n"
                                        "не дольше» в его настройках) — те же четыре ноты, что у FX Robot, но вниз.")
        self.robot_end_check.setChecked(self._sound.robot_end_enabled if self._sound is not None
                                        else str(settings.value(ROBOT_END_SETTING, True)).lower() not in ("false", "0"))
        robot_end_play = QtWidgets.QPushButton("▶", self)
        robot_end_play.setAutoDefault(False)
        robot_end_play.setFixedWidth(32)
        robot_end_play.setToolTip("Прослушать FX Robot End")
        robot_end_play.setEnabled(self._sound is not None)
        robot_end_play.clicked.connect(lambda _=False: self._preview_sound(ROBOT_END))
        robot_end_row = QtWidgets.QHBoxLayout()
        robot_end_row.setSpacing(6)
        robot_end_row.addWidget(self.robot_end_check)
        robot_end_row.addWidget(robot_end_play)
        robot_end_row.addStretch(1)
        sound_box, sound_form = group("Звуковые уведомления")
        sound_form.addRow(self.sound_check)
        sound_form.addRow(self.robot_sound_check)
        sound_form.addRow(robot_end_row)
        sound_form.addRow("Громкость:", volume_row)
        sound_form.addRow("Прослушать:", preview_row)
        sound_form.addRow("", hint(
            "Pulse — обычное уведомление · Signal — крупная сделка, айсберг · Robot — обнаружен робот · "
            "Robot End — робот остановился · "
            "Alert — резкое движение цены, касание линии."
            + (f"\nНе найдены в папке Sound: {', '.join(missing)}" if missing else "")))

        # ================= Горячие клавиши =================
        # Сохраняются только по «OK» (accept); окна стакана подхватывают сразу (hotkeys.REGISTRY.changed).
        self.hotkeys_page = hotkeys.HotkeysPage(hotkeys.REGISTRY.bindings(), dim)

        # ---- Звук: сделки в стакане (sound_notifier.TRADE_KINDS) ----
        trade_box, trade_form = group("Сделки в стакане")
        self.trade_sound_checks = {}
        for kind in TRADE_KINDS:
            check = QtWidgets.QCheckBox(SOUND_TITLES[kind], self)
            check.setChecked(self._sound.trade_enabled(kind) if self._sound is not None else True)
            play = QtWidgets.QPushButton("▶", self)
            play.setAutoDefault(False)
            play.setFixedWidth(32)
            play.setToolTip("Прослушать")
            play.setEnabled(self._sound is not None)
            play.clicked.connect(lambda _=False, k=kind: self._preview_sound(k))
            line = QtWidgets.QHBoxLayout()
            line.addWidget(check)
            line.addStretch(1)
            line.addWidget(play)
            trade_form.addRow(line)
            self.trade_sound_checks[kind] = check
        trade_form.addRow(hint(
            "Открытие — позиция появилась или перевернулась; закрытие — позиция стала нулевой. "
            "SL / TP звучат в момент срабатывания (и у TP-заявки на сервере — при её исполнении); "
            "отдельного звука закрытия после них нет. Работает в PAPER и LIVE, если звук включён."))

        # ================= Цвета и Шрифты =================
        # Цвета — для темы, сохранённой на момент открытия настроек; сохраняются по «OK».
        self.colors_page = appearance_pages.ColorsPage(appearance.saved_theme(settings), dim)
        self.fonts_page = appearance_pages.FontsPage(dim)
        self.needs_restart = False         # после «OK»: изменены цвета/шрифт графиков или цвета приложения

        # ================= Синхронизация =================
        self.sync_page = sync_page.SyncPage(settings, dim, getattr(parent, "drawings_sync", None),
                                            notes_manager=getattr(parent, "notes_sync", None))

        # ================= каркас окна =================
        self.sections = QtWidgets.QListWidget()
        self.sections.addItems(self.PAGES)
        self.sections.setFixedWidth(170)
        self.sections.setObjectName("settingsSections")
        self.sections.setStyleSheet(
            "QListWidget#settingsSections { border: none; padding: 4px 0; }"
            "QListWidget#settingsSections::item { padding: 5px 10px; border-radius: 3px; }"
        )
        self.pages = QtWidgets.QStackedWidget()
        self.pages.addWidget(page(general_box))
        self.pages.addWidget(page(look_box, confirm_box))
        self.pages.addWidget(self.colors_page)           # своя прокрутка внутри
        self.pages.addWidget(self.fonts_page)
        # Поля подключения — в рамке цвета связи с Finam: тот же индикатор, что точка у часов (conn_frame.py, 2.1.60)
        import conn_frame
        self.conn_frame = conn_frame.ConnectionFrame(lambda: self.parent(), dim)
        self.conn_frame.add(conn_box)
        self.conn_frame.add(diag_box)
        self.pages.addWidget(page(self.conn_frame))
        self.pages.addWidget(page(sound_box, trade_box))
        self.pages.addWidget(self.hotkeys_page)          # своя прокрутка внутри — без page() и растяжки
        self.pages.addWidget(self.sync_page)
        self.sections.currentRowChanged.connect(self.pages.setCurrentIndex)
        try:
            start_page = int(settings.value("ui/settings_page", 0) or 0)
        except (TypeError, ValueError):
            start_page = 0
        self.sections.setCurrentRow(start_page if 0 <= start_page < len(self.PAGES) else 0)

        ok_btn = QtWidgets.QPushButton("OK")
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self.accept)
        cancel_btn = QtWidgets.QPushButton("Отмена")
        cancel_btn.setAutoDefault(False)
        cancel_btn.clicked.connect(self.reject)
        buttons = QtWidgets.QVBoxLayout()
        buttons.setSpacing(8)
        buttons.addWidget(ok_btn)
        buttons.addWidget(cancel_btn)
        buttons.addStretch(1)

        frame = QtWidgets.QFrame()
        frame.setObjectName("settingsSectionsFrame")
        frame.setStyleSheet("QFrame#settingsSectionsFrame { border: 1px solid %s; border-radius: 3px; }"
                            % getattr(fx_theme, "BORDER_STRONG", "#3a3d44"))
        frame_lay = QtWidgets.QVBoxLayout(frame)
        frame_lay.setContentsMargins(0, 0, 0, 0)
        frame_lay.addWidget(self.sections)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(14)
        layout.addWidget(frame)
        layout.addWidget(self.pages, 1)
        layout.addLayout(buttons)
        self._session_open_price = None

    def _pick_theme(self, key: str) -> None:
        self._theme = key
        self.theme_name_label.setText(dict((k, t) for k, t, _c in self.THEMES).get(key, ""))

    def _open_diagnostics(self) -> None:
        dlg = ConnectionDiagnosticsDialog(self)
        dlg.exec()

    def accept(self) -> None:
        tz_name = self.tz_combo.currentText().strip()
        if not _is_valid_timezone(tz_name):
            self.sections.setCurrentRow(0)
            QtWidgets.QMessageBox.warning(
                self,
                "Неверный часовой пояс",
                f"Неизвестный часовой пояс: «{tz_name}».\n"
                "Выберите значение из списка, например Europe/Moscow или UTC.",
            )
            return
        self.settings.setValue("appearance/theme", self._theme)
        self.settings.setValue(FONT_SIZE_KEY, int(self.font_combo.currentData() or 0))
        self.settings.setValue("finam/secret", self.secret_edit.text())
        self.settings.setValue("finam/account_id", self.account_edit.text().strip())
        self.settings.setValue(_TZ_SETTINGS_KEY, tz_name)
        self.settings.setValue(_HISTORY_SETTINGS_KEY, self.history_combo.currentData())
        self.settings.setValue(BOOK_ENGINE_KEY, self.book_engine_combo.currentData())
        self.settings.setValue(appearance.ICONS_KEEP_KEY, int(self.icons_keep_combo.currentData()))
        self.settings.setValue("ui/settings_page", self.sections.currentRow())
        hotkeys.REGISTRY.set_bindings(self.hotkeys_page.values(), self.settings)
        if self._sound is not None:
            self._sound.set_enabled(self.sound_check.isChecked())
            self._sound.set_volume(self.volume_slider.value())
        else:
            self.settings.setValue("sound/enabled", self.sound_check.isChecked())
            self.settings.setValue("sound/volume", self.volume_slider.value())
        for kind, check in self.trade_sound_checks.items():
            self.settings.setValue(TRADE_SETTING[kind], check.isChecked())
        self.settings.setValue(ROBOT_SETTING, self.robot_sound_check.isChecked())
        self.settings.setValue(ROBOT_END_SETTING, self.robot_end_check.isChecked())
        for check, key in self._confirm_keys:
            self.settings.setValue(key, check.isChecked())
        areas = self.colors_page.changed_areas()
        appearance.save_overrides(self.colors_page.theme, self.colors_page.values(), self.settings)
        self.settings.setValue(appearance.ACTIVE_FRAME_KEY, self.colors_page.active_check.isChecked())
        appearance.save_fonts(self.fonts_page.values(), self.settings)
        self.sync_page.save()
        self.needs_restart = bool(areas & {"app", "chart"}) or self.fonts_page.chart_changed()
        appearance.NOTIFIER.changed.emit()             # открытые стаканы перекрашиваются сразу
        super().accept()

    def reject(self) -> None:
        self.settings.setValue("ui/settings_page", self.sections.currentRow())
        if self._sound is not None:          # громкость менялась при прослушивании — вернуть прежнюю
            self._sound.set_volume(self._sound_volume_before)
        super().reject()

    def _preview_sound(self, kind: str) -> None:
        if self._sound is not None:
            self._sound.set_volume(self.volume_slider.value())
            self._sound.play(kind, force=True)
