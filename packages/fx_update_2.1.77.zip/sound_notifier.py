# -*- coding: utf-8 -*-
"""FX Terminal — звуковые уведомления (фирменные сигналы FX Pulse / FX Signal / FX Alert).

Звуки лежат в папке Sound рядом с терминалом:
    Sound/FX_Pulse.wav   — обычное уведомление (мягкие три восходящие ноты)
    Sound/FX_Signal.wav  — крупная сделка, айсберг
    Sound/FX_Robot.wav   — обнаружен робот (обычный и спредовый): четыре быстрые восходящие ноты, свой —
                           чтобы робота было слышно отдельно; галочкой в «Настройки» → «Звук» можно вернуть
                           FX Signal. Файл короче MIN_GAP_SEC — успевает доиграть до следующего звука;
                           собирается tools/make_robot_sound.py
    Sound/FX_Robot_End.wav — робот остановился (2.1.77): те же ноты, но нисходящие; галочка «Звук при
                           остановке робота» в «Настройки» → «Звук»; собирается make_robot_sound.py --end
    Sound/FX_Alert.wav   — резкое движение цены, касание линии, критическое событие
    Sound/FX_Open.wav, FX_Close.wav, FX_TakeProfit.wav, FX_StopLoss.wav — сделки стакана:
                           открыта позиция, закрыта, сработал TP, сработал SL
                           (нет файла — звучит запасной из трёх основных, см. FALLBACK)

Проигрывание — QSoundEffect (QtMultimedia, малая задержка, громкость); если модуль
недоступен — winsound (Windows). Нет файла / нет звука — уведомление просто остаётся
беззвучным, терминал не падает. Настройки — в QSettings (sound/enabled, sound/volume).
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

from PySide6 import QtCore

try:
    from PySide6.QtMultimedia import QSoundEffect
except Exception:                       # нет QtMultimedia в сборке — запасной путь winsound
    QSoundEffect = None

try:
    import winsound
except Exception:                       # не Windows
    winsound = None


PULSE, SIGNAL, ALERT = "pulse", "signal", "alert"
OPEN, CLOSE, TP, SL = "open", "close", "tp", "sl"          # сделки стакана (Trader.trade_event)
ROBOT = "robot"                                            # обнаружен робот («Алгоритмы»)
ROBOT_END = "robot_end"                                    # робот остановился («Алгоритмы», 2.1.77)
FILES = {PULSE: "FX_Pulse.wav", SIGNAL: "FX_Signal.wav", ALERT: "FX_Alert.wav", ROBOT: "FX_Robot.wav",
         ROBOT_END: "FX_Robot_End.wav",
         OPEN: "FX_Open.wav", CLOSE: "FX_Close.wav", TP: "FX_TakeProfit.wav", SL: "FX_StopLoss.wav"}
TITLES = {PULSE: "FX Pulse — обычное уведомление",
          SIGNAL: "FX Signal — крупная сделка, айсберг",
          ROBOT: "FX Robot — обнаружен робот",
          ROBOT_END: "FX Robot End — робот остановился",
          ALERT: "FX Alert — резкое движение, касание линии",
          OPEN: "Открыта позиция", CLOSE: "Закрыта позиция",
          TP: "Сработал Take-profit", SL: "Сработал Stop-loss"}
# Сделки важнее уведомлений «Алгоритмов»: в паузе антиспама звук сделки не глушится.
PRIORITY = {PULSE: 0, SIGNAL: 1, ROBOT: 1.5, ROBOT_END: 1.5, ALERT: 2, OPEN: 3, CLOSE: 3, TP: 4, SL: 4}
FALLBACK = {OPEN: PULSE, CLOSE: PULSE, TP: SIGNAL, SL: ALERT, ROBOT: SIGNAL, ROBOT_END: PULSE}   # нет файла — этот
ROBOT_SETTING = "sound/robot_own"      # «Свой звук для роботов (FX Robot)»; выключено — роботы звучат FX Signal
ROBOT_END_SETTING = "sound/robot_end"  # «Звук при остановке робота (FX Robot End)», по умолчанию включено
TRADE_KINDS = (OPEN, CLOSE, TP, SL)
TRADE_SETTING = {OPEN: "sound/trade_open", CLOSE: "sound/trade_close", TP: "sound/trade_tp", SL: "sound/trade_sl"}

MIN_GAP_SEC = 0.7          # пачка уведомлений подряд — один звук, а не «пулемёт»
SOUND_DIR_NAME = "Sound"

# По словам в типе/заголовке уведомления выбираем сигнал (регистр не важен).
_ALERT_WORDS = ("алерт", "alert", "касание", "резк", "критич", "стоп", "ликвидац", "маржин", "скачок", "движени")
_ROBOT_WORDS = ("робот", "robot")
_SIGNAL_WORDS = ("айсберг", "крупн", "iceberg", "large", "повтор", "сигнал")


def classify(*texts) -> str:
    """Тип звука по тексту уведомления: alert > robot > signal > pulse."""
    joined = " ".join(str(t) for t in texts if t).lower()
    if any(w in joined for w in _ALERT_WORDS):
        return ALERT
    if any(w in joined for w in _ROBOT_WORDS):
        return ROBOT
    if any(w in joined for w in _SIGNAL_WORDS):
        return SIGNAL
    return PULSE


class SoundNotifier(QtCore.QObject):
    """Создаётся в GUI-потоке; play() можно звать только из него."""

    def __init__(self, settings: QtCore.QSettings, sound_dir: Path, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._dir = Path(sound_dir)
        self._effects: dict[str, object] = {}
        self._last_at = 0.0
        self._last_priority = -1
        self._warned: set[str] = set()
        if QSoundEffect is not None:
            for kind, name in FILES.items():
                path = self._dir / name
                if not path.is_file():
                    continue
                effect = QSoundEffect(self)
                effect.setSource(QtCore.QUrl.fromLocalFile(str(path)))
                self._effects[kind] = effect
        self._apply_volume()

    # ---- настройки ----------------------------------------------------------
    @property
    def enabled(self) -> bool:
        value = self._settings.value("sound/enabled", True)
        return str(value).lower() not in ("false", "0", "no")

    def set_enabled(self, on: bool) -> None:
        self._settings.setValue("sound/enabled", bool(on))

    @property
    def volume(self) -> int:
        try:
            return max(0, min(100, int(self._settings.value("sound/volume", 70))))
        except (TypeError, ValueError):
            return 70

    def set_volume(self, percent: int) -> None:
        self._settings.setValue("sound/volume", max(0, min(100, int(percent))))
        self._apply_volume()

    def _apply_volume(self) -> None:
        for effect in self._effects.values():
            try:
                effect.setVolume(self.volume / 100.0)
            except Exception:
                pass

    def missing_files(self) -> list[str]:
        return [name for name in FILES.values() if not (self._dir / name).is_file()]

    @property
    def robot_own(self) -> bool:
        value = self._settings.value(ROBOT_SETTING, True)
        return str(value).lower() not in ("false", "0", "no")

    @property
    def robot_end_enabled(self) -> bool:
        """Галочка «Звук при остановке робота» (по умолчанию включена)."""
        value = self._settings.value(ROBOT_END_SETTING, True)
        return str(value).lower() not in ("false", "0", "no")

    def play_robot_end(self, *_args) -> None:
        """Робот, о котором было уведомление, остановился (QuotesTab.robot_stopped) — FX Robot End, если звук и
        галочка «Звук при остановке робота» включены. Своя дорожка: строки робота склеиваются в одну, и звук
        склеенной строки не повторяется — поэтому остановка звучит отдельно от уведомлений."""
        if self.enabled and self.robot_end_enabled:
            self.play(ROBOT_END)

    def trade_enabled(self, kind: str) -> bool:
        """Галочка «Настройки» → «Звук» → «Сделки в стакане» для этого события (по умолчанию включена)."""
        value = self._settings.value(TRADE_SETTING.get(kind, ""), True)
        return str(value).lower() not in ("false", "0", "no")

    def play_trade(self, kind: str) -> None:
        """Звук сделки стакана — если включён звук и галочка этого события."""
        if self.enabled and kind in TRADE_SETTING and self.trade_enabled(kind):
            self.play(kind)

    def play_notice(self, kind: str) -> None:
        """Уведомление окна стакана (крупный объём, айсберг, сигнальный уровень, сделка) — если звук включён.
        kind — PULSE / SIGNAL / ALERT; громкость и антиспам — общие с остальными уведомлениями."""
        if self.enabled:
            self.play(kind if kind in (PULSE, SIGNAL, ALERT) else PULSE)

    # ---- проигрывание -------------------------------------------------------
    def notify(self, *texts) -> None:
        """Звук для уведомления (если звук включён); тип выбирается по тексту."""
        if self.enabled:
            self.play(classify(*texts))

    def play(self, kind: str, force: bool = False) -> None:
        """force=True — кнопка «Проверить» в настройках: без антиспама и при выключенном звуке."""
        kind = kind if kind in FILES else PULSE
        if kind == ROBOT and not force and not self.robot_own:
            kind = SIGNAL                            # свой звук робота выключен — как раньше, FX Signal
        if kind in FALLBACK and kind not in self._effects and not (self._dir / FILES[kind]).is_file():
            kind_priority = PRIORITY[kind]
            kind = FALLBACK[kind]                    # своего файла нет — запасной звук, но с важностью сделки
        else:
            kind_priority = PRIORITY[kind]
        now = time.monotonic()
        if not force:
            # Внутри паузы молчим, если только новое событие не важнее уже прозвучавшего.
            if now - self._last_at < MIN_GAP_SEC and kind_priority <= self._last_priority:
                return
        self._last_at, self._last_priority = now, kind_priority

        effect = self._effects.get(kind)
        if effect is not None:
            try:
                for other in self._effects.values():   # новый сигнал не накладывается на старый
                    if other is not effect and other.isPlaying():
                        other.stop()
                effect.play()
                return
            except Exception as exc:
                self._warn(f"QSoundEffect: {type(exc).__name__}: {exc}")
        path = self._dir / FILES[kind]
        if winsound is not None and path.is_file():
            try:
                winsound.PlaySound(str(path), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
                return
            except Exception as exc:
                self._warn(f"winsound: {type(exc).__name__}: {exc}")
        if not path.is_file():
            self._warn(f"нет файла {path}")

    def _warn(self, text: str) -> None:
        if text not in self._warned:
            self._warned.add(text)
            print(f"[звук] {text}", file=sys.stderr)
