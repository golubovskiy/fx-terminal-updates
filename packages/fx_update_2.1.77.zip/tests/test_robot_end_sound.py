# -*- coding: utf-8 -*-
"""Звук остановки робота (2.1.77): Sound/FX_Robot_End.wav (нисходящий ход, формат и громкость как у FX Robot),
SoundNotifier.play_robot_end (галочка «Звук при остановке робота»), а во вкладке «Алгоритмы» — один сигнал
robot_stopped на серию, о которой было уведомление, и «· остановился» в строке робота ленты уведомлений.

Окно вкладки не создаётся: настоящие методы вкладки (_notify, _report_robot_stop, _mark_robot_row_stopped)
выполняются на объекте-подставке. Настройки терминала не трогаются (свой временный файл настроек).
Запуск:  python tests/test_robot_end_sound.py"""
from __future__ import annotations

import math
import os
import sys
import tempfile
import types
import wave
from types import SimpleNamespace

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pandas as pd  # noqa: E402
from PySide6 import QtCore, QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import quotes_tab  # noqa: E402
import robot_core  # noqa: E402
import sound_notifier as sn  # noqa: E402

SOUND = os.path.join(ROOT, "Sound")
SYM = "CRZ6@RTSX"


def _read(name: str):
    with wave.open(os.path.join(SOUND, name), "rb") as w:
        info = (w.getnchannels(), w.getsampwidth(), w.getframerate())
        x = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(float) / 32767.0
    return info, x


def _pitch(x, at: float, length: float = 0.05) -> float:
    """Основная частота куска звука (по спектру), Гц."""
    seg = x[int(at * 44100):int((at + length) * 44100)]
    spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg))))
    freqs = np.fft.rfftfreq(len(seg), 1 / 44100)
    band = (freqs > 300) & (freqs < 1000)               # первые гармоники нот A4…A5
    return float(freqs[band][np.argmax(spec[band])])


def test_end_sound_file():
    info, x = _read("FX_Robot_End.wav")
    assert info == (1, 2, 44100), info
    assert 0.3 < len(x) / 44100 < sn.MIN_GAP_SEC
    assert np.abs(x).max() < 0.95 and abs(x[0]) < 0.01 and abs(x[-1]) < 0.01
    rms = 20 * math.log10(math.sqrt(float((x ** 2).mean())))
    assert -20.0 < rms < -14.0, rms                      # громкость — как у FX Robot
    import importlib.util
    spec = importlib.util.spec_from_file_location("make_robot_sound", os.path.join(ROOT, "tools", "make_robot_sound.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    y = mod.render(end=True)
    assert len(y) == len(x) and float(np.abs(np.clip(y, -1, 1) - x).max()) < 3 / 32767
    step = mod.STEP_SEC
    first, last = _pitch(x, 0.0, step), _pitch(x, 3 * step, step)
    assert first > last * 1.5, (first, last)             # ход вниз (FX Robot — вверх)
    _, up = _read("FX_Robot.wav")
    assert _pitch(up, 0.0, step) < _pitch(up, 3 * step, step)


def test_notifier_switch():
    s = QtCore.QSettings(os.path.join(tempfile.mkdtemp(), "s.ini"), QtCore.QSettings.Format.IniFormat)
    n = sn.SoundNotifier(s, SOUND)
    assert sn.FILES[sn.ROBOT_END] == "FX_Robot_End.wav" and "FX_Robot_End.wav" not in n.missing_files()
    assert n.robot_end_enabled                          # по умолчанию — включено
    played = []
    n.play = lambda kind, force=False: played.append(kind)
    n.play_robot_end()
    assert played == [sn.ROBOT_END]
    s.setValue(sn.ROBOT_END_SETTING, False)             # галочка снята — молчит
    n.play_robot_end()
    s.setValue(sn.ROBOT_END_SETTING, True)
    s.setValue("sound/enabled", False)                  # звук выключен совсем — тоже
    n.play_robot_end()
    assert played == [sn.ROBOT_END]


class _Signal:
    def __init__(self):
        self.calls = []

    def emit(self, *args):
        self.calls.append(args)


def _tab():
    tab = SimpleNamespace(events=[], _events_unsaved=[], _recent_events={}, unread=0, unread_level=0,
                          robot_stopped=_Signal(), event_added=_Signal(), saved=0, clock=[pd.Timestamp("2026-11-16 08:00", tz="UTC")])
    tab._now_utc = lambda: tab.clock[0]
    tab._live_notifications = lambda: None
    tab._update_unread = lambda: None
    tab._save_events = lambda: setattr(tab, "saved", tab.saved + 1)
    tab._robot_info = robot_core.robot_info
    for name in ("_notify", "_report_robot_stop", "_mark_robot_row_stopped"):
        setattr(tab, name, types.MethodType(getattr(quotes_tab.QuotesTab, name), tab))
    return tab


def _chain(uid: int, notified: bool) -> dict:
    t0 = pd.Timestamp("2026-11-16 08:00:00", tz="UTC")
    chain = dict(count=10, volume=100, gaps_sum=9.0, gaps_sq=9.5, turnover=1e6, is_buy=True, size=10, started=t0,
                 last_ts=t0 + pd.Timedelta(seconds=252), price=12.3, uid=uid)
    if notified:
        chain["notified"] = True
    return chain


def test_stop_reported_once_and_row_marked():
    tab = _tab()
    tab._notify(SYM, "Robot", "10 сделок × 10 лотов", title="Робот: покупка", extra={"size": 10.0, "turnover": 1e6})
    other = tab._notify(SYM, "Сделка", "крупная", title="Крупная сделка") or tab.events[-1]
    assert tab.events[-1] is other and len(tab.events) == 2
    row = tab.events[0]
    tab.clock[0] = pd.Timestamp("2026-11-16 08:05:30", tz="UTC")
    chain = _chain(1, notified=True)
    tab._report_robot_stop(SYM, chain)
    assert len(tab.robot_stopped.calls) == 1 and tab.robot_stopped.calls[0][0] == SYM
    assert row["title"] == "Робот: покупка" + quotes_tab.STOPPED_MARK, row["title"]
    assert "работал 4 мин 12 с" in row["details"], row["details"]
    assert tab.events[-1] is row and row["time"] == "08:05:30"        # строка — наверх, время — остановки
    assert tab._events_unsaved[-1]["id"] == row["id"]                 # в журнал — новая версия с тем же id
    tab._report_robot_stop(SYM, chain)                                # таймер и «gone» — повторно: молча
    assert len(tab.robot_stopped.calls) == 1 and row["title"].count(quotes_tab.STOPPED_MARK) == 1
    tab._report_robot_stop(SYM, _chain(2, notified=False))             # серия без уведомления — молча
    assert len(tab.robot_stopped.calls) == 1
    tab.clock[0] = pd.Timestamp("2026-11-16 08:06:00", tz="UTC")
    tab._notify(SYM, "Robot", "12 сделок × 10 лотов", title="Робот: покупка", extra={"size": 10.0, "turnover": 1e6})
    assert quotes_tab.STOPPED_MARK not in row["title"] and "2 серии" in row["title"], row["title"]   # снова работает


def test_stop_without_row_still_sounds():
    tab = _tab()
    tab._report_robot_stop(SYM, _chain(3, notified=True))       # строка ушла из ленты — звук всё равно
    assert len(tab.robot_stopped.calls) == 1 and tab.events == []


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
