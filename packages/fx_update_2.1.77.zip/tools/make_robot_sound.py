# -*- coding: utf-8 -*-
"""Синтез звуков робота: Sound/FX_Robot.wav — «обнаружен робот», Sound/FX_Robot_End.wav — «робот остановился».

    python tools/make_robot_sound.py [ФАЙЛ]          # по умолчанию — Sound/FX_Robot.wav рядом с терминалом
    python tools/make_robot_sound.py --end [ФАЙЛ]    # по умолчанию — Sound/FX_Robot_End.wav (с 2.1.77)

FX Robot — четыре восходящие ноты ля минора (A4, C5, E5, A5) и короткий отзвук A4 + E5 + A5. FX Robot End — те же
ноты в обратном порядке (A5, E5, C5, A4) и отзвук вниз, к A4 + E4: на слух сразу понятно, робот начал или закончил.
Оба — 0,62 с, моно, 44,1 кГц, 16 бит. Параметры подобраны под остальные звуки терминала:
    * длина меньше sound_notifier.MIN_GAP_SEC (0,7 с) — при частых срабатываниях звук успевает доиграть и
      не накладывается сам на себя;
    * громкость около −17 дБ (rms) — как у FX_Open / FX_Close / FX_TakeProfit / FX_StopLoss;
    * ноты начинаются плавно (6–10 мс) — без щелчков; основная энергия в 500–2000 Гц — слышно и на ноутбуке.
Хочется другой темп, высоту или яркость — правятся константы ниже, файл пересобирается этой командой.
Нужен только numpy.
"""
from __future__ import annotations

import math
import sys
import wave
from pathlib import Path

import numpy as np

SR = 44100
A4, C5, E5, A5 = 440.0, 523.25, 659.26, 880.0
E4 = 329.63
NOTES = (A4, C5, E5, A5)                   # восходящий ход
ECHO = ((A4, 0.35), (E5, 0.30), (A5, 0.35))    # отзвук после последней ноты: (частота, громкость)
NOTES_END = tuple(reversed(NOTES))         # «робот остановился» — нисходящий ход
ECHO_END = ((A4, 0.45), (E4, 0.30), (C5, 0.20))   # отзвук внизу — «закончил»
STEP_SEC = 0.062                           # шаг между нотами
LENGTH_SEC = 0.62                          # длина файла
TARGET_RMS_DB = -17.0                      # громкость — как у остальных звуков терминала
PEAK = 0.60                                # потолок пиков (мягкое ограничение)
# гармоники ноты: (номер, громкость); верхние затухают быстрее — «колокольчик», а не писк
PARTIALS = ((1, 1.0), (2, 0.6), (3, 0.34), (4, 0.30), (5, 0.14), (6, 0.14), (8, 0.09))


def _biquad(x: np.ndarray, b: list[float], a: list[float]) -> np.ndarray:
    """Фильтр второго порядка (прямая форма I) — без scipy."""
    b0, b1, b2 = (v / a[0] for v in b)
    a1, a2 = a[1] / a[0], a[2] / a[0]
    y = np.zeros_like(x)
    x1 = x2 = y1 = y2 = 0.0
    for i, v in enumerate(x.tolist()):
        out = b0 * v + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2, x1, y2, y1 = x1, v, y1, out
        y[i] = out
    return y


def highpass(x: np.ndarray, freq: float, q: float = 0.707) -> np.ndarray:
    """Срез низа: под нотами нет полезного звука, только гул."""
    w = 2 * math.pi * freq / SR
    al, c = math.sin(w) / (2 * q), math.cos(w)
    return _biquad(x, [(1 + c) / 2, -(1 + c), (1 + c) / 2], [1 + al, -2 * c, 1 - al])


def high_shelf(x: np.ndarray, freq: float, gain_db: float) -> np.ndarray:
    """Подъём верха (полка): ясность на небольших колонках."""
    A = 10 ** (gain_db / 40)
    w = 2 * math.pi * freq / SR
    c, s = math.cos(w), math.sin(w)
    k = 2 * math.sqrt(A) * (s / 2 * math.sqrt(2))
    b = [A * ((A + 1) + (A - 1) * c + k), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - k)]
    a = [(A + 1) - (A - 1) * c + k, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - k]
    return _biquad(x, b, a)


def tone(freq: float, dur: float, attack: float, decay: float) -> np.ndarray:
    """Одна нота: сумма гармоник с затуханием и плавным началом (attack, с) — резкое начало даёт щелчок."""
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros_like(t)
    for k, amp in PARTIALS:
        y += amp * np.exp(-t / (decay / (1 + 0.18 * (k - 1)))) * np.sin(2 * math.pi * freq * k * t)
    n = max(1, int(attack * SR))
    y[:n] *= 0.5 - 0.5 * np.cos(np.pi * np.arange(n) / n)
    return y


def _place(buf: np.ndarray, y: np.ndarray, at: float) -> None:
    i = int(at * SR)
    buf[i:i + len(y)] += y[:max(0, len(buf) - i)]


def _finish(x: np.ndarray, tail_fade: float = 0.06) -> np.ndarray:
    """Плавный конец (файл заканчивается тишиной), громкость TARGET_RMS_DB, мягкое ограничение пиков."""
    n = int(tail_fade * SR)
    x[-n:] *= 0.5 + 0.5 * np.cos(np.pi * np.arange(n) / n)
    for _ in range(6):
        rms = math.sqrt(float((x ** 2).mean()))
        x = x * (10 ** (TARGET_RMS_DB / 20) / rms)
        if np.abs(x).max() > PEAK:
            x = PEAK * np.tanh(x / PEAK * 0.9) / math.tanh(0.9)
    return x


def render(end: bool = False) -> np.ndarray:
    """Звук целиком: отсчёты −1…1. end=True — «робот остановился» (FX_Robot_End.wav)."""
    notes, echo = (NOTES_END, ECHO_END) if end else (NOTES, ECHO)
    buf = np.zeros(int(LENGTH_SEC * SR))
    for i, freq in enumerate(notes):
        _place(buf, tone(freq, 0.30, attack=0.006, decay=0.11) * (0.85 + 0.05 * i), i * STEP_SEC)
    for freq, amp in echo:
        _place(buf, tone(freq, 0.36, attack=0.010, decay=0.16) * amp, len(notes) * STEP_SEC)
    return _finish(high_shelf(highpass(buf, 200.0), 2500.0, 3.0))


def save(path: Path, x: np.ndarray) -> None:
    data = (np.clip(x, -1.0, 1.0) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def main(argv: list[str]) -> int:
    args = argv[1:]
    end = "--end" in args
    args = [a for a in args if a != "--end"]
    name = "FX_Robot_End.wav" if end else "FX_Robot.wav"
    path = Path(args[0]) if args else Path(__file__).resolve().parent.parent / "Sound" / name
    x = render(end)
    save(path, x)
    rms = 20 * math.log10(math.sqrt(float((x ** 2).mean())))
    print(f"{path}: {len(x) / SR:.2f} с, пик {np.abs(x).max():.2f}, громкость {rms:.1f} дБ")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
