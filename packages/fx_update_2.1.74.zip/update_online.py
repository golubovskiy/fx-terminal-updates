# -*- coding: utf-8 -*-
"""Обновления через интернет (2.1.68): репозиторий github.com/golubovskiy/fx-terminal-updates — без Qt.

Что лежит в репозитории (его наполняет tools/publish_update.py на компьютере автора):
    latest.json              — список опубликованных пакетов с подписью Ed25519 (ниже);
    packages/fx_update_*.zip — сами пакеты обновления (те же, что ставятся вручную через «О проекте»).

latest.json:
    {"format": 1, "key": "<номер ключа>", "signature": "<подпись, base64>",
     "payload": {"app": "FX Terminal", "published": "...", "latest": "2.1.69",
                 "packages": [{"version", "requires", "file", "sha256", "size", "date", "build_rust", "changes"}, …]}}
Подписан payload в каноническом виде (canonical: ключи по алфавиту, без пробелов, UTF-8) — поэтому файл можно
читать глазами, а подпись не зависит от отступов. Подпись и данные в одном файле: GitHub раздаёт файлы через
кэш, и два отдельных файла (данные и подпись) могли бы на минуты разойтись.

Проверка (check):
    1. скачать latest.json; подпись должна сходиться с одним из PUBLIC_KEYS — иначе ничего не ставим;
    2. построить цепочку от установленной версии (plan_chain): requires пакета — самая старая версия, на которую
       его можно ставить; на каждом шаге берётся самый новый пакет, который можно ставить на достигнутую версию.
       Обычно requires — предыдущая версия, и цепочка идёт по всем пакетам; пакет, который заменяет неудачный
       (2.1.72 вместо 2.1.71, requires 2.1.70), позволяет неудачный перешагнуть. Разрыв — дальше вручную;
    3. скачать пакеты цепочки в _install/downloads/ и сверить размер и sha256 (они в подписанном payload) и
       версию в manifest.json пакета.
Ставит их updater.py, как и ручную установку: бэкап, проверки, откат при сбое.

Ключи: PUBLIC_KEYS — открытые ключи автора (32 байта, base64). Закрытый хранится только на его компьютере
(tools/publish_update.py --init) и в репозиторий не попадает никогда. Ключей нет — проверка через интернет
выключена (ставить нечего проверить). Смена ключа: новый ключ добавляется сюда пакетом, подписанным старым.

Адрес репозитория для проверок можно подменить переменной окружения FX_UPDATES_URL (путь file:// или http://).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import ssl
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import ed25519_lite
import updater

REPO = "golubovskiy/fx-terminal-updates"
BASE_URL = f"https://raw.githubusercontent.com/{REPO}/main/"
INDEX_FILE = "latest.json"
PACKAGES_DIR = "packages"
FORMAT = 1
DOWNLOADS = "downloads"                 # _install/downloads — скачанные пакеты
KEEP_DOWNLOADS = 20                     # столько последних скачанных пакетов храним
TIMEOUT_SEC = 20
MAX_INDEX_BYTES = 4 * 1024 * 1024
MAX_PACKAGE_BYTES = 64 * 1024 * 1024

# Открытые ключи автора (base64 от 32 байт). Пусто — проверка обновлений через интернет выключена.
# 2.1.69: ключ автора, созданный 16.11.2026 командой tools/publish_update.py --init (номер ключа 9daad1147531048a — update_online.key_id).
PUBLIC_KEYS: tuple[str, ...] = (
    "ZppzuWxkmYXa0cZ3MReF2NHTUhSH6YpVNMVppa6tulI=",
)

OK, NONE, GAP, NO_KEY, ERROR = "ok", "none", "gap", "no_key", "error"


class OnlineError(Exception):
    """Проверка или скачивание не удались; текст — для человека."""


class NotFound(OnlineError):
    """Файла нет в репозитории (HTTP 404): для latest.json — обновления ещё ни разу не публиковались."""


def base_url() -> str:
    url = os.environ.get("FX_UPDATES_URL") or BASE_URL
    return url if url.endswith("/") else url + "/"


def key_id(pub: bytes) -> str:
    """Короткий номер ключа: первые 16 знаков sha256 от открытого ключа."""
    return hashlib.sha256(pub).hexdigest()[:16]


def known_keys(keys=None) -> dict[str, bytes]:
    out = {}
    for text in (PUBLIC_KEYS if keys is None else keys):
        try:
            pub = base64.b64decode(text, validate=True)
        except (ValueError, TypeError):
            continue
        if len(pub) == 32:
            out[key_id(pub)] = pub
    return out


def canonical(payload: dict) -> bytes:
    """Подписываемые байты payload: одинаковые у публикации и у проверки при любых отступах файла."""
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_index(payload: dict, seed: bytes) -> dict:
    """latest.json целиком: payload с подписью закрытым ключом seed (для tools/publish_update.py)."""
    pub = ed25519_lite.public_key(seed)
    sig = ed25519_lite.sign(seed, canonical(payload))
    return {"format": FORMAT, "key": key_id(pub), "signature": base64.b64encode(sig).decode("ascii"),
            "payload": payload}


def index_bytes(index: dict) -> bytes:
    return (json.dumps(index, ensure_ascii=False, indent=1) + "\n").encode("utf-8")


def verify_index(raw: bytes, keys=None) -> dict:
    """Байты latest.json -> payload, если подпись верна одним из ключей; иначе OnlineError."""
    known = known_keys(keys)
    if not known:
        raise OnlineError("в терминале нет ключа подписи обновлений")
    try:
        index = json.loads(raw.decode("utf-8"))
        payload = index["payload"]
        sig = base64.b64decode(index["signature"], validate=True)
        kid = str(index["key"])
    except (ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
        raise OnlineError(f"latest.json повреждён ({type(exc).__name__})") from None
    if int(index.get("format", 0) or 0) > FORMAT:
        raise OnlineError("latest.json новее, чем понимает этот терминал — обновитесь вручную")
    pub = known.get(kid)
    if pub is None:
        raise OnlineError(f"latest.json подписан неизвестным ключом {kid}")
    if not isinstance(payload, dict) or not ed25519_lite.verify(pub, canonical(payload), sig):
        raise OnlineError("подпись latest.json не сходится — пакеты не ставятся")
    return payload


def _v(text) -> tuple[int, ...]:
    return updater.parse_version(str(text or "0"))


def plan_chain(payload: dict, current: str) -> tuple[list[dict], str | None]:
    """Пакеты для перехода с current на самую новую версию, по порядку -> (шаги, причина разрыва или None).
    Шаг — самый новый пакет, который можно ставить на достигнутую версию (requires не выше неё, файл на месте);
    так пакет-замена перешагивает неудачный (см. описание файла). Разрыв: дальше есть пакеты, но ни один нельзя
    ставить — нужна версия, которой нет в репозитории, или файла пакета там уже нет."""
    entries = [e for e in payload.get("packages") or [] if isinstance(e, dict) and e.get("version")]
    steps: list[dict] = []
    reached = current
    while True:
        ahead = sorted((e for e in entries if _v(e["version"]) > _v(reached)), key=lambda e: _v(e["version"]))
        if not ahead:
            return steps, None
        fits = [e for e in ahead if e.get("file") and not (e.get("requires") and _v(e["requires"]) > _v(reached))]
        if not fits:
            first = ahead[0]
            need = first.get("requires")
            if need and _v(need) > _v(reached):
                return steps, (f"для {first['version']} нужна версия {need}, а её нет в репозитории — "
                               f"установите {need} вручную («О проекте» → «Установить обновление…»)")
            return steps, f"пакета {first['version']} в репозитории уже нет — установите его вручную"
        best = fits[-1]
        steps.append(best)
        reached = best["version"]


def _context():
    return ssl.create_default_context()


def fetch(url: str, limit: int, timeout: float = TIMEOUT_SEC) -> bytes:
    """Скачать url (не больше limit байт). Ошибки сети и HTTP -> OnlineError с понятным текстом."""
    request = urllib.request.Request(url, headers={"User-Agent": "FX-Terminal-updater", "Cache-Control": "no-cache"})
    try:
        kwargs = {"timeout": timeout}
        if url.startswith("https:"):
            kwargs["context"] = _context()
        with urllib.request.urlopen(request, **kwargs) as resp:          # noqa: S310 — адрес задан в коде
            data = resp.read(limit + 1)
    except urllib.error.HTTPError as exc:
        cls = NotFound if exc.code == 404 else OnlineError
        raise cls(f"GitHub ответил {exc.code} на {url.rsplit('/', 1)[-1]}") from None
    except (urllib.error.URLError, OSError, ValueError) as exc:
        reason = getattr(exc, "reason", exc)
        raise OnlineError(f"GitHub не ответил: {reason}") from None
    if len(data) > limit:
        raise OnlineError(f"{url.rsplit('/', 1)[-1]} больше {limit // (1024 * 1024)} МБ — не скачиваю")
    return data


def downloads_dir(root: Path) -> Path:
    return Path(root) / updater.INSTALL_DIR / DOWNLOADS


def download(root: Path, entry: dict, url: str | None = None) -> Path:
    """Скачать пакет шага в _install/downloads и проверить: размер, sha256, версия и requires в manifest.json.
    Уже скачанный и верный — не скачивается заново."""
    name = Path(str(entry["file"])).name
    if not name.startswith("fx_update_") or not name.endswith(".zip"):
        raise OnlineError(f"странное имя пакета: {name}")
    folder = downloads_dir(root)
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / name
    want = str(entry.get("sha256") or "").lower()
    if not (target.exists() and updater.sha256_file(target) == want):
        data = fetch(url or (base_url() + str(entry["file"])), MAX_PACKAGE_BYTES)
        if entry.get("size") is not None and len(data) != int(entry["size"]):
            raise OnlineError(f"{name}: размер {len(data)} вместо {entry['size']}")
        if hashlib.sha256(data).hexdigest() != want:
            raise OnlineError(f"{name}: контрольная сумма не сходится — пакет не ставится")
        tmp = target.with_suffix(".part")
        tmp.write_bytes(data)
        os.replace(tmp, target)
    try:
        manifest = updater.read_package(target)
    except updater.UpdateError as exc:
        raise OnlineError(f"{name}: {exc}") from None
    if str(manifest.get("version")) != str(entry["version"]) or \
            str(manifest.get("requires") or "") != str(entry.get("requires") or ""):
        raise OnlineError(f"{name}: версия в пакете не та, что в latest.json")
    return target


def prune_downloads(root: Path, keep: int = KEEP_DOWNLOADS) -> None:
    folder = downloads_dir(root)
    if not folder.is_dir():
        return
    files = sorted(folder.glob("fx_update_*.zip"), key=lambda p: _v(p.stem[len("fx_update_"):]))
    for old in files[:-keep] if keep else files:
        try:
            old.unlink()
        except OSError:
            pass
    for part in folder.glob("*.part"):
        try:
            part.unlink()
        except OSError:
            pass


@dataclass
class Result:
    """Итог проверки: status — OK (есть что ставить, пакеты скачаны), NONE (последняя версия), GAP (цепочка
    рвётся — шаги до разрыва всё равно можно поставить), NO_KEY (ключа нет), ERROR (сеть, подпись, пакет)."""
    status: str
    current: str = ""
    latest: str = ""
    steps: list[dict] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    message: str = ""
    checked: str = ""

    @property
    def target(self) -> str:
        return self.steps[-1]["version"] if self.steps else self.current

    def changes(self) -> list[tuple[str, str, list[str]]]:
        """Изменения всех шагов — новые сверху, как CHANGES в version.py."""
        return [(s["version"], str(s.get("date") or ""), list(s.get("changes") or [])) for s in reversed(self.steps)]


def check(root: Path, keys=None, download_packages: bool = True) -> Result:
    """Проверить репозиторий и (если есть что ставить) скачать пакеты. Исключений не бросает."""
    root = Path(root)
    current = updater.current_version(root)
    res = Result(NONE, current=current, checked=datetime.now().strftime("%H:%M"))
    if not known_keys(keys):
        res.status, res.message = NO_KEY, "в терминале ещё нет ключа подписи обновлений — проверка выключена"
        return res
    try:
        try:
            raw = fetch(base_url() + INDEX_FILE, MAX_INDEX_BYTES)
        except NotFound:                                             # репозиторий есть, публикаций ещё не было
            res.message = "в репозитории ещё нет опубликованных обновлений"
            return res
        payload = verify_index(raw, keys)
        res.latest = str(payload.get("latest") or "")
        steps, gap = plan_chain(payload, current)
        res.steps = steps
        if download_packages:
            res.files = [str(download(root, step)) for step in steps]
            prune_downloads(root)
        if gap and not steps:
            res.status, res.message = GAP, gap
        elif steps:
            res.status = OK
            res.message = (f"доступна версия {res.target}" + (f" (пакетов: {len(steps)})" if len(steps) > 1 else "")
                           + (f"; дальше — {gap}" if gap else ""))
        else:
            res.message = f"установлена последняя версия {current}"
    except OnlineError as exc:
        res.status, res.message, res.steps, res.files = ERROR, str(exc), [], []
    except Exception as exc:                                         # noqa: BLE001 — проверка не роняет терминал
        res.status, res.message, res.steps, res.files = ERROR, f"{type(exc).__name__}: {exc}", [], []
    return res


def install_command(root: Path, res: Result) -> list[str] | None:
    """Команда updater для установки скачанных пакетов цепочки (по порядку) или None."""
    if res.status != OK or not res.files:
        return None
    return updater.updater_command(root, "apply", *res.files)


def entry_for(zip_path: Path, file_rel: str) -> dict:
    """Запись latest.json для пакета (для tools/publish_update.py): версия и изменения — из manifest.json."""
    manifest = updater.read_package(zip_path)
    data = Path(zip_path).read_bytes()
    return {"version": str(manifest["version"]), "requires": manifest.get("requires") or None, "file": file_rel,
            "sha256": hashlib.sha256(data).hexdigest(), "size": len(data),
            "date": str(manifest.get("date") or time.strftime("%Y-%m-%d")),
            "build_rust": bool(manifest.get("build_rust")), "changes": list(manifest.get("changes") or [])}


def copy_package(zip_path: Path, repo: Path) -> str:
    """Положить пакет в packages/ репозитория -> путь внутри репозитория (для latest.json)."""
    manifest = updater.read_package(zip_path)
    rel = f"{PACKAGES_DIR}/fx_update_{manifest['version']}.zip"
    target = Path(repo) / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(zip_path, target)
    return rel
