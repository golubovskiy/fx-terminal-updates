# -*- coding: utf-8 -*-
"""Неудачный пакет в репозитории обновлений (2.1.72): пакет-замена с requires как у неудачного перешагивает его
(update_online.plan_chain), а tools/publish_update.py --withdraw снимает неудачный совсем. Без Qt и без интернета;
часть с git пропускается, если git не установлен.  Запуск:  python tests/test_update_supersede.py"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

import update_online as uo  # noqa: E402
from test_update_online import SEED, _Url, _package, _terminal  # noqa: E402


def _e(v, r, f=True):
    return {"version": v, "requires": r, "file": f"packages/fx_update_{v}.zip" if f else None}


def test_replacement_steps_over_failed_package():
    payload = {"packages": [_e("2.1.69", "2.1.68"), _e("2.1.70", "2.1.69"), _e("2.1.71", "2.1.70"),
                            _e("2.1.72", "2.1.70"), _e("2.1.73", "2.1.72")]}
    plan = lambda cur: [s["version"] for s in uo.plan_chain(payload, cur)[0]]   # noqa: E731
    assert plan("2.1.68") == ["2.1.69", "2.1.70", "2.1.72", "2.1.73"]           # 2.1.71 перешагнули
    assert plan("2.1.70") == ["2.1.72", "2.1.73"]
    assert plan("2.1.71") == ["2.1.72", "2.1.73"]                               # кто успел поставить 2.1.71 — тоже
    assert plan("2.1.73") == []
    # обычная цепочка (requires — предыдущая версия) — по всем пакетам, как раньше
    chain = {"packages": [_e("2.1.1", "2.1.0"), _e("2.1.2", "2.1.1"), _e("2.1.3", "2.1.2")]}
    assert [s["version"] for s in uo.plan_chain(chain, "2.1.0")[0]] == ["2.1.1", "2.1.2", "2.1.3"]
    # файла самого нового нет — берётся предыдущий подходящий, дальше разрыв
    steps, gap = uo.plan_chain({"packages": [_e("2.1.1", "2.1.0"), _e("2.1.2", "2.1.0", f=False)]}, "2.1.0")
    assert [s["version"] for s in steps] == ["2.1.1"] and "уже нет" in gap


def test_withdraw_failed_package():
    if shutil.which("git") is None:
        print("      (git не установлен — проверка снятия пакета пропущена)")
        return
    import publish_update as pu
    for name, value in (("GIT_AUTHOR_NAME", "test"), ("GIT_AUTHOR_EMAIL", "test@example.invalid"),
                        ("GIT_COMMITTER_NAME", "test"), ("GIT_COMMITTER_EMAIL", "test@example.invalid")):
        os.environ.setdefault(name, value)
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:     # объекты git — только для чтения
        tmp = Path(tmp)
        origin = tmp / "origin.git"
        subprocess.run(["git", "init", "--quiet", "--bare", str(origin)], check=True)
        work = tmp / "work"
        pu.ensure_repo(work, url=str(origin), log=lambda *_: None)
        built = tmp / "built"
        built.mkdir()
        bad = _package(built, "2.1.1", "2.1.0", 1)
        assert pu.publish([bad], work, SEED, log=lambda *_: None) == ["2.1.1"]
        assert pu.withdraw("2.1.9", work, SEED, log=lambda *_: None) is False      # такой нет
        assert pu.withdraw("2.1.1", work, SEED, log=lambda *_: None) is True
        assert not (work / "packages" / "fx_update_2.1.1.zip").exists()
        payload = pu.read_payload(work, SEED)
        assert payload["packages"] == [] and payload["latest"] is None
        good = _package(built, "2.1.2", "2.1.0", 2)                                  # замена — снова публикуется
        assert pu.publish([good], work, SEED, log=lambda *_: None) == ["2.1.2"]
        clone = tmp / "clone"
        subprocess.run(["git", "clone", "--quiet", str(origin), str(clone)], check=True)
        term = _terminal(tmp / "term")
        import base64
        import ed25519_lite as ed
        with _Url(clone):
            res = uo.check(term, keys=(base64.b64encode(ed.public_key(SEED)).decode("ascii"),))
        assert res.status == uo.OK and [s["version"] for s in res.steps] == ["2.1.2"], res.message


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
