# -*- coding: utf-8 -*-
"""«О проекте»: небольшая кнопка «GitHub ↗» открывает страницу репозитория обновлений (2.1.71). Браузер в проверке
не открывается: update_dialog.open_updates_page подменена.  Запуск:  python tests/test_about_link.py"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtWidgets  # noqa: E402

APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

import update_dialog as ud  # noqa: E402


def test_github_button_opens_updates_page():
    assert ud.UPDATES_PAGE == "https://github.com/golubovskiy/fx-terminal-updates"
    opened = []
    saved = ud.open_updates_page
    ud.open_updates_page = lambda: opened.append(ud.UPDATES_PAGE) or True
    dlg = ud.AboutDialog()
    try:
        button = dlg.page_btn
        assert button.text() == "GitHub ↗" and not button.autoDefault() and not button.isDefault()
        assert ud.UPDATES_PAGE in button.toolTip()
        button.click()
        assert opened == [ud.UPDATES_PAGE], opened
    finally:
        ud.open_updates_page = saved
        dlg.deleteLater()
        APP.processEvents()


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
