# -*- coding: utf-8 -*-
"""Где лежит программа и где её данные (2.1.79, к сборке в exe) — только стандартная библиотека.

Два вида установки:

    из исходников (C:\\FX_Terminal, запуск python gui_app.py) — всё как раньше: данные (журналы logs/, базы *.db,
        рисунки, события, кэши) лежат рядом с кодом, DATA_DIR = APP_DIR;

    собранная программа (tools/build_exe.py: PyInstaller «папкой» + установщик Inno Setup) —
        %LOCALAPPDATA%\\Programs\\FX Terminal\\
            FX Terminal.exe     — окно терминала (без консоли)
            fx_python.exe       — тот же Python с консолью: установщик обновлений и проверки (python_command)
            _internal\\          — Python и библиотеки (PySide6, QtAds, pandas, fx_engine …), собраны PyInstaller
            app\\                — файлы терминала (.py, Sound, tests) обычной папкой: их меняют пакеты обновлений
        данные — %LOCALAPPDATA%\\FX_Terminal (переустановка и удаление программы их не трогают).

Настройки, токен Finam и заметки — в реестре (QSettings "MyTradingTools/FxTerminal"), одни на обе установки.
FX_DATA_DIR — своя папка данных (проверки и отладка).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

FROZEN = bool(getattr(sys, "frozen", False))          # запущена собранная программа (PyInstaller)
APP_DIR = Path(__file__).resolve().parent              # файлы терминала (.py); в собранной — папка app\
GUI_EXE_NAME = "FX Terminal.exe"
PYTHON_EXE_NAME = "fx_python.exe"
DATA_FOLDER_NAME = "FX_Terminal"


def _data_dir() -> Path:
    custom = os.environ.get("FX_DATA_DIR")
    if custom:
        return Path(custom)
    if not FROZEN:
        return APP_DIR
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / DATA_FOLDER_NAME


DATA_DIR = _data_dir()                                 # журналы, базы, рисунки, события, кэши
LOG_DIR = DATA_DIR / "logs"


def ensure_data_dir() -> Path:
    """Создать папку данных (и logs\\), если её ещё нет. Ошибку не поднимает — пишущий файл сам её увидит."""
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return DATA_DIR


def program_dir() -> Path:
    """Папка с exe собранной программы (на уровень выше app\\); из исходников — папка терминала."""
    return Path(sys.executable).resolve().parent if FROZEN else APP_DIR


def python_command() -> list[str]:
    """Чем запускать скрипты терминала (установщик обновлений, проверки tests/*.py): из исходников — тем же
    Python (sys.executable), в собранной программе — fx_python.exe (Python с консолью; fx_boot.py выполняет
    переданный ему .py). Окно терминала (FX Terminal.exe) для этого не годится: у него нет консоли."""
    if FROZEN:
        return [str(program_dir() / PYTHON_EXE_NAME)]
    return [sys.executable]


def gui_command(*args: str) -> list[str]:
    """Запуск окна терминала: из исходников — python gui_app.py, в собранной — FX Terminal.exe."""
    if FROZEN:
        return [str(program_dir() / GUI_EXE_NAME), *args]
    return [sys.executable, str(APP_DIR / "gui_app.py"), *args]
