"""
GUI-терминал для валюты и валютных фьючерсов на PySide6 + pyqtgraph.
Работает на Windows 11 (и кроссплатформенно вообще).

Установка:
    pip install PySide6 pyqtgraph pandas numpy requests finam-sdk

Запуск:
    python gui_app.py
    $env:FX_PERF_DETAIL=1; python gui_app.py    # то же + подробный замер нагрузки по событиям Qt

Модули терминала (gui_app.py — только запуск: журнал, иконка, тема, главное окно):
    app_common.py       — общие константы и функции: инструменты, квартальные фьючерсы,
                           имена символов, таймфреймы, часовые пояса, шрифт, стиль, ресурсы
    main_window.py      — главное окно: меню, пространства, подключение к Finam, вкладки
    chart_panel.py      — панель графика и отдельное окно графика из «Алгоритмов»
    chart_items.py      — элементы графика: объёмы, шкала цены, значки, фигуры разметки
    settings_dialog.py  — диалог «Настройки…»
    data_workers.py     — фоновые загрузки: история свечей, каталог/позиции/заявки, диагностика
    data_status_window.py — окно «Состояние подключения»
    brokers/, services/, core/ — шлюз Finam, хаб подписок, журнал, лимит LIVE, замер нагрузки
                           (services/perf.py, perf_qt.py → logs/perf_ГГГГ-ММ-ДД.csv), модели

Файлы рядом:
    finam_terminal.py   — REST-клиент Finam Trade API (свечи + индикаторы)
    finam_sdk_client.py — gRPC-клиент (официальный SDK): стриминг котировок,
                           инструменты, позиции, заявки
    candlestick_item.py — кастомный виджет свечного графика для pyqtgraph
    candle_cache.py      — SQLite-кэш свечей для мгновенной отрисовки
    fx_terminal.ico     — иконка приложения (окно, панель задач, рабочий стол)
    scalper_widget.py   — «Стакан» (скальпер): несколько окон, «Инструмент» и «Каталог…», PAPER / LIVE
    workspace_shell.py  — рабочие области: докинг-панели (PySide6-QtAds), нижние вкладки областей,
    docking.py            стартовый экран с карточками; status_clock.py — индикатор подключения и часы
    open_interest_tab.py — вкладка «Открытый интерес» по фьючерсам Si и CR (ближайшие контракты
                           по дате, шкала справа); ей нужен options_common.py
    options_tab.py      — вкладка «Опционы» (цепочка, премии, открытый интерес); ей нужны ещё
                           options_chain_chart_widget.py, options_oi_view.py, options_common.py,
                           options_theme.py — все рядом с gui_app.py

Обновления:
    version.py          — версия и список изменений («О проекте»)
    updater.py          — установка пакета обновления / откат отдельным процессом (бэкап в _backup/,
                           состояние в _install/); update_dialog.py — окна «О проекте» и установки;
                           tools/make_update.py — сборка пакета fx_update_<версия>.zip

Токен НЕ хардкодится в коде — вводится в диалоге настроек и хранится
через QSettings (реестр Windows / файл конфигурации), либо передаётся
через переменные окружения FINAM_SECRET / FINAM_ACCOUNT_ID.
"""
from __future__ import annotations

import faulthandler
import json
import os
import re
import ssl
import sys
import traceback
from datetime import date, timedelta
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)
from zoneinfo import available_timezones

ROOT = Path(__file__).resolve().parent


def _update_guard() -> None:
    """До тяжёлых импортов: счётчик запусков для защиты от неудачного обновления (updater.startup_begin).
    Терминал после обновления дважды подряд не дожил до «запуск удачный» (упал при импорте или на старте) —
    предложить вернуть прошлую версию. Окно — системное (MessageBoxW): Qt может быть как раз сломан."""
    try:
        import updater
        updater.ensure_baseline(ROOT)
        offer = updater.startup_begin(ROOT)
    except Exception:
        traceback.print_exc()
        return
    if not offer:
        return
    text = (f"После обновления до {offer['version']} терминал дважды подряд не запустился.\n\n"
            f"Вернуть прошлую версию {offer['back_to']}? Файлы вернутся из бэкапа, терминал запустится снова.")
    if os.name == "nt":
        import ctypes
        yes = ctypes.windll.user32.MessageBoxW(None, text, "FX Terminal — обновление", 0x04 | 0x30) == 6
    else:
        print(text)
        yes = input("Вернуть? [y/N] ").strip().lower() in ("y", "д", "да", "yes")
    if yes:
        # python_command: в собранной программе — fx_python.exe (app_paths), из исходников — этот же Python
        cmd = [*app_paths.python_command(), str(ROOT / "updater.py"), "rollback", "--backup", offer["backup"], "--restart"]
        updater.spawn(cmd, ROOT)
        os._exit(0)


if __name__ == "__main__":                       # не при импорте (tests/test_imports.py, проверки updater)
    _update_guard()

import pandas as pd
import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
import shiboken6
import pyqtgraph as pg
import fx_theme

from candlestick_item import CandlestickItem, TimeAxisItem, BULL_COLOR, BEAR_COLOR
from finam_terminal import (
    FinamClient,
    enrich_with_indicators,
    INSTRUMENTS,
    to_friendly_symbol,
    from_friendly_symbol,
    register_symbols,
    sma,
    vwap,
)
from finam_sdk_client import FinamStreamClient
from quotes_tab import QuotesTab, QuotesEventMarker
from instrument_picker import InstrumentPickerDialog
from tick_volume_manager import TickVolumeManager
from window_links import LinkHub, install_link_titlebar
from order_flow import (
    OrderFlowController,
    OrderFlowTab,
    ORDER_FLOW_SYMBOLS,
    resolve_quarterly_symbols,
)
from connection_diagnostics import ConnectionDiagnosticsDialog
from cny_forward_tab import CnyForwardMonitorTab, set_display_timezone as set_cny_display_timezone
import docking
from open_interest_tab import OpenInterestTab
from options_tab import OptionsTab
from status_clock import StatusClock, FinamClockSource
from notes_panel import NotesStore, NotesPanel
from sound_notifier import SoundNotifier, PULSE, SIGNAL, ALERT, TITLES as SOUND_TITLES
from workspace_shell import PanelSpec, ShellGroup, WorkspaceShell
import candle_cache

from app_common import (  # noqa: F401
    APP_ICON_NAME,
    APP_USER_MODEL_ID,
    _install_russian_qt,
    _resource_path,
    app_stylesheet,
    apply_app_font_size,
)
from main_window import (  # noqa: F401
    MainWindow,
)


def _set_windows_app_id() -> None:
    """Задаёт AppUserModelID. Вызывать ДО создания QApplication/окон."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
    except Exception:
        pass  # косметика: без неё просто останется иконка Python на панели задач


def _load_app_icon() -> QtGui.QIcon:
    """Загружает fx_terminal.ico; при отсутствии файла возвращает пустую иконку."""
    path = _resource_path(APP_ICON_NAME)
    if not path.is_file():
        print(f"[icon] файл иконки не найден: {path}", file=sys.stderr)
        return QtGui.QIcon()
    icon = QtGui.QIcon(str(path))
    if icon.isNull():
        print(f"[icon] не удалось загрузить иконку: {path}", file=sys.stderr)
    return icon


def main() -> None:
    # "Unhandled win32 exception" в python.exe — это падение на уровне
    # нативного кода (Qt/C++), а не обычное Python-исключение, поэтому
    # try/except его не ловит и обычный трейсбек не покажет. faulthandler
    # печатает в лог-файл, какая именно Python-функция выполнялась в
    # момент падения — это единственная практическая зацепка в таких
    # случаях, дальше разбираемся по этому логу, а не вслепую.
    # Журнал: то, что пишется в консоль, — ещё и в logs/fx_terminal_ГГГГ-ММ-ДД.log (14 дней). Обычный запуск —
    # тихий режим (2.1.65): в файлы идут только ошибки, предупреждения и минуты аномальной нагрузки. Все журналы,
    # как раньше, — запуск с переменной FX_LOGS=1 или ключом --logs (services/log_mode.py).
    all_logs = False
    app_paths.ensure_data_dir()          # папка данных и logs\ (в собранной программе — %LOCALAPPDATA%\FX_Terminal)
    try:
        from services import log_mode
        all_logs = log_mode.from_argv(sys.argv)
    except Exception:
        log_mode = None
    try:
        from services.log_file import install as install_log_file
        install_log_file(app_paths.LOG_DIR, quiet=not all_logs)
    except Exception:
        pass
    try:
        import version
        print(f"[версия] FX Terminal {version.VERSION} (сборка {version.BUILD_DATE})")
    except Exception:
        pass
    if log_mode is not None:
        print(log_mode.describe())

    faulthandler_log = app_paths.DATA_DIR / "crash_faulthandler.log"
    # Файл открывается заново каждый запуск. Если прошлый запуск оставил в нём сбой — сначала копия в
    # logs/crash_ДАТА_ВРЕМЯ.txt и строка в журнал, иначе единственная улика стирается (services/crash_log.py).
    try:
        from services import crash_log
        saved_crash = crash_log.keep_previous(faulthandler_log, app_paths.LOG_DIR)
        if saved_crash:
            print(crash_log.describe(saved_crash), file=sys.stderr)
    except Exception:
        traceback.print_exc()
    _faulthandler_file = open(faulthandler_log, "w", encoding="utf-8")
    faulthandler.enable(file=_faulthandler_file)

    # "Прогреваем" SSL/сертификаты Windows на ГЛАВНОМ потоке до того, как
    # какой-либо фоновый QThread впервые тронет ssl/requests. Похоже, что
    # именно самый первый SSL-вызов процесса ронял python.exe с access
    # violation, если происходил в фоновом потоке (см. crash_faulthandler.log
    # — падало внутри ssl_wrap_socket/urllib3 при первом обращении к
    # системному хранилищу сертификатов Windows). Простая синхронная
    # инициализация здесь ничего не решает функционально, только переносит
    # первый "холодный" SSL-вызов туда, где он безопаснее.
    try:
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.load_default_certs()  # именно это реально трогает хранилище сертификатов Windows
    except Exception:
        pass  # прогрев best-effort — если не получилось, ниже всё равно попробуем как раньше

    _set_windows_app_id()
    # Подробный замер нагрузки (каждое событие Qt по классу окна) — только по FX_PERF_DETAIL=1,
    # сам добавляет несколько процентов нагрузки (services/perf_qt.py).
    app_class = QtWidgets.QApplication
    try:
        from services.perf_qt import TimingApplication, detail_enabled
        if detail_enabled():
            app_class = TimingApplication
            print("[нагрузка] подробный режим: замер каждого события Qt", file=sys.stderr)
    except Exception:
        traceback.print_exc()
    app = app_class(sys.argv)
    if app_class is not QtWidgets.QApplication:
        try:                       # и время отрисовки по видам элементов графиков (services/perf_items.py)
            from services import perf_items
            print(f"[нагрузка] подробный режим: замер элементов графиков ({perf_items.install()} методов)",
                  file=sys.stderr)
        except Exception:
            traceback.print_exc()
    app.setWindowIcon(_load_app_icon())
    app.setStyle("Fusion")
    # Первый этап оформления: общая тема FX Terminal в духе Adobe.
    initial_theme = str(QtCore.QSettings("MyTradingTools", "FxTerminal").value("appearance/theme", "dark"))
    app.setStyleSheet(app_stylesheet(initial_theme))
    fx_theme.apply_palette(app, initial_theme)
    apply_app_font_size(app)
    _install_russian_qt(app)
    # На Windows окрашиваем системную шапку верхнеуровневых окон в тёмный teal.
    fx_theme.install_windows_titlebar_color(app)
    window = MainWindow()
    window.show()
    # Сторож зависаний: интерфейс не отвечает 10 с — стеки всех потоков в logs/hang_ГГГГ-ММ-ДД.txt.
    try:
        from services import hang_watch
        hang_watch.install(app_paths.LOG_DIR, parent=window, quiet=not all_logs)
    except Exception:
        traceback.print_exc()
    # Обновления: итог прошлой установки / отката — один раз; проработал STARTUP_OK_SEC — запуск удачный;
    try:
        import updater
        import update_dialog
        QtCore.QTimer.singleShot(1500, lambda: update_dialog.show_last_result(window, ROOT))
        QtCore.QTimer.singleShot(updater.STARTUP_OK_SEC * 1000, lambda: updater.startup_ok(ROOT))
        # через интернет (github.com/golubovskiy/fx-terminal-updates): после запуска и раз в час (2.1.68)
        update_dialog.start_auto_check(window, ROOT)
    except Exception:
        traceback.print_exc()
    exit_code = app.exec()
    _finish_process(window, exit_code)


def _finish_process(window, exit_code: int) -> None:
    """Выход без разрушения Qt-объектов сборщиком мусора Python.

    Все потоки терминал уже остановил в closeEvent. Но если какой-то gRPC-вызов завис и его
    поток не успел закончиться, обычный sys.exit начал бы удалять окна вместе с их QThread —
    Qt на это аварийно завершает процесс («QThread: Destroyed while thread is still running»).
    Поэтому сохраняем настройки, сбрасываем буферы и выходим сразу (os._exit).
    Перед выходом: запуск отмечается удачным (updater.startup_ok); если из «О проекте» выбрана установка
    обновления или откат — запускается updater.py (он дождётся конца этого процесса), иначе при
    _restart_requested — новый экземпляр терминала."""
    try:
        window.settings.sync()
    except Exception:
        pass
    try:
        QtCore.QSettings("MyTradingTools", "FxTerminal").sync()
    except Exception:
        pass
    try:
        import updater
        updater.startup_ok(ROOT)               # штатное закрытие — тоже удачный запуск
    except Exception:
        pass
    update_command = getattr(window, "_update_command", None)
    if update_command:                          # «О проекте» → установка / откат: updater сам запустит терминал
        try:
            import updater
            updater.spawn(update_command, ROOT)
        except Exception:
            traceback.print_exc()
    elif getattr(window, "_restart_requested", False):
        _spawn_new_instance()
    try:
        import logging
        logging.shutdown()
    except Exception:
        pass
    try:
        from services.log_file import drain_console
        drain_console()                         # консоль пишет свой поток — дописать хвост
    except Exception:
        pass
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.flush()
        except Exception:
            pass
    os._exit(int(exit_code or 0))


def _spawn_new_instance() -> None:
    """Запуск нового экземпляра терминала (перезапуск после смены темы). Настройки к этому
    моменту уже сохранены, поэтому новый процесс читает актуальную раскладку."""
    try:
        if getattr(sys, "frozen", False):           # собранный .exe
            program, args = sys.executable, list(sys.argv[1:])
        else:
            program, args = sys.executable, [os.path.abspath(sys.argv[0])] + list(sys.argv[1:])
        QtCore.QProcess.startDetached(program, args, os.getcwd())
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    main()
