# -*- coding: utf-8 -*-
"""Установка обновлений FX Terminal из пакета (zip с manifest.json) — только стандартная библиотека.

Почему отдельная программа: пока терминал запущен, его модули загружены, а модуль Rust (fx_engine) Windows
не даёт перезаписать. Поэтому терминал (меню «О проекте» → «Установить обновление…», update_dialog.py)
только показывает, что поменяется, и закрывается, а этот файл запускается отдельным процессом:

    python updater.py apply ПАКЕТ.zip [ПАКЕТ2.zip …] --wait-pid PID --restart [--keep ФАЙЛ …] [--allow-downgrade]
    python updater.py rollback [--backup ПАПКА] --wait-pid PID --restart
    python updater.py status

Что делает apply:
    1. ждёт, пока терминал (PID) закроется;
    2. проверяет пакет: manifest.json, контрольные суммы, пути (только код и ресурсы, см. allowed_path);
    3. копирует заменяемые и удаляемые файлы в _backup/<версия>_<время>/ (+ backup.json — что было);
    4. раскладывает файлы (запись во временный файл и замена — недописанного файла не бывает);
       файл, который вы правили сами (сумма не совпадает с установленной), заменяется только если в окне
       обновления стояла галочка; без неё ваш файл остаётся, новый ложится рядом как ФАЙЛ.new;
    5. при необходимости — pip install и пересборка fx_engine (manifest: "pip", "build_rust"); перед pip
       запоминается весь список пакетов venv (имя -> версия): pip может заодно обновить и зависимости
       (numpy, protobuf …), и откат возвращает их все — новые удаляет, изменённые ставит прежних версий;
    6. проверки: tests/test_imports.py и тесты из пакета; сбой — сам откатывается из бэкапа;
    7. пишет итог в _install/last_update.json (терминал покажет его при следующем запуске) и запускает
       терминал снова.

Несколько пакетов (2.1.68, обновление через интернет — update_online.py): ставятся по очереди, каждый со своим
бэкапом и проверками; сбой одного — он откатывается, следующие не ставятся, уже поставленные остаются (терминал
на промежуточной версии, рабочей — её проверки прошли). В last_update.json — общий итог.

Данные не трогаются никогда: базы (*.db), журналы (logs/), настройки (*.ini, реестр), рисунки, заметки,
события (*.json) — пакет с такими путями отклоняется целиком.

Собранная программа (exe, 2.1.79, app_paths.py): этот файл лежит в папке app\\ рядом с остальными .py и
запускается через fx_python.exe (Python с консолью из той же сборки); проверки — тоже им, терминал после установки —
FX Terminal.exe. Пакет с pip или пересборкой Rust там не ставится (нет pip, maturin и Rust) — его заменяет новая
версия установщика; журнал установки — в папке журналов данных (%LOCALAPPDATA%\\FX_Terminal\\logs).

_install/installed.json — какие файлы с какими суммами установлены (по нему видно ваши правки);
_install/startup.json — счётчик запусков: терминал, дважды подряд упавший на старте после обновления,
предлагает откат (startup_begin / startup_ok).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

try:                                        # папки и запуск (2.1.79); старой установки без app_paths — по-прежнему
    import app_paths
except Exception:                           # noqa: BLE001
    app_paths = None
FROZEN = bool(getattr(sys, "frozen", False))   # собранная программа: нет pip / maturin
FROZEN_BLOCK = ("пакет меняет библиотеки Python или модуль Rust (pip / пересборка) — в собранной программе так не "
                "обновить: поставьте новую версию установщиком FX_Terminal_Setup")

FORMAT = 1                                  # версия формата manifest.json
MANIFEST = "manifest.json"
INSTALL_DIR = "_install"
BACKUP_DIR = "_backup"
STATE_FILE = "installed.json"
LAST_FILE = "last_update.json"
STARTUP_FILE = "startup.json"
KEEP_BACKUPS = 10                           # столько последних бэкапов храним
CRASH_STARTS = 3                            # третий запуск подряд без «запустился нормально» — предлагаем откат
STARTUP_OK_SEC = 60                         # терминал проработал столько — запуск удачный (gui_app.py)
WAIT_PID_SEC = 120                          # столько ждём закрытия терминала
CHECK_TIMEOUT_SEC = 300                     # одна проверка (тест) — не дольше
DEFAULT_CHECKS = ["tests/test_imports.py"]

# Что может быть в пакете: код и ресурсы. Всё остальное (данные, настройки) — нельзя.
ALLOWED_SUFFIXES = {".py", ".rs", ".toml", ".md", ".wav", ".png", ".ico", ".svg", ".qss"}
ALLOWED_TXT_PREFIXES = ("readme", "requirements")      # .txt — только README*.txt / requirements*.txt
PROTECTED_DIRS = {"logs", BACKUP_DIR, INSTALL_DIR, "venv", ".venv", "env", ".git", "__pycache__", "target",
                  "cache", "data"}


class UpdateError(Exception):
    """Пакет нельзя установить (причина — в тексте)."""


# ------------------------------------------------------------------ мелочи

def parse_version(text: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", str(text or ""))
    return tuple(int(p) for p in parts) or (0,)


def current_version(root: Path) -> str:
    """Версия из version.py — читаем текст, не импортируем (модуль мог быть уже загружен старым)."""
    try:
        text = (Path(root) / "version.py").read_text(encoding="utf-8")
    except OSError:
        return "0"
    m = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', text, re.M)
    return m.group(1) if m else "0"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def allowed_path(rel: str) -> str | None:
    """None — путь можно ставить из пакета; иначе — причина отказа."""
    if not rel or "\\" in rel or rel.startswith("/") or ":" in rel:
        return f"«{rel}»: путь должен быть относительным, через /"
    parts = PurePosixPath(rel).parts
    if any(p in ("", ".", "..") for p in parts):
        return f"«{rel}»: недопустимый путь"
    if parts[0].lower() in PROTECTED_DIRS or any(p.lower() == "__pycache__" for p in parts):
        return f"«{rel}»: папка {parts[0]} — данные терминала, обновление их не трогает"
    name = parts[-1].lower()
    suffix = PurePosixPath(name).suffix
    if suffix == ".txt" and name.startswith(ALLOWED_TXT_PREFIXES):
        return None
    if suffix not in ALLOWED_SUFFIXES:
        return f"«{rel}»: файлы {suffix or 'без расширения'} — данные или настройки, обновление их не трогает"
    return None


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write_json(path: Path, data) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def _write_file(path: Path, data: bytes, tries: int = 20) -> None:
    """Запись во временный файл и замена; файл занят (антивирус, редактор) — повторяем до 10 с."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".fxupd.tmp")
    tmp.write_bytes(data)
    for attempt in range(tries):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == tries - 1:
                tmp.unlink(missing_ok=True)
                raise
            time.sleep(0.5)


# ------------------------------------------------------------------ установленное состояние

def load_state(root: Path) -> dict | None:
    return _read_json(Path(root) / INSTALL_DIR / STATE_FILE)


def save_state(root: Path, state: dict) -> None:
    _write_json(Path(root) / INSTALL_DIR / STATE_FILE, state)


def scan_files(root: Path) -> dict[str, str]:
    """Все файлы терминала, которые может менять обновление: путь -> sha256."""
    root = Path(root)
    found = {}
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root)
        if rel_dir.parts and rel_dir.parts[0].lower() in PROTECTED_DIRS:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames if d.lower() not in PROTECTED_DIRS and not d.startswith(".")]
        for name in filenames:
            rel = (rel_dir / name).as_posix()
            if allowed_path(rel) is None:
                try:
                    found[rel] = sha256_file(Path(dirpath) / name)
                except OSError:
                    pass
    return found


def ensure_baseline(root: Path) -> dict:
    """Нет installed.json (первый запуск с обновлениями) — запомнить файлы как есть: это точка отсчёта,
    от которой видны ваши правки."""
    state = load_state(root)
    if state is None:
        state = {"version": current_version(root), "files": scan_files(root), "baseline": _now()}
        save_state(root, state)
    return state


# ------------------------------------------------------------------ пакет и план

def read_package(zip_path) -> dict:
    """manifest.json пакета, проверенный: формат, версия, суммы и пути всех файлов."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except (OSError, zipfile.BadZipFile) as exc:
        raise UpdateError(f"это не пакет обновления: {exc}")
    with zf:
        try:
            manifest = json.loads(zf.read(MANIFEST).decode("utf-8"))
        except KeyError:
            raise UpdateError("в архиве нет manifest.json — это не пакет обновления (старый zip "
                              "распаковывается вручную)")
        except ValueError as exc:
            raise UpdateError(f"manifest.json повреждён: {exc}")
        if int(manifest.get("format", 0)) > FORMAT:
            raise UpdateError("пакет новее этой программы обновления — сначала поставьте предыдущий пакет")
        if not manifest.get("version") or not isinstance(manifest.get("files"), dict):
            raise UpdateError("в manifest.json нет версии или списка файлов")
        names = set(zf.namelist())
        for rel, info in manifest["files"].items():
            reason = allowed_path(rel)
            if reason:
                raise UpdateError(reason)
            if rel not in names:
                raise UpdateError(f"в архиве нет файла {rel}")
            if sha256_bytes(zf.read(rel)) != info.get("sha256"):
                raise UpdateError(f"файл {rel} повреждён (контрольная сумма не совпала)")
        for rel in manifest.get("delete", []):
            reason = allowed_path(rel)
            if reason:
                raise UpdateError(reason)
    manifest["_zip"] = str(zip_path)
    return manifest


def plan(root: Path, manifest: dict) -> dict:
    """Что сделает установка: какие файлы добавятся / заменятся, какие из них вы правили сами."""
    root = Path(root)
    state = load_state(root) or {"files": {}}
    known = state.get("files", {})
    cur, new = current_version(root), str(manifest["version"])
    files = []
    for rel, info in sorted(manifest["files"].items()):
        path = root / rel
        if not path.exists():
            files.append({"path": rel, "action": "add", "modified": False})
            continue
        local = sha256_file(path)
        if local == info["sha256"]:
            files.append({"path": rel, "action": "same", "modified": False})
            continue
        modified = rel in known and known[rel] != local
        files.append({"path": rel, "action": "replace", "modified": modified, "untracked": rel not in known})
    requires = manifest.get("requires")
    warnings = []
    requires_ok = not requires or parse_version(cur) >= parse_version(requires)
    if not requires_ok:
        warnings.append(f"пакет ставится на версию не ниже {requires}, а у вас {cur} — сначала "
                        "поставьте пропущенные пакеты")
    downgrade = parse_version(new) < parse_version(cur)
    if downgrade:
        warnings.append(f"версия пакета {new} старше установленной {cur}")
    blocked = FROZEN and bool(manifest.get("pip") or manifest.get("build_rust"))
    if blocked:
        warnings.append(FROZEN_BLOCK)
        requires_ok = False                  # кнопка «Установить» не даст поставить то, что не встанет
    deletes = [rel for rel in manifest.get("delete", []) if (root / rel).exists()]
    return {"from": cur, "to": new, "files": files, "delete": deletes, "requires_ok": requires_ok,
            "downgrade": downgrade, "warnings": warnings, "changes": manifest.get("changes", []),
            "pip": manifest.get("pip", []), "build_rust": bool(manifest.get("build_rust"))}


# ------------------------------------------------------------------ установка

def _python() -> list[str]:
    """Чем запускать скрипты (проверки, сам updater): app_paths.python_command — в собранной программе
    fx_python.exe; без app_paths (старая установка) — этот же Python."""
    return app_paths.python_command() if app_paths is not None else [sys.executable]


def _log_dir(root: Path) -> Path:
    """Журнал установки: у установленного терминала — папка журналов данных (app_paths.LOG_DIR; из исходников
    это root/logs, как раньше), у чужой папки (проверки во временной) — её logs."""
    if app_paths is not None and Path(root).resolve() == app_paths.APP_DIR:
        return app_paths.LOG_DIR
    return Path(root) / "logs"


def _log_to(root: Path):
    log_dir = _log_dir(root)
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / f"update_{datetime.now():%Y-%m-%d}.log"

    def log(msg: str) -> None:
        line = f"[{datetime.now():%H:%M:%S}] {msg}"
        print(line, flush=True)
        try:
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except OSError:
            pass
    return log


PIP_SKIP = {"pip", "setuptools", "wheel", "fx_engine", "fx-engine"}   # не из PyPI / сама установка


def _canon(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def pip_snapshot() -> dict[str, str]:
    """Все пакеты venv: имя (нормализованное) -> версия. Без вызова pip — через importlib.metadata."""
    from importlib import metadata
    out = {}
    for dist in metadata.distributions():
        name = dist.metadata.get("Name")
        if name:
            out[_canon(name)] = dist.version
    return out


def pip_restore_plan(before: dict[str, str], after: dict[str, str]) -> tuple[list[str], list[str]]:
    """Что сделать, чтобы из after получить before: (удалить, поставить "имя==версия"). fx_engine, pip,
    setuptools, wheel не трогаем — fx_engine возвращается своим колесом (wheel_before)."""
    skip = {_canon(n) for n in PIP_SKIP}
    remove = sorted(n for n in after if n not in before and n not in skip)
    install = sorted(f"{n}=={v}" for n, v in before.items() if n not in skip and after.get(n) != v)
    return remove, install


def _run(cmd: list[str], cwd: Path, log, timeout: float = 1800) -> None:
    log("  > " + " ".join(str(c) for c in cmd))
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    res = subprocess.run([str(c) for c in cmd], cwd=str(cwd), env=env, capture_output=True, text=True,
                         encoding="utf-8", errors="replace", timeout=timeout)
    tail = (res.stdout + res.stderr).strip().splitlines()[-15:]
    for line in tail:
        log("    " + line)
    if res.returncode != 0:
        raise UpdateError(f"команда завершилась с кодом {res.returncode}: {' '.join(str(c) for c in cmd[:4])}")


def _latest_wheel(root: Path) -> str | None:
    wheels = sorted((Path(root) / "fx_engine_rs" / "target" / "wheels").glob("fx_engine-*.whl"),
                    key=lambda p: p.stat().st_mtime)
    return str(wheels[-1]) if wheels else None


def run_checks(root: Path, tests: list[str], log) -> None:
    """Проверки после установки — каждый тест отдельным процессом (как tests/run_all.py)."""
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "QT_QPA_PLATFORM": "offscreen"}
    for rel in tests:
        path = Path(root) / rel
        if not path.exists():
            continue
        res = subprocess.run([*_python(), str(path)], cwd=str(root), env=env, capture_output=True,
                             text=True, encoding="utf-8", errors="replace", timeout=CHECK_TIMEOUT_SEC)
        lines = [ln for ln in res.stdout.strip().splitlines() if ln.strip()]
        log(f"  {'ok  ' if res.returncode == 0 else 'FAIL'} {rel}: {lines[-1] if lines else '(нет вывода)'}")
        if res.returncode != 0:
            for ln in (res.stdout + res.stderr).strip().splitlines()[-25:]:
                log("    " + ln)
            raise UpdateError(f"проверка {rel} не прошла")


def apply(root: Path, zip_path, keep: set[str] | None = None, allow_downgrade: bool = False,
          checks: bool = True, log=print) -> dict:
    """Установить пакет. keep — правленные вами файлы, которые НЕ заменять (новый ляжет рядом .new).
    -> итог (он же пишется в _install/last_update.json)."""
    root = Path(root)
    keep = set(keep or ())
    manifest = read_package(zip_path)
    ensure_baseline(root)
    p = plan(root, manifest)
    if not p["requires_ok"]:
        raise UpdateError(p["warnings"][0])
    if p["downgrade"] and not allow_downgrade:
        raise UpdateError(p["warnings"][-1])
    log(f"Обновление {p['from']} → {p['to']}: файлов {len(manifest['files'])}, удалить {len(p['delete'])}")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    bdir = root / BACKUP_DIR / f"{p['from']}_{stamp}"
    record = {"from": p["from"], "to": p["to"], "time": _now(), "replaced": [], "added": [], "deleted": [],
              "new_beside": [], "state": load_state(root), "pip_snapshot": None, "wheel_before": None,
              "restored": False}
    result = {"status": "error", "from": p["from"], "to": p["to"], "time": _now(), "backup": str(bdir),
              "kept": [], "message": "", "seen": False}
    started = False
    try:
        with zipfile.ZipFile(manifest["_zip"]) as zf:
            bdir.mkdir(parents=True)
            started = True
            # 1. бэкап всего, что поменяется
            for item in p["files"]:
                if item["action"] == "replace" and item["path"] not in keep:
                    _backup_file(root, bdir, item["path"])
                    record["replaced"].append(item["path"])
            for rel in p["delete"]:
                _backup_file(root, bdir, rel)
                record["deleted"].append(rel)
            _write_json(bdir / "backup.json", record)
            # 2. файлы
            for item in p["files"]:
                rel = item["path"]
                if item["action"] == "same":
                    continue
                data = zf.read(rel)
                if item["action"] == "replace" and rel in keep:
                    _write_file(root / (rel + ".new"), data)
                    record["new_beside"].append(rel + ".new")
                    result["kept"].append(rel)
                    log(f"  оставлен ваш {rel}, новый — рядом: {rel}.new")
                    continue
                _write_file(root / rel, data)
                if item["action"] == "add":
                    record["added"].append(rel)
                log(f"  {'добавлен' if item['action'] == 'add' else 'заменён'} {rel}")
            for rel in p["delete"]:
                (root / rel).unlink(missing_ok=True)
                log(f"  удалён {rel}")
            _write_json(bdir / "backup.json", record)
        # 3. пакеты Python и модуль Rust
        if p["pip"]:
            record["pip_snapshot"] = pip_snapshot()          # весь venv — pip может тронуть и зависимости
            _write_json(bdir / "backup.json", record)
            _run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", *p["pip"]], root, log)
            remove, install = pip_restore_plan(record["pip_snapshot"], pip_snapshot())
            changed = len(remove) + len(install)
            log(f"  pip: изменено пакетов {changed}" + (f" (новые: {', '.join(remove)})" if remove else ""))
        if p["build_rust"]:
            record["wheel_before"] = _latest_wheel(root)
            _write_json(bdir / "backup.json", record)
            log("  пересборка fx_engine (несколько минут)…")
            _run([sys.executable, "-m", "maturin", "build", "--release"], root / "fx_engine_rs", log)
            wheel = _latest_wheel(root)
            if not wheel:
                raise UpdateError("сборка fx_engine не дала файла .whl")
            _run([sys.executable, "-m", "pip", "install", "--force-reinstall", wheel], root, log)
        # 4. проверки
        if checks:
            tests = list(manifest.get("checks") or DEFAULT_CHECKS)
            tests += [rel for rel in manifest["files"] if rel.startswith("tests/test_") and rel not in tests]
            log("Проверки:")
            run_checks(root, tests, log)
        # 5. готово
        state = load_state(root) or {"files": {}}
        files = dict(state.get("files", {}))
        for rel, info in manifest["files"].items():
            if rel not in keep:
                files[rel] = info["sha256"]
        for rel in p["delete"]:
            files.pop(rel, None)
        save_state(root, {"version": p["to"], "files": files, "updated": _now()})
        result.update(status="ok", message=f"Установлена версия {p['to']}"
                      + (f"; ваши файлы оставлены: {', '.join(result['kept'])} (новые — рядом, .new)"
                         if result["kept"] else ""))
        log(result["message"])
        prune_backups(root)
    except Exception as exc:                                         # noqa: BLE001
        reason = str(exc) or type(exc).__name__
        log(f"СБОЙ: {reason}")
        if started:
            try:
                _write_json(bdir / "backup.json", record)
                rollback(root, bdir, log=log)
                result.update(status="rolled_back", message=f"Обновление до {p['to']} не установлено: {reason}. "
                              f"Возвращена версия {p['from']}.")
            except Exception as exc2:                                # noqa: BLE001
                result.update(status="error", message=f"Обновление до {p['to']} не установлено ({reason}), и откат "
                              f"не прошёл: {exc2}. Файлы прошлой версии — в {bdir}")
        else:
            result.update(status="error", message=f"Обновление до {p['to']} не установлено: {reason}")
        log(result["message"])
    _write_json(root / INSTALL_DIR / LAST_FILE, result)
    return result


def apply_chain(root: Path, packages, keep: set[str] | None = None, allow_downgrade: bool = False,
                checks: bool = True, log=print) -> dict:
    """Поставить пакеты по очереди (см. описание файла). -> общий итог (он же в _install/last_update.json)."""
    root = Path(root)
    packages = list(packages)
    done: list[str] = []
    res: dict = {}
    for package in packages:
        try:
            res = apply(root, package, keep=keep, allow_downgrade=allow_downgrade, checks=checks, log=log)
        except UpdateError as exc:
            res = {"status": "error", "time": _now(), "seen": False, "message": f"Обновление не установлено: {exc}"}
            log(res["message"])
        if res.get("status") != "ok":
            break
        done.append(str(res.get("to")))
    if len(packages) > 1:
        if res.get("status") == "ok":
            res = dict(res, message=f"Установлены обновления {', '.join(done)}: теперь версия {done[-1]}"
                       + (f"; {res['message'].split('; ', 1)[1]}" if "; " in res.get("message", "") else ""))
        elif done:
            res = dict(res, message=f"{res.get('message', '')} Перед этим установлены {', '.join(done)} — "
                                    f"терминал на версии {done[-1]}.")
        log(res["message"])
    _write_json(root / INSTALL_DIR / LAST_FILE, res)
    return res


def _backup_file(root: Path, bdir: Path, rel: str) -> None:
    src = root / rel
    if src.exists():
        dst = bdir / "files" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


# ------------------------------------------------------------------ откат и бэкапы

def list_backups(root: Path) -> list[dict]:
    """Бэкапы, новые первыми: {"dir", "from", "to", "time", "restored"}."""
    out = []
    base = Path(root) / BACKUP_DIR
    if not base.exists():
        return out
    for d in base.iterdir():
        rec = _read_json(d / "backup.json") if d.is_dir() else None
        if rec:
            out.append({"dir": str(d), "from": rec.get("from"), "to": rec.get("to"), "time": rec.get("time", ""),
                        "restored": bool(rec.get("restored"))})
    out.sort(key=lambda r: r["time"], reverse=True)
    return out


def rollback(root: Path, backup=None, log=print) -> dict:
    """Вернуть файлы из бэкапа (по умолчанию — последнего ещё не откатанного): заменённые и удалённые
    файлы — обратно, добавленные пакетом — удалить, installed.json — как был; пакеты venv — как в снимке до
    pip install (новые удалить, изменённые — прежних версий; нужен интернет до PyPI), fx_engine — прежнее колесо."""
    root = Path(root)
    if backup is None:
        candidates = [b for b in list_backups(root) if not b["restored"]]
        if not candidates:
            raise UpdateError("нет бэкапа, который можно вернуть")
        backup = candidates[0]["dir"]
    bdir = Path(backup)
    rec = _read_json(bdir / "backup.json")
    if not rec:
        raise UpdateError(f"в {bdir} нет backup.json")
    log(f"Откат {rec.get('to')} → {rec.get('from')} из {bdir.name}")
    for rel in rec.get("added", []):
        (root / rel).unlink(missing_ok=True)
        log(f"  удалён добавленный {rel}")
    for rel in rec.get("new_beside", []):
        (root / rel).unlink(missing_ok=True)
    for rel in rec.get("replaced", []) + rec.get("deleted", []):
        src = bdir / "files" / rel
        if src.exists():
            _write_file(root / rel, src.read_bytes())
            log(f"  возвращён {rel}")
    if rec.get("pip_snapshot"):
        remove, install = pip_restore_plan(rec["pip_snapshot"], pip_snapshot())
        for cmd, items in ((["uninstall", "-y"], remove), (["install", "--no-deps"], install)):
            if not items:
                continue
            try:
                _run([sys.executable, "-m", "pip", *cmd, "--disable-pip-version-check", *items], root, log)
            except Exception as exc:                                 # noqa: BLE001
                log(f"  пакеты Python вернуть не удалось ({exc}) — вручную: pip {' '.join(cmd)} {' '.join(items)}")
    if rec.get("wheel_before"):
        try:
            _run([sys.executable, "-m", "pip", "install", "--force-reinstall", rec["wheel_before"]], root, log)
        except Exception as exc:                                     # noqa: BLE001
            log(f"  прежний fx_engine вернуть не удалось: {exc}")
    if rec.get("state"):
        save_state(root, rec["state"])
    rec["restored"] = True
    _write_json(bdir / "backup.json", rec)
    log(f"Возвращена версия {rec.get('from')}")
    return rec


def prune_backups(root: Path, keep: int = KEEP_BACKUPS) -> None:
    for old in list_backups(root)[keep:]:
        shutil.rmtree(old["dir"], ignore_errors=True)


# ------------------------------------------------------------------ запуск терминала

def take_last_result(root: Path) -> dict | None:
    """Итог последней установки / отката, ещё не показанный пользователю (и пометить показанным)."""
    path = Path(root) / INSTALL_DIR / LAST_FILE
    res = _read_json(path)
    if not res or res.get("seen"):
        return None
    res["seen"] = True
    try:
        _write_json(path, res)
    except OSError:
        pass
    return res


def startup_begin(root: Path) -> dict | None:
    """Вызывается при запуске терминала. Если это уже CRASH_STARTS-й запуск подряд без startup_ok, а версия
    поставлена обновлением, -> {"version", "back_to", "backup"} — предложить откат; иначе None."""
    root = Path(root)
    path = root / INSTALL_DIR / STARTUP_FILE
    version = current_version(root)
    rec = _read_json(path, {}) or {}
    starts = int(rec.get("starts", 0)) + 1 if rec.get("version") == version else 1
    offer = None
    last = _read_json(root / INSTALL_DIR / LAST_FILE, {}) or {}
    if starts >= CRASH_STARTS and last.get("status") == "ok" and last.get("to") == version:
        backups = [b for b in list_backups(root) if not b["restored"] and b["to"] == version]
        if backups:
            offer = {"version": version, "back_to": backups[0]["from"], "backup": backups[0]["dir"]}
            starts = 1                    # не спрашивать при каждом следующем запуске
    try:
        _write_json(path, {"version": version, "starts": starts, "time": _now()})
    except OSError:
        pass
    return offer


def startup_ok(root: Path) -> None:
    """Терминал проработал STARTUP_OK_SEC или закрылся штатно — запуск удачный."""
    try:
        _write_json(Path(root) / INSTALL_DIR / STARTUP_FILE,
                    {"version": current_version(root), "starts": 0, "time": _now()})
    except OSError:
        pass


def wait_pid(pid: int, timeout: float = WAIT_PID_SEC) -> bool:
    """Дождаться завершения процесса. True — завершился."""
    if not pid:
        return True
    deadline = time.monotonic() + timeout
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, int(pid))      # SYNCHRONIZE
        if not handle:
            return True                                                 # процесса уже нет
        try:
            return kernel32.WaitForSingleObject(handle, int(timeout * 1000)) == 0
        finally:
            kernel32.CloseHandle(handle)
    while time.monotonic() < deadline:
        try:
            os.kill(int(pid), 0)
        except OSError:
            return True
        time.sleep(0.3)
    return False


def updater_command(root: Path, action: str, *args: str) -> list[str]:
    """Команда запуска этой программы из терминала (новый процесс после закрытия терминала). В собранной программе
    sys.executable терминала — FX Terminal.exe без консоли, поэтому запуск — через _python (fx_python.exe)."""
    return [*_python(), str(Path(root) / "updater.py"), action, *args, "--wait-pid", str(os.getpid()),
            "--restart"]


def spawn(cmd: list[str], cwd: Path) -> None:
    """Запустить отдельным процессом, не связанным с терминалом (в своём окне консоли на Windows)."""
    flags = 0
    if os.name == "nt":
        flags = subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(cmd, cwd=str(cwd), creationflags=flags, close_fds=True)


def _restart_terminal(root: Path, log) -> None:
    log("Запускаю терминал…")
    if app_paths is not None and Path(root).resolve() == app_paths.APP_DIR:
        cmd = app_paths.gui_command()            # собранная программа — FX Terminal.exe, из исходников — gui_app.py
    else:
        cmd = [sys.executable, str(Path(root) / "gui_app.py")]
    subprocess.Popen(cmd, cwd=str(root))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Обновления FX Terminal")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("apply", help="установить пакет")
    a.add_argument("package", nargs="+", help="пакет(ы); несколько — по очереди (цепочка версий)")
    a.add_argument("--keep", action="append", default=[], help="ваш правленный файл не заменять")
    a.add_argument("--allow-downgrade", action="store_true")
    a.add_argument("--no-checks", action="store_true")
    r = sub.add_parser("rollback", help="вернуть файлы из бэкапа")
    r.add_argument("--backup")
    sub.add_parser("status", help="версия и бэкапы")
    for p in (a, r):
        p.add_argument("--wait-pid", type=int, default=0)
        p.add_argument("--restart", action="store_true")
    args = ap.parse_args(argv)
    root = Path(__file__).resolve().parent
    if args.cmd == "status":
        print(f"FX Terminal {current_version(root)}")
        for b in list_backups(root):
            print(f"  {b['time']}  {b['from']} → {b['to']}{'  (откатан)' if b['restored'] else ''}  {b['dir']}")
        return 0
    log = _log_to(root)
    if args.wait_pid:
        log("Жду закрытия терминала…")
        if not wait_pid(args.wait_pid):
            log("Терминал не закрылся — обновление отменено, файлы не тронуты")
            _write_json(root / INSTALL_DIR / LAST_FILE, {"status": "error", "time": _now(), "seen": False,
                                                         "message": "Терминал не закрылся — обновление отменено"})
            return 1
        time.sleep(1.0)                   # Windows отпускает файлы чуть позже конца процесса
    code = 0
    if args.cmd == "apply":
        res = apply_chain(root, args.package, keep=set(args.keep), allow_downgrade=args.allow_downgrade,
                          checks=not args.no_checks, log=log)
        code = 0 if res["status"] == "ok" else 1
    else:
        try:
            rec = rollback(root, args.backup, log=log)
            res = {"status": "rollback", "time": _now(), "seen": False, "from": rec.get("to"),
                   "to": rec.get("from"), "message": f"Возвращена версия {rec.get('from')}"}
        except Exception as exc:                                     # noqa: BLE001
            res = {"status": "error", "time": _now(), "seen": False, "message": f"Откат не прошёл: {exc}"}
            log(res["message"])
            code = 1
        _write_json(root / INSTALL_DIR / LAST_FILE, res)
    if args.restart:
        _restart_terminal(root, log)
    else:
        time.sleep(2)
    return code


if __name__ == "__main__":
    sys.exit(main())
