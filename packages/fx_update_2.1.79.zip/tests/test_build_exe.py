# -*- coding: utf-8 -*-
"""Подготовка к сборке в exe (2.1.79): папки программы и данных (app_paths), пути данных всех модулей, загрузчик
fx_boot (режим «выполнить скрипт»), установщик обновлений в собранной программе (чем запускать проверки и
терминал, отказ от пакетов с pip / Rust) и tools/build_exe.py без PyInstaller (список файлов, файл сборки,
сценарий установщика). Данные терминала не трогаются: всё во временных папках.
Запуск:  python tests/test_build_exe.py"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import app_paths  # noqa: E402
import updater  # noqa: E402

_spec = importlib.util.spec_from_file_location("build_exe", ROOT / "tools" / "build_exe.py")
build_exe = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(build_exe)
_spec2 = importlib.util.spec_from_file_location("make_update", ROOT / "tools" / "make_update.py")
make_update = importlib.util.module_from_spec(_spec2)
_spec2.loader.exec_module(make_update)

ENV = {**os.environ, "PYTHONIOENCODING": "utf-8", "QT_QPA_PLATFORM": "offscreen"}


def _run(code: str, **env) -> dict:
    """Выполнить код отдельным Python (свои переменные окружения) и вернуть то, что он напечатал JSON-ом."""
    res = subprocess.run([sys.executable, "-c", code], cwd=str(ROOT), env={**ENV, **env}, capture_output=True,
                         text=True, encoding="utf-8", errors="replace", timeout=300)
    assert res.returncode == 0, res.stdout[-2000:] + res.stderr[-3000:]
    return json.loads(res.stdout.strip().splitlines()[-1])


def test_source_install_unchanged():
    """Из исходников всё как раньше: данные рядом с кодом, запуск — этим же Python."""
    assert not app_paths.FROZEN and app_paths.APP_DIR == ROOT
    if not os.environ.get("FX_DATA_DIR"):
        assert app_paths.DATA_DIR == ROOT and app_paths.LOG_DIR == ROOT / "logs"
    assert app_paths.python_command() == [sys.executable]
    assert app_paths.gui_command("--logs") == [sys.executable, str(ROOT / "gui_app.py"), "--logs"]


def test_frozen_layout():
    """Собранная программа: данные — %LOCALAPPDATA%\\FX_Terminal, скрипты — fx_python.exe, окно — FX Terminal.exe."""
    with tempfile.TemporaryDirectory() as tmp:
        prog = Path(tmp) / "FX Terminal"
        code = (
            "import sys, json; sys.frozen = True; "
            f"sys.executable = {str(prog / 'FX Terminal.exe')!r}; "
            "import app_paths as p; "
            "print(json.dumps({'data': str(p.DATA_DIR), 'logs': str(p.LOG_DIR), 'py': p.python_command(), "
            "'gui': p.gui_command('--logs'), 'prog': str(p.program_dir())}))")
        env = {k: v for k, v in ENV.items() if k != "FX_DATA_DIR"}
        res = subprocess.run([sys.executable, "-c", code], cwd=str(ROOT), env={**env, "LOCALAPPDATA": tmp},
                             capture_output=True, text=True, encoding="utf-8", timeout=60)
        assert res.returncode == 0, res.stderr
        got = json.loads(res.stdout.strip())
        assert Path(got["data"]) == Path(tmp) / "FX_Terminal" and Path(got["logs"]) == Path(tmp) / "FX_Terminal" / "logs"
        assert got["py"] == [str(prog / "fx_python.exe")] and Path(got["prog"]) == prog
        assert got["gui"] == [str(prog / "FX Terminal.exe"), "--logs"]


def test_data_paths_follow_data_dir():
    """Все файлы данных модулей — в папке данных (FX_DATA_DIR), не рядом с кодом."""
    with tempfile.TemporaryDirectory() as tmp:
        code = r'''
import json, sys
from PySide6 import QtWidgets
app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
import candle_cache, quotes_tab, order_flow, chart_drawings_store, note_images, options_common
import options_chain_chart_widget, mm_summary, connection_diagnostics, cny_forward_monitor_v2_5
from services import algo_shadow, rust_book_shadow
paths = {
    "cache": candle_cache.DB_PATH, "events": quotes_tab.EVENTS_FILE, "events_old": quotes_tab.EVENTS_LEGACY_FILE,
    "mm_logs": quotes_tab.MM_LOG_DIR, "bars": order_flow.BARS_FILE, "minutes": order_flow.MINUTES_FILE,
    "drawings": chart_drawings_store.DRAWINGS_FILE, "images": note_images.IMAGES_DIR,
    "options": options_common.BASE_DIR, "options_db": options_chain_chart_widget.DB_FILE,
    "mm_summary": mm_summary.LOG_DIR, "diag": connection_diagnostics.LOG_DIR,
    "forward": cny_forward_monitor_v2_5.CSV_PATH, "shadow": algo_shadow.LOG_DIR, "book": rust_book_shadow.LOG_FOLDER,
}
print(json.dumps({k: str(v) for k, v in paths.items()}))
'''
        env = {k: v for k, v in ENV.items() if k not in ("FX_DRAWINGS_FILE", "FX_NOTES_IMAGES_DIR")}
        res = subprocess.run([sys.executable, "-c", code], cwd=str(ROOT), env={**env, "FX_DATA_DIR": tmp},
                             capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        assert res.returncode == 0, res.stderr[-3000:]
        got = json.loads(res.stdout.strip().splitlines()[-1])
        outside = {k: v for k, v in got.items() if not Path(v).is_relative_to(Path(tmp))}
        assert not outside, f"не в папке данных: {outside}"


def test_no_new_data_paths_next_to_code():
    """Новые файлы данных — только через app_paths: Path(__file__) остаётся лишь там, где речь о самой программе
    (ресурсы, папка установки обновлений)."""
    allowed = {"app_paths.py", "app_common.py", "gui_app.py", "update_dialog.py", "updater.py", "fx_boot.py"}
    found = []
    files = build_exe.app_files(ROOT)
    stray = set(build_exe.untracked(ROOT, files))          # свои файлы вне репозитория — не наша забота
    for rel in [f for f in files if f not in stray]:
        if not rel.endswith(".py") or rel.startswith("tests/") or Path(rel).name in allowed:
            continue
        for n, line in enumerate((ROOT / rel).read_text(encoding="utf-8").splitlines(), 1):
            code = line.split("#", 1)[0]
            if re.search(r"Path\(__file__\)", code) and ("logs" in code or re.search(r"\.(db|json|jsonl|csv)", code)):
                found.append(f"{rel}:{n}: {line.strip()}")
    assert not found, "данные рядом с кодом:\n" + "\n".join(found)


def test_boot_runs_scripts():
    """fx_boot СКРИПТ.py аргументы — как «python СКРИПТ.py»: __main__, argv, папка скрипта в пути, код возврата."""
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "probe.py"
        (Path(tmp) / "helper_mod.py").write_text("VALUE = 7\n", encoding="utf-8")
        script.write_text("import sys, json, helper_mod, app_paths\n"
                          "print(json.dumps({'name': __name__, 'argv': sys.argv[1:], 'v': helper_mod.VALUE}))\n"
                          "sys.exit(3)\n", encoding="utf-8")
        res = subprocess.run([sys.executable, str(ROOT / "fx_boot.py"), str(script), "a", "b c"], cwd=tmp, env=ENV,
                             capture_output=True, text=True, encoding="utf-8", timeout=60)
        assert res.returncode == 3, (res.returncode, res.stderr)
        got = json.loads(res.stdout.strip())
        assert got == {"name": "__main__", "argv": ["a", "b c"], "v": 7}


VERSION_PY = 'VERSION = "2.0.0"\nBUILD_DATE = "2026-11-16"\n\nCHANGES: list[tuple[str, str, list[str]]] = [\n]\n'


def test_frozen_updater_refuses_pip_and_rust():
    """Собранная программа: пакет с пересборкой Rust или pip не ставится (нет maturin / pip), файлы не тронуты;
    обычный пакет ставится как всегда."""
    root = Path(tempfile.mkdtemp(prefix="fx_frozen_"))
    src = Path(tempfile.mkdtemp(prefix="fx_src_"))
    saved = updater.FROZEN
    try:
        (root / "version.py").write_text(VERSION_PY, encoding="utf-8")
        (root / "a.py").write_text("A = 1\n", encoding="utf-8")
        updater.ensure_baseline(root)
        for rel, text in {"version.py": VERSION_PY, "a.py": "A = 2\n"}.items():
            (src / rel).write_text(text, encoding="utf-8")
        rust = make_update.build(src, "2.0.1", ["a.py"], ["с Rust"], src, build_rust=True)
        updater.FROZEN = True
        plan = updater.plan(root, updater.read_package(rust))
        assert not plan["requires_ok"] and updater.FROZEN_BLOCK in plan["warnings"]
        res = updater.apply_chain(root, [rust], checks=False, log=lambda *_: None)
        assert res["status"] == "error" and "установщиком" in res["message"], res
        assert (root / "a.py").read_text(encoding="utf-8") == "A = 1\n"
        plain = make_update.build(src, "2.0.2", ["a.py"], ["обычный"], src)
        res = updater.apply_chain(root, [plain], checks=False, log=lambda *_: None)
        assert res["status"] == "ok" and (root / "a.py").read_text(encoding="utf-8") == "A = 2\n", res
    finally:
        updater.FROZEN = saved
        shutil.rmtree(root, ignore_errors=True)
        shutil.rmtree(src, ignore_errors=True)


def test_updater_uses_app_paths():
    """Проверки, сам updater и перезапуск — через app_paths (в собранной программе это fx_python.exe и
    FX Terminal.exe, а не sys.executable окна); журнал установки — в папке журналов данных."""
    saved = updater.app_paths

    class Fake:
        APP_DIR = ROOT
        LOG_DIR = Path(tempfile.gettempdir()) / "fx_logs_probe"

        @staticmethod
        def python_command():
            return ["X:/fx_python.exe"]

        @staticmethod
        def gui_command(*args):
            return ["X:/FX Terminal.exe", *args]

    try:
        updater.app_paths = Fake
        assert updater.updater_command(ROOT, "apply", "p.zip")[:2] == ["X:/fx_python.exe", str(ROOT / "updater.py")]
        assert updater._log_dir(ROOT) == Fake.LOG_DIR
        other = Path(tempfile.gettempdir())
        assert updater._log_dir(other) == other / "logs"                  # чужая папка (проверки) — её logs
        launched = []
        real_popen = updater.subprocess.Popen
        updater.subprocess.Popen = lambda cmd, cwd=None, **kw: launched.append(cmd)
        try:
            updater._restart_terminal(ROOT, lambda *_: None)
        finally:
            updater.subprocess.Popen = real_popen
        assert launched == [["X:/FX Terminal.exe"]]
    finally:
        updater.app_paths = saved


def test_build_script_without_pyinstaller():
    files = build_exe.app_files(ROOT)
    for need in ("app_paths.py", "fx_boot.py", "gui_app.py", "updater.py", "version.py", "brokers/finam/live.py",
                 "services/__init__.py", "tests/test_imports.py", "Sound/FX_Robot.wav"):
        assert need in files, need
    assert not [f for f in files if f.startswith(("tools/", "fx_engine_rs/", "venv/")) or "__pycache__" in f]
    assert build_exe.app_files(ROOT, ("gui_app.py",)).count("gui_app.py") == 0          # --exclude
    names = build_exe.module_names(["a.py", "brokers/__init__.py", "brokers/finam/live.py", "tests/test_x.py",
                                    "fx_boot.py", "Sound/x.wav"])
    assert names == ["a", "brokers", "brokers.finam.live", "test_x"]
    spec = build_exe.spec_text(ROOT, build_exe.module_names(files), build_exe.third_party_dirs(), ROOT / "fx_terminal.ico")
    compile(spec, "fx_terminal.spec", "exec")
    for need in ("fx_boot.py", "a.pure = [entry for entry in a.pure if not _is_app(entry)]", "console=False",
                 "console=True", "'fx_python'", "'FX Terminal'", "'quotes_tab'", "'PySide6QtAds'", "'fx_engine'"):
        assert need in spec, need
    iss = build_exe.iss_text("2.1.79", Path("C:/b/dist/FX Terminal"), Path("C:/b"), None)
    for need in ("AppId={{CA7B0AEE-", "PrivilegesRequired=lowest", "{localappdata}\\Programs\\FX Terminal",
                 "Russian.isl", "OutputBaseFilename=FX_Terminal_Setup_2.1.79", 'Name: "{app}\\app"',
                 'WorkingDir: "{app}\\app"'):
        assert need in iss, need
    assert build_exe.read_version(ROOT) == re.search(r'VERSION = "([^"]+)"', (ROOT / "version.py").read_text(encoding="utf-8")).group(1)


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
