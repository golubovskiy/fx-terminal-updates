# -*- coding: utf-8 -*-
"""Обновления (updater.py, tools/make_update.py): пакет, установка с бэкапом, ваши правки, откат при
сбое проверок, ручной откат, защита от падений после обновления. Всё во временной папке, без Qt и сети.
Запуск:  python tests/test_updater.py"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import updater  # noqa: E402

_spec = importlib.util.spec_from_file_location("make_update", ROOT / "tools" / "make_update.py")
make_update = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(make_update)

VERSION_PY = '''VERSION = "2.0.0"
BUILD_DATE = "2026-10-31"

CHANGES: list[tuple[str, str, list[str]]] = [
    ("2.0.0", "2026-10-31", ["первая"]),
]
'''


def make_root() -> Path:
    """Терминал в миниатюре: version.py, два модуля, данные (база, журнал, настройки)."""
    root = Path(tempfile.mkdtemp(prefix="fx_upd_"))
    (root / "version.py").write_text(VERSION_PY, encoding="utf-8")
    (root / "a.py").write_text("A = 1\n", encoding="utf-8")
    (root / "b.py").write_text("B = 1\n", encoding="utf-8")
    (root / "options_history.db").write_bytes(b"DATA")
    (root / "logs").mkdir()
    (root / "logs" / "fx.log").write_text("log", encoding="utf-8")
    (root / "chart_drawings.json").write_text("{}", encoding="utf-8")
    updater.ensure_baseline(root)
    return root


def package(root: Path, version: str, files: dict[str, str], **kw) -> Path:
    """Собрать пакет из «исходников» во второй папке (как у разработчика) — version.py поднимется там."""
    src = Path(tempfile.mkdtemp(prefix="fx_src_"))
    shutil.copy2(root / "version.py", src / "version.py")
    for rel, text in files.items():
        (src / rel).parent.mkdir(parents=True, exist_ok=True)
        (src / rel).write_text(text, encoding="utf-8")
    return make_update.build(src, version, list(files), [f"изменения {version}"], src, **kw)


def quiet(*_a, **_k):
    pass


def test_allowed_paths():
    for ok in ("a.py", "brokers/finam/gateway.py", "tests/test_x.py", "Sound/FX_Open.wav", "README.txt",
               "fx_engine_rs/src/book.rs", "fx_engine_rs/Cargo.toml"):
        assert updater.allowed_path(ok) is None, ok
    for bad in ("options_history.db", "chart_drawings.json", "settings.ini", "notes.txt", "logs/x.py",
                "_backup/a.py", "../a.py", "/a.py", "C:/a.py", "a\\b.py", "venv/x.py", "__pycache__/a.py"):
        assert updater.allowed_path(bad), bad


def test_install_and_rollback():
    root = make_root()
    pkg = package(root, "2.0.1", {"a.py": "A = 2\n", "c.py": "C = 1\n"})
    res = updater.apply(root, pkg, log=quiet)
    assert res["status"] == "ok", res
    assert (root / "a.py").read_text() == "A = 2\n" and (root / "c.py").exists()
    assert updater.current_version(root) == "2.0.1"
    assert '("2.0.1"' in (root / "version.py").read_text(encoding="utf-8")
    assert (root / "options_history.db").read_bytes() == b"DATA"          # данные не тронуты
    assert updater.load_state(root)["version"] == "2.0.1"
    backups = updater.list_backups(root)
    assert len(backups) == 1 and backups[0]["from"] == "2.0.0" and backups[0]["to"] == "2.0.1"
    last = updater.take_last_result(root)
    assert last and last["status"] == "ok" and updater.take_last_result(root) is None   # показывается один раз
    # повторная установка того же — нечего менять
    p = updater.plan(root, updater.read_package(pkg))
    assert all(f["action"] == "same" for f in p["files"]), p
    # ручной откат
    updater.rollback(root, log=quiet)
    assert (root / "a.py").read_text() == "A = 1\n" and not (root / "c.py").exists()
    assert updater.current_version(root) == "2.0.0" and updater.load_state(root)["version"] == "2.0.0"
    assert updater.list_backups(root)[0]["restored"] is True
    shutil.rmtree(root, ignore_errors=True)


def test_user_edits_kept_or_replaced():
    """b.py вы правили сами: без галочки — ваш остаётся, новый ложится рядом .new."""
    root = make_root()
    (root / "b.py").write_text("B = 'моя правка'\n", encoding="utf-8")
    pkg = package(root, "2.0.1", {"a.py": "A = 2\n", "b.py": "B = 2\n"})
    p = updater.plan(root, updater.read_package(pkg))
    mods = {f["path"]: f["modified"] for f in p["files"]}
    assert mods == {"a.py": False, "b.py": True, "version.py": False}, p
    res = updater.apply(root, pkg, keep={"b.py"}, log=quiet)
    assert res["status"] == "ok" and res["kept"] == ["b.py"], res
    assert (root / "b.py").read_text(encoding="utf-8") == "B = 'моя правка'\n"
    assert (root / "b.py.new").read_text() == "B = 2\n"
    shutil.rmtree(root, ignore_errors=True)


def test_failed_check_rolls_back():
    """Проверка из пакета упала — всё вернулось как было, итог «rolled_back»."""
    root = make_root()
    pkg = package(root, "2.0.1", {"a.py": "A = 2\n", "c.py": "C = 1\n",
                                  "tests/test_new.py": "import sys\nprint('сломано')\nsys.exit(1)\n"})
    res = updater.apply(root, pkg, log=quiet)
    assert res["status"] == "rolled_back", res
    assert (root / "a.py").read_text() == "A = 1\n"
    assert not (root / "c.py").exists() and not (root / "tests" / "test_new.py").exists()
    assert updater.current_version(root) == "2.0.0" and updater.load_state(root)["version"] == "2.0.0"
    assert json.loads((root / "_install" / "last_update.json").read_text(encoding="utf-8"))["status"] == "rolled_back"
    shutil.rmtree(root, ignore_errors=True)


def test_bad_packages_refused():
    root = make_root()
    # подмена файла в архиве — сумма не совпала
    pkg = package(root, "2.0.1", {"a.py": "A = 2\n"})
    broken = pkg.with_name("broken.zip")
    with zipfile.ZipFile(pkg) as src, zipfile.ZipFile(broken, "w") as dst:
        for name in src.namelist():
            dst.writestr(name, b"A = 666\n" if name == "a.py" else src.read(name))
    for bad, why in ((broken, "повреждён"),):
        try:
            updater.read_package(bad)
        except updater.UpdateError as exc:
            assert why in str(exc), exc
        else:
            raise AssertionError("пакет принят")
    # данные в пакете
    evil = pkg.with_name("evil.zip")
    manifest = {"format": 1, "version": "2.0.1", "files": {"options_history.db": {"sha256": updater.sha256_bytes(b"x")}}}
    with zipfile.ZipFile(evil, "w") as zf:
        zf.writestr("manifest.json", json.dumps(manifest))
        zf.writestr("options_history.db", b"x")
    try:
        updater.read_package(evil)
    except updater.UpdateError as exc:
        assert "данные" in str(exc) or "не трогает" in str(exc), exc
    else:
        raise AssertionError("пакет с базой принят")
    # обычный zip без manifest.json
    plain = pkg.with_name("plain.zip")
    with zipfile.ZipFile(plain, "w") as zf:
        zf.writestr("a.py", "A = 3\n")
    try:
        updater.read_package(plain)
    except updater.UpdateError as exc:
        assert "manifest" in str(exc)
    else:
        raise AssertionError("zip без manifest принят")
    # пропущенная версия и откат на старую — без разрешения не ставятся
    needs = package(root, "2.0.5", {"a.py": "A = 5\n"}, requires="2.0.4")
    try:
        updater.apply(root, needs, log=quiet)
    except updater.UpdateError as exc:
        assert "не ниже 2.0.4" in str(exc), exc
    else:
        raise AssertionError("пакет поставлен через пропущенную версию")
    old_root = make_root()
    updater.apply(old_root, package(old_root, "2.0.3", {"a.py": "A = 3\n"}), log=quiet)
    older = package(old_root, "2.0.2", {"a.py": "A = 2\n"}, bump=False)
    try:
        updater.apply(old_root, older, log=quiet)
    except updater.UpdateError as exc:
        assert "старше" in str(exc)
    else:
        raise AssertionError("старая версия поставлена без разрешения")
    shutil.rmtree(root, ignore_errors=True)
    shutil.rmtree(old_root, ignore_errors=True)


def test_crash_loop_offers_rollback():
    """После обновления терминал не дожил до startup_ok два запуска подряд — на третьем предложить откат."""
    root = make_root()
    updater.apply(root, package(root, "2.0.1", {"a.py": "A = 2\n"}), log=quiet)
    assert updater.startup_begin(root) is None                  # 1-й запуск — упал
    assert updater.startup_begin(root) is None                  # 2-й — упал
    offer = updater.startup_begin(root)                         # 3-й — предложить
    assert offer and offer["version"] == "2.0.1" and offer["back_to"] == "2.0.0", offer
    assert updater.startup_begin(root) is None                  # отказались — не спрашивать сразу снова
    updater.startup_ok(root)
    for _ in range(2):
        assert updater.startup_begin(root) is None
        updater.startup_ok(root)                                # нормальные запуски — тишина
    shutil.rmtree(root, ignore_errors=True)


def test_pip_restore_plan():
    """pip install пакета заодно обновил зависимость и поставил новую — откат вернёт обе, fx_engine не трогает."""
    before = {"pandas": "2.2.3", "numpy": "2.1.0", "fx-engine": "0.2.1", "pip": "24.0"}
    after = {"pandas": "2.2.3", "numpy": "2.2.1", "tzdata": "2025.1", "fx-engine": "0.2.2", "pip": "25.0"}
    remove, install = updater.pip_restore_plan(before, after)
    assert remove == ["tzdata"] and install == ["numpy==2.1.0"], (remove, install)
    snap = updater.pip_snapshot()
    assert snap and all(k == k.lower() and "_" not in k for k in snap), list(snap)[:5]


def test_baseline_ignores_data():
    root = make_root()
    files = updater.load_state(root)["files"]
    assert set(files) == {"version.py", "a.py", "b.py"}, files
    shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            import traceback
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed} из {len(tests)} проверок прошли")
    sys.exit(1 if failed else 0)
