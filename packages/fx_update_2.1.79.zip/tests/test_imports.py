# -*- coding: utf-8 -*-
"""Проверка, что все модули терминала импортируются (нет циклов импорта, ошибок уровня модуля,
потерянных имён после разделения gui_app.py). Окна не создаются, к Finam не подключается.
Запуск из папки терминала:  python tests/test_imports.py"""
from __future__ import annotations

import importlib
import os
import sys
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")      # без окон на экране

MODULES = [
    "app_common", "settings_dialog", "data_workers", "chart_items", "chart_drawings_store", "drawings_sync", "sync_page", "chart_panel", "main_window",
    "gui_app", "events_journal", "data_status_window", "scalper_widget", "quotes_tab", "order_flow",
    "tick_bars_item", "tick_volume_window", "tick_volume_manager", "services.rust_book_shadow", "open_interest_tab", "cny_forward_tab",
    "options_chain_chart_widget", "options_tab", "options_vol_view",
    "brokers.finam.gateway", "brokers.finam.raw_book", "brokers.finam.live", "brokers.finam.shared_client", "brokers.paper",
    "services.market_data_hub", "services.qt_dispatch", "services.log_file", "services.log_mode", "ed25519_lite", "update_online", "services.live_guard",
    "services.perf", "services.perf_qt", "services.hang_watch", "services.crash_log", "services.pg_tweaks", "hotkeys", "connection_diagnostics", "hour_notes", "flow_notes", "notes_sync", "chart_trades", "toolbar_drum", "note_images", "chart_snapshot", "chart_pen", "notes_meta", "trade_notes", "notify_merge", "robot_notes", "iceberg_kind",
    "appearance", "appearance_pages", "account_core", "account_window", "option_levels",
    "mm_detector", "escalation_detector", "algo_core", "services.algo_shadow", "mm_marks", "algo_icons", "robot_core", "robot_rust", "spread_core", "spread_rust", "iceberg_core", "iceberg_rust", "conn_frame", "button_feedback", "mm_summary", "atr_core", "atr_window", "version", "app_paths", "fx_boot", "updater", "update_dialog", "options_gex_view", "chart_overlay", "chart_fib_dialog",
]


if __name__ == "__main__":
    from PySide6 import QtWidgets
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])   # некоторым модулям нужен Qt
    failed = 0
    for name in MODULES:
        try:
            importlib.import_module(name)
            print(f"ok    {name}")
        except Exception as exc:                                     # noqa: BLE001
            failed += 1
            print(f"FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"\n{len(MODULES) - failed} из {len(MODULES)} проверок прошли")
    sys.exit(1 if failed else 0)
