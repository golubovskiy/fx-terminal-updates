# -*- coding: utf-8 -*-
"""Картинки заметок: снимки графика и картинки из буфера обмена (PNG, средствами Qt — без доп. пакетов).

Где лежат: папка notes_images рядом с терминалом (C:\\FX_Terminal\\notes_images), файл — «<случайный id>.png».
Заметка хранит только имена файлов: note["images"] = ["3f9c…e1.png", …]. Имя случайное и не меняется,
поэтому файл никогда не перезаписывается — синхронизации (notes_sync.py) достаточно докачать
недостающие и отправить новые; удалённую заметку — удалить и её картинки.

Имена из чужих данных (сервер, другой терминал) проверяются valid_name: только «hex.png», без папок —
файл не может оказаться вне notes_images.
"""
from __future__ import annotations

import os
import re
import uuid
from pathlib import Path

import app_paths
IMAGES_DIR = Path(os.environ.get("FX_NOTES_IMAGES_DIR") or app_paths.DATA_DIR / "notes_images")
REMOTE_DIR = "notes_images"                # подпапка на WebDAV-сервере (в папке синхронизации)
_NAME_RE = re.compile(r"^[0-9a-f]{12,32}\.png$")


def valid_name(name) -> bool:
    return isinstance(name, str) and bool(_NAME_RE.match(name))


def path_of(name: str) -> Path:
    if not valid_name(name):
        raise ValueError(f"недопустимое имя картинки: {name!r}")
    return IMAGES_DIR / name


def exists(name: str) -> bool:
    return valid_name(name) and path_of(name).is_file()


def images_of(note: dict) -> list[str]:
    """Картинки заметки (только допустимые имена, без повторов, по порядку)."""
    out = []
    for name in note.get("images") or []:
        if valid_name(name) and name not in out:
            out.append(name)
    return out


def new_name() -> str:
    return uuid.uuid4().hex + ".png"


def save_bytes(data: bytes, name: str | None = None) -> str:
    """PNG-байты -> файл в IMAGES_DIR (атомарно). Возвращает имя."""
    name = name or new_name()
    path = path_of(name)
    IMAGES_DIR.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)
    return name


def save_image(image) -> str | None:
    """QPixmap / QImage -> PNG в IMAGES_DIR. Возвращает имя или None (картинка пустая / не записалась)."""
    if image is None or image.isNull():
        return None
    from PySide6 import QtCore
    buf = QtCore.QBuffer()
    buf.open(QtCore.QIODevice.OpenModeFlag.WriteOnly)
    if not image.save(buf, "PNG"):
        return None
    return save_bytes(bytes(buf.data()))


def delete(names) -> None:
    for name in names:
        try:
            if valid_name(name):
                path_of(name).unlink(missing_ok=True)
        except OSError:
            pass
