"""
Order Flow — вкладка "Покупка/Продажа" в FX Terminal.

Порт функционала buy_sell_volume Lua-скрипта для QUIK на Finam Trade API:
скользящий объём агрессивных покупок/продаж за 5, 15 и 30 минут по нескольким
инструментам, с индикатором баланса покупатель/продавец.

Откуда сделки: MarketDataHub (services/market_data_hub.py) — одна подписка у брокера
на инструмент, переподключение и отсев повторов по trade_id делает FinamGateway.
Без шлюза (не запустился) сделок нет — таблица пустая, ГО и ролловер работают.
Сторона сделки (side) приходит готовым полем — правило сравнения с bid/ask не нужно
(в QUIK-версии её давали биты flags в OnAllTrade).

Инструменты: постоянные (вечные фьючерсы и спот CNY) + текущие квартальные Si/Eu/CR.
Квартальные выбираются RolloverWorker по настоящей дате экспирации из GetAsset
по единому правилу терминала (contracts.py) и меняются при ролловере сами.

Как считаются деньги сделки (переключатель «Фьючерсы» в окне, QSettings order_flow/futures_full):
    * по ГО (по умолчанию): ГО на лот (GetAssetParams) × лоты — сколько денег заблокировано;
    * по полной стоимости: цена × лоты × множитель контракта (сколько стоит сам контракт:
      Si — цена в рублях за 1000 $, множитель 1; CR — рубли за 1 юань, контракт 1000 юаней,
      множитель 1000; USDRUBF / EURRUBF / CNYRUBF — 1000; см. brokers/finam/gateway.py).
    Для TOM/TOD — всегда фактический оборот (цена × лоты × 1000), переключатель их не меняет.
Каждая сделка запоминается сразу в обоих видах, поэтому переключение мгновенное и не теряет историю.

График баланса (покупки − продажи) — отдельная панель OrderFlowChartPanel («График баланса ↗»
во вкладке): её можно вынести в отдельное окно, таймфрейм 1 м … 1 д. Зелёный столбик вверх — перевес
покупок, красный вниз — продаж. По X — только торговое время (trading_slots): ночь, выходные и перерывы
между сессиями схлопнуты, граница сессии — пунктир. Свечи собираются из минут (MinuteStore,
order_flow_minutes.jsonl, 14 дней; копятся с 30.10); для 30 м и крупнее история до этого — из прежних
получасов (BarStore, order_flow_bars.json, 48 ч). Получасы копятся с запуска
терминала и сохраняются в order_flow_bars.json рядом с терминалом (BAR_KEEP_SEC — 48 ч),
поэтому перезапуск днём не стирает график. Столбик — сумма по всем инструментам окна.

Кнопка «Заметка» появляется, когда минуты копятся без перерыва 5 часов: итоги за 5 ч по всем инструментам —
в окно «Заметки», коротко в «Подробности», полная сводка (по инструментам и по часам) — в «Комментарий»
(расчёт и текст — flow_notes.py).
"""

import json
import random
import sys
import time
import traceback
from collections import deque
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)

import pyqtgraph as pg
from PySide6 import QtCore, QtGui, QtWidgets

from finam_sdk_client import FinamStreamClient
import contracts
import flow_notes
import hour_notes
from finam_terminal import (
    INSTRUMENTS,
    is_currency_futures_ticker,
)

WINDOW_5M_SEC = 300
WINDOW_15M_SEC = 900
WINDOW_30M_SEC = 1800

REFRESH_MS = 1000

BAR_SEC = 1800                      # один столбик графика — 30 минут
BAR_KEEP_SEC = 48 * 3600            # сколько получасов хранить (и в файле)
BAR_SAVE_MS = 60_000                # как часто сохранять получасы в файл
BARS_FILE = app_paths.DATA_DIR / "order_flow_bars.json"
# Минуты для графика баланса с выбором таймфрейма (MinuteStore): из минут собирается любой ТФ от 1 м до 1 д.
MINUTE_SEC = 60
MINUTE_KEEP_SEC = 14 * 86400        # сколько дней минут хранить
MINUTES_FILE = app_paths.DATA_DIR / "order_flow_minutes.jsonl"
CHART_TF_KEY = "order_flow/chart_tf"              # QSettings: таймфрейм графика баланса, секунды
CHART_TFS = ((60, "1м"), (300, "5м"), (900, "15м"), (1800, "30м"), (3600, "1ч"), (14400, "4ч"), (86400, "1д"))
FUTURES_FULL_KEY = "order_flow/futures_full"      # QSettings: True — фьючерсы по полной стоимости
SPLITTER_KEY = "order_flow/splitter"              # QSettings: была граница таблица / график (график — панель с 30.10)

# Повтор запроса ГО при неудаче — 5, 10, 20, 40, 60 … с (+ до 20 % случайной добавки,
# чтобы запросы всех инструментов не стучались в сервер разом).
RETRY_FIRST_SEC = 5
RETRY_MAX_SEC = 60


def _retry_delay_ms(attempt: int) -> int:
    base = min(RETRY_MAX_SEC, RETRY_FIRST_SEC * (2 ** max(0, attempt - 1)))
    return int(base * (1.0 + random.uniform(0.0, 0.2)) * 1000)


def _short_error(exc) -> str:
    """Одна строка вместо traceback: «UNAVAILABLE: Socket closed» и т. п."""
    code = getattr(exc, "code", None)
    details = getattr(exc, "details", None)
    try:
        if callable(code) and callable(details):
            name = getattr(code(), "name", str(code()))
            return f"{name}: {details() or ''}".strip().rstrip(":")
    except Exception:
        pass
    lines = str(exc).strip().splitlines()
    return f"{type(exc).__name__}: {lines[0] if lines else ''}".strip().rstrip(":")
GAUGE_BAR_LEN = 16

# За сколько дней до фактической экспирации перестаём
# отслеживать квартальный контракт.
ROLL_DAYS_BEFORE_EXPIRY = contracts.ROLL_DAYS   # единое правило терминала (contracts.py)

# Квартальные валютные фьючерсы Finam.
#
# ВАЖНО:
# Si = USD/RUB
# Eu = EUR/RUB
# CR = CNY/RUB
#
# CR, а не CN.
CURRENCY_FUTURES_BASES = {"SI", "EU", "CR"}

# "Вечные" валютные инструменты.
_PERPETUAL_SYMBOLS = [
    s
    for s in INSTRUMENTS
    if s.startswith(("USD", "EUR", "CNY"))
]

ORDER_FLOW_SYMBOLS = list(_PERPETUAL_SYMBOLS)

# Инструменты, для которых Order Flow считает
# фактический рублёвый оборот, а не ГО-поток.
NOMINAL_FLOW_SYMBOLS = {
    "CNYRUB_TOM@MISX",
    "CNY000000TOD@MISX",
}


def _is_quarterly_currency_symbol(symbol: str) -> bool:
    """
    Проверяет, является ли symbol квартальным валютным фьючерсом
    Si / Eu / CR на RTSX.

    Примеры:
        SiZ6@RTSX -> True
        EuH7@RTSX -> True
        CRZ6@RTSX -> True

    Постоянные:
        USDRUBF@RTSX -> False
        EURRUBF@RTSX -> False
        CNYRUBF@RTSX -> False
    """
    if not symbol:
        return False

    if "@RTSX" not in symbol.upper():
        return False

    ticker = symbol.split("@", 1)[0].upper()

    if not ticker.startswith(tuple(CURRENCY_FUTURES_BASES)):
        return False

    # Квартальный ticker имеет базу + месяц + код года.
    #
    # SiZ6
    # EuH7
    # CRZ6
    #
    # Проверяем именно известные месяцы квартального цикла:
    # H = март
    # M = июнь
    # U = сентябрь
    # Z = декабрь
    if len(ticker) < 3:
        return False

    month_code = ticker[-2]

    return month_code in {"H", "M", "U", "Z"}


def _parse_expiration(asset: dict) -> datetime | None:
    """
    Извлекает фактическое время экспирации из GetAsset().

    Ожидаемый Finam ответ:

        "future_details": {
            "expiration_date": "2026-12-16T21:00:00Z"
        }

    Возвращает timezone-aware datetime в UTC.
    """
    future_details = asset.get("future_details") or {}

    value = future_details.get("expiration_date")

    if not value:
        return None

    if isinstance(value, dict):
        # На случай другой формы protobuf.
        year = value.get("year")
        month = value.get("month")
        day = value.get("day")

        if year and month and day:
            return datetime(
                int(year),
                int(month),
                int(day),
                tzinfo=timezone.utc,
            )

        return None

    value = str(value).strip()

    if not value:
        return None

    try:
        # 2026-12-16T21:00:00Z
        return datetime.fromisoformat(
            value.replace("Z", "+00:00")
        ).astimezone(timezone.utc)

    except ValueError:
        print(
            f"[order-flow] Не удалось разобрать expiration_date: "
            f"{value!r}",
            file=sys.stderr,
        )
        return None


def _asset_expiration_date(asset: dict) -> datetime | None:
    """
    Возвращает точную дату/время экспирации из GetAsset().
    """
    return _parse_expiration(asset)


def resolve_quarterly_symbols(
    client: FinamStreamClient,
    assets: list[dict],
    now: datetime | None = None,
) -> list[str]:
    """
    Определяет актуальные квартальные валютные фьючерсы.

    Алгоритм:

    1. Берём активные инструменты из Assets().
    2. Оставляем только Si / Eu / CR квартальные контракты.
    3. Для каждого кандидата вызываем GetAsset().
    4. Получаем точную future_details.expiration_date.
    5. Контракты, до экспирации которых осталось <= 3 дней,
       исключаем.
    6. Для каждого базиса оставляем ближайший актуальный контракт.

    В результате:

        Si -> ближайший актуальный Si
        Eu -> ближайший актуальный Eu
        CR -> ближайший актуальный CR
    """
    if now is None:
        now = datetime.now(timezone.utc)

    candidates: list[tuple[datetime, str]] = []

    for asset in assets:
        symbol = str(asset.get("symbol") or "").strip()

        if not symbol:
            continue

        if asset.get("is_archived"):
            continue

        if not _is_quarterly_currency_symbol(symbol):
            continue

        try:
            details = client.get_asset(symbol)
        except Exception:
            print(
                f"[order-flow] GetAsset не удалось получить для "
                f"{symbol}:",
                file=sys.stderr,
            )
            traceback.print_exc()
            continue

        expiry = _asset_expiration_date(details)
        if expiry is not None:
            contracts.register_expiration(symbol, expiry)   # настоящая дата — для всех окон

        if expiry is None:
            print(
                f"[order-flow] Нет даты экспирации у {symbol}",
                file=sys.stderr,
            )
            continue

        days_left = (expiry - now).total_seconds() / 86400.0

        print(
            f"[order-flow] {symbol}: "
            f"expiration={expiry.isoformat()}, "
            f"осталось={days_left:.2f} дн.",
            file=sys.stderr,
        )

        # Единое правило: переход за ROLL_DAYS дней до экспирации по московской дате
        # (так же решают график, «Открытый интерес» и «Опционы»).
        if not contracts.is_current(symbol):
            continue

        candidates.append((expiry, symbol))

    # Сначала сортировка по реальной дате экспирации.
    candidates.sort(key=lambda x: x[0])

    # Для каждого базиса берём только ближайший контракт.
    result: list[str] = []
    seen_bases: set[str] = set()

    for expiry, symbol in candidates:
        ticker = symbol.split("@", 1)[0].upper()

        if ticker.startswith("SI"):
            base = "SI"
        elif ticker.startswith("EU"):
            base = "EU"
        elif ticker.startswith("CR"):
            base = "CR"
        else:
            continue

        if base in seen_bases:
            continue

        seen_bases.add(base)
        result.append(symbol)

    result.sort()

    return result

# --------------------------------------------------------------------------
# Чистая логика (без Qt) — скользящее окно и gauge-индикатор
# --------------------------------------------------------------------------

def gauge_bar(buy: float, sell: float) -> tuple[str, str]:
    """Порт gaugeBar() из Lua. Возвращает (текст полосы, "buy"/"sell"/"neutral")."""
    total = buy + sell
    if total <= 1:
        return "." * GAUGE_BAR_LEN + " нет сделок", "neutral"

    buy_pct = buy / total
    buy_blocks = round(buy_pct * GAUGE_BAR_LEN)
    buy_blocks = max(0, min(GAUGE_BAR_LEN, buy_blocks))
    sell_blocks = GAUGE_BAR_LEN - buy_blocks
    bar = "#" * buy_blocks + "-" * sell_blocks

    if buy_pct > 0.55:
        return f"{bar} ПОКУПАТЕЛЬ {round(buy_pct * 100)}%", "buy"
    if buy_pct < 0.45:
        return f"{bar} ПРОДАВЕЦ {round((1 - buy_pct) * 100)}%", "sell"
    return f"{bar} РАВНОВЕСИЕ", "neutral"


class RollingWindow:
    """
    Копит сделки по одному инструменту:
    (время, деньги по ГО, деньги по полной стоимости, сторона).

    Считает объём покупок/продаж за последние:
    - 5 минут
    - 15 минут
    - 30 минут
    — по ГО или по полной стоимости (windows(full=...)).

    Старые записи за пределами 30 минут удаляются.
    """

    def __init__(self):
        self._trades: deque[tuple[float, float, float, bool]] = deque()
        # (ts, go_rub, full_rub, is_sell)

    def add_trade(
        self,
        go_rub: float,
        is_sell: bool,
        ts: float | None = None,
        full_rub: float | None = None,
    ) -> None:
        ts = ts if ts is not None else time.time()
        self._trades.append((ts, go_rub, go_rub if full_rub is None else full_rub, is_sell))
        self._prune(ts)

    def _prune(self, now: float) -> None:
        cutoff = now - WINDOW_30M_SEC

        while self._trades and self._trades[0][0] < cutoff:
            self._trades.popleft()

    def windows(self, now: float | None = None, full: bool = False):
        now = now if now is not None else time.time()

        buy_5m = sell_5m = 0.0
        buy_15m = sell_15m = 0.0
        buy_30m = sell_30m = 0.0

        for ts, go_value, full_value, is_sell in self._trades:
            go_rub = full_value if full else go_value
            age = now - ts

            if age <= WINDOW_30M_SEC:
                if is_sell:
                    sell_30m += go_rub
                else:
                    buy_30m += go_rub

            if age <= WINDOW_15M_SEC:
                if is_sell:
                    sell_15m += go_rub
                else:
                    buy_15m += go_rub

            if age <= WINDOW_5M_SEC:
                if is_sell:
                    sell_5m += go_rub
                else:
                    buy_5m += go_rub

        return (
            buy_5m,
            sell_5m,
            buy_15m,
            sell_15m,
            buy_30m,
            sell_30m,
        )


class BarStore:
    """Баланс по получасам: {инструмент: {начало получаса (UTC, с): [покупки ГО, продажи ГО,
    покупки полн., продажи полн.]}}. Хранит BAR_KEEP_SEC, сохраняется в BARS_FILE (JSON)."""

    def __init__(self, path: Path | None = BARS_FILE):
        self.path = path
        self.data: dict[str, dict[int, list[float]]] = {}
        self.dirty = False
        self.version = 0                  # растёт при каждом изменении (кэш графика баланса)

    @staticmethod
    def start_of(ts: float) -> int:
        return int(ts // BAR_SEC) * BAR_SEC

    def add(self, symbol: str, ts: float, go_rub: float, full_rub: float, is_sell: bool) -> None:
        cell = self.data.setdefault(symbol, {}).setdefault(self.start_of(ts), [0.0, 0.0, 0.0, 0.0])
        cell[1 if is_sell else 0] += go_rub
        cell[3 if is_sell else 2] += full_rub
        self.dirty = True
        self.version += 1

    def prune(self, now: float | None = None) -> None:
        cutoff = (now if now is not None else time.time()) - BAR_KEEP_SEC
        for symbol in list(self.data):
            bars = {k: v for k, v in self.data[symbol].items() if k >= cutoff}
            if bars:
                self.data[symbol] = bars
            else:
                self.data.pop(symbol)

    def series(self, symbol: str | None, full: bool) -> list[tuple[int, float, float]]:
        """[(начало получаса, покупки, продажи)] по возрастанию; symbol None — сумма всех."""
        b, s = (2, 3) if full else (0, 1)
        total: dict[int, list[float]] = {}
        for sym, bars in self.data.items():
            if symbol is not None and sym != symbol:
                continue
            for start, cell in bars.items():
                acc = total.setdefault(start, [0.0, 0.0])
                acc[0] += cell[b]
                acc[1] += cell[s]
        return [(start, acc[0], acc[1]) for start, acc in sorted(total.items())]

    def load(self) -> None:
        if self.path is None or not self.path.is_file():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self.data = {sym: {int(k): [float(x) for x in v][:4] for k, v in bars.items() if len(v) >= 4}
                         for sym, bars in raw.get("bars", {}).items()}
            self.prune()
        except Exception as exc:
            print(f"[order-flow] {self.path.name} не прочитан: {type(exc).__name__}: {exc}", file=sys.stderr)
            self.data = {}

    def clear(self) -> None:
        """Кнопка «Сбросить график»: забыть все получасы и сразу записать пустой файл
        (иначе после перезапуска старые получасы вернулись бы из BARS_FILE)."""
        self.data = {}
        self.dirty = True
        self.version += 1
        self.save()

    def save(self) -> None:
        if self.path is None or not self.dirty:
            return
        self.prune()
        try:
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"bar_sec": BAR_SEC, "bars": self.data}), encoding="utf-8")
            tmp.replace(self.path)
            self.dirty = False
        except OSError as exc:
            print(f"[order-flow] {self.path.name} не сохранён: {exc}", file=sys.stderr)


class MinuteStore:
    """Покупки и продажи по минутам: {начало минуты (UTC, с): {инструмент: [покупки ГО, продажи ГО,
    покупки полн., продажи полн.]}}. Хранит MINUTE_KEEP_SEC. Из минут график баланса собирает любой таймфрейм
    (series), а получасы BarStore остаются для истории до начала минут.

    Файл — дозаписью (JSON Lines, строка = минута со всеми инструментами), как журнал уведомлений
    (events_journal.py): раз в BAR_SAVE_MS дописываются только изменившиеся минуты. Сделка может прийти
    с опозданием (лента Finam отстаёт до ~2 мин) и изменить уже записанную минуту — тогда минута
    дописывается ещё раз, при чтении побеждает последняя строка. Целиком файл переписывается, когда строк
    стало вдвое больше, чем минут."""

    def __init__(self, path: Path | None = MINUTES_FILE):
        self.path = path
        self.data: dict[int, dict[str, list[float]]] = {}
        self._dirty: set[int] = set()
        self.lines = 0
        self.version = 0                  # растёт при каждом изменении (кэш графика баланса)

    @staticmethod
    def start_of(ts: float) -> int:
        return int(ts // MINUTE_SEC) * MINUTE_SEC

    def add(self, symbol: str, ts: float, go_rub: float, full_rub: float, is_sell: bool) -> None:
        minute = self.start_of(ts)
        cell = self.data.setdefault(minute, {}).setdefault(symbol, [0.0, 0.0, 0.0, 0.0])
        cell[1 if is_sell else 0] += go_rub
        cell[3 if is_sell else 2] += full_rub
        self._dirty.add(minute)
        self.version += 1

    def first_minute(self) -> int | None:
        return min(self.data) if self.data else None

    def prune(self, now: float | None = None) -> None:
        cutoff = (now if now is not None else time.time()) - MINUTE_KEEP_SEC
        for minute in [m for m in self.data if m < cutoff]:
            self.data.pop(minute, None)
            self._dirty.discard(minute)
            self.version += 1

    def series(self, tf: int, full: bool, tz_offset: int = 0) -> list[tuple[int, float, float]]:
        """[(начало свечи UTC, покупки, продажи)] по возрастанию, сумма всех инструментов. Свечи — по
        местному времени (tz_offset — сдвиг часового пояса, с): у 1д граница — местная полночь."""
        b, s = (2, 3) if full else (0, 1)
        total: dict[int, list[float]] = {}
        for minute, cells in self.data.items():
            start = bucket_start(minute, tf, tz_offset)
            acc = total.setdefault(start, [0.0, 0.0])
            for cell in cells.values():
                acc[0] += cell[b]
                acc[1] += cell[s]
        return [(start, acc[0], acc[1]) for start, acc in sorted(total.items())]

    @staticmethod
    def _line(minute: int, cells: dict) -> str:
        return json.dumps({"t": minute, "c": cells}, separators=(",", ":")) + "\n"

    def load(self) -> None:
        if self.path is None or not self.path.is_file():
            return
        clean = True
        try:
            raw = self.path.read_bytes()
        except OSError as exc:
            print(f"[order-flow] {self.path.name} не прочитан: {exc}", file=sys.stderr)
            return
        lines = 0
        for line in raw.split(b"\n"):
            if not line.strip():
                continue
            lines += 1
            try:
                row = json.loads(line.decode("utf-8"))
                self.data[int(row["t"])] = {str(k): [float(x) for x in v][:4] for k, v in row["c"].items()
                                            if len(v) >= 4}
            except (ValueError, KeyError, TypeError, AttributeError, UnicodeDecodeError):
                clean = False                    # оборванная строка (терминал закрыли во время записи)
        if raw and not raw.endswith(b"\n"):
            clean = False
        self.lines = lines
        before = len(self.data)
        self.prune()
        if not clean or len(self.data) < before or self.lines > 2 * max(1, len(self.data)):
            self._rewrite()

    def save(self) -> None:
        if self.path is None or not self._dirty:
            return
        self.prune()
        if self.lines + len(self._dirty) > 2 * max(1000, len(self.data)):
            self._rewrite()
            return
        dirty, self._dirty = sorted(self._dirty), set()
        data = "".join(self._line(m, self.data[m]) for m in dirty if m in self.data)
        try:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(data)
            self.lines += len(dirty)
        except OSError as exc:
            self._dirty.update(dirty)
            print(f"[order-flow] {self.path.name} не сохранён: {exc}", file=sys.stderr)

    def _rewrite(self) -> None:
        if self.path is None:
            return
        tmp = self.path.with_name(self.path.name + ".tmp")
        try:
            tmp.write_text("".join(self._line(m, self.data[m]) for m in sorted(self.data)), encoding="utf-8")
            tmp.replace(self.path)
            self.lines = len(self.data)
            self._dirty = set()
        except OSError as exc:
            print(f"[order-flow] {self.path.name} не сохранён: {exc}", file=sys.stderr)

    def clear(self) -> None:
        self.data = {}
        self._dirty = set()
        self.version += 1
        self._rewrite()


def bucket_start(ts: float, tf: int, tz_offset: int = 0) -> int:
    """Начало свечи таймфрейма tf (с), в которую попадает момент ts (UTC, с); свечи выровнены по местному
    времени (tz_offset — сдвиг часового пояса от UTC, с): 1ч — по часам, 4ч — 00/04/08…, 1д — по полуночи."""
    ts = int(ts)
    return ts - ((ts + tz_offset) % tf)


def flow_series(minutes: MinuteStore, halves: "BarStore", tf: int, full: bool,
                tz_offset: int = 0) -> list[tuple[int, float, float]]:
    """Баланс по свечам таймфрейма tf: из минут; для времени ДО первой минуты (минуты копятся с 30.10) —
    из старых получасов BarStore, если таймфрейм кратен получасу (у 1–15 м прошлой истории нет)."""
    total: dict[int, list[float]] = {}
    for start, buy, sell in minutes.series(tf, full, tz_offset):
        total[start] = [buy, sell]
    first = minutes.first_minute()
    if tf % BAR_SEC == 0:
        for start, buy, sell in halves.series(None, full):
            if first is not None and start + BAR_SEC > first:
                continue                          # этот получас уже есть в минутах
            acc = total.setdefault(bucket_start(start, tf, tz_offset), [0.0, 0.0])
            acc[0] += buy
            acc[1] += sell
    return [(start, acc[0], acc[1]) for start, acc in sorted(total.items())]


def full_value_multiplier(symbol: str) -> float | None:
    """Рублей на 1,0 цены по одному лоту — для «полной стоимости» сделки (цена × лоты × множитель).
    Те же правила, что у шлюза (brokers/finam/gateway.py), без запроса к брокеру."""
    try:
        from brokers.finam.gateway import CURRENCY_SPOT_LOT, FUTURES_MULTIPLIER_BY_BASE, PERPETUAL_MULTIPLIER
    except Exception:
        return None
    ticker = symbol.split("@", 1)[0].upper()
    if symbol in NOMINAL_FLOW_SYMBOLS:
        return float(CURRENCY_SPOT_LOT)
    if ticker in PERPETUAL_MULTIPLIER:
        return float(PERPETUAL_MULTIPLIER[ticker])
    if _is_quarterly_currency_symbol(symbol):
        value = FUTURES_MULTIPLIER_BY_BASE.get(ticker[:2])
        return float(value) if value is not None else None
    return None


def go_flow(initial_margin: float, size_lots: float) -> float:
    """
    ГО-поток сделки в RUB.

    initial_margin — ГО на 1 торговый лот,
    size_lots — количество лотов в сделке.
    """
    return initial_margin * size_lots

def nominal_flow(
    trade: dict,
) -> tuple[float, bool] | None:
    """
    Фактический рублёвый оборот сделки.

    Для TOM/TOD:
        цена × количество лотов
    """

    price = _unwrap_decimal(
        trade.get("price")
    )

    size = _unwrap_decimal(
        trade.get("size")
    )

    side = str(
        trade.get("side", "")
    ).upper()

    try:
        price = float(price)
        size = float(size)
    except (TypeError, ValueError):
        return None

    if price <= 0 or size <= 0:
        return None

    if "SELL" in side:
        is_sell = True
    elif "BUY" in side:
        is_sell = False
    else:
        return None

    LOT_SIZE = 1000

    return price * size * LOT_SIZE, is_sell

def _unwrap_decimal(value):
    if isinstance(value, dict):
        return value.get("value", value)
    return value

def _money_to_float(value) -> float | None:
    """
    Finam MoneyValue:
    {'currency_code': 'RUB', 'units': '1145', 'nanos': 790000000}
    -> 1145.79
    """
    if not isinstance(value, dict):
        return None

    try:
        units = float(value.get("units", 0))
        nanos = float(value.get("nanos", 0))
        return units + nanos / 1_000_000_000
    except (TypeError, ValueError):
        return None

def parse_trade(
    trade: dict,
    initial_margin: float,
) -> tuple[float, bool] | None:
    """
    Достаёт (ГО-поток, is_sell) из сделки.

    ГО-поток = initial_margin × количество лотов.
    """
    size = _unwrap_decimal(trade.get("size"))
    side = str(trade.get("side", "")).upper()

    try:
        size = float(size)
    except (TypeError, ValueError):
        return None

    if size <= 0 or initial_margin <= 0:
        return None

    if "SELL" in side:
        is_sell = True
    elif "BUY" in side:
        is_sell = False
    else:
        return None

    return go_flow(initial_margin, size), is_sell


# --------------------------------------------------------------------------
# Qt-воркер rollover.
#
# ВАЖНО:
# GetAsset() и Assets() могут выполнять сетевые gRPC-запросы.
# Поэтому rollover НИКОГДА не выполняем в GUI-потоке.
# --------------------------------------------------------------------------


class RolloverWorker(QtCore.QObject):
    """
    Фоновая проверка квартальных валютных фьючерсов.

    Делает:
        Assets()
        ↓
        определение Si/Eu/CR кандидатов
        ↓
        GetAsset() для каждого кандидата
        ↓
        получение точной expiration_date
        ↓
        определение актуальных контрактов
    """

    finished = QtCore.Signal(list)
    error = QtCore.Signal(str)

    def __init__(self, client: FinamStreamClient):
        super().__init__()
        self.client = client

    @QtCore.Slot()
    def run(self) -> None:
        try:
            assets = self.client.list_assets()

            symbols = resolve_quarterly_symbols(
                self.client,
                assets,
            )

            print(
                "[order-flow] Актуальные квартальные фьючерсы: "
                f"{symbols}",
                file=sys.stderr,
            )

            self.finished.emit(symbols)

        except Exception:
            self.error.emit(traceback.format_exc())

# --------------------------------------------------------------------------
# Контроллер: на инструмент — подписка на сделки в хабе
# --------------------------------------------------------------------------

class OrderFlowController(QtCore.QObject):
    """
    Контроллер Order Flow. start(client, hub): сделки — из MarketDataHub, client —
    справочник (ГО, экспирации для ролловера).

    Постоянные инструменты:
        USDRUBF@RTSX
        EURRUBF@RTSX
        CNYRUBF@RTSX
        CNYRUB_TOM@MISX
        CNY000000TOD@MISX

    Квартальные:
        Si...
        Eu...
        CR...

    Квартальные инструменты определяются автоматически через:

        Assets()
            ↓
        GetAsset()
            ↓
        future_details.expiration_date

    Rollover:
        - один раз сразу после запуска;
        - затем один раз в начале торговой сессии EARLY_TRADING;
        - старый контракт удаляется;
        - новый контракт добавляется.
    """

    # Проверяем не чаще одного раза в день.
    #
    # Это не polling rollover.
    # Таймер используется только как механизм ожидания следующей
    # рассчитанной EARLY_TRADING-сессии.
    ROLLOVER_FALLBACK_MS = 60 * 60 * 1000

    def __init__(
        self,
        symbols: list[str],
        parent=None,
    ):
        super().__init__(parent)

        self.symbols = list(symbols)

        self.windows: dict[str, RollingWindow] = {
            s: RollingWindow()
            for s in self.symbols
        }
        
        # ГО на один торговый лот:
        # symbol -> (LONG ГО, SHORT ГО)
        self._initial_margin: dict[
            str,
            tuple[float, float],
        ] = {}
        
        # Как считать фьючерсы в таблице и на графике: False — по ГО, True — по полной стоимости.
        # Сделки хранятся в обоих видах, переключение (set_full_value) мгновенное.
        self.full_value = str(QtCore.QSettings("MyTradingTools", "FxTerminal")
                              .value(FUTURES_FULL_KEY, "false")).lower() in ("true", "1")

        # Баланс по получасам для графика — копится и сохраняется в BARS_FILE.
        self.bars = BarStore()
        self.bars.load()
        # Минуты — для графика баланса с выбором таймфрейма (MinuteStore, MINUTES_FILE).
        self.minutes = MinuteStore()
        self.minutes.load()
        self._bars_timer = QtCore.QTimer(self)
        self._bars_timer.timeout.connect(self.save_bars)
        self._bars_timer.start(BAR_SAVE_MS)

        # Повтор запроса ГО: номер попытки (пауза 5 → 60 с) и таймеры на инструмент.
        self._attempts: dict[str, int] = {}
        self._retry_timers: dict[str, QtCore.QTimer] = {}

        # Сделки из MarketDataHub — переподключение и отсев повторов делает шлюз.
        self._hub = None
        self._hub_subs: dict[str, object] = {}


        # Клиент сохраняем для rollover.
        self._client: FinamStreamClient | None = None

        # Только квартальные символы.
        self._quarterly_symbols: set[str] = set()

        # Worker rollover.
        self._rollover_thread: QtCore.QThread | None = None
        self._rollover_worker: RolloverWorker | None = None

        # Одноразовый таймер до следующего rollover.
        self._rollover_timer = QtCore.QTimer(self)
        self._rollover_timer.setSingleShot(True)
        self._rollover_timer.timeout.connect(
            self._run_rollover_check
        )

    # ------------------------------------------------------------------
    # START
    # ------------------------------------------------------------------

    def start(self, client: FinamStreamClient, hub=None) -> None:
        """
        Запуск Order Flow.

        Сначала:
            1. останавливаем старые потоки;
            2. сохраняем client;
            3. запускаем постоянные инструменты;
            4. сразу запускаем rollover check.

        Это важно: программа не ждёт начала следующей торговой
        сессии, чтобы определить актуальные Si/Eu/CR.
        """

        self.stop()

        self._client = client
        self._hub = hub

        # Постоянные инструменты.
        for i, symbol in enumerate(self.symbols):
            QtCore.QTimer.singleShot(
                i * 150,
                lambda s=symbol: self._start_one(
                    client,
                    s,
                ),
            )

        # Сразу определяем актуальные квартальные контракты.
        QtCore.QTimer.singleShot(
            max(500, len(self.symbols) * 150 + 500),
            self._run_rollover_check,
        )

    # ------------------------------------------------------------------
    # ADD SYMBOLS
    # ------------------------------------------------------------------

    def add_symbols(
        self,
        client: FinamStreamClient,
        symbols: list[str],
    ) -> None:
        """
        Добавить новые инструменты к уже работающему Order Flow.

        Этот метод оставляем для совместимости с существующим gui_app.py.
        """

        new_symbols = [
            s
            for s in symbols
            if s not in self.windows
        ]

        if not new_symbols:
            return

        for symbol in new_symbols:
            self.windows[symbol] = RollingWindow()
            self.symbols.append(symbol)

        for i, symbol in enumerate(new_symbols):
            QtCore.QTimer.singleShot(
                i * 150,
                lambda s=symbol: self._start_one(
                    client,
                    s,
                ),
            )

    # ------------------------------------------------------------------
    # REMOVE SYMBOLS
    # ------------------------------------------------------------------

    def remove_symbols(
        self,
        symbols: list[str] | set[str],
    ) -> None:
        """
        Удалить инструменты из Order Flow.

        Используется rollover-механизмом.
        """

        for symbol in list(symbols):
            sub = self._hub_subs.pop(symbol, None)
            if sub is not None:
                sub.close()
            self._cancel_retry(symbol)
            self._attempts.pop(symbol, None)

            self.windows.pop(symbol, None)
            self._initial_margin.pop(symbol, None)

            try:
                self.symbols.remove(symbol)
            except ValueError:
                pass

    # ------------------------------------------------------------------
    # START ONE TRADE STREAM
    # ------------------------------------------------------------------

    def _start_one(
        self,
        client: FinamStreamClient,
        symbol: str,
    ) -> None:
        """
        Получить ГО для инструмента (один раз, потом из памяти) и подписаться на сделки в хабе.
        """

        if symbol in self._hub_subs:
            return

        # --------------------------------------------------------------
        # Получаем ГО только для инструментов, которые
        # считаются через ГО.
        #
        # TOM/TOD считаются по фактическому обороту
        # и GetAssetParams() для них не нужен.
        # --------------------------------------------------------------

        if symbol not in NOMINAL_FLOW_SYMBOLS and symbol not in self._initial_margin:
            try:
                params = client.get_asset_params(symbol)

                long_margin = _money_to_float(
                    params.get("long_initial_margin")
                )

                short_margin = _money_to_float(
                    params.get("short_initial_margin")
                )

                if long_margin is None or long_margin <= 0:
                    raise RuntimeError(
                        f"{symbol}: некорректный long_initial_margin: "
                        f"{params.get('long_initial_margin')!r}"
                    )

                if short_margin is None or short_margin <= 0:
                    raise RuntimeError(
                        f"{symbol}: некорректный short_initial_margin: "
                        f"{params.get('short_initial_margin')!r}"
                    )

                self._initial_margin[symbol] = (
                    long_margin,
                    short_margin,
                )

                print(
                    f"[order-flow] {symbol}: "
                    f"ГО LONG={long_margin:.2f} RUB/лот, "
                    f"SHORT={short_margin:.2f} RUB/лот",
                    file=sys.stderr,
                )

            except Exception:
                self._attempts[symbol] = self._attempts.get(symbol, 0) + 1
                delay = _retry_delay_ms(self._attempts[symbol])
                print(
                    f"[order-flow] {symbol}: не удалось получить ГО: "
                    f"{_short_error(sys.exc_info()[1])} — повтор через {delay // 1000} с",
                    file=sys.stderr,
                )
                self._schedule_retry(symbol, delay)
                return

        # --------------------------------------------------------------
        # Подписка на сделки в хабе
        # --------------------------------------------------------------

        if self._hub is None:
            return                               # шлюз не запустился — сделок нет
        from core.models import InstrumentId
        self._hub_subs[symbol] = self._hub.subscribe_trades(
            InstrumentId.parse(symbol),
            lambda trade, s=symbol: self._on_hub_trade(s, trade),
        )

    # ------------------------------------------------------------------
    # ПОВТОР ЗАПРОСА ГО
    # ------------------------------------------------------------------

    def _schedule_retry(self, symbol: str, delay_ms: int) -> None:
        timer = self._retry_timers.get(symbol)
        if timer is None:
            timer = QtCore.QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(lambda s=symbol: self._retry(s))
            self._retry_timers[symbol] = timer
        timer.start(delay_ms)

    def _cancel_retry(self, symbol: str) -> None:
        timer = self._retry_timers.pop(symbol, None)
        if timer is not None:
            timer.stop()
            timer.deleteLater()

    def _retry(self, symbol: str) -> None:
        if self._client is None or symbol not in self.windows:
            return
        self._start_one(self._client, symbol)

    # ------------------------------------------------------------------
    # ROLLOVER
    # ------------------------------------------------------------------

    def _run_rollover_check(self) -> None:
        """
        Запустить фоновую проверку rollover.

        Никаких сетевых вызовов в GUI-потоке.
        """

        if self._client is None:
            return

        # Если предыдущая проверка ещё идёт — не запускаем вторую.
        if (
            self._rollover_thread is not None
            and self._rollover_thread.isRunning()
        ):
            return

        thread = QtCore.QThread(self)

        worker = RolloverWorker(
            self._client
        )

        worker.moveToThread(thread)

        thread.started.connect(
            worker.run
        )

        worker.finished.connect(
            self._on_rollover_finished
        )

        worker.error.connect(
            self._on_rollover_error
        )

        worker.finished.connect(
            thread.quit
        )

        worker.error.connect(
            thread.quit
        )

        thread.finished.connect(
            worker.deleteLater
        )

        thread.finished.connect(
            self._on_rollover_thread_finished
        )

        self._rollover_thread = thread
        self._rollover_worker = worker

        print(
            "[order-flow] Запускаем rollover check...",
            file=sys.stderr,
        )

        thread.start()

    @QtCore.Slot(list)
    def _on_rollover_finished(
        self,
        new_symbols: list[str],
    ) -> None:
        """
        Применить новый набор квартальных контрактов.
        """

        new_set = set(new_symbols)

        old_set = set(
            self._quarterly_symbols
        )

        added = sorted(
            new_set - old_set
        )

        removed = sorted(
            old_set - new_set
        )

        if added:
            print(
                "[order-flow] Добавляем квартальные: "
                f"{added}",
                file=sys.stderr,
            )

        if removed:
            print(
                "[order-flow] Удаляем квартальные: "
                f"{removed}",
                file=sys.stderr,
            )

        # Сначала запускаем новые.
        if self._client is not None and added:
            self.add_symbols(
                self._client,
                added,
            )

        # Затем удаляем старые.
        if removed:
            self.remove_symbols(
                removed,
            )

        self._quarterly_symbols = new_set

        if not added and not removed:
            print(
                "[order-flow] Rollover: изменений нет",
                file=sys.stderr,
            )

        # После проверки рассчитываем следующую EARLY_TRADING.
        self._schedule_next_rollover()

    @QtCore.Slot(str)
    def _on_rollover_error(
        self,
        message: str,
    ) -> None:
        print(
            "[order-flow] Ошибка rollover:\n"
            + message,
            file=sys.stderr,
        )

        # Даже при ошибке не оставляем rollover без следующей попытки.
        self._schedule_rollover_fallback()

    @QtCore.Slot()
    def _on_rollover_thread_finished(
        self,
    ) -> None:
        self._rollover_thread = None
        self._rollover_worker = None

    # ------------------------------------------------------------------
    # NEXT EARLY TRADING
    # ------------------------------------------------------------------

    def _schedule_next_rollover(self) -> None:
        """
        Определить следующую EARLY_TRADING через Schedule().

        Schedule() вызывается в отдельном Qt-потоке через маленький
        фоновый worker, чтобы GUI никогда не блокировался.
        """

        if self._client is None:
            return

        # Для определения расписания используем любой известный
        # квартальный контракт.
        #
        # Если квартальных пока нет, берём активный кандидат из Assets.
        symbol = (
            sorted(self._quarterly_symbols)[0]
            if self._quarterly_symbols
            else None
        )

        if symbol is None:
            self._schedule_rollover_fallback()
            return

        QtCore.QTimer.singleShot(
            100,
            lambda s=symbol: self._load_schedule_for_rollover(s),
        )

    def _load_schedule_for_rollover(
        self,
        symbol: str,
    ) -> None:
        """
        Получить Schedule в отдельном потоке.
        """

        if self._client is None:
            return

        class ScheduleWorker(QtCore.QObject):
            finished = QtCore.Signal(dict)
            error = QtCore.Signal(str)

            def __init__(
                self,
                client,
                symbol,
            ):
                super().__init__()
                self.client = client
                self.symbol = symbol

            @QtCore.Slot()
            def run(self):
                try:
                    data = self.client.get_schedule(
                        self.symbol
                    )
                    self.finished.emit(data)
                except Exception:
                    self.error.emit(
                        traceback.format_exc()
                    )

        thread = QtCore.QThread(self)

        worker = ScheduleWorker(
            self._client,
            symbol,
        )

        worker.moveToThread(thread)

        thread.started.connect(
            worker.run
        )

        worker.finished.connect(
            self._on_schedule_received
        )

        worker.error.connect(
            self._on_schedule_error
        )

        worker.finished.connect(
            thread.quit
        )

        worker.error.connect(
            thread.quit
        )

        thread.finished.connect(
            worker.deleteLater
        )

        # Храним ссылки, чтобы Python не уничтожил объекты
        # раньше времени.
        if not hasattr(self, "_schedule_threads"):
            self._schedule_threads = set()

        self._schedule_threads.add(thread)

        def cleanup():
            self._schedule_threads.discard(thread)

        thread.finished.connect(cleanup)

        thread.start()

    @QtCore.Slot(dict)
    def _on_schedule_received(
        self,
        schedule: dict,
    ) -> None:
        """
        Найти следующую EARLY_TRADING и поставить одноразовый таймер.
        """

        now = datetime.now(timezone.utc)

        sessions = schedule.get("sessions") or []

        next_start: datetime | None = None

        for session in sessions:
            session_type = str(
                session.get("type", "")
            ).upper()

            if session_type != "EARLY_TRADING":
                continue

            interval = session.get("interval") or {}

            start_value = interval.get(
                "start_time"
            )

            if not start_value:
                continue

            try:
                start = datetime.fromisoformat(
                    str(start_value).replace(
                        "Z",
                        "+00:00",
                    )
                ).astimezone(
                    timezone.utc
                )
            except ValueError:
                continue

            if start > now:
                if (
                    next_start is None
                    or start < next_start
                ):
                    next_start = start

        if next_start is None:
            self._schedule_rollover_fallback()
            return

        delay_ms = max(
            1000,
            int(
                (
                    next_start - now
                ).total_seconds()
                * 1000
            ),
        )

        self._rollover_timer.start(
            delay_ms
        )

        print(
            "[order-flow] Следующий rollover check: "
            f"{next_start.isoformat()} UTC "
            f"(через {delay_ms / 3600000:.2f} ч.)",
            file=sys.stderr,
        )

    @QtCore.Slot(str)
    def _on_schedule_error(
        self,
        message: str,
    ) -> None:
        print(
            "[order-flow] Ошибка получения Schedule:\n"
            + message,
            file=sys.stderr,
        )

        self._schedule_rollover_fallback()

    def _schedule_rollover_fallback(self) -> None:
        """
        Резервный вариант.

        Если Schedule временно недоступен, повторяем через час.
        Это не основной режим — в штатной работе используется
        EARLY_TRADING из Schedule().
        """

        self._rollover_timer.start(
            self.ROLLOVER_FALLBACK_MS
        )

        print(
            "[order-flow] Следующая rollover-проверка "
            "через 1 час (fallback)",
            file=sys.stderr,
        )

    # ------------------------------------------------------------------
    # STOP
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """
        Полностью остановить Order Flow и rollover.
        """

        self._rollover_timer.stop()

        if (
            self._rollover_thread is not None
            and self._rollover_thread.isRunning()
        ):
            self._rollover_thread.quit()

            if not self._rollover_thread.wait(2000):
                print(
                    "[предупреждение] "
                    "rollover thread не завершился вовремя",
                    file=sys.stderr,
                )

        self._rollover_thread = None
        self._rollover_worker = None

        for sub in list(self._hub_subs.values()):
            sub.close()
        self._hub_subs.clear()

        for symbol in list(self._retry_timers):
            self._cancel_retry(symbol)
        self._attempts.clear()
        self._initial_margin.clear()
        self.save_bars()                         # получасы и минуты переживают перезапуск

    def save_bars(self) -> None:
        self.bars.save()
        self.minutes.save()

    def clear_bars(self) -> None:
        """«Сбросить график»: забыть получасы и минуты (и в файлах)."""
        self.bars.clear()
        self.minutes.clear()

    def flow_series(self, tf: int) -> list[tuple[int, float, float]]:
        """Баланс всех инструментов по свечам таймфрейма tf (с) — для графика баланса. Пересчёт (по всем
        минутам за 14 дней) — только если данные или параметры изменились: панель спрашивает раз в 2 с."""
        key = (self.minutes.version, self.bars.version, tf, self.full_value, _tz_offset())
        cached = self.__dict__.get("_flow_cache")
        if cached is not None and cached[0] == key:
            return cached[1]
        series = flow_series(self.minutes, self.bars, tf, self.full_value, key[4])
        self._flow_cache = (key, series)
        return series

    def set_full_value(self, on: bool) -> None:
        """Переключатель «Фьючерсы: по ГО / по полной стоимости» (запоминается)."""
        self.full_value = bool(on)
        QtCore.QSettings("MyTradingTools", "FxTerminal").setValue(FUTURES_FULL_KEY, self.full_value)

    # ------------------------------------------------------------------
    # TRADE
    # ------------------------------------------------------------------

    def _on_hub_trade(self, symbol: str, trade) -> None:
        """Trade из хаба -> тот же словарь, что раньше давал поток Finam (расчёт ниже не меняется).
        Время сделки (биржевое) — для получаса графика."""
        if trade.side is None:
            return
        self._on_trade(symbol, {
            "trade_id": trade.trade_id,
            "price": {"value": repr(float(trade.price))},
            "size": {"value": repr(float(trade.volume))},
            "side": "SIDE_BUY" if trade.side.value == "buy" else "SIDE_SELL",
            "ts": float(trade.ts or 0.0),
        })

    @QtCore.Slot(str, dict)
    def _on_trade(
        self,
        symbol: str,
        trade: dict,
    ) -> None:
        if self._attempts.get(symbol):
            print(f"[order-flow] {symbol}: поток сделок восстановлен", file=sys.stderr)
            self._attempts[symbol] = 0           # сделки пошли — следующая пауза снова с 5 с

        # --------------------------------------------------------------
        # TOM/TOD:
        # фактический рублёвый оборот
        # --------------------------------------------------------------

        if symbol in NOMINAL_FLOW_SYMBOLS:
            parsed = nominal_flow(trade)

            if parsed is None:
                return

            flow_rub, is_sell = parsed
            full_rub = flow_rub                  # TOM/TOD: оборот — он же полная стоимость

        # --------------------------------------------------------------
        # Остальные инструменты:
        # поток через ГО
        # --------------------------------------------------------------

        else:
            margins = self._initial_margin.get(symbol)

            if margins is None:
                return

            long_margin, short_margin = margins

            side = str(
                trade.get("side", "")
            ).upper()

            if "SELL" in side:
                initial_margin = short_margin

            elif "BUY" in side:
                initial_margin = long_margin

            else:
                return

            parsed = parse_trade(
                trade,
                initial_margin,
            )

            if parsed is None:
                return

            flow_rub, is_sell = parsed

            # Полная стоимость: цена × лоты × множитель контракта.
            full_rub = flow_rub
            mult = full_value_multiplier(symbol)
            try:
                price = float(_unwrap_decimal(trade.get("price")))
                size = float(_unwrap_decimal(trade.get("size")))
                if mult is not None and price > 0 and size > 0:
                    full_rub = price * size * mult
            except (TypeError, ValueError):
                pass

        # --------------------------------------------------------------
        # Передаём деньги сделки (по ГО и по полной стоимости) в RollingWindow
        # и в получас графика
        # --------------------------------------------------------------

        window = self.windows.get(symbol)

        if window is None:
            return

        ts = float(trade.get("ts") or 0.0) or time.time()
        window.add_trade(
            flow_rub,
            is_sell,
            full_rub=full_rub,
        )
        self.bars.add(symbol, ts, flow_rub, full_rub, is_sell)
        self.minutes.add(symbol, ts, flow_rub, full_rub, is_sell)

    # ------------------------------------------------------------------
    # ERROR
    # ------------------------------------------------------------------

    @QtCore.Slot(str)
    def _on_error(
        self,
        message: str,
    ) -> None:
        print(
            "[order-flow] ошибка потока сделок:\n"
            + message,
            file=sys.stderr,
        )

    # ------------------------------------------------------------------
    # SNAPSHOT
    # ------------------------------------------------------------------

    def snapshot(
        self,
    ) -> list[
        tuple[
            str,
            float,
            float,
            float,
            float,
            float,
            float,
        ]
    ]:
        """
        Возвращает:

        (
            symbol,
            buy_5m,
            sell_5m,
            buy_15m,
            sell_15m,
            buy_30m,
            sell_30m,
        )
        """

        now = time.time()

        return [
            (
                s,
                *self.windows[s].windows(now, full=self.full_value),
            )
            for s in self.symbols
            if s in self.windows
        ]


# --------------------------------------------------------------------------
# Виджет вкладки
# --------------------------------------------------------------------------

def _fmt_rub(n: float) -> str:
    n = round(n)
    sign = "-" if n < 0 else ""
    n = abs(n)
    s = str(n)
    out = []
    for i, ch in enumerate(reversed(s)):
        if i and i % 3 == 0:
            out.append(" ")
        out.append(ch)
    return sign + "".join(reversed(out))

def display_ticker(symbol: str) -> str:
    return symbol.split("@", 1)[0]


def _fmt_compact(n: float) -> str:
    """1 234 567 -> «1,2 млн», 3 400 000 000 -> «3,4 млрд» (подписи оси и подсказки графика)."""
    a = abs(n)
    for limit, word in ((1e9, "млрд"), (1e6, "млн"), (1e3, "тыс")):
        if a >= limit:
            return f"{n / limit:.1f}".replace(".", ",") + f" {word}"
    return f"{n:.0f}"


_TZ_CACHE: list = [0.0, None]          # [когда прочитали, ZoneInfo]


def _display_tz():
    """Часовой пояс терминала для подписей графика баланса. Читается из настроек не чаще раза
    в 10 с: шкала спрашивает его на каждую подпись при каждой перерисовке."""
    now = time.monotonic()
    if _TZ_CACHE[1] is not None and now - _TZ_CACHE[0] < 10.0:
        return _TZ_CACHE[1]
    from zoneinfo import ZoneInfo
    name = str(QtCore.QSettings("MyTradingTools", "FxTerminal").value("display/timezone", "Europe/Moscow"))
    try:
        tz = ZoneInfo(name)
    except Exception:
        tz = ZoneInfo("Europe/Moscow")
    _TZ_CACHE[0], _TZ_CACHE[1] = now, tz
    return tz


def _tz_offset() -> int:
    """Сдвиг часового пояса терминала от UTC сейчас, с (свечи графика баланса — по местному времени)."""
    off = datetime.now(_display_tz()).utcoffset()
    return int(off.total_seconds()) if off is not None else 0


class _MoneyAxis(pg.AxisItem):
    def tickStrings(self, values, scale, spacing):                    # noqa: N802 (имя pyqtgraph)
        return [_fmt_compact(v) for v in values]


SESSION_GAP_SEC = 3600       # свечей без единой сделки по всем инструментам дольше часа — биржа закрыта


def trading_slots(starts: list[int], current: int, gap_sec: int = SESSION_GAP_SEC,
                  tf: int = BAR_SEC) -> tuple[list[int], list[int]]:
    """Свечи таймфрейма tf для графика баланса — только торговое время: (начала свечей по порядку, номера,
    с которых начинается новая торговая сессия). Раньше по X шло настоящее время, и ночь, выходные,
    перерывы между сессиями были пустыми провалами на полграфика (29.10).

    Торговое время берётся по самим сделкам: от первой сделки самого раннего инструмента до последней
    сделки самого позднего. Внутри сессии свечи без сделок остаются (пустыми); перерыв, в котором не было
    сделок ни по одному инструменту дольше gap_sec, — биржа закрыта: такие свечи выкидываются, а на шкале —
    граница сессии. Расписание Finam (Schedule) здесь не годится: оно отдаёт только ближайшие сессии,
    а графику нужна и прошлая история. current — текущая свеча: она в конце, если сессия идёт
    (биржа закрыта — пустой «текущей» свечи после перерыва нет)."""
    traded = sorted(set(starts))
    if traded and traded[-1] < current and current - traded[-1] - tf < gap_sec:
        traded.append(current)                          # сессия идёт, а сделок в этой свече ещё нет
    slots: list[int] = []
    breaks: list[int] = []
    for t in traded:
        if slots:
            gap = t - slots[-1]
            if gap - tf < gap_sec:                      # тихий кусок сессии — пустые свечи на месте
                slots.extend(range(slots[-1] + tf, t, tf))
            else:
                breaks.append(len(slots))               # биржа была закрыта — новая сессия
        slots.append(t)
    return slots, breaks


class _SlotAxis(pg.AxisItem):
    """Шкала времени графика баланса в «торговых» свечах: X — номер свечи в trading_slots, подписи — её время
    в часовом поясе терминала («Настройки» → «Основные»). Нерабочее время на шкале не занимает места. Шаг
    подписей подбирается под ширину; начало каждой сессии подписано с датой."""

    STEPS = (1, 2, 3, 4, 6, 12, 24, 48, 96)       # в свечах
    MIN_LABEL_PX = 64

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.slots: list[int] = []
        self.breaks: set[int] = set()
        self.tf = BAR_SEC

    def set_slots(self, slots: list[int], breaks: list[int], tf: int) -> None:
        self.slots, self.breaks, self.tf = list(slots), set(breaks), int(tf)
        self.picture = None
        self.update()

    def _aligned(self, dt: datetime, step: int) -> bool:
        if self.tf >= 86400:
            return dt.toordinal() % step == 0
        return ((dt.hour * 3600 + dt.minute * 60) // self.tf) % step == 0

    def tickValues(self, minVal, maxVal, size):                       # noqa: N802 (имя pyqtgraph)
        if not self.slots or size <= 0 or maxVal <= minVal:
            return []
        per_slot = size / (maxVal - minVal)
        step = next((st for st in self.STEPS if st * per_slot >= self.MIN_LABEL_PX), self.STEPS[-1])
        tz = _display_tz()
        lo, hi = max(0, int(minVal)), min(len(self.slots) - 1, int(maxVal) + 1)
        ticks, last = [], -10 ** 9
        for i in range(lo, hi + 1):
            dt = datetime.fromtimestamp(self.slots[i], tz)
            if (i in self.breaks or i == 0 or self._aligned(dt, step)) and i - last >= step:
                ticks.append(float(i))
                last = i
        return [(step, ticks)]

    def tickStrings(self, values, scale, spacing):                    # noqa: N802
        tz = _display_tz()
        out = []
        for k, v in enumerate(values):
            i = int(round(v))
            if not 0 <= i < len(self.slots):
                out.append("")
                continue
            dt = datetime.fromtimestamp(self.slots[i], tz)
            if self.tf >= 86400:
                out.append(dt.strftime("%d.%m"))
                continue
            with_date = (k == 0 or i in self.breaks or (dt.hour == 0 and dt.minute == 0)
                         or spacing * self.tf >= 86400)
            out.append(dt.strftime("%d.%m %H:%M" if with_date else "%H:%M"))
        return out


class BalanceBarsChart(QtWidgets.QWidget):
    """График баланса покупок и продаж всех инструментов «Покупки/Продажи» за каждую свечу таймфрейма.
    Зелёный столбик вверх — покупки больше продаж, красный вниз — наоборот; текущая (незакрытая) свеча —
    бледнее. По X — только торговое время (trading_slots, _SlotAxis): ночь, выходные и перерывы между
    сессиями не занимают места, граница сессии — пунктир. Подсказка при наведении: время, покупки,
    продажи, баланс. Данные и таймфрейм даёт панель (OrderFlowChartPanel)."""

    VISIBLE_SLOTS = 32                   # сколько свечей видно сразу; дальше — перетаскиванием
    BAR_WIDTH = 0.8                      # ширина столбика в свечах (между соседними — зазор)

    def __init__(self, parent=None):
        super().__init__(parent)
        from candlestick_item import BULL_COLOR, BEAR_COLOR
        self._bull, self._bear = BULL_COLOR, BEAR_COLOR
        self._series: list[tuple[int, float, float]] = []
        self._slots: list[int] = []
        self._index: dict[int, int] = {}
        self._break_lines: list = []
        self.tf = BAR_SEC
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.axis_x = _SlotAxis(orientation="bottom")
        # Шкала суммы — справа, как у графиков цены терминала; слева оси нет.
        self.plot = pg.PlotWidget(axisItems={"bottom": self.axis_x, "right": _MoneyAxis(orientation="right")})
        self.plot.showAxis("right")
        self.plot.hideAxis("left")
        self.plot.setMenuEnabled(False)
        self.plot.showGrid(x=True, y=True, alpha=0.15)
        self.plot.setMouseEnabled(x=True, y=False)
        self.plot.addLine(y=0, pen=pg.mkPen(fx_color("TEXT_DIM", "#8b9098"), width=1))
        # Один BarGraphItem на все столбики (высота со знаком, цвет — у каждого свой). Пустым его
        # не оставляем: у pyqtgraph пустой BarGraphItem падает при расчёте границ — прячем.
        self.bars = pg.BarGraphItem(x=[0], height=[0], width=self.BAR_WIDTH)
        self.bars.setVisible(False)
        self.plot.addItem(self.bars)
        self.plot.disableAutoRange()             # диапазоны ставит set_series
        self.empty = pg.TextItem("Свечи появятся с первыми сделками", color=fx_color("TEXT_DIM", "#8b9098"),
                                 anchor=(0.5, 0.5))
        self.plot.addItem(self.empty)
        lay.addWidget(self.plot)
        self.plot.scene().sigMouseMoved.connect(self._on_mouse)
        self._current = None                      # (ТФ, текущая свеча) при прошлой подгонке окна
        self._fit_window()

    def _current_bucket(self) -> int:
        return bucket_start(time.time(), self.tf, _tz_offset())

    def _fit_window(self) -> None:
        """Окно по X: последние VISIBLE_SLOTS свечей и текущая целиком (справа небольшой запас)."""
        self._current = (self.tf, self._current_bucket())
        right = max(len(self._slots), 1) - 1 + 1.5
        self.plot.setXRange(right - self.VISIBLE_SLOTS, right, padding=0)
        lo, hi = self.plot.getViewBox().viewRange()[0]
        self.empty.setPos((lo + hi) / 2, 0)

    def _set_break_lines(self, breaks: list[int]) -> None:
        for line in self._break_lines:
            self.plot.removeItem(line)
        pen = pg.mkPen(fx_color("TEXT_DIM", "#8b9098"), width=1, style=QtCore.Qt.PenStyle.DashLine)
        self._break_lines = [self.plot.addLine(x=i - 0.5, pen=pen) for i in breaks]

    def set_series(self, series: list[tuple[int, float, float]], tf: int | None = None) -> None:
        """series: [(начало свечи UTC, покупки, продажи)] по возрастанию; tf — таймфрейм, с."""
        tf_changed = tf is not None and int(tf) != self.tf
        if tf is not None:
            self.tf = int(tf)
        self._series = series
        current = self._current_bucket()
        # У дневных свечей «биржа закрыта» — выходные (больше суток без сделок), а не ночь.
        gap = max(SESSION_GAP_SEC, self.tf) if self.tf < 86400 else 86400
        slots, breaks = trading_slots([start for start, _b, _s in series], current, gap_sec=gap, tf=self.tf)
        grew = len(slots) != len(self._slots)
        self._slots, self._index = slots, {t: i for i, t in enumerate(slots)}
        self.axis_x.set_slots(slots, breaks, self.tf)
        self._set_break_lines(breaks)
        if tf_changed or (self.tf, current) != self._current or grew:
            self._fit_window()                   # новая свеча или другой ТФ — окно к правому краю
        self.empty.setVisible(not series)
        self.bars.setVisible(bool(series))
        if not series:
            return
        xs, heights, brushes = [], [], []
        for start, buy, sell in series:
            net = buy - sell
            color = QtGui.QColor(self._bull if net >= 0 else self._bear)   # вверх — покупки, вниз — продажи
            color.setAlpha(110 if start == current else 220)                # текущая свеча ещё копится
            xs.append(float(self._index[start]))
            heights.append(net)
            brushes.append(pg.mkBrush(color))
        n = len(series)
        self.bars.setOpts(x=xs, height=heights, width=self.BAR_WIDTH, brushes=brushes, pens=[pg.mkPen(None)] * n)
        lo, hi = self.plot.getViewBox().viewRange()[0]
        visible = [h for x, h in zip(xs, heights) if lo - 1 <= x <= hi] or [0.0]
        top = max(max(visible), 0.0)
        bottom = min(min(visible), 0.0)
        pad = (top - bottom) * 0.08 or 1.0
        self.plot.setYRange(bottom - pad, top + pad, padding=0)

    def _on_mouse(self, pos) -> None:
        if not self._series or not self.plot.sceneBoundingRect().contains(pos):
            QtWidgets.QToolTip.hideText()
            return
        x = self.plot.getViewBox().mapSceneToView(pos).x()
        i = int(round(x))
        if not 0 <= i < len(self._slots) or abs(x - i) > self.BAR_WIDTH / 2:
            QtWidgets.QToolTip.hideText()
            return
        start = self._slots[i]
        hit = next((item for item in self._series if item[0] == start), None)
        if hit is None:
            QtWidgets.QToolTip.hideText()
            return
        _start, buy, sell = hit
        tz = _display_tz()
        t0 = datetime.fromtimestamp(start, tz)
        t1 = datetime.fromtimestamp(start + self.tf, tz)
        span = f"{t0:%d.%m}" if self.tf >= 86400 else f"{t0:%d.%m %H:%M}–{t1:%H:%M}"
        text = (f"{span}\n"
                f"Покупки: {_fmt_rub(buy)}\nПродажи: {_fmt_rub(sell)}\nБаланс: {_fmt_rub(buy - sell)}")
        if start == self._current_bucket():
            text += "\n(свеча ещё идёт)"
        QtWidgets.QToolTip.showText(QtGui.QCursor.pos(), text)


class OrderFlowChartPanel(QtWidgets.QWidget):
    """Отдельная панель «Баланс покупок/продаж» (раньше — график под таблицей «Покупки/Продажи»): её можно
    закрепить в любом пространстве или вынести в отдельное окно, как остальные панели терминала.
    Таймфрейм — 1 м … 1 д (CHART_TFS, запоминается); деньги — как в «Покупке/Продаже» (по ГО / по полной
    стоимости, общий переключатель). Данные — OrderFlowController (минуты и старые получасы)."""

    REFRESH_SEC = 2.0                    # перерисовка не чаще (и только если данные изменились)

    def __init__(self, controller: "OrderFlowController", parent=None):
        super().__init__(parent)
        self.controller = controller
        settings = QtCore.QSettings("MyTradingTools", "FxTerminal")
        try:
            tf = int(settings.value(CHART_TF_KEY, BAR_SEC))
        except (TypeError, ValueError):
            tf = BAR_SEC
        if tf not in {t for t, _ in CHART_TFS}:
            tf = BAR_SEC
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Таймфрейм:"))
        self.tf_combo = QtWidgets.QComboBox()
        for sec, title in CHART_TFS:
            self.tf_combo.addItem(title, sec)
        self.tf_combo.setCurrentIndex(next(i for i, (t, _) in enumerate(CHART_TFS) if t == tf))
        self.tf_combo.setToolTip("Свечи графика баланса. 1–15 м собираются из минут — история у них с 30.10;\n"
                                 "30 м и крупнее — ещё и из прежних получасов.")
        self.tf_combo.currentIndexChanged.connect(self._on_tf)
        top.addWidget(self.tf_combo)
        top.addSpacing(12)
        top.addWidget(QtWidgets.QLabel("Фьючерсы:"))
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItem("по ГО", False)
        self.mode_combo.addItem("по полной стоимости", True)
        self.mode_combo.setToolTip("Тот же переключатель, что во вкладке «Покупка/Продажа».")
        self.mode_combo.currentIndexChanged.connect(self._on_mode)
        top.addWidget(self.mode_combo)
        top.addStretch(1)
        self.reset_btn = QtWidgets.QPushButton("Сбросить график")
        self.reset_btn.setToolTip("Удалить накопленные свечи графика баланса и начать накопление заново.\n"
                                  "Таблица «Покупка/Продажа» не меняется.")
        self.reset_btn.clicked.connect(self._reset)
        top.addWidget(self.reset_btn)
        lay.addLayout(top)
        self.chart = BalanceBarsChart()
        self.chart.tf = tf
        lay.addWidget(self.chart, 1)
        self._key = None
        self._drawn_at = 0.0
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(REFRESH_MS)
        self._sync_mode()

    @property
    def tf(self) -> int:
        return int(self.tf_combo.currentData() or BAR_SEC)

    def _sync_mode(self) -> None:
        want = 1 if self.controller.full_value else 0
        if self.mode_combo.currentIndex() != want:
            self.mode_combo.blockSignals(True)
            self.mode_combo.setCurrentIndex(want)
            self.mode_combo.blockSignals(False)

    def _on_tf(self, _index: int) -> None:
        QtCore.QSettings("MyTradingTools", "FxTerminal").setValue(CHART_TF_KEY, self.tf)
        self.refresh(force=True)

    def _on_mode(self, _index: int) -> None:
        self.controller.set_full_value(bool(self.mode_combo.currentData()))
        self.refresh(force=True)

    def _reset(self) -> None:
        answer = QtWidgets.QMessageBox.question(
            self, "Сбросить график",
            "Удалить все накопленные свечи графика баланса?\n"
            "Накопление начнётся заново с текущих сделок. Таблица «Покупка/Продажа» не изменится.",
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No)
        if answer != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        self.controller.clear_bars()
        print("[order-flow] график баланса сброшен пользователем", file=sys.stderr)
        self.refresh(force=True)

    def refresh(self, force: bool = False) -> None:
        """Перерисовка не чаще REFRESH_SEC и только если изменились данные, таймфрейм или текущая свеча;
        закрытая (невидимая) панель ничего не считает."""
        if not self.isVisible():
            return
        self._sync_mode()
        now = time.monotonic()
        if not force and now - self._drawn_at < self.REFRESH_SEC:
            return
        try:
            tf = self.tf
            series = self.controller.flow_series(tf)
            key = (tf, self.controller.full_value, series, bucket_start(time.time(), tf, _tz_offset()))
            if not force and key == self._key:
                return
            self._drawn_at, self._key = now, key
            self.chart.set_series(series, tf)
        except Exception:                        # ошибка графика не должна ронять терминал
            if not getattr(self, "_error_shown", False):
                self._error_shown = True
                traceback.print_exc()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        QtCore.QTimer.singleShot(0, lambda: self.refresh(force=True))


def fx_color(name: str, default: str) -> str:
    try:
        import fx_theme
        return str(getattr(fx_theme, name, default))
    except Exception:
        return default

class OrderFlowTab(QtWidgets.QWidget):
    COLUMNS = [
        "Инструмент",
        "Покупка 5м",
        "Продажа 5м",
        "Нетто 5м",
        "Покупка 15м",
        "Продажа 15м",
        "Нетто 15м",
        "Баланс 30м",
    ]

    BUY_BG = QtGui.QColor("#0b3723")
    BUY_FG = QtGui.QColor("#78ffaa")
    SELL_BG = QtGui.QColor("#460f0f")
    SELL_FG = QtGui.QColor("#ff8c8c")
    NEUTRAL_BG = QtGui.QColor("#214343")
    NEUTRAL_FG = QtGui.QColor("#efe4b0")

    def __init__(self, controller: OrderFlowController, parent=None):
        super().__init__(parent)
        self.controller = controller

        layout = QtWidgets.QVBoxLayout(self)

        # Переключатель: как считать фьючерсы (таблица и график). График — по всем инструментам.
        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Фьючерсы:"))
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItem("по ГО", False)
        self.mode_combo.addItem("по полной стоимости", True)
        self.mode_combo.setCurrentIndex(1 if controller.full_value else 0)
        self.mode_combo.setToolTip(
            "По ГО — сколько денег заблокировано под сделки (ГО × лоты).\n"
            "По полной стоимости — сколько стоят сами контракты (цена × лоты × размер контракта).\n"
            "CNYRUB_TOM / TOD — всегда по обороту.")
        self.mode_combo.currentIndexChanged.connect(self._on_mode)
        top.addWidget(self.mode_combo)
        top.addStretch(1)
        # График баланса — отдельная панель (OrderFlowChartPanel): её можно вынести в отдельное окно
        # и выбрать таймфрейм. Открывает её главное окно (open_chart назначает MainWindow).
        self.open_chart = None
        self.chart_btn = QtWidgets.QPushButton("График баланса ↗")
        self.chart_btn.setToolTip("Открыть график баланса покупок/продаж отдельной панелью\n"
                                  "(можно закрепить в пространстве или вынести в окно; таймфрейм 1 м … 1 д).")
        self.chart_btn.clicked.connect(lambda: self.open_chart() if callable(self.open_chart) else None)
        top.addWidget(self.chart_btn)
        # «Заметка» — итоги за 5 ч (flow_notes.py); скрыта, пока данных без перерыва меньше 5 ч
        self.note_btn = QtWidgets.QPushButton("Заметка")
        self.note_btn.setToolTip("Итоги за последние 5 часов по всем инструментам — в «Заметки»:\n"
                                 "коротко в «Подробности», по инструментам и по часам — в «Комментарий».")
        self.note_btn.setAutoDefault(False)
        self.note_btn.clicked.connect(self._add_flow_note)
        self.note_btn.setVisible(False)
        self._note_check = (-1, -1)                      # (минута, версия минут) последней проверки
        top.addWidget(self.note_btn)
        layout.addLayout(top)
        self.status_lbl = QtWidgets.QLabel("")
        self.status_lbl.setVisible(False)
        layout.addWidget(self.status_lbl)

        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setRowCount(len(controller.symbols) + 1)  # + строка ИТОГО

        layout.addWidget(self.table, 1)

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(REFRESH_MS)
        self.refresh()

    def _on_mode(self, _index: int) -> None:
        self.controller.set_full_value(bool(self.mode_combo.currentData()))
        self.refresh()

    def _update_note_btn(self) -> None:
        """Показать «Заметку», когда данных без перерыва набралось flow_notes.FLOW_NOTE_SEC. Проверка — раз в
        минуту или когда число минут изменилось (новая минута, сброс графика): обходить минуты за 14 дней
        каждую секунду незачем."""
        minutes = self.controller.minutes
        key = (int(time.time() // 60), len(minutes.data))
        if key == self._note_check:
            return
        self._note_check = key
        self.note_btn.setVisible(flow_notes.ready(minutes.data, time.time()))

    def _add_flow_note(self) -> None:
        full = self.controller.full_value
        result = flow_notes.summary(self.controller.minutes.data, time.time(), full, _tz_offset(), display_ticker)
        if result is None:
            text = "Для заметки нет сделок за 5 часов"
        else:
            details, comment = result
            store = hour_notes.find_notes_store(self)
            if store is None:
                text = "Окно «Заметки» недоступно"
            else:
                store.add(symbol="все инструменты", kind="Покупка/Продажа",
                          title=f"Итоги за {flow_notes.FLOW_NOTE_SEC // 3600} часов", details=details,
                          comment=comment, event_time=datetime.now().astimezone().isoformat(timespec="seconds"))
                text = "Итоги за 5 часов добавлены в «Заметки»"
        self.status_lbl.setText(text)
        self.status_lbl.setVisible(True)
        QtCore.QTimer.singleShot(8000, lambda: self.status_lbl.setVisible(False))

    def refresh(self) -> None:
        want = 1 if self.controller.full_value else 0         # переключатель могли сменить в панели графика
        if self.mode_combo.currentIndex() != want:
            self.mode_combo.blockSignals(True)
            self.mode_combo.setCurrentIndex(want)
            self.mode_combo.blockSignals(False)
        self._update_note_btn()
        rows = self.controller.snapshot()
        self.table.setRowCount(len(rows) + 1)

        total_b5 = total_s5 = 0.0
        total_b15 = total_s15 = 0.0
        total_b30 = total_s30 = 0.0

        for r, (
            symbol,
            b5,
            s5,
            b15,
            s15,
            b30,
            s30,
        ) in enumerate(rows):

            total_b5 += b5
            total_s5 += s5

            total_b15 += b15
            total_s15 += s15

            total_b30 += b30
            total_s30 += s30

            gauge_text, bias = gauge_bar(b30, s30)

            self._set_row(
                r,
                display_ticker(symbol),
                b5,
                s5,
                b15,
                s15,
                gauge_text,
                bias,
            )

        total_gauge, total_bias = gauge_bar(
            total_b30,
            total_s30,
        )

        self._set_row(
            len(rows),
            "ИТОГО ПО ВСЕМ ИНСТРУМЕНТАМ",
            total_b5,
            total_s5,
            total_b15,
            total_s15,
            total_gauge,
            total_bias,
        )

        # Ширина колонок — по содержимому, но не каждую секунду: подгонка пересчитывает все ячейки.
        now = time.monotonic()
        if now - getattr(self, "_columns_fit_at", 0.0) >= 10.0 or len(rows) != getattr(self, "_columns_rows", -1):
            self._columns_fit_at, self._columns_rows = now, len(rows)
            self.table.resizeColumnsToContents()

    def _set_row(
        self,
        row: int,
        symbol: str,
        b5: float,
        s5: float,
        b15: float,
        s15: float,
        gauge_text: str,
        bias: str,
    ) -> None:

        values = [
            symbol,
            _fmt_rub(b5),
            _fmt_rub(s5),
            _fmt_rub(b5 - s5),
            _fmt_rub(b15),
            _fmt_rub(s15),
            _fmt_rub(b15 - s15),
            gauge_text,
        ]

        for col, value in enumerate(values):
            self.table.setItem(
                row,
                col,
                QtWidgets.QTableWidgetItem(value),
            )

        bg, fg = {
            "buy": (self.BUY_BG, self.BUY_FG),
            "sell": (self.SELL_BG, self.SELL_FG),
        }.get(
            bias,
            (self.NEUTRAL_BG, self.NEUTRAL_FG),
        )

        gauge_item = self.table.item(
            row,
            len(self.COLUMNS) - 1,
        )

        if gauge_item is not None:
            gauge_item.setBackground(bg)
            gauge_item.setForeground(fg)
