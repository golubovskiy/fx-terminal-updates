"""
Диагностика соединения. Основа — окно диагностики QUIK (выбор сервера, Ping / Tracert /
проверка порта, консоль, запись в файл), плюс проверки, которые для Finam Trade API (gRPC
поверх TLS) говорят больше, чем ICMP-ping:

    «Полная проверка» — по очереди, с итогом ✔ / ⚠ / ✖ по каждому пункту:
        1. DNS: во что резолвится сервер и за сколько;
        2. TCP-пинг: серия подключений к порту — задержка мин / сред / макс, разброс, потери
           (обычный ping часто молчит: ICMP режут провайдеры и сами серверы);
        3. TLS: рукопожатие, ALPN h2 (нужен gRPC), кем выдан сертификат и когда истекает —
           подмена сертификата антивирусом / прокси видна сразу;
        4. API через соединение терминала (шлюз Finam): задержка запроса времени сервера,
           расхождение часов ПК с сервером, токен (торговый / только чтение, доступ к биржам),
           состояние потоков данных.
    Отчёт сохраняется в logs/diagnostics_ГГГГ-ММ-ДД_ЧЧММСС.txt; «Копировать отчёт» — в буфер.
    «TCP-пинг» отдельно — 20 подключений или непрерывно до Stop (галочка «Непрерывно»).

Сетевые проверки идут в фоновом потоке (JobWorker), окно не замирает. Терминал (шлюз,
REST-клиент) диалог находит сам — по цепочке родителей (у MainWindow есть md_gateway);
открытый без терминала, он пропускает шаги API.

Открывается: «Настройки» → «Подключение» → «Диагностика…» (settings_dialog.py).
"""

from __future__ import annotations

import html
import socket
import ssl
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)
from typing import Callable

from PySide6 import QtCore, QtGui, QtWidgets


# ============================================================================
# Finam servers
# ============================================================================

def _terminal_endpoint() -> tuple[str, int]:
    """Адрес, к которому реально подключается терминал (шлюз Finam: gRPC; REST — тот же хост)."""
    try:
        from brokers.finam.gateway import GRPC_ENDPOINT
        host, _, port = str(GRPC_ENDPOINT).rpartition(":")
        return host or "api.finam.ru", int(port or 443)
    except Exception:
        return "api.finam.ru", 443


_EP_HOST, _EP_PORT = _terminal_endpoint()
KNOWN_SERVERS = [
    (
        f"Finam Trade API — терминал (gRPC и REST) [{_EP_HOST}:{_EP_PORT}]",
        _EP_HOST,
        _EP_PORT,
    ),
    (
        "Прежний Trade API, для сравнения [trade-api.finam.ru:443]",
        "trade-api.finam.ru",
        443,
    ),
]


LOG_DIR = app_paths.LOG_DIR
LOG_PATH = LOG_DIR / "connection_diagnostics.log"     # «Записывать в файл результат»

OK, WARN, BAD, SKIP = "ok", "warn", "bad", "skip"
MARK = {OK: "✔", WARN: "⚠", BAD: "✖", SKIP: "—"}
TCP_PING_COUNT = 20
TCP_PING_INTERVAL_SEC = 0.25
API_TIME_SAMPLES = 5

# Кто выпускает сертификаты при перехвате HTTPS (антивирус, корпоративный прокси):
# такой издатель вместо публичного центра сертификации — повод проверить настройки.
INTERCEPTORS = ("kaspersky", "eset", "avast", "avg", "bitdefender", "dr.web", "drweb", "fortinet",
                "fortigate", "zscaler", "sophos", "mcafee", "norton", "symantec web", "netskope",
                "cisco umbrella", "palo alto", "checkpoint", "check point", "proxy", "mitm", "fiddler",
                "charles")


# ============================================================================
# Оценки (без сети — проверяются в tests/test_diagnostics.py)
# ============================================================================

def tcp_stats(samples_ms: list[float | None]) -> dict:
    """samples_ms: время подключения каждой попытки или None (не удалось).
    -> {sent, lost, loss_pct, min, avg, max, jitter} (jitter — среднее |разность соседних|)."""
    ok = [x for x in samples_ms if x is not None]
    sent = len(samples_ms)
    lost = sent - len(ok)
    result = {"sent": sent, "lost": lost, "loss_pct": 100.0 * lost / sent if sent else 0.0,
              "min": None, "avg": None, "max": None, "jitter": None}
    if ok:
        result.update(min=min(ok), avg=statistics.fmean(ok), max=max(ok),
                      jitter=statistics.fmean(abs(a - b) for a, b in zip(ok, ok[1:])) if len(ok) > 1 else 0.0)
    return result


def tcp_verdict(stats: dict) -> tuple[str, str]:
    if not stats["sent"] or stats["avg"] is None:
        return BAD, "сервер не отвечает на порту"
    text = (f"{stats['avg']:.0f} мс в среднем (мин {stats['min']:.0f}, макс {stats['max']:.0f}, "
            f"разброс {stats['jitter']:.0f}), потери {stats['loss_pct']:.0f} %")
    if stats["loss_pct"] >= 20 or stats["avg"] > 150:
        return BAD, text
    if stats["loss_pct"] > 0 or stats["avg"] > 50 or stats["jitter"] > 30:
        return WARN, text
    return OK, text


def interceptor_of(issuer: str) -> str | None:
    low = (issuer or "").lower()
    for name in INTERCEPTORS:
        if name in low:
            return name
    return None


def cert_name(parts) -> str:
    """Поле subject / issuer из ssl.getpeercert() -> «CN=…, O=…»."""
    items = []
    for rdn in parts or ():
        for key, value in rdn:
            if key in ("commonName", "organizationName"):
                items.append(f"{'CN' if key == 'commonName' else 'O'}={value}")
    return ", ".join(items) or "—"


def clock_verdict(offset_sec: float) -> tuple[str, str]:
    sign = "спешат" if offset_sec > 0 else "отстают"
    text = f"часы ПК {sign} на {abs(offset_sec):.2f} с"
    if abs(offset_sec) >= 2.0:
        return BAD, text + " — синхронизируйте время Windows (Параметры → Время → Синхронизировать)"
    if abs(offset_sec) >= 0.5:
        return WARN, text + " — «задержка ленты сделок» будет неточной"
    return OK, text


def api_verdict(samples_ms: list[float]) -> tuple[str, str]:
    if not samples_ms:
        return BAD, "запрос к API не прошёл"
    avg = statistics.fmean(samples_ms)
    text = f"{avg:.0f} мс в среднем (мин {min(samples_ms):.0f}, макс {max(samples_ms):.0f})"
    if avg > 300:
        return BAD, text
    if avg > 100:
        return WARN, text
    return OK, text


def token_verdict(details: dict) -> tuple[str, str]:
    """TokenDetails Finam -> оценка: торговый ли токен и есть ли доступ к срочному и валютному рынкам."""
    readonly = bool(details.get("readonly"))
    accounts = details.get("account_ids") or []
    mics = {}
    for perm in details.get("md_permissions") or []:
        mics[str(perm.get("mic"))] = perm
    parts = [f"счетов {len(accounts)}", "только чтение" if readonly else "торговый"]
    problems = []
    for mic, title in (("RTSX", "срочный рынок"), ("MISX", "Мосбиржа")):
        perm = mics.get(mic)
        if perm is None:
            problems.append(f"нет доступа: {title} ({mic})")
            continue
        delay = int(perm.get("delay_minutes") or 0)
        level = str(perm.get("quote_level") or "").replace("QUOTE_LEVEL_", "").lower()
        parts.append(f"{mic}: {level}{', задержка ' + str(delay) + ' мин' if delay else ''}")
        if delay:
            problems.append(f"{mic}: данные с задержкой {delay} мин")
    text = "; ".join(parts + problems)
    if not accounts or problems:
        return BAD if not accounts else WARN, text
    if readonly:
        return WARN, text + " — LIVE-заявки этим токеном не отправить"
    return OK, text


# ============================================================================
# UI STYLES
# ============================================================================

# Оформление — из общей темы терминала (fx_theme): кнопки — «таблетки», как в остальных
# диалогах; поле сервера — как все поля ввода. Консоль: в тёмной теме — чёрная,
# в светлой — белая с тёмным текстом.
try:
    import fx_theme
except Exception:            # окно открыто отдельно, без файлов терминала
    fx_theme = None


def _c(name: str, default: str) -> str:
    return str(getattr(fx_theme, name, default)) if fx_theme is not None else default


def _is_light() -> bool:
    return fx_theme is not None and getattr(fx_theme, "_THEME", "dark") == "light"


def _console_qss() -> str:
    if _is_light():
        bg, fg, border = "#ffffff", "#1e1e1e", _c("BORDER", "#c6c6c6")
    else:
        bg, fg, border = "#000000", "#d0d0d0", "#303030"
    return (
        "QTextEdit {"
        f" background-color: {bg}; color: {fg}; border: 1px solid {border}; border-radius: 3px;"
        " font-family: Consolas, 'Courier New', monospace; font-size: 12px; padding: 6px;"
        "}"
    )


# ============================================================================
# TCP PORT CHECK WORKER
# ============================================================================

class PortCheckWorker(QtCore.QObject):
    """
    Проверка доступности TCP-порта.

    В интерфейсе это называется "Telnet", как в диагностике QUIK,
    но фактически выполняется обычная TCP-проверка соединения.

    Проверка выполняется в отдельном QThread, чтобы интерфейс
    не зависал во время ожидания сети.
    """

    line = QtCore.Signal(str)
    finished = QtCore.Signal()

    def __init__(
        self,
        host: str,
        port: int,
        timeout: float = 5.0,
    ) -> None:
        super().__init__()

        self.host = host
        self.port = port
        self.timeout = timeout

        self._cancel_requested = False

    @QtCore.Slot()
    def cancel(self) -> None:
        """
        Запрашивает остановку проверки.
        """

        self._cancel_requested = True

    @QtCore.Slot()
    def run(self) -> None:
        """
        Выполняет TCP-проверку.

        Используется короткий интервал ожидания, чтобы Stop
        реагировал быстро даже при недоступном сервере.
        """

        self.line.emit(
            f"Проверка TCP-соединения: {self.host}:{self.port}"
        )

        self.line.emit(
            f"Таймаут: {self.timeout:.1f} сек."
        )

        started = time.monotonic()

        sock: socket.socket | None = None

        try:
            # Небольшой timeout позволяет быстро реагировать
            # на запрос Stop.
            connect_timeout = min(0.5, self.timeout)

            sock = socket.socket(
                socket.AF_INET,
                socket.SOCK_STREAM,
            )

            sock.settimeout(connect_timeout)

            while True:
                if self._cancel_requested:
                    self.line.emit("Проверка остановлена пользователем.")
                    return

                elapsed = time.monotonic() - started

                if elapsed >= self.timeout:
                    self.line.emit(
                        f"Не удалось подключиться к "
                        f"{self.host}:{self.port} — превышен таймаут."
                    )
                    return

                try:
                    sock.connect((self.host, self.port))

                    elapsed_ms = (
                        time.monotonic() - started
                    ) * 1000

                    self.line.emit(
                        f"Соединение с узлом {self.host} "
                        f"на порт {self.port} установлено "
                        f"({elapsed_ms:.0f} мс)."
                    )

                    return

                except socket.timeout:
                    # Продолжаем до общего timeout.
                    continue

                except OSError as exc:
                    if self._cancel_requested:
                        self.line.emit(
                            "Проверка остановлена пользователем."
                        )
                        return

                    elapsed = time.monotonic() - started

                    if elapsed >= self.timeout:
                        self.line.emit(
                            f"Не удалось подключиться к "
                            f"{self.host}:{self.port} — {exc}"
                        )
                        return

                    # Для большинства ошибок повторная попытка
                    # не имеет смысла. Возвращаем ошибку сразу.
                    self.line.emit(
                        f"Не удалось подключиться к "
                        f"{self.host}:{self.port} — {exc}"
                    )
                    return

        except OSError as exc:
            self.line.emit(
                f"Ошибка TCP-проверки: {exc}"
            )

        finally:
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass

            self.finished.emit()


# ============================================================================
# FULL CHECK / TCP PING WORKER
# ============================================================================

class JobWorker(QtCore.QObject):
    """Фоновая задача диагностики: job(worker) выполняется в QThread и пишет через
    worker.say(text) (строка консоли) и worker.result(шаг, статус, текст) (строка итога).
    worker.cancelled — запрошен Stop."""

    line = QtCore.Signal(str)
    step_done = QtCore.Signal(str, str, str)
    finished = QtCore.Signal()

    def __init__(self, job: Callable[["JobWorker"], None]) -> None:
        super().__init__()
        self._job = job
        self.cancelled = False

    @QtCore.Slot()
    def cancel(self) -> None:
        self.cancelled = True

    def say(self, text: str) -> None:
        self.line.emit(text)

    def result(self, step: str, status: str, text: str) -> None:
        self.step_done.emit(step, status, text)

    def sleep(self, seconds: float) -> bool:
        """Пауза с проверкой Stop; False — остановлено."""
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if self.cancelled:
                return False
            time.sleep(min(0.05, max(0.0, end - time.monotonic())))
        return not self.cancelled

    @QtCore.Slot()
    def run(self) -> None:
        try:
            self._job(self)
        except Exception as exc:                                     # noqa: BLE001
            self.line.emit(f"ОШИБКА проверки: {type(exc).__name__}: {exc}")
        finally:
            self.finished.emit()


def tcp_connect_ms(host: str, port: int, timeout: float = 3.0) -> float | None:
    started = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return (time.perf_counter() - started) * 1000.0
    except OSError:
        return None


def check_dns(w: JobWorker, host: str) -> None:
    w.say(f"[1] DNS: {host}")
    started = time.perf_counter()
    try:
        infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except OSError as exc:
        w.say(f"    не удалось: {exc}")
        w.result("DNS", BAD, f"имя не резолвится: {exc}")
        return
    ms = (time.perf_counter() - started) * 1000.0
    addrs = sorted({info[4][0] for info in infos})
    w.say(f"    {', '.join(addrs)}  ({ms:.0f} мс)")
    w.result("DNS", WARN if ms > 300 else OK, f"{', '.join(addrs[:4])} за {ms:.0f} мс")


def check_tcp(w: JobWorker, host: str, port: int, count: int = TCP_PING_COUNT, continuous: bool = False) -> None:
    w.say(f"[2] TCP-пинг: {host}:{port}, " + ("непрерывно до Stop" if continuous else f"{count} подключений"))
    samples: list[float | None] = []
    i = 0
    while continuous or i < count:
        if w.cancelled:
            w.say("    остановлено")
            break
        i += 1
        ms = tcp_connect_ms(host, port)
        samples.append(ms)
        w.say(f"    #{i:<3} " + (f"{ms:6.1f} мс" if ms is not None else "нет ответа"))
        if continuous and i % 10 == 0:
            st = tcp_stats(samples)
            w.say(f"    — за {st['sent']}: " + tcp_verdict(st)[1])
        if not w.sleep(TCP_PING_INTERVAL_SEC if not continuous else 1.0):
            w.say("    остановлено")
            break
    if samples:
        status, text = tcp_verdict(tcp_stats(samples))
        w.say(f"    итог: {text}")
        w.result("TCP-пинг", status, text)


def check_tls(w: JobWorker, host: str, port: int) -> None:
    w.say(f"[3] TLS: {host}:{port}")
    context = ssl.create_default_context()
    context.set_alpn_protocols(["h2", "http/1.1"])
    started = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=5.0) as raw:
            tcp_ms = (time.perf_counter() - started) * 1000.0
            t1 = time.perf_counter()
            with context.wrap_socket(raw, server_hostname=host) as tls:
                hs_ms = (time.perf_counter() - t1) * 1000.0
                cert = tls.getpeercert() or {}
                alpn = tls.selected_alpn_protocol()
                version = tls.version()
    except ssl.SSLCertVerificationError as exc:
        w.say(f"    сертификат не прошёл проверку: {exc.verify_message}")
        w.result("TLS", BAD, f"сертификат не прошёл проверку ({exc.verify_message}) — "
                             "возможен перехват HTTPS антивирусом или прокси")
        return
    except (OSError, ssl.SSLError) as exc:
        w.say(f"    не удалось: {exc}")
        w.result("TLS", BAD, f"рукопожатие не прошло: {exc}")
        return
    issuer = cert_name(cert.get("issuer"))
    subject = cert_name(cert.get("subject"))
    not_after = cert.get("notAfter")
    days_left = None
    if not_after:
        try:
            expires = datetime.fromtimestamp(ssl.cert_time_to_seconds(not_after), tz=timezone.utc)
            days_left = (expires - datetime.now(timezone.utc)).days
        except Exception:
            pass
    w.say(f"    {version}, ALPN {alpn or '—'}, TCP {tcp_ms:.0f} мс + рукопожатие {hs_ms:.0f} мс")
    w.say(f"    сертификат: {subject}")
    w.say(f"    выдан:      {issuer}" + (f", истекает через {days_left} дн." if days_left is not None else ""))
    problems, status = [], OK
    spy = interceptor_of(issuer)
    if spy:
        problems.append(f"сертификат выдал «{spy}» — HTTPS перехватывается, gRPC может рваться")
        status = BAD
    if alpn != "h2":
        problems.append("сервер / посредник не согласовал HTTP/2 (нужен gRPC)")
        status = BAD
    if days_left is not None and days_left < 7:
        problems.append(f"сертификат истекает через {days_left} дн.")
        status = max(status, WARN, key=[OK, WARN, BAD].index)
    if hs_ms > 400 and status == OK:
        status = WARN
    w.result("TLS", status, f"{version}, h2: {'да' if alpn == 'h2' else 'нет'}, рукопожатие {hs_ms:.0f} мс; "
                            f"выдан {issuer}" + ("; " + "; ".join(problems) if problems else ""))


def check_api(w: JobWorker, host_window) -> None:
    gateway = getattr(host_window, "md_gateway", None) if host_window is not None else None
    w.say("[4] API через соединение терминала")
    if gateway is None:
        w.say("    шлюз Finam не запущен (или окно открыто без терминала) — пропускаю")
        for step in ("API: задержка", "Часы ПК", "Потоки данных"):
            w.result(step, SKIP, "шлюз не запущен")
    else:
        samples, offsets = [], []
        for _ in range(API_TIME_SAMPLES):
            if w.cancelled:
                return
            t0 = time.time()
            p0 = time.perf_counter()
            try:
                server = float(gateway.server_time())
            except Exception as exc:
                w.say(f"    запрос времени сервера не прошёл: {type(exc).__name__}: {exc}")
                break
            rtt = (time.perf_counter() - p0) * 1000.0
            samples.append(rtt)
            offsets.append(t0 + rtt / 2000.0 - server)          # ПК минус сервер, с поправкой на половину пути
            w.say(f"    время сервера: {rtt:.0f} мс")
            if not w.sleep(0.2):
                return
        w.result("API: задержка", *api_verdict(samples))
        if offsets:
            w.result("Часы ПК", *clock_verdict(statistics.median(offsets)))
        else:
            w.result("Часы ПК", SKIP, "время сервера не получено")
        try:
            st = gateway.stats()
            idle = st.get("idle_sec") or {}
            worst = max(idle.values()) if idle else None
            text = (f"{'подключено' if st['connected'] else 'нет связи'}; потоков {st['streams']} "
                    f"(работают {st['up']}, восстанавливаются {st['down']}); обрывов с запуска {st['reconnects']}")
            if worst is not None:
                text += f"; давность последнего сообщения до {worst:.0f} с"
            status = BAD if not st["connected"] else WARN if st["down"] or st["reconnects"] else OK
            w.say(f"    {text}")
            w.result("Потоки данных", status, text)
        except Exception as exc:
            w.result("Потоки данных", SKIP, f"нет сводки: {exc}")
    client = getattr(host_window, "client", None) if host_window is not None else None
    if client is None or not hasattr(client, "get_token_details"):
        w.result("Токен", SKIP, "REST-клиент не создан (не задан токен?)")
        return
    try:
        details = client.get_token_details()
    except Exception as exc:
        w.say(f"    TokenDetails не прошёл: {type(exc).__name__}: {exc}")
        w.result("Токен", BAD, f"проверка токена не прошла: {exc}")
        return
    status, text = token_verdict(details if isinstance(details, dict) else {})
    w.say(f"    токен: {text}")
    w.result("Токен", status, text)


def find_terminal(widget):
    """MainWindow терминала по цепочке родителей (у него есть md_gateway)."""
    while widget is not None:
        if hasattr(widget, "md_gateway"):
            return widget
        widget = widget.parent()
    return None


# ============================================================================
# CONNECTION DIAGNOSTICS DIALOG
# ============================================================================

class ConnectionDiagnosticsDialog(QtWidgets.QDialog):
    """
    Окно диагностики соединения по образцу диагностики QUIK.

    Возможности:

    - выбор сервера; ручной ввод host или host:port;
    - «Полная проверка»: DNS, TCP-пинг, TLS, API терминала — с итогом ✔ / ⚠ / ✖ и отчётом в logs/;
    - «TCP-пинг»: 20 подключений или непрерывно до Stop;
    - Ping; Tracert (быстрый: -w 500 -h 20); TCP-проверка порта ("Telnet");
    - остановка выполняемой проверки; консольный вывод;
    - «Копировать отчёт» в буфер; запись всего вывода в logs/connection_diagnostics.log.
    """

    def __init__(
        self,
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)

        self.setWindowTitle("Диагностика соединения")
        self.resize(980, 600)
        self.setMinimumSize(860, 440)

        self._process: QtCore.QProcess | None = None

        self._job_thread: QtCore.QThread | None = None
        self._job_worker: JobWorker | None = None
        self._job_title = ""
        self._job_report = False             # сохранить отчёт в logs/ по окончании (полная проверка)
        self._results: list[tuple[str, str, str]] = []
        self._terminal = find_terminal(parent)

        self._port_thread: QtCore.QThread | None = None
        self._port_worker: PortCheckWorker | None = None

        # Буфер вывода QProcess.
        # Храним именно bytes, чтобы не ломать CP866
        # на границе между двумя readyRead-сигналами.
        self._process_output_buffer = b""

        self._build_ui()

    # ========================================================================
    # UI
    # ========================================================================

    def _build_ui(self) -> None:
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # --------------------------------------------------------------------
        # Верхняя панель
        # --------------------------------------------------------------------

        top = QtWidgets.QHBoxLayout()
        top.setSpacing(6)

        server_label = QtWidgets.QLabel("Сервер:")
        top.addWidget(server_label)

        self.server_combo = QtWidgets.QComboBox()
        self.server_combo.setEditable(True)

        self.server_combo.setInsertPolicy(
            QtWidgets.QComboBox.NoInsert
        )

        # Немного сузили относительно исходных 360px,
        # чтобы combo не подходил вплотную к кнопкам.
        self.server_combo.setMinimumWidth(280)

        for label, host, port in KNOWN_SERVERS:
            self.server_combo.addItem(
                label,
                userData=(host, port),
            )

        # При изменении текста пользователь может вручную
        # вводить host:port.
        self.server_combo.lineEdit().setPlaceholderText(
            "host или host:port"
        )

        # stretch убран: comboBox больше не растягивается
        # на всё доступное пространство и не "наезжает" на кнопки.
        top.addWidget(self.server_combo, 1)   # поле растягивается, кнопки — своей ширины

        # Разделитель + отступ между полем сервера и кнопками —
        # чтобы кнопки визуально не сливались со шторкой выбора сервера.
        top.addSpacing(8)

        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.VLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        separator.setStyleSheet(f"color: {_c('BORDER', '#454545')};")
        top.addWidget(separator)

        top.addSpacing(8)

        self.full_btn = QtWidgets.QPushButton("Полная проверка")
        self.full_btn.setToolTip("DNS, TCP-пинг, TLS-сертификат, API терминала (задержка, часы, токен, потоки) — "
                                 "с итогом по каждому пункту")
        self.full_btn.clicked.connect(self._run_full)
        top.addWidget(self.full_btn)

        self.tcp_btn = QtWidgets.QPushButton("TCP-пинг")
        self.tcp_btn.setToolTip("Серия подключений к порту: задержка, разброс, потери (работает, где ICMP-ping режут)")
        self.tcp_btn.clicked.connect(self._run_tcp_ping)
        top.addWidget(self.tcp_btn)

        self.ping_btn = QtWidgets.QPushButton("Ping")
        self.ping_btn.setToolTip(
            "Проверить доступность сервера через ICMP"
        )
        self.ping_btn.clicked.connect(self._run_ping)
        top.addWidget(self.ping_btn)

        self.tracert_btn = QtWidgets.QPushButton("Tracert")
        self.tracert_btn.setToolTip(
            "Показать маршрут до сервера"
        )
        self.tracert_btn.clicked.connect(self._run_tracert)
        top.addWidget(self.tracert_btn)

        self.telnet_btn = QtWidgets.QPushButton("Telnet")
        self.telnet_btn.setToolTip(
            "Проверить TCP-доступность указанного порта"
        )
        self.telnet_btn.clicked.connect(self._run_telnet)
        top.addWidget(self.telnet_btn)

        self.stop_btn = QtWidgets.QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_running)
        top.addWidget(self.stop_btn)


        for btn in (self.full_btn, self.tcp_btn, self.ping_btn, self.tracert_btn, self.telnet_btn, self.stop_btn):
            btn.setAutoDefault(False)          # Enter в поле сервера не должен жать Ping
            # «таблетки» компактнее, чем в обычных диалогах — четыре кнопки в одном ряду
            btn.setStyleSheet("QPushButton { padding: 3px 12px; min-width: 52px; }")
            btn.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed, QtWidgets.QSizePolicy.Policy.Fixed)

        layout.addLayout(top)

        # --------------------------------------------------------------------
        # Информационная строка
        # --------------------------------------------------------------------

        self.target_label = QtWidgets.QLabel(
            "Цель: —"
        )

        self.target_label.setStyleSheet(
            f"color: {_c('TEXT_DIM', '#888888')};"
            "padding: 2px 4px;"
        )

        layout.addWidget(self.target_label)

        # --------------------------------------------------------------------
        # Console
        # --------------------------------------------------------------------

        self.console = QtWidgets.QTextEdit()
        self.console.setReadOnly(True)

        self.console.setLineWrapMode(
            QtWidgets.QTextEdit.NoWrap
        )

        self.console.setStyleSheet(_console_qss())

        layout.addWidget(
            self.console,
            stretch=1,
        )

        # --------------------------------------------------------------------
        # Нижняя панель
        # --------------------------------------------------------------------

        bottom = QtWidgets.QHBoxLayout()

        self.save_to_file_check = QtWidgets.QCheckBox(
            "Записывать в файл результат"
        )

        bottom.addWidget(
            self.save_to_file_check
        )

        self.continuous_check = QtWidgets.QCheckBox("Непрерывный TCP-пинг")
        self.continuous_check.setToolTip("«TCP-пинг» раз в секунду до Stop, сводка каждые 10 попыток — "
                                         "чтобы поймать редкие пропадания связи")
        bottom.addWidget(self.continuous_check)

        bottom.addStretch()

        self.copy_btn = QtWidgets.QPushButton("Копировать отчёт")
        self.copy_btn.setAutoDefault(False)
        self.copy_btn.clicked.connect(self._copy_report)
        bottom.addWidget(self.copy_btn)

        self.clear_btn = QtWidgets.QPushButton(
            "Очистить"
        )

        self.clear_btn.clicked.connect(
            self.console.clear
        )

        self.clear_btn.setAutoDefault(False)

        bottom.addWidget(
            self.clear_btn
        )

        layout.addLayout(bottom)

    # ========================================================================
    # SERVER / PORT PARSING
    # ========================================================================

    def _current_host_port(
        self,
    ) -> tuple[str, int]:
        """
        Возвращает текущие host и port.

        Важный момент:
        если пользователь вручную изменил текст editable ComboBox,
        мы НЕ доверяем currentData(), а разбираем фактический текст.

        Поддерживаются:

            api.finam.ru
            api.finam.ru:443
            trade-api.finam.ru:443
        """

        line_edit = self.server_combo.lineEdit()

        if line_edit is None:
            text = self.server_combo.currentText().strip()
        else:
            text = line_edit.text().strip()

        if not text:
            raise ValueError(
                "Сервер не указан."
            )

        # Если текст точно совпадает с одним из названий
        # списка — используем соответствующий host/port.
        index = self.server_combo.findText(
            text,
            QtCore.Qt.MatchExactly,
        )

        if index >= 0:
            data = self.server_combo.itemData(index)

            if (
                isinstance(data, tuple)
                and len(data) == 2
            ):
                host, port = data
                return self._validate_host_port(
                    host,
                    port,
                )

        # --------------------------------------------------------------------
        # host:port
        # --------------------------------------------------------------------

        host = text
        port = 443

        # IPv6 в форме [::1]:443
        if text.startswith("["):
            closing = text.find("]")

            if closing == -1:
                raise ValueError(
                    "Некорректный IPv6-адрес."
                )

            host = text[1:closing]

            remainder = text[closing + 1:].strip()

            if remainder:
                if not remainder.startswith(":"):
                    raise ValueError(
                        "После IPv6-адреса должен быть указан порт "
                        "в формате [адрес]:порт."
                    )

                port_str = remainder[1:].strip()

                if not port_str:
                    raise ValueError(
                        "Порт не указан."
                    )

                try:
                    port = int(port_str)
                except ValueError:
                    raise ValueError(
                        "Порт должен быть числом."
                    )

        else:
            # Обычный hostname:port.
            #
            # rpartition используется специально, чтобы не ломать
            # возможный IPv6 без квадратных скобок.
            if text.count(":") == 1:
                possible_host, separator, possible_port = (
                    text.rpartition(":")
                )

                if separator:
                    if possible_host.strip():
                        try:
                            port = int(
                                possible_port.strip()
                            )
                            host = possible_host.strip()
                        except ValueError:
                            raise ValueError(
                                "Порт должен быть числом."
                            )

            elif text.count(":") > 1:
                # IPv6 без [] считаем hostname,
                # порт по умолчанию 443.
                host = text

        return self._validate_host_port(
            host,
            port,
        )

    @staticmethod
    def _validate_host_port(
        host: str,
        port: int,
    ) -> tuple[str, int]:
        """
        Проверяет host и port.
        """

        host = str(host).strip()

        if not host:
            raise ValueError(
                "Имя сервера не может быть пустым."
            )

        if not isinstance(port, int):
            raise ValueError(
                "Порт должен быть целым числом."
            )

        if port < 1 or port > 65535:
            raise ValueError(
                "Порт должен находиться в диапазоне 1–65535."
            )

        return host, port

    def _get_target_or_show_error(
        self,
    ) -> tuple[str, int] | None:
        """
        Получает host/port и показывает пользователю
        понятную ошибку при неправильном вводе.
        """

        try:
            host, port = self._current_host_port()

        except ValueError as exc:
            QtWidgets.QMessageBox.warning(
                self,
                "Некорректный сервер",
                str(exc),
            )
            return None

        self.target_label.setText(
            f"Цель: {host}:{port}"
        )

        return host, port

    # ========================================================================
    # CONSOLE / LOGGING
    # ========================================================================

    def _append(
        self,
        text: str,
    ) -> None:
        """
        Добавляет строку в консоль.

        При включённой записи также сохраняет её в лог.
        """

        if text is None:
            return

        text = str(text)

        self.console.append(
            text                         # обычный текст; цветные строки итога добавляет _on_job_finished
        )
        self._log_line(text)

    def _log_line(self, text: str) -> None:
        """Строка в logs/connection_diagnostics.log, если включено «Записывать в файл результат»."""
        if self.save_to_file_check.isChecked():
            try:
                LOG_PATH.parent.mkdir(
                    parents=True,
                    exist_ok=True,
                )

                with LOG_PATH.open(
                    "a",
                    encoding="utf-8",
                ) as f:
                    f.write(text + "\n")

            except OSError:
                # Ошибка записи лога не должна
                # останавливать диагностику.
                pass

    def _append_header(
        self,
        title: str,
        host: str,
        port: int,
    ) -> None:
        """
        Выводит начало диагностики.
        """

        self.console.clear()

        self._append(
            "=" * 70
        )

        self._append(
            title
        )

        self._append(
            f"Сервер: {host}"
        )

        self._append(
            f"Порт:   {port}"
        )

        self._append(
            f"Время:  {time.strftime('%Y-%m-%d %H:%M:%S')}"
        )

        self._append(
            "=" * 70
        )

    # ========================================================================
    # RUNNING STATE
    # ========================================================================

    def _set_running(
        self,
        running: bool,
    ) -> None:
        """
        Переключает состояние кнопок.
        """

        self.full_btn.setEnabled(not running)
        self.tcp_btn.setEnabled(not running)
        self.continuous_check.setEnabled(not running)

        self.ping_btn.setEnabled(
            not running
        )

        self.tracert_btn.setEnabled(
            not running
        )

        self.telnet_btn.setEnabled(
            not running
        )

        self.stop_btn.setEnabled(
            running
        )

        self.clear_btn.setEnabled(
            not running
        )

        self.server_combo.setEnabled(
            not running
        )

    # ========================================================================
    # QPROCESS
    # ========================================================================

    def _run_process(
        self,
        program: str,
        args: list[str],
        title: str,
        host: str,
        port: int,
    ) -> None:
        """
        Запускает ping/tracert через QProcess.
        """

        if self._process is not None:
            return

        self._append_header(
            title,
            host,
            port,
        )

        command_line = " ".join(
            [program] + args
        )

        self._append(
            f"$ {command_line}"
        )

        self._append("")

        self._process_output_buffer = b""

        self._set_running(True)

        process = QtCore.QProcess(self)

        process.setProcessChannelMode(
            QtCore.QProcess.MergedChannels
        )

        process.readyReadStandardOutput.connect(
            lambda p=process: self._on_process_output(p)
        )

        process.errorOccurred.connect(
            lambda error, p=process:
            self._on_process_error(p, error)
        )

        process.finished.connect(
            lambda exit_code, exit_status, p=process:
            self._on_process_finished(
                p,
                exit_code,
                exit_status,
            )
        )

        self._process = process

        process.start(
            program,
            args,
        )

    def _decode_process_bytes(
        self,
        data: bytes,
    ) -> str:
        """
        Декодирует вывод Windows-команд.

        Приоритет:
            CP866
            CP1251
            UTF-8
        """

        if not data:
            return ""

        for encoding in (
            "cp866",
            "cp1251",
            "utf-8",
        ):
            try:
                return data.decode(
                    encoding
                )
            except UnicodeDecodeError:
                continue

        return data.decode(
            "utf-8",
            errors="replace",
        )

    def _on_process_output(
        self,
        process: QtCore.QProcess,
    ) -> None:
        """
        Обрабатывает вывод QProcess с буферизацией
        незавершённой строки.
        """

        if process is not self._process:
            return

        data = bytes(
            process.readAllStandardOutput()
        )

        if not data:
            return

        self._process_output_buffer += data

        # Windows обычно использует CRLF.
        # Разбираем по LF, оставляя последнюю незавершённую
        # строку в буфере.
        parts = self._process_output_buffer.split(
            b"\n"
        )

        self._process_output_buffer = parts.pop()

        for raw_line in parts:
            raw_line = raw_line.rstrip(
                b"\r"
            )

            text = self._decode_process_bytes(
                raw_line
            )

            if text.strip():
                self._append(
                    text
                )

    def _flush_process_output(self) -> None:
        """
        Выводит последнюю незавершённую строку.
        """

        if not self._process_output_buffer:
            return

        data = self._process_output_buffer

        self._process_output_buffer = b""

        text = self._decode_process_bytes(
            data
        )

        if text.strip():
            self._append(
                text
            )

    def _on_process_error(
        self,
        process: QtCore.QProcess,
        error: QtCore.QProcess.ProcessError,
    ) -> None:
        """
        Обрабатывает ошибки запуска/работы QProcess.
        """

        if process is not self._process:
            return

        if error == QtCore.QProcess.FailedToStart:
            self._append(
                "ОШИБКА: не удалось запустить программу."
            )

        elif error == QtCore.QProcess.Crashed:
            self._append(
                "ОШИБКА: процесс завершился аварийно."
            )

        elif error == QtCore.QProcess.Timedout:
            self._append(
                "ОШИБКА: операция превысила таймаут."
            )

        elif error == QtCore.QProcess.WriteError:
            self._append(
                "ОШИБКА: ошибка записи в процесс."
            )

        elif error == QtCore.QProcess.ReadError:
            self._append(
                "ОШИБКА: ошибка чтения вывода процесса."
            )

        elif error == QtCore.QProcess.UnknownError:
            self._append(
                "ОШИБКА: неизвестная ошибка процесса."
            )

    def _on_process_finished(
        self,
        process: QtCore.QProcess,
        exit_code: int,
        exit_status: QtCore.QProcess.ExitStatus,
    ) -> None:
        """
        Обрабатывает завершение ping/tracert.
        """

        if process is not self._process:
            return

        # Забираем остаток буфера.
        self._flush_process_output()

        if exit_status == QtCore.QProcess.NormalExit:
            self._append(
                f"Код завершения: {exit_code}"
            )
        else:
            self._append(
                "Процесс завершён аварийно."
            )

        self._append(
            "--- диагностика завершена ---"
        )

        self._set_running(False)

        process.deleteLater()

        self._process = None

    # ========================================================================
    # PING
    # ========================================================================

    def _run_ping(self) -> None:
        """
        Запускает Windows ping.
        """

        target = self._get_target_or_show_error()

        if target is None:
            return

        host, port = target

        # Проверяем наличие ping.
        ping_path = self._find_windows_command(
            "ping"
        )

        if ping_path is None:
            QtWidgets.QMessageBox.critical(
                self,
                "Ping",
                "Программа ping.exe не найдена.",
            )
            return

        self._run_process(
            ping_path,
            [
                "-n",
                "4",
                host,
            ],
            "PING",
            host,
            port,
        )

    # ========================================================================
    # TRACERT
    # ========================================================================

    def _run_tracert(self) -> None:
        """
        Запускает Windows tracert.
        """

        target = self._get_target_or_show_error()

        if target is None:
            return

        host, port = target

        tracert_path = self._find_windows_command(
            "tracert"
        )

        if tracert_path is None:
            QtWidgets.QMessageBox.critical(
                self,
                "Tracert",
                "Программа tracert.exe не найдена.",
            )
            return

        self._run_process(
            tracert_path,
            [
                "-d",              # без обратного DNS по каждому узлу — в разы быстрее
                "-w", "500",       # ожидание ответа узла, мс (по умолчанию 4000)
                "-h", "20",        # не дальше 20 узлов
                host,
            ],
            "TRACERT",
            host,
            port,
        )

    # ========================================================================
    # COMMAND DISCOVERY
    # ========================================================================

    @staticmethod
    def _find_windows_command(
        command: str,
    ) -> str | None:
        """
        Возвращает путь к системной команде.

        Сначала пробуем стандартное имя.
        Windows сама разрешит .exe через PATH.
        """

        # QProcess умеет находить executable через PATH,
        # поэтому возвращаем имя команды.
        #
        # Дополнительная проверка не обязательна.
        if not command:
            return None

        return command

    # ========================================================================
    # ПОЛНАЯ ПРОВЕРКА / TCP-ПИНГ (JobWorker)
    # ========================================================================

    def _run_full(self) -> None:
        target = self._get_target_or_show_error()
        if target is None:
            return
        host, port = target
        terminal = self._terminal

        def job(w: JobWorker) -> None:
            check_dns(w, host)
            if w.cancelled:
                return
            check_tcp(w, host, port)
            if w.cancelled:
                return
            check_tls(w, host, port)
            if w.cancelled:
                return
            check_api(w, terminal)

        self._run_job("ПОЛНАЯ ПРОВЕРКА", host, port, job, report=True)

    def _run_tcp_ping(self) -> None:
        target = self._get_target_or_show_error()
        if target is None:
            return
        host, port = target
        continuous = self.continuous_check.isChecked()
        self._run_job("TCP-ПИНГ", host, port,
                      lambda w: check_tcp(w, host, port, continuous=continuous), report=False)

    def _run_job(self, title: str, host: str, port: int, job, report: bool) -> None:
        if self._job_thread is not None and self._job_thread.isRunning():
            return
        self._append_header(title, host, port)
        self._results = []
        self._job_title, self._job_report = title, report
        self._set_running(True)
        self._job_thread = QtCore.QThread(self)
        self._job_worker = JobWorker(job)
        self._job_worker.moveToThread(self._job_thread)
        self._job_thread.started.connect(self._job_worker.run)
        self._job_worker.line.connect(self._append)
        self._job_worker.step_done.connect(self._on_step_done)
        self._job_worker.finished.connect(self._job_thread.quit)
        self._job_worker.finished.connect(self._on_job_finished)
        self._job_thread.finished.connect(self._on_job_thread_finished)
        self._job_thread.finished.connect(self._job_worker.deleteLater)
        self._job_thread.start()

    def _on_step_done(self, step: str, status: str, text: str) -> None:
        self._results.append((step, status, text))

    def _on_job_finished(self) -> None:
        if self._results:
            self._append("")
            self._append("ИТОГ")
            colors = {OK: _c("BUY", "#2ecc55"), WARN: "#e0a020", BAD: _c("SELL", "#e61e1e"),
                      SKIP: _c("TEXT_DIM", "#888888")}
            for step, status, text in self._results:
                self.console.append(
                    f"<span style='color:{colors.get(status, '')}'>{MARK.get(status, '?')}</span> "
                    f"<b>{html.escape(step)}</b>: {html.escape(text)}")
                self._log_line(f"{MARK.get(status, '?')} {step}: {text}")
            worst = max((st for _, st, _ in self._results if st != SKIP), default=OK, key=[OK, WARN, BAD].index)
            verdict = {OK: "Связь с Finam в порядке.",
                       WARN: "Связь работает, но есть замечания (⚠ выше).",
                       BAD: "Есть проблема (✖ выше) — с ней стоит разобраться."}[worst]
            self._append(verdict)
        self._append(f"--- {self._job_title.lower()}: завершено ---")
        if self._job_report:
            self._save_report()
        self._set_running(False)

    def _on_job_thread_finished(self) -> None:
        thread = self._job_thread
        self._job_worker = None
        self._job_thread = None
        if thread is not None:
            thread.deleteLater()

    def _report_text(self) -> str:
        return self.console.toPlainText()

    def _save_report(self) -> None:
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            path = LOG_DIR / f"diagnostics_{time.strftime('%Y-%m-%d_%H%M%S')}.txt"
            path.write_text(self._report_text(), encoding="utf-8")
            self._append(f"Отчёт: {path}")
        except OSError as exc:
            self._append(f"Отчёт не сохранён: {exc}")

    def _copy_report(self) -> None:
        QtWidgets.QApplication.clipboard().setText(self._report_text())
        self.target_label.setText("Отчёт скопирован в буфер обмена")

    # ========================================================================
    # TELNET / TCP
    # ========================================================================

    def _run_telnet(self) -> None:
        """
        TCP-проверка выбранного host:port.
        """

        if (
            self._port_thread is not None
            and self._port_thread.isRunning()
        ):
            return

        target = self._get_target_or_show_error()

        if target is None:
            return

        host, port = target

        self._append_header(
            "TCP / TELNET",
            host,
            port,
        )

        self._set_running(True)

        self._port_thread = QtCore.QThread(
            self
        )

        self._port_worker = PortCheckWorker(
            host,
            port,
            timeout=5.0,
        )

        self._port_worker.moveToThread(
            self._port_thread
        )

        # Поток запускает worker.
        self._port_thread.started.connect(
            self._port_worker.run
        )

        # Вывод worker → консоль.
        self._port_worker.line.connect(
            self._append
        )

        # Worker завершил работу.
        self._port_worker.finished.connect(
            self._port_thread.quit
        )

        self._port_worker.finished.connect(
            self._on_port_worker_finished
        )

        # После завершения thread объект worker
        # удаляется через Qt event loop.
        self._port_thread.finished.connect(
            self._on_port_thread_finished
        )

        self._port_thread.finished.connect(
            self._port_worker.deleteLater
        )

        self._port_thread.start()

    def _on_port_worker_finished(self) -> None:
        """
        Worker закончил TCP-проверку.
        """

        self._append(
            "--- TCP-проверка завершена ---"
        )

        # Кнопки можно вернуть сразу.
        self._set_running(False)

    def _on_port_thread_finished(self) -> None:
        """
        Поток TCP-проверки полностью завершился.
        """

        thread = self._port_thread

        self._port_worker = None
        self._port_thread = None

        if thread is not None:
            thread.deleteLater()

    # ========================================================================
    # STOP
    # ========================================================================

    def _stop_running(self) -> None:
        """
        Останавливает текущую диагностику.
        """

        stopped_something = False

        # --------------------------------------------------------------------
        # QProcess
        # --------------------------------------------------------------------

        process = self._process

        if process is not None:
            stopped_something = True

            self._append(
                "Остановка процесса..."
            )

            self._process_output_buffer = b""

            process.kill()

            # waitForFinished здесь НЕ используем,
            # чтобы не блокировать GUI.
            #
            # finished-сигнал сам завершит обработку.
            self._set_running(False)

        # --------------------------------------------------------------------
        # TCP worker
        # --------------------------------------------------------------------

        worker = self._port_worker

        if worker is not None:
            stopped_something = True

            self._append(
                "Запрошена остановка TCP-проверки..."
            )

            worker.cancel()

        job = self._job_worker
        if job is not None:
            stopped_something = True
            self._append("Запрошена остановка проверки...")
            job.cancel()                 # шаг закончит текущее подключение (до нескольких секунд) и выйдет

        if not stopped_something:
            self._set_running(False)

    # ========================================================================
    # CLOSE
    # ========================================================================

    def closeEvent(
        self,
        event: QtGui.QCloseEvent,
    ) -> None:
        """
        Корректно закрывает процессы и TCP-поток.
        """

        # ------------------------------------------------------------
        # QProcess
        # ------------------------------------------------------------

        if self._process is not None:
            try:
                self._process.kill()
            except RuntimeError:
                pass

            self._process = None

        # ------------------------------------------------------------
        # TCP worker
        # ------------------------------------------------------------

        worker = self._port_worker

        if worker is not None:
            try:
                worker.cancel()
            except RuntimeError:
                pass

        job = self._job_worker
        if job is not None:
            try:
                job.cancel()
            except RuntimeError:
                pass
        job_thread = self._job_thread
        if job_thread is not None and job_thread.isRunning():
            job_thread.quit()
            if not job_thread.wait(6000):        # TLS / API-запрос может ждать до ~5 с
                job_thread.terminate()
                job_thread.wait(500)
            self._job_thread = None
            self._job_worker = None

        thread = self._port_thread

        if thread is not None:
            # Worker после cancel должен выйти очень быстро.
            #
            # Не вызываем terminate() без необходимости:
            # принудительное убийство Qt-потока может оставить
            # ресурсы в некорректном состоянии.
            if thread.isRunning():
                thread.quit()

                if not thread.wait(1500):
                    # В нормальной ситуации сюда попадать не должны.
                    #
                    # terminate() оставляем как последний защитный
                    # вариант при закрытии приложения.
                    thread.terminate()
                    thread.wait(500)

            self._port_thread = None
            self._port_worker = None

        super().closeEvent(event)
