# -*- coding: utf-8 -*-
"""Детекторы вкладки «Алгоритмы» — на Rust (fx_engine); Python-версии — эталон в проверках.

Вкладка создаёт детекторы только через фабрики этого модуля:
    price_move_detector(symbol) — «Цена»: резкое движение (эталон algo_core.PriceMoveDetector);
    volume_surge(symbol)        — «Рост оборота» (algo_core.VolumeSurge);
    escalation_detector(symbol) — «Наращивание» / POV (escalation_detector.EscalationDetector);
    mm_detector(symbol, sensitivity) — следы маркет-мейкера (mm_detector.MMDetector).

С 2.1.38 все четыре считает только Rust (fx_engine 0.4.0 и новее), запасного Python в работе нет:
    * этап 1 («Цена», «Рост оборота», «Наращивание») — на Rust с 2.1.23, за 10–11.11 около 6,3 млн вызовов
      в тени без единого расхождения с Python и без ошибок;
    * этап 2 (маркет-мейкер) — неделя в тени (с 2.1.12), за 11.11 — 1,65 млн вызовов без расхождений.
Эталоны на Python остаются в репозитории: с ними Rust сверяется в tests/test_algo_rust.py (при установке
каждого обновления), ими же собираются события и тексты (Rust отдаёт только числа; Rs* ниже приводят ответ
к виду эталона: escalation_detector.make_event, mm_detector.event_from_numbers / describe).

Что бывает вместо запасного варианта:
    * модуля fx_engine нет или он старый — детекторы «Алгоритмов» не работают (ответ «ничего»), в журнале
      об этом строка при запуске: модуль нужно пересобрать (обновление с пересборкой Rust);
    * Rust-детектор инструмента выдал ошибку — строка в журнал, детектор этого инструмента создаётся заново
      (накопленное окно теряется); MAX_ERRORS ошибок — детектор этого инструмента выключен до перезапуска.

Сверка «в тени» (_Pair, Shadow*, ShadowStats) в работе больше не используется: оставлена для проверок и для
следующих детекторов (этап 3 — робот, айсберг, спредовый робот), которые пойдут тем же путём: Rust в тени
рядом с Python, потом Rust.
"""
from __future__ import annotations

import csv
import sys
import time
from datetime import datetime
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)

import escalation_detector as esc_ref      # имя escalation_detector занято фабрикой ниже
import mm_detector as mm_ref              # имя mm_detector занято фабрикой ниже

LOG_DIR = app_paths.LOG_DIR
CSV_PREFIX = "rust_algo_"
DETAILS_PER_MINUTE = 5           # подробных строк о расхождениях в журнал — не больше стольких в минуту
DETAIL_MAX_CHARS = 1500          # строка о расхождении не длиннее (снимок стакана в аргументах — длинный)
NEEDED = ("PriceMoveDetector", "VolumeSurge", "EscalationDetector", "MMDetector")   # fx_engine 0.4.0 и новее
NEEDED_MM = "MMDetector"         # (имя оставлено для проверок)
MAX_ERRORS = 3                   # столько ошибок Rust у детектора инструмента — и он выключен до перезапуска

OLD_SHADOW_LOGS = ("rust_shadow_*.csv", "rust_book_*.csv", "rust_algo_*.csv")   # журналы сверок «в тени»

_engine_module = None            # None — ещё не пробовали; False — модуля с детекторами нет; иначе fx_engine


def drop_old_shadow_logs(folder=None) -> int:
    """Удалить из logs журналы сверок «в тени» (2.1.57): сверка по сделкам (rust_shadow_*.csv) и сверка стакана
    (rust_book_*.csv) убраны из терминала, сверка детекторов (rust_algo_*.csv) не пишется с 2.1.38, когда детекторы
    перешли на Rust. Возвращает, сколько файлов удалено; занятый или защищённый файл пропускается."""
    removed = 0
    for pattern in OLD_SHADOW_LOGS:
        for path in Path(folder or LOG_DIR).glob(pattern):
            try:
                path.unlink()
                removed += 1
            except OSError:
                pass
    return removed


def _engine():
    """Модуль fx_engine с детекторами «Алгоритмов». None — модуля нет или он старый: детекторы не работают
    (строка в журнал — один раз)."""
    global _engine_module
    if _engine_module is None:
        _engine_module = False
        try:
            import fx_engine
            missing = [name for name in NEEDED if not hasattr(fx_engine, name)]
            if missing:
                print(f"[rust-алгоритмы] в fx_engine {getattr(fx_engine, '__version__', '?')} нет "
                      f"{', '.join(missing)} — детекторы «Алгоритмов» (цена, рост оборота, наращивание, "
                      "маркет-мейкер) НЕ РАБОТАЮТ: нужен модуль 0.4.0 или новее (обновление с пересборкой Rust)",
                      file=sys.stderr)
            else:
                _engine_module = fx_engine
                print(f"[rust-алгоритмы] «Цену», «Рост оборота», «Наращивание» и маркет-мейкера считает Rust "
                      f"(fx_engine {fx_engine.__version__})")
        except Exception as exc:
            print(f"[rust-алгоритмы] модуль fx_engine не загружен ({type(exc).__name__}: {exc}) — детекторы "
                  "«Алгоритмов» (цена, рост оборота, наращивание, маркет-мейкер) НЕ РАБОТАЮТ: модуль нужно "
                  "собрать (обновление с пересборкой Rust)", file=sys.stderr)
    return _engine_module or None


# ---- Python-обёртки Rust-детекторов: тот же API и вид ответа, что у эталонов -------------------------------

class RsPriceMoveDetector:
    def __init__(self, rust_obj):
        self._o = rust_obj

    def on_price(self, now, price, window, pct):
        return self._o.on_price(float(now), float(price), float(window), float(pct))


class RsVolumeSurge:
    def __init__(self, rust_obj):
        self._o = rust_obj

    def add(self, sec, lots, is_buy, turnover, period) -> None:
        self._o.add(int(sec), float(lots), bool(is_buy), float(turnover or 0), int(period))

    def check(self, min_lots, ratio):
        hit = self._o.check(float(min_lots or 0), float(ratio or 0))
        if hit is None:
            return None
        lots, buy_share, turnover, usual, times = hit
        return {"lots": lots, "buy_share": buy_share, "turnover": turnover, "usual": usual, "ratio": times}

    def baseline(self):
        return self._o.baseline()


class RsEscalationDetector:
    def __init__(self, symbol: str, rust_obj):
        self.symbol = symbol
        self._o = rust_obj

    def configure(self, min_links=4, growth=1.3, tolerance=0.3, min_first=1.0, min_total=0.0) -> None:
        self._o.configure(int(min_links), float(growth), float(tolerance), float(min_first), float(min_total))

    def _events(self, raw) -> list[dict]:
        return [esc_ref.make_event(self.symbol, *fields) for fields in raw]

    def on_order(self, ts, side, volume, price) -> list[dict]:
        return self._events(self._o.on_order(float(ts), str(side), float(volume), float(price)))

    def flush(self, now) -> list[dict]:
        return self._events(self._o.flush(float(now)))


class RsMMDetector:
    """fx_engine.MMDetector с API эталона: события — словари как у mm_detector.MMDetector (с текстом)."""

    def __init__(self, symbol: str, rust_obj):
        self.symbol = symbol
        self._o = rust_obj

    @property
    def sensitivity(self) -> str:
        return self._o.sensitivity

    def configure(self, sensitivity="normal") -> None:
        self._o.configure(str(sensitivity))

    def _events(self, raw) -> list[dict]:
        return [mm_ref.event_from_numbers(self.symbol, *fields) for fields in raw]

    def on_trade(self, mono, price, volume, side, lag=0.0) -> list[dict]:
        return self._events(self._o.on_trade(float(mono), float(price), float(volume), side, float(lag)))

    def on_book(self, mono, bids, asks) -> list[dict]:
        return self._events(self._o.on_book(float(mono), list(bids.items()), list(asks.items())))


# ---- сверка ---------------------------------------------------------------------------------------------

class ShadowStats:
    """Счётчики тени по детекторам; раз в минуту — строка в CSV и итог в журнал терминала."""

    def __init__(self, log_dir: Path = LOG_DIR):
        self.log_dir = log_dir
        self.minute = None
        self.rows: dict[str, list] = {}        # детектор -> [вызовов, расхождений, нс Python, нс Rust, ошибок]
        self.details = 0

    def _roll(self) -> None:
        minute = int(time.time() // 60)
        if self.minute is None:
            self.minute = minute
        elif minute != self.minute:
            self.flush()
            self.minute = minute

    def count(self, name: str, py_ns: int, rs_ns: int, mismatch: bool) -> None:
        self._roll()
        row = self.rows.setdefault(name, [0, 0, 0, 0, 0])
        row[0] += 1
        row[1] += 1 if mismatch else 0
        row[2] += py_ns
        row[3] += rs_ns

    def error(self, name: str) -> None:
        self._roll()
        self.rows.setdefault(name, [0, 0, 0, 0, 0])[4] += 1

    def detail(self, text: str) -> None:
        self._roll()
        if self.details < DETAILS_PER_MINUTE:
            self.details += 1
            if len(text) > DETAIL_MAX_CHARS:
                text = text[:DETAIL_MAX_CHARS] + " …"
            print(f"[rust-алгоритмы] расхождение: {text}", file=sys.stderr)

    def flush(self) -> None:
        """Записать накопленное за минуту (вызывается сама при смене минуты)."""
        rows, self.rows, self.details = self.rows, {}, 0
        if not rows or self.minute is None:
            return
        stamp = datetime.fromtimestamp(self.minute * 60).strftime("%Y-%m-%d %H:%M")
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            path = self.log_dir / f"{CSV_PREFIX}{stamp[:10]}.csv"
            new = not path.exists()
            with path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if new:
                    writer.writerow(["time", "detector", "calls", "mismatches", "py_us_per_call", "rust_us_per_call",
                                     "rust_errors"])
                for name, (calls, bad, py_ns, rs_ns, errors) in sorted(rows.items()):
                    writer.writerow([stamp, name, calls, bad, f"{py_ns / max(1, calls) / 1000:.2f}",
                                     f"{rs_ns / max(1, calls) / 1000:.2f}", errors])
        except OSError as exc:
            print(f"[rust-алгоритмы] журнал не записан: {exc}", file=sys.stderr)
        calls = sum(r[0] for r in rows.values())
        bad = sum(r[1] for r in rows.values())
        errors = sum(r[4] for r in rows.values())
        parts = ", ".join(f"{name} {r[0]}" for name, r in sorted(rows.items()))
        py_us = sum(r[2] for r in rows.values()) / max(1, calls) / 1000
        rs_us = sum(r[3] for r in rows.values()) / max(1, calls) / 1000
        print(f"[rust-алгоритмы] {stamp}: вызовов {calls} ({parts}), расхождений {bad}"
              + (f", ошибок Rust {errors}" if errors else "")
              + f"; Python {py_us:.1f} мкс, Rust {rs_us:.1f} мкс на вызов")


STATS = ShadowStats()


def _same(a, b) -> bool:
    """Точное совпадение ответов (числа — до последнего знака)."""
    return a == b


class _Pair:
    """Эталон на Python + Rust-версия с тем же API: ответы сверяются. Наружу — ответ Python, а с
    rust_out=True (детекторы этапа 1, с 2.1.23) — ответ Rust; после ошибки Rust — снова Python."""

    def __init__(self, name: str, symbol: str, py, rs, stats: ShadowStats = None, rust_out: bool = False):
        self._name, self._symbol, self._py, self._rs = name, symbol, py, rs
        self._stats = stats or STATS
        self._rust_out = bool(rust_out)

    def _call(self, method: str, *args):
        t0 = time.perf_counter_ns()
        result = getattr(self._py, method)(*args)
        t1 = time.perf_counter_ns()
        rs = self._rs
        if rs is None:
            return result
        try:
            other = getattr(rs, method)(*args)
        except Exception as exc:
            self._rs = None                          # Rust этого детектора выключен, Python — как раньше
            self._stats.error(self._name)
            print(f"[rust-алгоритмы] {self._name} {self._symbol}: ошибка Rust в {method} — {type(exc).__name__}: "
                  f"{exc}; дальше только Python", file=sys.stderr)
            return result
        t2 = time.perf_counter_ns()
        bad = not _same(result, other)
        self._stats.count(self._name, t1 - t0, t2 - t1, bad)
        if bad:
            self._stats.detail(f"{self._name} {self._symbol} {method}{args!r}: Python {result!r}, Rust {other!r}")
        return other if self._rust_out else result


class ShadowPriceMoveDetector(_Pair):
    def on_price(self, now, price, window, pct):
        return self._call("on_price", now, price, window, pct)


class ShadowVolumeSurge(_Pair):
    def add(self, sec, lots, is_buy, turnover, period) -> None:
        self._call("add", sec, lots, is_buy, turnover, period)

    def check(self, min_lots, ratio):
        return self._call("check", min_lots, ratio)

    def baseline(self):
        return self._py.baseline()


class ShadowEscalationDetector(_Pair):
    def configure(self, *args, **kwargs) -> None:
        self._py.configure(*args, **kwargs)
        if self._rs is not None:
            try:
                self._rs.configure(*args, **kwargs)
            except Exception as exc:
                self._rs = None
                self._stats.error(self._name)
                print(f"[rust-алгоритмы] {self._name} {self._symbol}: ошибка Rust в configure — {exc}",
                      file=sys.stderr)

    def on_order(self, ts, side, volume, price) -> list[dict]:
        return self._call("on_order", ts, side, volume, price)

    def flush(self, now) -> list[dict]:
        return self._call("flush", now)


class _RustOnly:
    """Рабочий детектор: только Rust (с 2.1.38). make_rs создаёт Rust-детектор (в обёртке Rs*); None или ошибка
    при создании — детектор выключен. Ошибка в вызове — строка в журнал и детектор создаётся заново (_restore —
    вернуть ему настройки); MAX_ERRORS ошибок — выключен до перезапуска. Выключенный отвечает «ничего»."""

    def __init__(self, name: str, symbol: str, make_rs=None):
        self._name, self._symbol, self._make_rs, self._errors = name, symbol, make_rs, 0
        self._rs = self._create()

    def _create(self):
        if self._make_rs is None:
            return None
        try:
            return self._make_rs()
        except Exception as exc:
            print(f"[rust-алгоритмы] {self._name} {self._symbol}: Rust-детектор не создан — "
                  f"{type(exc).__name__}: {exc}; детектор выключен", file=sys.stderr)
            return None

    def _restore(self) -> None:
        """Вернуть заново созданному детектору настройки (у кого они есть)."""

    def _failed(self, method: str, exc: Exception) -> None:
        self._errors += 1
        STATS.error(self._name)
        off = self._errors >= MAX_ERRORS
        print(f"[rust-алгоритмы] {self._name} {self._symbol}: ошибка Rust в {method} — {type(exc).__name__}: "
              f"{exc}; " + ("детектор выключен до перезапуска терминала" if off
                            else "детектор создан заново (накопленное окно потеряно)"), file=sys.stderr)
        self._rs = None if off else self._create()
        if self._rs is not None:
            try:
                self._restore()
            except Exception:
                self._rs = None

    def _call(self, method: str, *args, default=None):
        if self._rs is None:
            return default
        try:
            return getattr(self._rs, method)(*args)
        except Exception as exc:
            self._failed(method, exc)
            return default


class RustPriceMove(_RustOnly):
    def on_price(self, now, price, window, pct):
        return self._call("on_price", now, price, window, pct)


class RustVolumeSurge(_RustOnly):
    def add(self, sec, lots, is_buy, turnover, period) -> None:
        self._call("add", sec, lots, is_buy, turnover, period)

    def check(self, min_lots, ratio):
        return self._call("check", min_lots, ratio)

    def baseline(self):
        return self._call("baseline")


class RustEscalation(_RustOnly):
    """Настройки запоминаются: детектор, созданный заново после ошибки, получает их же."""

    def __init__(self, name: str, symbol: str, make_rs=None):
        self._config = None
        super().__init__(name, symbol, make_rs)

    def _restore(self) -> None:
        if self._config is not None:
            self._rs.configure(*self._config[0], **self._config[1])

    def configure(self, *args, **kwargs) -> None:
        self._config = (args, kwargs)
        self._call("configure", *args, **kwargs)

    def on_order(self, ts, side, volume, price) -> list[dict]:
        return self._call("on_order", ts, side, volume, price, default=[])

    def flush(self, now) -> list[dict]:
        return self._call("flush", now, default=[])


class RustMM(_RustOnly):
    """Маркет-мейкер на Rust. Чувствительность запоминается: её отдаёт sensitivity (и у выключенного
    детектора) и получает детектор, созданный заново после ошибки."""

    def __init__(self, name: str, symbol: str, make_rs=None, sensitivity: str = "normal"):
        self._sensitivity = str(sensitivity)
        super().__init__(name, symbol, make_rs)

    @property
    def sensitivity(self) -> str:
        return self._sensitivity

    def _restore(self) -> None:
        self._rs.configure(self._sensitivity)

    def configure(self, sensitivity="normal") -> None:
        self._sensitivity = str(sensitivity)
        self._call("configure", self._sensitivity)

    def on_trade(self, mono, price, volume, side, lag=0.0) -> list[dict]:
        return self._call("on_trade", mono, price, volume, side, lag, default=[])

    def on_book(self, mono, bids, asks) -> list[dict]:
        return self._call("on_book", mono, bids, asks, default=[])


class ShadowMMDetector(_Pair):
    """Маркет-мейкер: каждая сделка и каждый снимок стакана — в обе версии, наружу — события Python."""

    @property
    def sensitivity(self) -> str:
        return self._py.sensitivity

    def configure(self, sensitivity="normal") -> None:
        self._py.configure(sensitivity)
        if self._rs is not None:
            try:
                self._rs.configure(sensitivity)
            except Exception as exc:
                self._rs = None
                self._stats.error(self._name)
                print(f"[rust-алгоритмы] {self._name} {self._symbol}: ошибка Rust в configure — {exc}",
                      file=sys.stderr)

    def on_trade(self, mono, price, volume, side, lag=0.0) -> list[dict]:
        return self._call("on_trade", mono, price, volume, side, lag)

    def on_book(self, mono, bids, asks) -> list[dict]:
        return self._call("on_book", mono, bids, asks)


# ---- фабрики --------------------------------------------------------------------------------------------
# Модуля нет — make_rs = None: детектор выключен (о причине — строка _engine() при запуске).

def price_move_detector(symbol: str = ""):
    engine = _engine()
    return RustPriceMove("цена", symbol,
                         None if engine is None else lambda: RsPriceMoveDetector(engine.PriceMoveDetector()))


def volume_surge(symbol: str = ""):
    engine = _engine()
    return RustVolumeSurge("оборот", symbol,
                           None if engine is None else lambda: RsVolumeSurge(engine.VolumeSurge()))


def escalation_detector(symbol: str):
    engine = _engine()
    return RustEscalation("наращивание", symbol,
                          None if engine is None else lambda: RsEscalationDetector(symbol, engine.EscalationDetector()))


def mm_detector(symbol: str, sensitivity: str = "normal"):
    """Детектор маркет-мейкера на Rust (с 2.1.38; до того — Python, Rust в тени)."""
    engine = _engine()
    return RustMM("маркет-мейкер", symbol,
                  None if engine is None else lambda: RsMMDetector(symbol, engine.MMDetector(str(sensitivity))),
                  sensitivity)
