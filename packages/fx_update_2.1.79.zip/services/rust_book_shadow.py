# -*- coding: utf-8 -*-
"""
С 2.1.57 сверка стакана «в тени» из терминала убрана (шлюз её не создаёт и сообщения в неё не подаёт): стакан с
30.10 строит сам Rust (brokers/finam/raw_book.py), а тень сверяла только стаканы, идущие через SDK. В работе из
этого модуля используется только schema_from_message (номера полей protobuf для BookEngine); классы сверки
остались для проверок и уйдут вместе с модулем при следующей пересборке fx_engine.

Rust-тень стакана (этап 1 Rust-шлюза): тот же поток Finam SubscribeOrderBook, что разбирает Python-шлюз,
параллельно разбирает Rust (fx_engine.BookEngine, fx_engine_rs/src/book.rs) — из двоичного protobuf, сам,
без SDK. После каждого сообщения стаканы сравниваются. На окна, детекторы и торговлю не влияет:
наружу по-прежнему уходит стакан Python.

Включается вместе с тенью сделок:
    $env:FX_RUST_SHADOW=1; python gui_app.py
Нужен fx_engine 0.2+ (с BookEngine); старый модуль — тень стакана просто не включается (в журнале
об этом строка).

Что пишется (раз в минуту, logs/rust_book_ГГГГ-ММ-ДД.csv и строка в журнал):
    msgs             — сообщений стакана за минуту (все инструменты);
    py_ms            — Python: применение сообщения (BookState.apply) + снимок OrderBook — то, что
                       Rust заменит; разбор protobuf внутри gRPC сюда не входит (его видно в
                       «ЦП шлюза book · приём»), а в Rust он входит;
    ser_ms           — сериализация сообщения обратно в байты для тени (на этапе 2 её не будет:
                       байты возьмём у gRPC без разбора);
    rust_ms          — Rust: разбор байтов + применение + снимок списками в Python;
    rust_full_ms     — то же + OrderBook из пар (как в шлюзе) — полная замена Python-пути;
    mismatch         — сообщений, после которых стаканы Python и Rust различаются (ожидается 0);
    errors           — сообщений, которые Rust не смог разобрать;
    levels           — среднее число уровней в стакане (покупки + продажи).
Внимание: при включённой тени строка «шлюз book» замера нагрузки включает и работу тени.

Номера полей protobuf берутся из описания сообщений установленного SDK (msg.DESCRIPTOR) при первом
сообщении — разбор Rust совпадает с той версией протокола, что реально приходит.
"""
from __future__ import annotations

import csv
import os
import sys
import threading
import time
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)

ENV = "FX_RUST_SHADOW"
CSV_PREFIX = "rust_book_"
PRICE_TOL = 1e-9
LOG_FOLDER = app_paths.LOG_DIR
MAX_MISMATCH_REPORTS = 5            # подробности первых расхождений — в журнал (дальше только счётчик)


def enabled() -> bool:
    return os.getenv(ENV, "").strip() in ("1", "true", "yes", "on")


def schema_from_message(msg, remove_action: int) -> dict:
    """Номера полей SubscribeOrderBookResponse / StreamOrderBook / Row / Decimal из описания сообщения."""
    resp = msg.DESCRIPTOR
    ob_field = resp.fields_by_name["order_book"]
    ob = ob_field.message_type
    row = ob.fields_by_name["rows"].message_type
    price = row.fields_by_name["price"]

    def number(desc, name) -> int:
        f = desc.fields_by_name.get(name)
        return int(f.number) if f is not None else 0

    return {
        "resp_order_book": int(ob_field.number),
        "ob_rows": number(ob, "rows"),
        "ob_snapshot": number(ob, "is_data_snapshot"),
        "row_price": int(price.number),
        "row_buy": number(row, "buy_size"),
        "row_sell": number(row, "sell_size"),
        "row_action": number(row, "action"),
        "action_remove": int(remove_action),
        "decimal_value": number(price.message_type, "value") or 1,
    }


def _sorted_levels(book) -> tuple[list, list]:
    """Стакан Python (BookState) в том же виде, что снимок Rust."""
    return (sorted(book.bids.items(), key=lambda kv: -kv[0]), sorted(book.asks.items(), key=lambda kv: kv[0]))


def _same(py_side: list, rust_side: list) -> bool:
    if len(py_side) != len(rust_side):
        return False
    for (pp, pv), (rp, rv) in zip(py_side, rust_side):
        if abs(pp - rp) > PRICE_TOL or pv != rv:
            return False
    return True


class BookShadow:
    """Тень стакана для всех инструментов шлюза. Вызовы feed — из потоков стакана (по потоку на
    инструмент); у каждого инструмента свой BookEngine, общая только статистика (под замком)."""

    def __init__(self, fx_engine, log, folder: Path | None = LOG_FOLDER):
        self._fx = fx_engine
        self._log = log
        self.folder = folder
        self._engines: dict = {}
        self._schema: dict | None = None
        self._lock = threading.Lock()
        self._minute = self._minute_key()
        self._stats = self._empty()
        self._reported = 0
        self.total_mismatch = 0
        self.total_msgs = 0

    @staticmethod
    def _minute_key() -> str:
        return time.strftime("%Y-%m-%d %H:%M")

    @staticmethod
    def _empty() -> dict:
        return {"msgs": 0, "py": 0.0, "ser": 0.0, "rust": 0.0, "full": 0.0, "mismatch": 0, "errors": 0,
                "levels": 0}

    # ---- жизненный цикл стакана инструмента
    def reset(self, iid) -> None:
        """Подписка на стакан заново (шлюз начинает с чистого стакана) — и тень тоже."""
        with self._lock:
            self._engines.pop(iid, None)

    def forget(self, iid) -> None:
        self.reset(iid)

    # ---- основное
    def feed(self, iid, msg, py_book, py_changed: bool, py_seconds: float, remove_action: int) -> None:
        try:
            self._feed(iid, msg, py_book, py_changed, py_seconds, remove_action)
        except Exception as exc:                        # тень не должна мешать шлюзу
            with self._lock:
                self._stats["errors"] += 1
            if self._reported < MAX_MISMATCH_REPORTS:
                self._reported += 1
                self._log(f"[rust-тень стакана] ошибка: {type(exc).__name__}: {exc}")

    def _feed(self, iid, msg, py_book, py_changed, py_seconds, remove_action) -> None:
        with self._lock:
            if self._schema is None:
                self._schema = schema_from_message(msg, remove_action)
                self._log(f"[rust-тень стакана] схема полей из SDK: {self._schema}")
            engine = self._engines.get(iid)
            if engine is None:
                engine = self._engines[iid] = self._fx.BookEngine(self._schema)
        t0 = time.perf_counter()
        raw = msg.SerializeToString()
        t1 = time.perf_counter()
        errors = 0
        try:
            changed = engine.apply(raw)
        except ValueError:
            changed, errors = None, 1
        bids, asks = engine.snapshot()
        t2 = time.perf_counter()
        _build_orderbook(iid, bids, asks)                  # как шлюз: OrderBook из пар
        t3 = time.perf_counter()

        py_bids, py_asks = _sorted_levels(py_book)
        same = _same(py_bids, bids) and _same(py_asks, asks) and (changed is None or changed == py_changed)
        if not same and self._reported < MAX_MISMATCH_REPORTS:
            self._reported += 1
            self._log(f"[rust-тень стакана] расхождение {iid}: Python {len(py_bids)}/{len(py_asks)} уровней, "
                      f"лучшие {py_bids[:1]} / {py_asks[:1]}; Rust {len(bids)}/{len(asks)}, {bids[:1]} / {asks[:1]}; "
                      f"изменился: Python {py_changed}, Rust {changed}")
        with self._lock:
            st = self._stats
            st["msgs"] += 1
            st["py"] += py_seconds
            st["ser"] += t1 - t0
            st["rust"] += t2 - t1
            st["full"] += t3 - t1
            st["mismatch"] += 0 if same else 1
            st["errors"] += errors
            st["levels"] += len(bids) + len(asks)
            self.total_msgs += 1
            self.total_mismatch += 0 if same else 1
            minute = self._minute_key()
            row = None
            if minute != self._minute:
                row = (self._minute, self._stats)
                self._minute, self._stats = minute, self._empty()
        if row is not None:
            self._write(*row)

    def flush(self) -> None:
        with self._lock:
            row = (self._minute, self._stats) if self._stats["msgs"] else None
            self._stats = self._empty()
        if row is not None:
            self._write(*row)

    def _write(self, minute: str, st: dict) -> None:
        n = st["msgs"]
        if n == 0:
            return
        values = [minute, n, f"{st['py'] * 1000:.3f}", f"{st['ser'] * 1000:.3f}", f"{st['rust'] * 1000:.3f}",
                  f"{st['full'] * 1000:.3f}", f"{st['py'] / n * 1e6:.2f}", f"{st['rust'] / n * 1e6:.2f}",
                  f"{st['full'] / n * 1e6:.2f}", st["mismatch"], st["errors"], st["levels"] // n]
        self._log(f"[rust-тень стакана] {minute}: сообщений {n}, Python {st['py'] / n * 1e6:.1f} мкс, "
                  f"Rust {st['rust'] / n * 1e6:.1f} мкс (с OrderBook {st['full'] / n * 1e6:.1f}), "
                  f"расхождений {st['mismatch']}, ошибок {st['errors']}, уровней {st['levels'] // n}")
        if self.folder is None:
            return
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            path = self.folder / f"{CSV_PREFIX}{minute[:10]}.csv"
            new = not path.exists()
            with path.open("a", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh)
                if new:
                    writer.writerow(["time", "msgs", "py_ms", "ser_ms", "rust_ms", "rust_full_ms",
                                     "py_us_per_msg", "rust_us_per_msg", "rust_full_us_per_msg",
                                     "mismatch", "errors", "levels"])
                writer.writerow(values)
        except OSError as exc:
            self._log(f"[rust-тень стакана] CSV не записан: {exc}")


def _build_orderbook(iid, bids, asks):
    """Как шлюз (BookState.snapshot): OrderBook из пар (цена, объём)."""
    from core.models import OrderBook
    return OrderBook(iid, tuple(bids), tuple(asks), time.time())


def create(log=None, folder: Path | None = LOG_FOLDER) -> BookShadow | None:
    """Тень стакана, если включена (FX_RUST_SHADOW=1) и модуль fx_engine умеет BookEngine; иначе None."""
    log = log or (lambda text: print(text, file=sys.stderr))
    if not enabled():
        return None
    try:
        import fx_engine
    except ImportError:
        log("[rust-тень стакана] модуль fx_engine не установлен — тень стакана выключена")
        return None
    if not hasattr(fx_engine, "BookEngine"):
        log(f"[rust-тень стакана] fx_engine {getattr(fx_engine, '__version__', '?')} без BookEngine — "
            "пересоберите модуль (fx_engine_rs/README.txt)")
        return None
    log(f"[rust-тень стакана] fx_engine {getattr(fx_engine, '__version__', '?')}: стакан считается и в Rust")
    return BookShadow(fx_engine, log, folder)
