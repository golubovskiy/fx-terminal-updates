# -*- coding: utf-8 -*-
"""
Рисунки графиков между перезапусками и между терминалами: линии, прямоугольники, надписи,
линейка — по инструменту.

Хранится в chart_drawings.json рядом с терминалом (а не в настройках: в реестр Windows на каждое
движение линии писать незачем). Точки рисунков записаны во времени (секунды UTC) и цене, а не в
номере свечи, поэтому рисунок встаёт на те же свечи на любом таймфрейме и после подгрузки истории.

Все графики одного инструмента делят один набор рисунков: график сохранил набор — остальные
графики этого инструмента получают сигнал changed и перерисовывают его у себя.

Синхронизация между терминалами (drawings_sync.py) объединяет наборы по рисункам:
    у каждого рисунка постоянный id, время последней правки mt (мс) и устройство dev;
    удалённый рисунок остаётся «надгробием» {"id", "deleted": true, "mt", "dev"} на TOMBSTONE_DAYS
    дней — иначе другой терминал вернул бы его обратно;
    при объединении из двух версий одного рисунка остаётся более поздняя (mt, при равенстве — dev).

Формат записи рисунка (кроме id / mt / dev):
    {"kind": "text",      "t": время, "y": цена, "text": "..."}
    {"kind": "hline",     "y": цена, "alert": bool}
    {"kind": "trendline", "p": [[t, y], [t, y]], "alert": bool}
    {"kind": "rect",      "p": [[t0, y0], [t1, y1]]}
    {"kind": "ruler",     "p": [[t, y], [t, y]]}
    {"kind": "fib",       "p": [[t, y], [t, y]], "alert": bool, "levels": [[уровень, цвет, вкл], …],
                          "extend": "none|right|left|both", "fill": bool, "reverse": bool}
    {"kind": "pen",       "p": [[t, y], …], "color": "#rrggbb", "width": 2}   — штрих карандаша (chart_pen.py)
    у любого рисунка может быть "locked": true — заблокирован (не двигается мышью)

Алерты по линиям синхронизируются как часть рисунка, а звучат только там, где включено
«Алерты по линиям срабатывают на этом терминале» (alerts_here, настройка самого терминала).
"""
from __future__ import annotations

import copy
import json
import os
import sys
import time
import uuid
from pathlib import Path

import app_paths
from PySide6 import QtCore

# FX_DRAWINGS_FILE — другой файл (тесты пишут во временную папку, а не в рисунки терминала)
DRAWINGS_FILE = Path(os.environ.get("FX_DRAWINGS_FILE") or app_paths.DATA_DIR / "chart_drawings.json")
SAVE_DELAY_MS = 1000          # запись на диск не чаще раза в секунду (перетаскивание линии — десятки изменений)
KINDS = ("text", "hline", "trendline", "rect", "ruler", "fib", "pen")
META = ("id", "mt", "dev")    # служебные поля записи — не содержимое рисунка
TOMBSTONE_DAYS = 30           # сколько помнить удалённые рисунки (терминал, не включавшийся дольше, вернёт их)
TIME_TOLERANCE = 1.0          # с — пересчёт «время → номер свечи → время» даёт крошечные расхождения
PRICE_TOLERANCE = 1e-9        # доля цены

DEVICE_KEY = "sync/device_id"
ALERTS_HERE_KEY = "sync/alerts_here"


def _settings() -> QtCore.QSettings:
    return QtCore.QSettings("MyTradingTools", "FxTerminal")


_DEVICE: str | None = None


def device_id() -> str:
    """Постоянный номер этого терминала (FX_DEVICE_ID — свой, для тестов)."""
    global _DEVICE
    if _DEVICE is None:
        _DEVICE = os.environ.get("FX_DEVICE_ID") or ""
        if not _DEVICE:
            s = _settings()
            _DEVICE = str(s.value(DEVICE_KEY, "") or "")
            if not _DEVICE:
                _DEVICE = uuid.uuid4().hex[:12]
                s.setValue(DEVICE_KEY, _DEVICE)
    return _DEVICE


_ALERTS_HERE: bool | None = None


def alerts_here() -> bool:
    """Срабатывают ли алерты по линиям на этом терминале (по умолчанию — да)."""
    global _ALERTS_HERE
    if _ALERTS_HERE is None:
        _ALERTS_HERE = str(_settings().value(ALERTS_HERE_KEY, True)).lower() not in ("false", "0")
    return _ALERTS_HERE


def set_alerts_here(on: bool, settings: QtCore.QSettings | None = None) -> None:
    global _ALERTS_HERE
    _ALERTS_HERE = bool(on)
    (settings or _settings()).setValue(ALERTS_HERE_KEY, bool(on))


def new_id() -> str:
    return uuid.uuid4().hex


def _now_ms() -> int:
    return int(time.time() * 1000)


# ------------------------------------------------------------------ объединение (без Qt)

def _close(a, b, key: str = "") -> bool:
    """Равенство содержимого с допуском: время — TIME_TOLERANCE, цена — PRICE_TOLERANCE."""
    if isinstance(a, bool) or isinstance(b, bool) or isinstance(a, str) or isinstance(b, str):
        return a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if key == "t":
            return abs(a - b) <= TIME_TOLERANCE
        return abs(a - b) <= PRICE_TOLERANCE * max(1.0, abs(a), abs(b))
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return False
        if key == "p":           # [[t, y], …]: первое — время
            return all(_close(pa[0], pb[0], "t") and _close(pa[1], pb[1]) for pa, pb in zip(a, b))
        return all(_close(x, y) for x, y in zip(a, b))
    return a == b


def same_content(a: dict, b: dict) -> bool:
    ka = {k for k in a if k not in META}
    kb = {k for k in b if k not in META}
    return ka == kb and all(_close(a[k], b[k], k) for k in ka)


def _rank(rec: dict) -> tuple:
    return (int(rec.get("mt", 0) or 0), str(rec.get("dev", "")))


def merge_lists(local: list[dict], remote: list[dict]) -> list[dict]:
    """Объединение двух наборов одного инструмента по id: из двух версий — более поздняя.
    Порядок — как у local, новые из remote — в конце (порядок рисования)."""
    by_id: dict[str, dict] = {}
    order: list[str] = []
    for rec in list(local) + list(remote):
        rid = rec.get("id")
        if not rid:
            continue
        cur = by_id.get(rid)
        if cur is None:
            order.append(rid)
            by_id[rid] = rec
        elif _rank(rec) > _rank(cur):
            by_id[rid] = rec
    return [copy.deepcopy(by_id[rid]) for rid in order]


def purge_tombstones(records: list[dict], now_ms: int | None = None) -> list[dict]:
    limit = (now_ms if now_ms is not None else _now_ms()) - TOMBSTONE_DAYS * 86400_000
    return [r for r in records if not (r.get("deleted") and int(r.get("mt", 0) or 0) < limit)]


def merge_data(local: dict, remote: dict) -> dict:
    """Объединение всех инструментов; старые надгробия убираются."""
    out = {}
    for sym in list(local) + [s for s in remote if s not in local]:
        merged = purge_tombstones(merge_lists(local.get(sym, []), remote.get(sym, [])))
        if merged:
            out[sym] = merged
    return out


def normalize(drawings) -> dict:
    """Записи из файла (в том числе прежнего формата без id) -> {инструмент: [запись]}."""
    out = {}
    if not isinstance(drawings, dict):
        return out
    for sym, recs in drawings.items():
        if not isinstance(recs, list):
            continue
        good = []
        for r in recs:
            if not isinstance(r, dict):
                continue
            if r.get("deleted") and r.get("id"):
                good.append(dict(r))
            elif r.get("kind") in KINDS:
                r = dict(r)
                r.setdefault("id", new_id())        # файл первой версии: рисунки без id
                r.setdefault("mt", 0)
                r.setdefault("dev", "")
                good.append(r)
        if good:
            out[str(sym)] = good
    return out


def dumps(data: dict) -> str:
    return json.dumps({"version": 2, "drawings": data}, ensure_ascii=False, indent=1)


def loads(text: str) -> dict:
    raw = json.loads(text)
    return normalize(raw.get("drawings", {}) if isinstance(raw, dict) else {})


# ------------------------------------------------------------------ хранилище терминала

class DrawingsStore(QtCore.QObject):
    """Рисунки по инструментам: get / put, отложенная запись в файл, объединение с другим терминалом."""

    changed = QtCore.Signal(str, object)      # инструмент, кто изменил (график-источник; None — синхронизация)
    edited = QtCore.Signal()                  # правка на этом терминале — повод синхронизироваться

    def __init__(self, path: Path = DRAWINGS_FILE, parent=None):
        super().__init__(parent)
        self.path = Path(path)
        self._data: dict[str, list[dict]] = {}
        self._dirty = False            # есть изменения, ещё не записанные в файл
        self._load()
        self._timer = QtCore.QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.flush)
        app = QtCore.QCoreApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.flush)

    def _load(self) -> None:
        try:
            if self.path.is_file():
                self._data = loads(self.path.read_text(encoding="utf-8"))
        except Exception as exc:                                   # повреждённый файл — начинаем с пустого
            print(f"[график] {self.path.name} не прочитан: {type(exc).__name__}: {exc}", file=sys.stderr)
            self._data = {}

    def get(self, symbol: str) -> list[dict]:
        """Действующие рисунки инструмента (без надгробий)."""
        return [copy.deepcopy(r) for r in self._data.get(symbol or "", []) if not r.get("deleted")]

    def snapshot(self) -> dict:
        """Всё содержимое, включая надгробия — для синхронизации."""
        return copy.deepcopy(self._data)

    def put(self, symbol: str, records: list[dict], source=None) -> None:
        """Новый набор рисунков инструмента с графика. Неизменённым рисункам время правки не
        меняется, изменённым и новым — сейчас; пропавшие становятся надгробиями."""
        if not symbol:
            return
        now, dev = _now_ms(), device_id()
        old = {r["id"]: r for r in self._data.get(symbol, []) if r.get("id")}
        result, changed = [], False
        for rec in records:
            rid = rec.get("id") or new_id()
            prev = old.pop(rid, None)
            if prev is not None and not prev.get("deleted") and same_content(prev, rec):
                result.append(prev)
                continue
            fresh = {k: copy.deepcopy(v) for k, v in rec.items() if k not in META}
            fresh.update(id=rid, mt=now, dev=dev)
            result.append(fresh)
            changed = True
        for rid, prev in old.items():
            if prev.get("deleted"):
                result.append(prev)
            else:
                result.append({"id": rid, "deleted": True, "mt": now, "dev": dev})
                changed = True
        if not changed:
            return
        self._data[symbol] = result
        self._mark_dirty()
        self.changed.emit(symbol, source)
        self.edited.emit()

    def merge_remote(self, remote: dict) -> list[str]:
        """Объединить с набором другого терминала; графикам изменённых инструментов — changed."""
        merged = merge_data(self._data, remote)
        touched = [sym for sym in set(merged) | set(self._data)
                   if merged.get(sym, []) != self._data.get(sym, [])]
        if not touched:
            return []
        self._data = merged
        self._mark_dirty()
        for sym in touched:
            self.changed.emit(sym, None)
        return touched

    def _mark_dirty(self) -> None:
        self._dirty = True
        self._timer.start(SAVE_DELAY_MS)

    def flush(self) -> None:
        """Записать на диск сейчас, если есть изменения (через временный файл — обрыв записи
        не портит прежний)."""
        self._timer.stop()
        if not self._dirty:
            return
        self._dirty = False
        try:
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(dumps(self._data), encoding="utf-8")
            tmp.replace(self.path)
        except Exception as exc:
            print(f"[график] {self.path.name} не сохранён: {exc}", file=sys.stderr)


_STORE: DrawingsStore | None = None


def store() -> DrawingsStore:
    """Общее хранилище терминала (создаётся при первом обращении, после QApplication)."""
    global _STORE
    if _STORE is None:
        _STORE = DrawingsStore()
    return _STORE
