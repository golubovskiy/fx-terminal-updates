# -*- coding: utf-8 -*-
"""Сводка исходов событий маркет-мейкера по журналам logs/mm_events_ДАТА.csv — без Qt (2.1.12).

Что считается (по каждому инструменту и итогом):
    защита уровня — сколько эпизодов закончилось и сколько из них «уровень устоял» / «уровень пробит»;
    снятия        — итоги снятых крупных заявок: «ушли с дороги» (цена прошла через место) / «приманка»
                    (ушла в другую сторону); снятия с итогом «вывода нет» в журнал не попадают (PullJournal);
    поглощения, перестановки котировщика, серии приманок, паузы стакана — сколько было;
    чувствительность — с 2.1.12 в журнале есть колонка sens: защита и снятия ещё и по ней.

Журнал до 2.1.12 (без колонок outcome / sens) тоже читается: итог берётся из текста строки.
Окно «Алгоритмы» → настройки инструмента → «Маркет-мейкер» → «Сводка исходов…»; из PowerShell:
    python mm_summary.py          — за 7 дней
    python mm_summary.py 30       — за 30 дней
"""
from __future__ import annotations

import csv
import sys
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path

import app_paths
LOG_DIR = app_paths.LOG_DIR
PREFIX = "mm_events_"

# Итог строки журнала (колонка outcome с 2.1.12; для старых строк — по тексту)
HELD, BROKEN = "устоял", "пробит"
THROUGH, BAIT = "ушли с дороги", "приманка"


def outcome_of(row: dict) -> str:
    """Итог события: защита — «устоял» / «пробит», снятие — «ушли с дороги» / «приманка»; иначе ""."""
    value = (row.get("outcome") or "").strip()
    if value:
        return value
    kind, stage, text = row.get("kind", ""), row.get("stage", ""), row.get("text", "") or ""
    if kind == "defense" and stage == "закончилась":
        return BROKEN if "пробит" in text else HELD
    if kind == "pull" and stage == "итог":
        if "приманк" in text:
            return BAIT
        if "ушли с дороги" in text:
            return THROUGH
    return ""


def event_outcome(event: dict) -> str:
    """Итог события детектора для колонки outcome журнала (quotes_tab._mm_events); иначе ""."""
    kind, stage = event.get("kind"), event.get("stage")
    if kind == "defense" and stage == "закончилась":
        return BROKEN if event.get("through") else HELD
    if kind == "pull" and stage == "итог":
        return {"through": THROUGH, "bait": BAIT}.get(event.get("outcome"), "")
    return ""


def journal_files(days: int = 7, log_dir: Path = LOG_DIR, today: date | None = None) -> list[Path]:
    """Журналы за последние days календарных дней (включая сегодня), по порядку дат."""
    today = today or date.today()
    out = []
    for back in range(max(1, int(days)) - 1, -1, -1):
        path = log_dir / f"{PREFIX}{today - timedelta(days=back):%Y-%m-%d}.csv"
        if path.exists():
            out.append(path)
    return out


def read_rows(paths) -> list[dict]:
    """Строки журналов (разделитель «;»). Повреждённые строки пропускаются."""
    rows = []
    for path in paths:
        try:
            with open(path, encoding="utf-8-sig", newline="") as fh:
                for row in csv.DictReader(fh, delimiter=";"):
                    if row.get("kind"):
                        rows.append(row)
        except (OSError, csv.Error, UnicodeDecodeError):
            continue
    return rows


def summarize(rows) -> dict:
    """{инструмент: Counter} и итог под ключом "" — счётчики по видам и итогам; плюс по чувствительности."""
    per = defaultdict(Counter)
    by_sens = defaultdict(Counter)
    for row in rows:
        kind, stage, symbol = row.get("kind", ""), row.get("stage", ""), row.get("symbol", "")
        outcome = outcome_of(row)
        keys = []
        if kind == "defense" and stage == "закончилась":
            keys = ["defense_end", f"defense_{outcome}"]
        elif kind == "pull" and stage == "итог" and outcome:
            keys = ["pull_end", f"pull_{outcome}"]
        elif kind in ("absorb", "requote", "stall"):
            keys = [kind]
        elif kind == "bait" and stage == "повторяется":
            keys = ["bait"]
        for key in keys:
            per[symbol][key] += 1
            per[""][key] += 1
            sens = (row.get("sens") or "").strip()
            if sens and key.startswith(("defense_", "pull_")):
                by_sens[sens][key] += 1
    return {"symbols": dict(per), "sens": dict(by_sens), "rows": len(rows)}


def _share(part: int, whole: int) -> str:
    return f"{100.0 * part / whole:.0f} %" if whole else "—"


SENS_NAMES = {"low": "низкая", "normal": "обычная", "high": "высокая"}


def format_text(summary: dict, days: int, files: list[Path] | None = None) -> str:
    """Сводка таблицей (моноширинный шрифт)."""
    files = files or []
    span = ""
    if files:
        first, last = files[0].stem[len(PREFIX):], files[-1].stem[len(PREFIX):]
        span = f" ({first[8:10]}.{first[5:7]}–{last[8:10]}.{last[5:7]})" if first != last else \
            f" ({first[8:10]}.{first[5:7]})"
    lines = [f"Сводка исходов маркет-мейкера за {days} дн.{span}: журналов {len(files)}, строк {summary['rows']}", ""]
    symbols = summary["symbols"]
    if not summary["rows"] or not symbols:
        lines.append("Событий нет: журналы logs/mm_events_ДАТА.csv за эти дни пусты или их нет.")
        return "\n".join(lines)
    head = (f"{'Инструмент':<20}{'Защита: устояла / пробита':>28}{'Снятия: ушли / приманка':>27}"
            f"{'Поглощ.':>9}{'Котир.':>8}{'Приман.':>9}{'Паузы':>7}")
    lines += [head, "-" * len(head)]
    order = sorted((s for s in symbols if s), key=lambda s: -sum(symbols[s].values()))
    for symbol in order + [""]:
        c = symbols[symbol]
        held, broken, ends = c["defense_" + HELD], c["defense_" + BROKEN], c["defense_end"]
        through, bait, pulls = c["pull_" + THROUGH], c["pull_" + BAIT], c["pull_end"]
        defense = f"{held} / {broken} ({_share(held, ends)} уст.)" if ends else "—"
        pull = f"{through} / {bait} ({_share(bait, pulls)} пр.)" if pulls else "—"
        if symbol == "":
            lines.append("-" * len(head))
        lines.append(f"{(symbol or 'Итого')[:19]:<20}{defense:>28}{pull:>27}{c['absorb']:>9}{c['requote']:>8}"
                     f"{c['bait']:>9}{c['stall']:>7}")
    if summary["sens"]:
        lines += ["", "По чувствительности (с 2.1.12):"]
        for sens in ("low", "normal", "high"):
            c = summary["sens"].get(sens)
            if not c:
                continue
            held, ends = c["defense_" + HELD], c["defense_end"]
            bait, pulls = c["pull_" + BAIT], c["pull_end"]
            lines.append(f"  {SENS_NAMES[sens]:<9} защита: устояла {held} из {ends} ({_share(held, ends)}); "
                         f"снятия: приманка {bait} из {pulls} ({_share(bait, pulls)})")
    lines += ["", "Защита «устояла» — доливы прекратились, а цена не прошла уровень; «пробита» — сделка за уровнем.",
              "Снятие: «ушли» — цена прошла через место снятой заявки, «приманка» — ушла в другую сторону.",
              "Для сравнения: на ленте 09.11 в случайные моменты такой же критерий дал «приманку» в 30–52 % выводов."]
    return "\n".join(lines)


def report(days: int = 7, log_dir: Path = LOG_DIR, today: date | None = None) -> str:
    files = journal_files(days, log_dir, today)
    return format_text(summarize(read_rows(files)), days, files)


def main(argv: list[str]) -> int:
    days = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 7
    print(report(days))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
