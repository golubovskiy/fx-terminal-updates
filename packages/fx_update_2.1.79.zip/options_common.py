# -*- coding: utf-8 -*-
"""Общее для окон FX Terminal: опционы (options_tab, options_chain_chart_widget, options_oi_view),
открытый интерес (open_interest_tab), gui_app.

Ролловер квартальных фьючерсов, имена инструментов, тикеры без суффикса площадки.
snapshot_path() — путь к JSON-снимку цепочки прежнего отдельного монитора
(cny_options_monitor_v2.py); терминал этот снимок не использует, функция оставлена
для совместимости.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import app_paths
BASE_DIR = app_paths.DATA_DIR          # снимки опционов (*.json) — в папке данных (2.1.79)

# Опционы на MOEX привязаны к квартальным фьючерсам. Ближайший контракт
# определяется по дате и переключается на следующий сам.
QUARTERLY_PREFIXES = ("Si", "CR", "Eu")      # USD/RUB, CNY/RUB, EUR/RUB
EXTRA_UNDERLYINGS = {"CNYRUB_TOM@MISX": "CNY/RUB, спот TOM"}   # не меняются по датам: тикер -> имя
INSTRUMENT_NAMES = {"Si": "USD/RUB", "CR": "CNY/RUB", "Eu": "EUR/RUB"}
MONTH_NAMES = {3: "март", 6: "июнь", 9: "сентябрь", 12: "декабрь"}
DEFAULT_PREFIX = "CR"
QUARTER_CODES = {3: "H", 6: "M", 9: "U", 12: "Z"}
try:                                         # единое правило терминала (contracts.py рядом)
    import contracts as _contracts
    ROLL_DAYS = _contracts.ROLL_DAYS
except Exception:                            # модуль скопирован отдельно — своё правило
    _contracts = None
    ROLL_DAYS = 3                            # за сколько дней до экспирации переходить на следующий; 0 — после экспирации
MSK = timezone(timedelta(hours=3))           # биржа живёт по Москве (без DST, без tzdata)


def _third_thursday(year: int, month: int) -> date:
    first = date(year, month, 1)
    first_thu = first + timedelta(days=(3 - first.weekday()) % 7)
    return first_thu + timedelta(days=14)


def front_quarterly_symbol(prefix: str, today: date | None = None, roll_days: int = ROLL_DAYS) -> str:
    """Ближайший квартальный фьючерс, например SiZ6@RTSX.

    Экспирация считается как третий четверг месяца (так у опционов в цепочке:
    2026-12-17); праздничные сдвиги не учитываются — для выбора контракта
    с запасом roll_days этого достаточно.
    """
    if _contracts is not None:               # с учётом настоящей даты экспирации из GetAsset
        return _contracts.front_quarterly(prefix, today, roll_days)
    today = today or datetime.now(MSK).date()
    for year in (today.year, today.year + 1):
        for month in sorted(QUARTER_CODES):
            if today <= _third_thursday(year, month) - timedelta(days=roll_days):
                return f"{prefix}{QUARTER_CODES[month]}{year % 10}@RTSX"
    raise RuntimeError("не удалось определить квартальный контракт")  # недостижимо


def underlying_choices(today: date | None = None) -> list[str]:
    return [front_quarterly_symbol(p, today) for p in QUARTERLY_PREFIXES] + list(EXTRA_UNDERLYINGS)


def default_underlying(today: date | None = None) -> str:
    return front_quarterly_symbol(DEFAULT_PREFIX, today)


_SYMBOL_RE = re.compile(r"^(?P<p>[A-Za-z]+)(?P<m>[HMUZ])(?P<y>\d)@RTSX$")
_SHORT_QUARTERLY_RE = re.compile(r"^[A-Za-z]+[HMUZ]\d$")


def _year_from_digit(digit: int, today: date | None = None) -> int:
    """Цифра года в тикере (6 в SiZ6) -> полный год относительно сегодняшней даты."""
    today = today or datetime.now(MSK).date()
    year = today.year - today.year % 10 + digit
    if year < today.year - 1:          # цифра года относится к следующему десятилетию
        year += 10
    return year


def describe_symbol(symbol: str, today: date | None = None) -> str:
    """Имя инструмента по тикеру: SiZ6@RTSX -> 'USD/RUB, декабрь 2026'. Неизвестный — ''."""
    if symbol in EXTRA_UNDERLYINGS:
        return EXTRA_UNDERLYINGS[symbol]
    m = _SYMBOL_RE.match(symbol)
    if not m or m["p"] not in INSTRUMENT_NAMES:
        return ""
    month = next(k for k, v in QUARTER_CODES.items() if v == m["m"])
    year = _year_from_digit(int(m["y"]), today)
    return f"{INSTRUMENT_NAMES[m['p']]}, {MONTH_NAMES[month]} {year}"


# Как контракт называется в каталоге брокера: Si-12.26, CNY-12.26 (у CR префикс CNY)
CONTRACT_PREFIX_NAMES = {"Si": "Si", "CR": "CNY", "Eu": "Eu"}


def contract_title(symbol: str, today: date | None = None) -> str:
    """SiZ6@RTSX -> 'Si-12.26', CRZ6@RTSX -> 'CNY-12.26'. Нераспознанный тикер — без суффикса площадки."""
    m = _SYMBOL_RE.match(symbol)
    if not m:
        return short_symbol(symbol)
    month = next(k for k, v in QUARTER_CODES.items() if v == m["m"])
    year = _year_from_digit(int(m["y"]), today)
    return f"{CONTRACT_PREFIX_NAMES.get(m['p'], m['p'])}-{month}.{year % 100:02d}"


def short_symbol(symbol: str) -> str:
    """Тикер для показа пользователю без суффикса площадки: SiZ6@RTSX -> SiZ6."""
    return re.sub(r"@[A-Za-z0-9_]+$", "", symbol or "")


def full_symbol(text: str) -> str:
    """Тикер, как он уходит в API, из введённого/выбранного текста.
    «SiZ6» -> «SiZ6@RTSX», «CNYRUB_TOM» -> «CNYRUB_TOM@MISX»; с «@» — как есть."""
    parts = (text or "").split()
    text = parts[0] if parts else ""
    if not text or "@" in text:
        return text
    for sym in underlying_choices():
        if short_symbol(sym) == text:
            return sym
    if _SHORT_QUARTERLY_RE.match(text):
        return text + "@RTSX"
    return text


def underlying_label(symbol: str, today: date | None = None) -> str:
    name = describe_symbol(symbol, today)
    short = short_symbol(symbol)
    return f"{short} — {name}" if name else short


def underlying_kind(symbol: str) -> str:
    """Как называть базовый актив в интерфейсе: «Спот» для площадки MISX, иначе «Фьючерс»."""
    return "Спот" if (symbol or "").endswith("@MISX") else "Фьючерс"


def snapshot_path(symbol: str) -> Path:
    """JSON-снимок цепочки по базовому активу: options_snapshot_CRZ6.json."""
    return BASE_DIR / f"options_snapshot_{short_symbol(symbol)}.json"
