# -*- coding: utf-8 -*-
"""Сборка FX Terminal в программу для Windows и установщик (2.1.79) — одной командой на компьютере автора.

    cd C:\\FX_Terminal
    venv\\Scripts\\activate
    pip install pyinstaller                  # один раз
    python tools\\build_exe.py               # → C:\\FX_Terminal_build\\FX_Terminal_Setup_<версия>.exe

    ключи: --out ПАПКА (куда собирать, по умолчанию FX_Terminal_build рядом с папкой терминала),
           --no-installer (только папка программы, без Inno Setup), --no-smoke (без проверки собранного),
           --exclude ФАЙЛ (не класть этот файл терминала в программу; можно несколько раз)

Что получается (подробно — app_paths.py):

    <out>\\dist\\FX Terminal\\
        FX Terminal.exe, fx_python.exe   — точки входа (fx_boot.py): окно терминала и Python с консолью
        _internal\\                       — Python и библиотеки из venv (PySide6, QtAds, pyqtgraph, pandas, numpy,
                                           matplotlib, finam-sdk/grpc, fx_engine …) — собраны PyInstaller
        app\\                             — файлы терминала как есть: *.py, пакеты brokers/core/services, tests\\,
                                           Sound\\, значок. Их меняют пакеты обновлений (updater.py) — поэтому
                                           они не в exe
    <out>\\FX_Terminal_Setup_<версия>.exe — установщик Inno Setup: без прав администратора, в
                                           %LOCALAPPDATA%\\Programs\\FX Terminal, ярлыки на рабочем столе и в «Пуске»

Как устроено:
    1. список файлов терминала (app_files): *.py в корне, brokers/, core/, services/, tests/, Sound/*.wav, значок;
       tools/, fx_engine_rs/ (исходники Rust), docs/, venv и папки данных не берутся никогда. Файлы, которых нет
       в git (если папка — копия репозитория), печатаются предупреждением: проверьте, что им место в программе;
    2. файл сборки PyInstaller (spec_text): анализ идёт от fx_boot.py, а все модули терминала и проверок даны как
       «скрытые импорты» — так PyInstaller находит ВСЕ библиотеки, которые они используют. Потом сами модули
       терминала из архива exe убираются (их место — папка app\\): обновления меняют их как обычные файлы;
    3. PyInstaller → папка программы, затем копия файлов терминала в app\\;
    4. проверка собранного (smoke): fx_python.exe app\\tests\\test_imports.py — все модули терминала импортируются
       из собранной программы (данные — во временной папке, FX_DATA_DIR);
    5. Inno Setup (ISCC.exe из стандартной папки установки или PATH) → установщик.

Нужно: Python и venv терминала (сборка берёт библиотеки из него), PyInstaller 6+, Inno Setup 6
(jrsoftware.org; без него — только папка программы). Подписи кода нет: Windows SmartScreen при первом запуске
установщика покажет «Windows защитил ваш компьютер» → «Подробнее» → «Выполнить в любом случае».
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import site
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP_NAME = "FX Terminal"
GUI_EXE = "FX Terminal"                     # app_paths.GUI_EXE_NAME без .exe
PYTHON_EXE = "fx_python"                    # app_paths.PYTHON_EXE_NAME без .exe
APP_ID = "{{CA7B0AEE-715C-412B-9027-AE9278B70E09}"   # Inno Setup: один на все версии (обновление поверх)
PUBLISHER = "golubovskiy"
URL = "https://github.com/golubovskiy/fx-terminal-updates"
ICON = "fx_terminal.ico"

PACKAGES = ("brokers", "core", "services")  # пакеты терминала (папки с __init__.py)
EXTRA_FILES = (ICON,)
SKIP_DIRS = {"__pycache__", ".git", "venv", ".venv", "env", "tools", "fx_engine_rs", "docs", "logs", "_install",
             "_backup", "build", "dist", "cache", "data", "notes_images"}
# Библиотеки, которых терминал не использует, но которые PyInstaller может потянуть через зависимости
EXCLUDES = ["tkinter", "PyQt5", "PyQt6", "PySide2", "IPython", "jupyter", "notebook", "pytest",
            "pyqtgraph.examples", "pyqtgraph.opengl", "pyqtgraph.jupyter"]
# Импортируются по имени во время работы — анализ кода их не видит
HIDDEN_LIBS = ["PySide6QtAds", "fx_engine", "PySide6.QtMultimedia", "PySide6.QtSvg", "PySide6.QtNetwork",
               "shiboken6", "zoneinfo", "sqlite3", "matplotlib.backends.backend_qtagg"]
COLLECT_SUBMODULES = ["finam_trade_api", "tzdata"]          # целиком (сгенерированные protobuf, база часовых поясов)
COLLECT_DATA = ["pyqtgraph", "tzdata", "certifi", "finam_trade_api"]


# ------------------------------------------------------------------ файлы терминала

def app_files(root: Path = ROOT, exclude: tuple[str, ...] = ()) -> list[str]:
    """Файлы терминала для папки app\\ (пути относительно root, через «/»), по порядку."""
    root = Path(root)
    skip = {e.replace("\\", "/") for e in exclude}
    found: list[str] = []
    for path in sorted(root.glob("*.py")):
        found.append(path.name)
    for pkg in PACKAGES + ("tests",):
        base = root / pkg
        if not base.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
            for name in sorted(filenames):
                if name.endswith(".py"):
                    found.append((Path(dirpath) / name).relative_to(root).as_posix())
    sound = root / "Sound"
    if sound.is_dir():
        found += [f"Sound/{p.name}" for p in sorted(sound.glob("*.wav"))]
    found += [name for name in EXTRA_FILES if (root / name).is_file()]
    return [rel for rel in found if rel not in skip]


def module_names(files: list[str]) -> list[str]:
    """Имена модулей для «скрытых импортов»: x.py → x, brokers/finam/live.py → brokers.finam.live,
    brokers/__init__.py → brokers, tests/test_x.py → test_x (папка tests — в пути поиска сборки)."""
    names = []
    for rel in files:
        if not rel.endswith(".py") or rel == "fx_boot.py":
            continue
        parts = rel[:-3].split("/")
        if parts[0] == "tests":
            parts = parts[1:]
        if parts[-1] == "__init__":
            parts = parts[:-1]
        if parts:
            names.append(".".join(parts))
    return names


def untracked(root: Path, files: list[str]) -> list[str]:
    """Файлы из списка, которых нет в git (папка — не копия репозитория или git нет — пустой список)."""
    if not (Path(root) / ".git").exists():
        return []
    try:
        res = subprocess.run(["git", "-C", str(root), "ls-files"], capture_output=True, text=True,
                             encoding="utf-8", timeout=60)
    except (OSError, subprocess.SubprocessError):
        return []
    if res.returncode != 0:
        return []
    tracked = set(res.stdout.split("\n"))
    return [rel for rel in files if rel not in tracked]


def third_party_dirs() -> list[str]:
    """Папки библиотек этого Python (venv и site-packages): модули оттуда остаются в exe, даже если venv лежит
    внутри папки терминала (C:\\FX_Terminal\\venv)."""
    dirs = {sys.prefix, sys.base_prefix}
    try:
        dirs.update(site.getsitepackages())
    except Exception:                                                # noqa: BLE001
        pass
    return sorted(str(Path(d).resolve()) for d in dirs if d)


# ------------------------------------------------------------------ PyInstaller

def spec_text(root: Path, modules: list[str], libs_dirs: list[str], icon: Path | None) -> str:
    """Файл сборки PyInstaller: два exe (окно и консоль) над одним набором библиотек; модули терминала —
    скрытые импорты для анализа, из архива убираются (APP_ROOT, кроме папок библиотек)."""
    return f'''# -*- mode: python ; coding: utf-8 -*-
# Создан tools/build_exe.py — правки сюда не вносить, они пропадут при следующей сборке.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

APP_ROOT = Path({str(root)!r}).resolve()
LIB_DIRS = [Path(d) for d in {libs_dirs!r}]
APP_MODULES = {modules!r}
ICON = {str(icon) if icon else None!r}


def _inside(path, base):
    try:
        path.relative_to(base)
        return True
    except ValueError:
        return False


def _is_app(entry):
    """Модуль терминала (файл в папке терминала, но не в venv / site-packages) — ему место в app\\\\, не в exe."""
    src = entry[1]
    if not src:
        return False
    path = Path(src).resolve()
    return _inside(path, APP_ROOT) and not any(_inside(path, d) for d in LIB_DIRS)


hidden = list(APP_MODULES) + {HIDDEN_LIBS!r}
for name in {COLLECT_SUBMODULES!r}:
    try:
        hidden += collect_submodules(name)
    except Exception:
        pass
datas = []
for name in {COLLECT_DATA!r}:
    try:
        datas += collect_data_files(name)
    except Exception:
        pass

a = Analysis(
    [str(APP_ROOT / "fx_boot.py")],
    pathex=[str(APP_ROOT), str(APP_ROOT / "tests")],
    hiddenimports=hidden,
    datas=datas,
    excludes={EXCLUDES!r},
    noarchive=False,
)
a.pure = [entry for entry in a.pure if not _is_app(entry)]
pyz = PYZ(a.pure)
exe_gui = EXE(pyz, a.scripts, [], exclude_binaries=True, name={GUI_EXE!r}, icon=ICON, console=False, upx=False)
exe_py = EXE(pyz, a.scripts, [], exclude_binaries=True, name={PYTHON_EXE!r}, icon=ICON, console=True, upx=False)
coll = COLLECT(exe_gui, exe_py, a.binaries, a.datas, name={APP_NAME!r}, upx=False)
'''


# ------------------------------------------------------------------ Inno Setup

def iss_text(version: str, dist_dir: Path, out_dir: Path, icon: Path | None) -> str:
    """Сценарий установщика Inno Setup. Каждая установка начисто меняет _internal\\ и app\\ (без старых модулей
    и бэкапов обновлений); данные (%LOCALAPPDATA%\\FX_Terminal) и настройки (реестр) не трогает ни установка,
    ни удаление."""
    icon_line = f"SetupIconFile={icon}\n" if icon else ""
    return f'''; Создан tools/build_exe.py — правки сюда не вносить, они пропадут при следующей сборке.
[Setup]
AppId={APP_ID}
AppName={APP_NAME}
AppVersion={version}
AppVerName={APP_NAME} {version}
AppPublisher={PUBLISHER}
AppPublisherURL={URL}
AppSupportURL={URL}
DefaultDirName={{localappdata}}\\Programs\\{APP_NAME}
DefaultGroupName={APP_NAME}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={out_dir}
OutputBaseFilename=FX_Terminal_Setup_{version}
{icon_line}UninstallDisplayIcon={{app}}\\{GUI_EXE}.exe
Compression=lzma2/max
SolidCompression=yes
CloseApplications=yes
WizardStyle=modern

[Languages]
Name: "ru"; MessagesFile: "compiler:Languages\\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "{{cm:CreateDesktopIcon}}"; GroupDescription: "{{cm:AdditionalIcons}}"

[InstallDelete]
Type: filesandordirs; Name: "{{app}}\\_internal"
Type: filesandordirs; Name: "{{app}}\\app"

[Files]
Source: "{dist_dir}\\*"; DestDir: "{{app}}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{{group}}\\{APP_NAME}"; Filename: "{{app}}\\{GUI_EXE}.exe"; WorkingDir: "{{app}}\\app"
Name: "{{group}}\\Удалить {APP_NAME}"; Filename: "{{uninstallexe}}"
Name: "{{autodesktop}}\\{APP_NAME}"; Filename: "{{app}}\\{GUI_EXE}.exe"; WorkingDir: "{{app}}\\app"; Tasks: desktopicon

[Run]
Filename: "{{app}}\\{GUI_EXE}.exe"; Description: "{{cm:LaunchProgram,{APP_NAME}}}"; WorkingDir: "{{app}}\\app"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{{app}}\\app"
Type: filesandordirs; Name: "{{app}}\\_internal"
'''


def find_iscc() -> str | None:
    """ISCC.exe (компилятор Inno Setup 6): PATH, затем стандартные папки установки."""
    found = shutil.which("ISCC") or shutil.which("iscc")
    if found:
        return found
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs")):
        if base:
            path = Path(base) / "Inno Setup 6" / "ISCC.exe"
            if path.is_file():
                return str(path)
    return None


# ------------------------------------------------------------------ сборка

def read_version(root: Path) -> str:
    found = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', (Path(root) / "version.py").read_text(encoding="utf-8"), re.M)
    if not found:
        raise SystemExit("в version.py нет VERSION")
    return found.group(1)


def copy_app(root: Path, files: list[str], dest: Path) -> None:
    if dest.exists():
        shutil.rmtree(dest)
    for rel in files:
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / rel, target)


def smoke(program: Path) -> bool:
    """Собранная программа импортирует все модули терминала (fx_python.exe app\\tests\\test_imports.py)."""
    exe = program / f"{PYTHON_EXE}.exe"
    test = program / "app" / "tests" / "test_imports.py"
    with tempfile.TemporaryDirectory(prefix="fx_smoke_") as data:
        env = {**os.environ, "QT_QPA_PLATFORM": "offscreen", "PYTHONIOENCODING": "utf-8", "FX_DATA_DIR": data}
        res = subprocess.run([str(exe), str(test)], cwd=str(program / "app"), env=env, capture_output=True,
                             text=True, encoding="utf-8", errors="replace", timeout=600)
    lines = [ln for ln in (res.stdout + res.stderr).splitlines() if ln.strip()]
    for ln in lines:
        if ln.startswith("FAIL") or "Error" in ln:
            print("    " + ln)
    print(f"  проверка собранного: {lines[-1] if lines else '(нет вывода)'}")
    return res.returncode == 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Сборка FX Terminal: PyInstaller + Inno Setup")
    ap.add_argument("--out", default=str(ROOT.parent / "FX_Terminal_build"))
    ap.add_argument("--no-installer", action="store_true")
    ap.add_argument("--no-smoke", action="store_true")
    ap.add_argument("--exclude", action="append", default=[])
    args = ap.parse_args(argv)

    out = Path(args.out).resolve()
    version = read_version(ROOT)
    files = app_files(ROOT, tuple(args.exclude))
    print(f"FX Terminal {version}: файлов терминала {len(files)} → {out}")
    extra = untracked(ROOT, files)
    if extra:
        print("  ! этих файлов нет в git — если им не место в программе, уберите их или --exclude:")
        for rel in extra:
            print(f"      {rel}")
    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        print("Нет PyInstaller: pip install pyinstaller (в venv терминала)")
        return 2

    work, dist = out / "build", out / "dist"
    out.mkdir(parents=True, exist_ok=True)
    icon = ROOT / ICON if (ROOT / ICON).is_file() else None
    spec = out / "fx_terminal.spec"
    spec.write_text(spec_text(ROOT, module_names(files), third_party_dirs(), icon), encoding="utf-8")
    print("1/4 PyInstaller (несколько минут)…")
    res = subprocess.run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--log-level", "WARN",
                          "--distpath", str(dist), "--workpath", str(work), str(spec)], cwd=str(out))
    if res.returncode != 0:
        print("СБОЙ: PyInstaller не собрал программу — пришлите вывод выше")
        return 1
    program = dist / APP_NAME
    print("2/4 файлы терминала → app\\")
    copy_app(ROOT, files, program / "app")
    if not args.no_smoke:
        print("3/4 проверка собранного…")
        if not smoke(program):
            print("СБОЙ: собранная программа не импортирует модули терминала — пришлите вывод выше")
            return 1
    else:
        print("3/4 проверка пропущена (--no-smoke)")
    if args.no_installer:
        print(f"Готово: {program}")
        return 0
    iscc = find_iscc()
    if iscc is None:
        print(f"4/4 нет Inno Setup 6 (jrsoftware.org) — установщик не собран; программа: {program}")
        return 0
    iss = out / "fx_terminal.iss"
    iss.write_text(iss_text(version, program, out, icon), encoding="utf-8-sig")   # BOM — Inno Setup читает UTF-8
    print("4/4 Inno Setup…")
    res = subprocess.run([iscc, "/Q", str(iss)], cwd=str(out))
    if res.returncode != 0:
        print("СБОЙ: Inno Setup не собрал установщик — пришлите вывод выше")
        return 1
    print(f"Готово: {out / f'FX_Terminal_Setup_{version}.exe'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
