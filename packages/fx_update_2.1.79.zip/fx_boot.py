# -*- coding: utf-8 -*-
"""Точка входа собранной программы (2.1.79): с этого файла PyInstaller собирает FX Terminal.exe и fx_python.exe
(tools/build_exe.py). Сам терминал в exe не зашит: его файлы (.py) лежат рядом, в папке app\\, и меняются пакетами
обновлений; в exe — только Python и библиотеки.

    FX Terminal.exe [--logs]                 — окно терминала: выполняет app\\gui_app.py, как «python gui_app.py»
    fx_python.exe СКРИПТ.py [аргументы]      — выполнить скрипт этим Python, как «python СКРИПТ.py»: так
                                                запускаются установщик обновлений (app\\updater.py) и проверки
                                                (app\\tests\\test_*.py) — app_paths.python_command
    fx_python.exe                            — без скрипта: тоже окно терминала (с консолью — для отладки)

Из исходников тот же файл работает так же: «python fx_boot.py tests\\test_imports.py» (это и проверяет
tests/test_build_exe.py, без PyInstaller).
"""
from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path


def app_dir() -> Path:
    """Папка с файлами терминала: у собранной программы — app\\ рядом с exe, из исходников — папка этого файла."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "app"
    return Path(__file__).resolve().parent


def _ensure_streams() -> None:
    """У окна без консоли (FX Terminal.exe) sys.stdout / sys.stderr — None: print и журнал терминала
    (services/log_file.py, «тройник» над ними) ждут настоящие потоки — даём «пустые»."""
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))


def run_script(script: str, args: list[str]) -> None:
    """Выполнить СКРИПТ.py как главный модуль (__name__ == "__main__"), с его папкой первой в sys.path —
    как «python СКРИПТ.py». SystemExit скрипта (код возврата проверки) уходит наружу как есть."""
    path = Path(script)
    if not path.is_absolute():
        path = Path.cwd() / path
    sys.argv = [str(path), *args]
    sys.path.insert(0, str(path.parent))
    runpy.run_path(str(path), run_name="__main__")


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv if argv is None else argv)
    root = app_dir()
    _ensure_streams()
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))                # модули терминала — из app\, а не из exe
    if len(argv) > 1 and argv[1].lower().endswith(".py"):
        run_script(argv[1], argv[2:])
        return
    os.chdir(root)
    sys.argv = [argv[0], *argv[1:]]                  # перезапуск терминала (gui_app) берёт ключи из sys.argv[1:]
    runpy.run_path(str(root / "gui_app.py"), run_name="__main__")


if __name__ == "__main__":
    main()
