"""
SQLite-кэш свечей для FX Terminal.

Логика простая: при каждом успешном получении свежих свечей с API — кэш для
пары (symbol, timeframe) полностью перезаписывается. При старте/обновлении
GUI сначала читает то, что есть в кэше (мгновенно, без сети), и рисует это,
пока в фоне идёт настоящий сетевой запрос за свежими данными.

Это НЕ полноценное хранилище истории с докачкой недостающих интервалов —
просто "последний известный снимок" на случай медленной сети или офлайна.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import app_paths
import pandas as pd

DB_PATH = app_paths.DATA_DIR / "fx_terminal_cache.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS candles (
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    time TEXT NOT NULL,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume REAL,
    PRIMARY KEY (symbol, timeframe, time)
);
"""


def _connect() -> sqlite3.Connection:
    # check_same_thread=False: вызывается из фоновых QThread-воркеров, а не
    # только из главного потока GUI. Каждый вызов открывает и закрывает своё
    # соединение — для нашей частоты запросов (раз в 15 сек) это не проблема.
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute(_SCHEMA)
    return conn


def save_bars(symbol: str, timeframe: str, df: pd.DataFrame) -> None:
    if df.empty:
        return

    conn = _connect()
    try:
        with conn:
            conn.execute(
                "DELETE FROM candles WHERE symbol = ? AND timeframe = ?",
                (symbol, timeframe),
            )

            rows = []

            for _, row in df.iterrows():
                ts = row.get("timestamp")

                # Для совместимости со старыми DataFrame,
                # где timestamp мог быть индексом.
                if ts is None:
                    ts = row.name

                ts = pd.to_datetime(ts, utc=True).isoformat()

                rows.append(
                    (
                        symbol,
                        timeframe,
                        ts,
                        float(row["open"]),
                        float(row["high"]),
                        float(row["low"]),
                        float(row["close"]),
                        float(row.get("volume", 0) or 0),
                    )
                )

            conn.executemany(
                "INSERT INTO candles (symbol, timeframe, time, open, high, low, close, volume) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                rows,
            )
    finally:
        conn.close()


def load_bars(symbol: str, timeframe: str) -> pd.DataFrame:
    conn = _connect()
    try:
        df = pd.read_sql_query(
            "SELECT time, open, high, low, close, volume FROM candles "
            "WHERE symbol = ? AND timeframe = ? ORDER BY time",
            conn,
            params=(symbol, timeframe),
        )
    finally:
        conn.close()

    if df.empty:
        return df

    df["time"] = pd.to_datetime(df["time"])
    return df.set_index("time")
