# -*- coding: utf-8 -*-
"""
FINAM — CNY/RUB FORWARD MONITOR v2.5

v2.4.1 stream architecture is preserved:
- Finam SubscribeQuote
- one dedicated stream reader thread
- merging of partial quote updates
- calculation every 30 seconds
- CSV history
- 4-panel historical dashboard PNG

Files:
    C:/FX_Terminal/cny_forward_history.csv
    C:/FX_Terminal/cny_forward_dashboard.png
"""

from __future__ import annotations

import csv
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)
from typing import Any

import matplotlib.dates as mdates
import matplotlib.pyplot as plt

from finam_sdk_client import FinamStreamClient


BASE_DIR = app_paths.DATA_DIR      # было жёстко C:/FX_Terminal; с 2.1.79 — папка данных терминала
CSV_PATH = BASE_DIR / "cny_forward_history.csv"
PNG_PATH = BASE_DIR / "cny_forward_dashboard.png"

TOM_SYMBOL = "CNYRUB_TOM@MISX"
FUTURE_MIC = "RTSX"
RUSFAR_SYMBOL = "RUSFAR@RTSX"
RUSFAR_3M_SYMBOL = "RUSFAR3M@RTSX"
RUSFARCNY_SYMBOL = "RUSFARCNY@RTSX"

UPDATE_INTERVAL = 30
INITIAL_WAIT_SECONDS = 15

MONTH_CODES = "HMUZ"


def now_local() -> datetime:
    return datetime.now().astimezone()


def value_of(obj: Any, key: str) -> float | None:
    if not isinstance(obj, dict):
        return None
    value = obj.get(key)
    if isinstance(value, dict):
        value = value.get("value")
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def quote_last(quote: dict[str, Any] | None) -> float | None:
    if not quote:
        return None
    for key in ("last", "close", "bid", "ask"):
        value = value_of(quote, key)
        if value is not None:
            return value
    return None


def quote_bid(quote: dict[str, Any] | None) -> float | None:
    return value_of(quote, "bid")


def quote_ask(quote: dict[str, Any] | None) -> float | None:
    return value_of(quote, "ask")


def get_asset_symbol(asset: Any) -> str | None:
    if not isinstance(asset, dict):
        return None
    for key in ("symbol", "ticker", "code"):
        if asset.get(key):
            return str(asset[key])
    return None


def get_asset_name(asset: Any) -> str | None:
    if not isinstance(asset, dict):
        return None
    for key in ("name", "display_name", "short_name"):
        if asset.get(key):
            return str(asset[key])
    return None


def get_expiration(asset: Any) -> datetime | None:
    if not isinstance(asset, dict):
        return None

    candidates = []
    future_details = asset.get("future_details")
    if isinstance(future_details, dict):
        candidates.append(future_details.get("expiration_date"))
    candidates.append(asset.get("expiration_date"))

    for value in candidates:
        if isinstance(value, datetime):
            dt = value
        elif isinstance(value, str):
            try:
                dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                continue
        else:
            continue

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt

    return None


class QuoteManager:
    """Хранит последние quotes и объединяет частичные обновления."""

    def __init__(self) -> None:
        self._quotes: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    def update(self, message: dict[str, Any]) -> None:
        quotes = message.get("quote", [])
        if isinstance(quotes, dict):
            quotes = [quotes]
        if not isinstance(quotes, list):
            return

        with self._lock:
            for quote in quotes:
                if not isinstance(quote, dict):
                    continue
                symbol = quote.get("symbol")
                if not symbol:
                    continue

                merged = dict(self._quotes.get(symbol, {}))
                merged.update(quote)
                self._quotes[symbol] = merged

    def get(self, symbol: str) -> dict[str, Any] | None:
        with self._lock:
            quote = self._quotes.get(symbol)
            return dict(quote) if quote else None

    def has(self, symbol: str) -> bool:
        return self.get(symbol) is not None


class QuoteStreamReader:
    """Единственный потребитель iterator-а SubscribeQuote."""

    def __init__(self, stream: Any, manager: QuoteManager) -> None:
        self.stream = stream
        self.manager = manager
        self.stop_event = threading.Event()
        self.thread = threading.Thread(
            target=self._run,
            name="FinamQuoteReader",
            daemon=True,
        )
        self.error: Exception | None = None
        self.updates_count = 0

    def start(self) -> None:
        self.thread.start()

    def _run(self) -> None:
        try:
            iterator = iter(self.stream)
            while not self.stop_event.is_set():
                message = next(iterator)
                if message is not None:
                    self.manager.update(message)
                    self.updates_count += 1
        except StopIteration:
            pass
        except Exception as exc:
            self.error = exc

    def stop(self) -> None:
        self.stop_event.set()
        try:
            self.stream.cancel()
        except Exception:
            pass
        if self.thread.is_alive():
            self.thread.join(timeout=2)


def candidate_symbols() -> list[str]:
    year = now_local().year
    result: list[str] = []

    for y in range(year - 1, year + 3):
        yy = str(y)[-1]
        for month in MONTH_CODES:
            result.append(f"CR{month}{yy}@{FUTURE_MIC}")

    return result


def find_nearest_future(
    client: FinamStreamClient,
) -> tuple[str, dict[str, Any], datetime]:
    print()
    print("Поиск ближайшего CNY-фьючерса...")

    candidates = candidate_symbols()
    print(f"Кандидатов для проверки: {len(candidates)}")

    now = datetime.now(timezone.utc)
    found: list[tuple[datetime, str, dict[str, Any]]] = []

    for symbol in candidates:
        print(f"  Проверяем {symbol}...")
        try:
            asset = client.get_asset(symbol)
        except Exception as exc:
            print(f"    ошибка: {exc}")
            continue

        expiration = get_expiration(asset)
        if expiration is None:
            print("    дата экспирации не найдена")
            continue

        if expiration <= now:
            print(f"    истёк: {expiration.date()}")
            continue

        asset_symbol = get_asset_symbol(asset) or symbol
        if "@" not in asset_symbol:
            asset_symbol = f"{asset_symbol}@{FUTURE_MIC}"

        print("    найден активный контракт.")
        print(f"    symbol    : {asset_symbol}")
        print(f"    name      : {get_asset_name(asset) or asset_symbol}")
        print(f"    expiration: {expiration}")

        found.append((expiration, asset_symbol, asset))

    if not found:
        raise RuntimeError("Активный CNY-фьючерс не найден.")

    found.sort(key=lambda x: x[0])
    expiration, symbol, asset = found[0]

    print()
    print("Ближайший фьючерс:")
    print(f"  Символ     : {symbol}")
    print(f"  Название   : {get_asset_name(asset) or symbol}")
    print(f"  Экспирация : {expiration}")

    return symbol, asset, expiration


def days_to_expiry(expiration: datetime) -> float:
    if expiration.tzinfo is None:
        expiration = expiration.replace(tzinfo=timezone.utc)
    return max((expiration - datetime.now(timezone.utc)).total_seconds() / 86400, 0.0)


def calculate_forward(
    tom: float,
    rub_rate: float,
    cny_rate: float,
    days: float,
) -> float:
    t = days / 365.0
    return tom * (1 + rub_rate / 100 * t) / (1 + cny_rate / 100 * t)


def make_record(
    timestamp: datetime,
    future_symbol: str,
    future_name: str,
    expiration: datetime,
    tom_quote: dict[str, Any],
    future_quote: dict[str, Any],
    rusfar_quote: dict[str, Any],
    rusfar_3m_quote: dict[str, Any],
    rusfarcny_quote: dict[str, Any],
    updates_count: int,
) -> dict[str, Any] | None:

    tom = quote_last(tom_quote)
    future = quote_last(future_quote)
    rusfar = quote_last(rusfar_quote)
    rusfar_3m = quote_last(rusfar_3m_quote)
    rusfarcny = quote_last(rusfarcny_quote)

    if None in (tom, future, rusfar, rusfar_3m, rusfarcny):
        return None

    days = days_to_expiry(expiration)

    fair_on_on = calculate_forward(tom, rusfar, rusfarcny, days)
    fair_3m = calculate_forward(tom, rusfar_3m, rusfarcny, days)

    market_basis = future - tom
    fair_basis_on_on = fair_on_on - tom
    residual_on_on = future - fair_on_on
    fair_basis_3m = fair_3m - tom
    residual_3m = future - fair_3m

    return {
        "timestamp": timestamp.isoformat(timespec="seconds"),
        "future_symbol": future_symbol,
        "future_name": future_name,
        "expiration": expiration.isoformat(),
        "days_to_expiry": days,
        "tom": tom,
        "future": future,
        "future_bid": quote_bid(future_quote),
        "future_ask": quote_ask(future_quote),
        "rusfar": rusfar,
        "rusfar_3m": rusfar_3m,
        "rusfarcny": rusfarcny,
        "fair_forward_on_on": fair_on_on,
        "market_basis": market_basis,
        "fair_basis_on_on": fair_basis_on_on,
        "market_residual_on_on": residual_on_on,
        "fair_forward_3m": fair_3m,
        "fair_basis_3m": fair_basis_3m,
        "market_residual_3m": residual_3m,
        "updates_count": updates_count,
    }


CSV_FIELDS = [
    "timestamp", "future_symbol", "future_name", "expiration",
    "days_to_expiry", "tom", "future", "future_bid", "future_ask",
    "rusfar", "rusfar_3m", "rusfarcny",
    "fair_forward_on_on", "market_basis", "fair_basis_on_on",
    "market_residual_on_on", "fair_forward_3m", "fair_basis_3m",
    "market_residual_3m", "updates_count",
]


def append_csv(record: dict[str, Any]) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    new_file = not CSV_PATH.exists()

    with CSV_PATH.open("a", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=CSV_FIELDS)
        if new_file:
            writer.writeheader()
        writer.writerow({key: record.get(key) for key in CSV_FIELDS})


def load_history() -> list[dict[str, Any]]:
    if not CSV_PATH.exists():
        return []

    result: list[dict[str, Any]] = []

    try:
        with CSV_PATH.open("r", newline="", encoding="utf-8-sig") as file:
            for row in csv.DictReader(file):
                try:
                    row["timestamp_dt"] = datetime.fromisoformat(row["timestamp"])
                    numeric = [
                        "days_to_expiry", "tom", "future", "future_bid",
                        "future_ask", "rusfar", "rusfar_3m", "rusfarcny",
                        "fair_forward_on_on", "market_basis",
                        "fair_basis_on_on", "market_residual_on_on",
                        "fair_forward_3m", "fair_basis_3m",
                        "market_residual_3m",
                    ]
                    for field in numeric:
                        try:
                            row[field] = float(row[field])
                        except (TypeError, ValueError):
                            row[field] = None
                    result.append(row)
                except Exception:
                    continue
    except Exception as exc:
        print(f"Ошибка чтения CSV: {exc}")

    return result


def draw_dashboard() -> None:
    rows = load_history()
    if not rows:
        return

    rows = rows[-1000:]
    times = [r["timestamp_dt"] for r in rows]

    def kop(field: str) -> list[float | None]:
        return [
            None if r[field] is None else r[field] * 100
            for r in rows
        ]

    fig, axes = plt.subplots(
        4, 1,
        figsize=(16, 12),
        sharex=True,
        gridspec_kw={"height_ratios": [1.25, 1.35, 1.0, 0.75]},
    )

    # 1. Базис
    axes[0].plot(times, kop("market_basis"), label="Future − TOM", linewidth=2)
    axes[0].plot(times, kop("fair_basis_on_on"), label="Fair Forward − TOM")
    axes[0].plot(times, kop("market_residual_on_on"),
                 label="Future − Fair Forward")
    axes[0].axhline(0, linewidth=0.8)
    axes[0].set_ylabel("коп.")
    axes[0].set_title("СТРУКТУРА БАЗИСА", loc="left")
    axes[0].legend(loc="upper left", frameon=False)

    # 2. Цены
    axes[1].plot(times, [r["tom"] for r in rows], label="CNY TOM")
    axes[1].plot(times, [r["fair_forward_on_on"] for r in rows],
                 label="Fair Forward")
    axes[1].plot(times, [r["future"] for r in rows],
                 label="CNY Future", linewidth=2)
    axes[1].set_ylabel("RUB")
    axes[1].set_title("ЦЕНЫ", loc="left")
    axes[1].legend(loc="upper left", frameon=False)

    # 3. Ставки
    axes[2].plot(times, [r["rusfar"] for r in rows], label="RUSFAR")
    axes[2].plot(times, [r["rusfar_3m"] for r in rows], label="RUSFAR 3M")
    axes[2].plot(times, [r["rusfarcny"] for r in rows], label="RUSFARCNY")
    axes[2].set_ylabel("%")
    axes[2].set_title("СТАВКИ", loc="left")
    axes[2].legend(loc="upper left", frameon=False)

    # 4. Срок
    axes[3].plot(times, [r["days_to_expiry"] for r in rows],
                 label="Дней до экспирации")
    axes[3].set_ylabel("дни")
    axes[3].set_title("СРОК ДО ЭКСПИРАЦИИ", loc="left")
    axes[3].legend(loc="upper right", frameon=False)

    for ax in axes:
        ax.grid(True, alpha=0.18)

    axes[-1].xaxis.set_major_formatter(
        mdates.DateFormatter("%d.%m\n%H:%M")
    )

    fig.suptitle(
        "FINAM — CNY/RUB FORWARD MONITOR v2.5",
        fontsize=14,
        fontweight="bold",
    )

    fig.tight_layout(rect=(0, 0, 1, 0.975), h_pad=1.4)
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(PNG_PATH, dpi=150, bbox_inches="tight")
    plt.close(fig)


def print_record(record: dict[str, Any]) -> None:
    market = record["market_basis"]

    def share(part: float, total: float) -> float | None:
        return None if abs(total) < 1e-12 else part / total * 100

    rate_share = share(record["fair_basis_on_on"], market)
    residual_share = share(record["market_residual_on_on"], market)

    print()
    print("=" * 78)
    print(f"Время: {record['timestamp']}")
    print(f"До экспирации: {record['days_to_expiry']:.2f} дней")

    print()
    print("РЫНОЧНЫЕ КОТИРОВКИ")
    print(f"  CNY TOM    : {record['tom']:.4f}")
    print(f"  CNY Future : {record['future']:.4f}")

    if record["future_bid"] is not None:
        print(f"  Future Bid : {record['future_bid']:.4f}")
    if record["future_ask"] is not None:
        print(f"  Future Ask : {record['future_ask']:.4f}")

    print()
    print("СТАВКИ")
    print(f"  RUSFAR     : {record['rusfar']:.2f}%")
    print(f"  RUSFAR 3M  : {record['rusfar_3m']:.2f}%")
    print(f"  RUSFARCNY  : {record['rusfarcny']:.2f}%")

    print()
    print("МОДЕЛЬ 1 — ON/ON")
    print(f"  Теоретический форвард : {record['fair_forward_on_on']:.6f}")
    print(f"  Фактический базис     : {market:+.6f} ₽ ({market*100:+.2f} коп.)")
    print(
        f"  Процентная часть      : {record['fair_basis_on_on']:+.6f} ₽ "
        f"({record['fair_basis_on_on']*100:+.2f} коп.)"
    )
    print(
        f"  Рыночная премия/дисконт: "
        f"{record['market_residual_on_on']:+.6f} ₽ "
        f"({record['market_residual_on_on']*100:+.2f} коп.)"
    )

    if rate_share is not None:
        print(f"  Доля процентной части : {rate_share:+.2f}%")
    if residual_share is not None:
        print(f"  Доля рыночного отклонения: {residual_share:+.2f}%")

    print()
    print("МОДЕЛЬ 2 — 3M/CNY")
    print(f"  Теоретический форвард : {record['fair_forward_3m']:.6f}")
    print(f"  Фактический базис     : {market:+.6f} ₽ ({market*100:+.2f} коп.)")
    print(
        f"  Процентная часть      : {record['fair_basis_3m']:+.6f} ₽ "
        f"({record['fair_basis_3m']*100:+.2f} коп.)"
    )
    print(
        f"  Рыночная премия/дисконт: "
        f"{record['market_residual_3m']:+.6f} ₽ "
        f"({record['market_residual_3m']*100:+.2f} коп.)"
    )

    print()
    print("ИСТОРИЯ")
    print(f"  Обновлений stream : {record['updates_count']}")
    print(f"  CSV               : {CSV_PATH}")
    print(f"  Dashboard         : {PNG_PATH}")
    print("=" * 78)


def main() -> None:
    print("=" * 78)
    print("FINAM — CNY/RUB FORWARD MONITOR v2.5")
    print("=" * 78)

    secret = os.getenv("FINAM_SECRET")
    if not secret:
        raise RuntimeError("Переменная окружения FINAM_SECRET не задана.")

    print()
    print("Создаём FinamStreamClient...")
    client = FinamStreamClient(secret=secret)

    future_symbol, future_asset, expiration = find_nearest_future(client)
    future_name = get_asset_name(future_asset) or future_symbol

    symbols = [
        TOM_SYMBOL,
        future_symbol,
        RUSFAR_SYMBOL,
        RUSFAR_3M_SYMBOL,
        RUSFARCNY_SYMBOL,
    ]

    print()
    print("ПОДПИСКА НА КОТИРОВКИ")
    for symbol in symbols:
        print(f"  {symbol}")

    print()
    print("Открываем SubscribeQuote...")
    stream = client.open_quote_stream(symbols)
    print("SubscribeQuote запущен.")

    manager = QuoteManager()
    reader = QuoteStreamReader(stream, manager)

    print()
    print("Запускаем поток чтения...")
    reader.start()

    print("Ждём первый snapshot...")
    deadline = time.time() + INITIAL_WAIT_SECONDS

    while time.time() < deadline:
        if all(manager.has(symbol) for symbol in symbols):
            break
        if reader.error:
            raise RuntimeError(f"Ошибка stream reader: {reader.error}")
        time.sleep(0.2)

    missing = [symbol for symbol in symbols if not manager.has(symbol)]
    if missing:
        reader.stop()
        raise RuntimeError(
            "Не получены snapshot для: " + ", ".join(missing)
        )

    print("Первоначальные snapshot получены.")

    # Если CSV уже существует, сразу строим dashboard из накопленной истории.
    draw_dashboard()

    try:
        while True:
            if reader.error:
                raise RuntimeError(
                    f"Ошибка stream reader: {reader.error}"
                )

            record = make_record(
                timestamp=now_local(),
                future_symbol=future_symbol,
                future_name=future_name,
                expiration=expiration,
                tom_quote=manager.get(TOM_SYMBOL) or {},
                future_quote=manager.get(future_symbol) or {},
                rusfar_quote=manager.get(RUSFAR_SYMBOL) or {},
                rusfar_3m_quote=manager.get(RUSFAR_3M_SYMBOL) or {},
                rusfarcny_quote=manager.get(RUSFARCNY_SYMBOL) or {},
                updates_count=reader.updates_count,
            )

            if record is not None:
                append_csv(record)
                draw_dashboard()
                print_record(record)

            time.sleep(UPDATE_INTERVAL)

    except KeyboardInterrupt:
        print()
        print("Остановка по Ctrl+C...")

    finally:
        reader.stop()
        print("Stream остановлен.")
        print("FINAM CNY/RUB FORWARD MONITOR завершён.")


if __name__ == "__main__":
    main()
