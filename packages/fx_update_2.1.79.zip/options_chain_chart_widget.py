# -*- coding: utf-8 -*-
"""FX Terminal — график цепочки опционов Finam gRPC (вкладка «Опционы», см. options_tab.py).

Вкладки: «Премии» (цепочка и история опциона), «Открытый интерес» (профиль OI или его изменение
за час / с начала дня, PCR, Max Pain, ожидаемое движение, история итогов), «Волатильность» (улыбка сейчас /
вчера / неделю назад, история ATM IV и перекоса 25Δ, IV rank; options_vol_view.py) и «Гамма (GEX)» (GEX коллов
и путов по страйкам, суммарная GEX по цене с зонами и Gamma flip; options_gex_view.py) — все на одном потоке
котировок, без JSON и отдельного монитора. История волатильности — таблица iv_points (раз в IV_POINT_SECONDS,
прошлые дни восстанавливаются из option_quotes).

Опционные уровни выбранной экспирации (option_levels.py: Max Pain, Call / Put wall, Gamma flip, коридор
ожидаемого движения) раз в LEVELS_SECONDS публикуются в общий реестр — их рисуют графики и стаканы базового
актива (галочка «Уровни на графиках и в стаканах»). «Метрика цепочки» — поля котировки (Mid, Bid, Ask, Last,
теоретическая цена, IV) или расчётные греки и GEX по страйкам (option_levels.greeks_of, модель Блэка).

Требования: PySide6, pyqtgraph, protobuf, finam_sdk_client, finam_trade_api;
рядом options_common.py и options_oi_view.py.

    OptionsChainChartWidget("CRZ6@RTSX", client=sdk_client, hub=md_hub)

client — FinamStreamClient терминала (цепочку OptionsChain запрашивает он; виджет его не
закрывает). Котировки — из hub (MarketDataHub терминала) одной пакетной подпиской
(subscribe_quotes_many: шлюз держит по потоку на группу из 10 символов и сам переподключает
их после обрыва).
"""
from __future__ import annotations

import json
import math
import time
import sqlite3
from datetime import datetime, timedelta, timezone
import threading
from contextlib import closing
from pathlib import Path

import app_paths  # папка данных (2.1.79: в собранной программе — %LOCALAPPDATA%\FX_Terminal)

import pyqtgraph as pg
from google.protobuf.json_format import MessageToDict
from PySide6.QtCore import Qt, QTimer, QObject, Signal, Slot
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QCheckBox,
    QPushButton, QSplitter, QMessageBox, QTabWidget,
)

from finam_trade_api.assets import OptionsChainRequest

from options_common import (
    default_underlying, full_symbol, short_symbol, underlying_choices, underlying_kind,
    underlying_label,
)
from options_oi_view import OIProfileView
from options_vol_view import VolatilityView
from options_gex_view import GexView
import option_levels as ol
from options_theme import palette

SNAPSHOT_SECONDS = 5
HISTORY_LIMIT = 1500
MAX_REL_SPREAD = 1.0           # Mid не рисуем, если (ask-bid)/mid больше этого
PRICE_METRICS = ("mid", "bid", "ask", "last", "theoretical")
RETENTION_DAYS = 30            # 0 — не чистить историю
STALE_QUOTE_SECONDS = 120      # дольше нет котировок — ленту считаем молчащей, историю OI не пишем
OI_WARMUP_SECONDS = 60         # после загрузки цепочки итоги OI неполные (котировки ещё приходят)
OI_HEARTBEAT_SECONDS = 300     # (до 2.0.79) итог OI писали и без изменений раз в 5 минут — ночью и в выходные
                               # это сотни одинаковых точек; теперь только при изменении (oi_totals_since берёт
                               # последнюю запись не позже нужного момента — повторы ей не нужны)
OI_HISTORY_LIMIT = 1500
OI_MIN_COVERAGE = 0.5          # итог OI пишем, только если OI известен хотя бы по этой доле опционов
OI_COVERAGE_KEEP = 0.97        # и не меньше чем по 97 % от лучшего покрытия экспирации за сеанс: иначе это
                               # недогруженная цепочка (переподписка, запуск) — итог занижен, на графике провал
OI_COVERAGE_RESET_SEC = 600    # покрытие ниже лучшего дольше 10 минут — это уже не догрузка: принять как норму
DB_FILE = app_paths.DATA_DIR / "options_history.db"
def ol_msk():
    return timezone(timedelta(hours=3))


LEVELS_SECONDS = 5             # пересчёт опционных уровней для графиков и стаканов
IV_POINT_SECONDS = 300         # точка истории волатильности (ATM IV, перекос, улыбка) — раз в 5 минут
VOL_REFRESH_SECONDS = 5        # перерисовка вкладки «Волатильность», пока она открыта
GEX_REFRESH_SECONDS = 5        # перерисовка вкладки «Гамма (GEX)», пока она открыта
GEX_TAB = 3                    # номер вкладки «Гамма (GEX)»
IV_BACKFILL_LOOKBACK = 86400   # состояние цепочки на конец прошлого дня — по записям за последние сутки
IV_POINTS_VERSION = 2          # растёт при смене расчёта улыбки — старая история волатильности пересчитывается
CHANGES_SECONDS = 60           # пересчёт изменения OI по страйкам (запросы к истории в SQLite)
SLOW_TAB_MS = 300              # заполнение вкладки дольше — строка в журнал (искать, что тормозит)

VALUE_KEYS = ("bid", "ask", "last", "close", "theoretical", "iv", "oi", "bid_size", "ask_size")


def _message_dict(message):
    """SDK может вернуть как protobuf-сообщение, так и уже готовый dict."""
    if isinstance(message, dict):
        return message
    return MessageToDict(message, preserving_proto_field_name=True)


def _raw(value):
    if isinstance(value, dict) and "value" in value:
        return value.get("value")
    return value


def _number(value):
    value = _raw(value)
    if value is None or isinstance(value, bool) or value == "":
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None     # NaN и ±inf — это не данные


def _positive(value):
    return value if value is not None and value > 0 else None


def _nested(data, *paths):
    for path in paths:
        value = data
        for key in path.split("."):
            if not isinstance(value, dict):
                value = None
                break
            value = value.get(key)
        if value is not None and value != "":
            return _raw(value)
    return None


def _option_type(value):
    text = str(value or "").upper()
    if "CALL" in text:
        return "CALL"
    if "PUT" in text:
        return "PUT"
    return "UNKNOWN"


def _extract_metadata(option):
    expiry = option.get("expiration_last_day") or option.get("expiration_first_day") or option.get("trade_last_day")
    if isinstance(expiry, dict):
        expiry = "-".join(str(expiry.get(k, 0)).zfill(2) for k in ("year", "month", "day"))
    return {
        "symbol": str(option.get("symbol") or ""),
        "type": _option_type(option.get("type")),
        "strike": _positive(_number(option.get("strike"))),
        "expiry": str(expiry or ""),
    }


def _values_from_quote(quote):
    """core.models.Quote (из хаба) -> значения опциона для таблицы и истории (VALUE_KEYS).
    Отрицательные цены, объёмы, OI и IV, а также NaN / ±inf — не данные (None)."""
    def clean(value):
        if value is None or not math.isfinite(value) or value < 0:
            return None
        return value
    return {
        "bid": clean(quote.bid), "ask": clean(quote.ask), "last": clean(quote.last),
        "close": clean(quote.close), "theoretical": clean(quote.theoretical), "iv": clean(quote.iv),
        "oi": clean(quote.open_interest), "bid_size": clean(quote.bid_size), "ask_size": clean(quote.ask_size),
    }


def _mirror_price_axis(plot):
    """Дублирует шкалу цены справа (оси связаны с одним ViewBox, значения те же)."""
    plot.showAxis("right")
    plot.getAxis("right").setStyle(showValues=True)


class QuoteStore:
    """SQLite-хранилище. Каждое обращение открывает и ЗАКРЫВАЕТ своё соединение.

    Пишутся только изменившиеся котировки (иначе база растёт впустую),
    старые записи удаляются по RETENTION_DAYS.
    """
    def __init__(self, path: Path):
        self.path = path
        self._last_saved: dict[tuple[str, str], tuple] = {}
        self._last_oi: dict[tuple[str, str], tuple] = {}
        self._best_oi_coverage: dict[tuple[str, str], int] = {}   # наибольшее «OI известен по N опционам» за сеанс
        self._low_oi_since: dict[tuple[str, str], float] = {}     # с какого момента покрытие ниже лучшего
        self._init_db()

    def _connect(self):
        con = sqlite3.connect(str(self.path), timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def _init_db(self):
        with closing(self._connect()) as con:
            with con:
                con.execute("""CREATE TABLE IF NOT EXISTS option_quotes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    underlying TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    option_type TEXT,
                    strike REAL,
                    expiry TEXT,
                    bid REAL, ask REAL, last REAL, close REAL,
                    theoretical REAL, iv REAL, oi REAL,
                    bid_size REAL, ask_size REAL
                )""")
                con.execute("CREATE INDEX IF NOT EXISTS idx_option_history ON option_quotes(underlying, symbol, ts)")
                con.execute("CREATE INDEX IF NOT EXISTS idx_option_chain ON option_quotes(underlying, ts, option_type, strike)")
                con.execute("""CREATE TABLE IF NOT EXISTS oi_totals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    underlying TEXT NOT NULL,
                    expiry TEXT NOT NULL,
                    futures_price REAL,
                    call_oi REAL, put_oi REAL, pcr REAL
                )""")
                columns = {row[1] for row in con.execute("PRAGMA table_info(oi_totals)")}
                for name in ("with_oi", "total"):      # покрытие: по скольким опционам из скольких известен OI
                    if name not in columns:
                        con.execute(f"ALTER TABLE oi_totals ADD COLUMN {name} INTEGER")
                con.execute("CREATE INDEX IF NOT EXISTS idx_oi_totals ON oi_totals(underlying, expiry, ts)")
                # История волатильности экспирации: ATM IV, перекос 25Δ и улыбка (JSON [[страйк, IV], …]).
                # Пишется раз в IV_POINT_SECONDS, прошлые дни дозаполняются из option_quotes (backfill_iv).
                con.execute("""CREATE TABLE IF NOT EXISTS iv_points (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    underlying TEXT NOT NULL,
                    expiry TEXT NOT NULL,
                    price REAL, atm_iv REAL, rr25 REAL, smile TEXT
                )""")
                con.execute("CREATE INDEX IF NOT EXISTS idx_iv_points ON iv_points(underlying, expiry, ts)")
                # Версия расчёта истории волатильности: точки, посчитанные до фильтра выбросов улыбки (30.10),
                # стираются — прошлые дни заново восстановит backfill_iv уже с фильтром.
                if con.execute("PRAGMA user_version").fetchone()[0] < IV_POINTS_VERSION:
                    con.execute("DELETE FROM iv_points")
                    con.execute(f"PRAGMA user_version = {IV_POINTS_VERSION}")
                if RETENTION_DAYS > 0:
                    cutoff = time.time() - RETENTION_DAYS * 86400
                    con.execute("DELETE FROM option_quotes WHERE ts < ?", (cutoff,))
                    con.execute("DELETE FROM oi_totals WHERE ts < ?", (cutoff,))
                    con.execute("DELETE FROM iv_points WHERE ts < ?", (cutoff,))

    def save_snapshot(self, underlying, records):
        now = time.time()
        rows = []
        fresh = {}
        for symbol, r in records.items():
            v = r.get("values", {})
            vals = tuple(v.get(k) for k in VALUE_KEYS)
            # Не засоряем базу пустыми записями до первой котировки
            # и повторами, когда ничего не изменилось с прошлого снимка.
            if all(x is None for x in vals[:7]):
                continue
            key = (underlying, symbol)
            if self._last_saved.get(key) == vals:
                continue
            fresh[key] = vals
            bid, ask, last, close, theoretical, iv, oi, bid_size, ask_size = vals
            rows.append((now, underlying, symbol, r.get("type"), r.get("strike"), r.get("expiry"),
                         bid, ask, last, close, theoretical, iv, oi, bid_size, ask_size))
        if not rows:
            return 0
        with closing(self._connect()) as con:
            with con:
                con.executemany("""INSERT INTO option_quotes
                    (ts,underlying,symbol,option_type,strike,expiry,bid,ask,last,close,theoretical,iv,oi,bid_size,ask_size)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", rows)
        self._last_saved.update(fresh)   # кэш обновляем только после успешной записи
        return len(rows)

    def save_oi_totals(self, underlying, totals, price):
        """totals: {экспирация: (call_oi, put_oi, опционов_с_OI, опционов_всего)}.

        Пишем только достоверное: если OI известен меньше чем по OI_MIN_COVERAGE опционов или заметно меньше,
        чем уже бывало за сеанс (OI_COVERAGE_KEEP), итог неполный и в историю не попадает. Неизвестная сторона
        остаётся NULL (на графике разрыв), а не нулём. Запись — только при изменении итога."""
        now = time.time()
        rows = []
        fresh = {}
        for expiry, (call, put, with_oi, total) in totals.items():
            if call is None and put is None:
                continue
            if total <= 0 or with_oi / total < OI_MIN_COVERAGE:
                continue
            key = (underlying, expiry)
            best = max(self._best_oi_coverage.get(key, 0), with_oi)
            if with_oi < best * OI_COVERAGE_KEEP:
                since = self._low_oi_since.setdefault(key, now)
                if now - since < OI_COVERAGE_RESET_SEC:
                    self._best_oi_coverage[key] = best
                    continue                 # цепочка догружается — итог занижен
                best = with_oi               # покрытие упало надолго (опционы сняли с торгов) — новая норма
            self._low_oi_since.pop(key, None)
            self._best_oi_coverage[key] = best
            last = self._last_oi.get(key)
            if last and last[0] == (call, put):
                continue                     # без изменений — повтор не пишем
            pcr = put / call if put is not None and call else None
            rows.append((now, underlying, expiry, price, call, put, pcr, with_oi, total))
            fresh[key] = ((call, put), now)
        if not rows:
            return 0
        with closing(self._connect()) as con:
            with con:
                con.executemany("""INSERT INTO oi_totals
                    (ts,underlying,expiry,futures_price,call_oi,put_oi,pcr,with_oi,total)
                    VALUES (?,?,?,?,?,?,?,?,?)""", rows)
        self._last_oi.update(fresh)
        return len(rows)

    def oi_totals_since(self, underlying, expiry, since):
        """Итоги OI экспирации [(ts, call, put, pcr, цена фьючерса)] начиная с последней записи
        не позже since (точка «час назад») — для итогов за час."""
        with closing(self._connect()) as con:
            base = con.execute("""SELECT ts,call_oi,put_oi,pcr,futures_price FROM oi_totals
                WHERE underlying=? AND expiry=? AND ts<=? ORDER BY ts DESC LIMIT 1""",
                               (underlying, expiry, since)).fetchall()
            rows = con.execute("""SELECT ts,call_oi,put_oi,pcr,futures_price FROM oi_totals
                WHERE underlying=? AND expiry=? AND ts>? ORDER BY ts""", (underlying, expiry, since)).fetchall()
        return base + rows

    def oi_at(self, underlying, symbols, at):
        """OI опционов на момент at: {символ: (ts, oi)} — последняя запись не позже at, а если её нет —
        первая после (история короче часа)."""
        out = {}
        with closing(self._connect()) as con:
            for symbol in symbols:
                row = con.execute("""SELECT ts,oi FROM option_quotes WHERE underlying=? AND symbol=?
                    AND ts<=? AND oi IS NOT NULL ORDER BY ts DESC LIMIT 1""", (underlying, symbol, at)).fetchone()
                if row is None:
                    row = con.execute("""SELECT ts,oi FROM option_quotes WHERE underlying=? AND symbol=?
                        AND ts>? AND oi IS NOT NULL ORDER BY ts LIMIT 1""", (underlying, symbol, at)).fetchone()
                if row is not None:
                    out[symbol] = (row[0], row[1])
        return out

    def oi_history(self, underlying, expiry, limit=OI_HISTORY_LIMIT):
        with closing(self._connect()) as con:
            return con.execute("""SELECT ts,call_oi,put_oi,pcr FROM oi_totals
                WHERE underlying=? AND expiry=? ORDER BY ts DESC LIMIT ?""", (underlying, expiry, limit)).fetchall()[::-1]

    # ---- волатильность

    def save_iv_point(self, underlying, expiry, snap, ts=None):
        """snap — option_levels.vol_snapshot(): точка истории ATM IV / перекоса / улыбки."""
        with closing(self._connect()) as con:
            with con:
                con.execute("""INSERT INTO iv_points (ts,underlying,expiry,price,atm_iv,rr25,smile)
                    VALUES (?,?,?,?,?,?,?)""", (ts or time.time(), underlying, expiry, snap.get("price"),
                                                snap.get("atm"), snap.get("rr25"),
                                                json.dumps([[k, round(v, 5)] for k, v in snap["smile"]])))

    def iv_points(self, underlying, expiry):
        """[(ts, цена, ATM IV, перекос 25Δ, улыбка [(страйк, IV)])] по времени."""
        with closing(self._connect()) as con:
            rows = con.execute("""SELECT ts,price,atm_iv,rr25,smile FROM iv_points
                WHERE underlying=? AND expiry=? ORDER BY ts""", (underlying, expiry)).fetchall()
        out = []
        for ts, price, atm, rr, smile in rows:
            try:
                pts = [(float(k), float(v)) for k, v in json.loads(smile or "[]")]
            except (ValueError, TypeError):
                pts = []
            out.append((ts, price, atm, rr, pts))
        return out

    def chain_at(self, underlying, expiry, at, lookback=IV_BACKFILL_LOOKBACK):
        """Состояние цепочки на момент at: последняя запись каждого опциона за lookback до at —
        [{"type", "strike", "values": {bid, ask, iv, oi}}] (как записи виджета, для option_levels)."""
        with closing(self._connect()) as con:
            rows = con.execute("""SELECT symbol, option_type, strike, bid, ask, iv, oi, MAX(ts) FROM option_quotes
                WHERE underlying=? AND ts<=? AND ts>? AND expiry=? GROUP BY symbol""",
                               (underlying, at, at - lookback, expiry)).fetchall()
        return [{"symbol": sym, "type": typ, "strike": strike,
                 "values": {"bid": bid, "ask": ask, "iv": iv, "oi": oi}}
                for sym, typ, strike, bid, ask, iv, oi, _ts in rows]

    def day_closes(self, underlying, expiry):
        """Последняя запись итогов OI каждого прошедшего дня (по Москве): [(ts, цена фьючерса)] — точки,
        на которые восстанавливается история волатильности до начала её записи."""
        with closing(self._connect()) as con:
            rows = con.execute("""SELECT MAX(ts), futures_price FROM oi_totals
                WHERE underlying=? AND expiry=? AND futures_price IS NOT NULL
                GROUP BY CAST((ts + 10800) / 86400 AS INTEGER)""", (underlying, expiry)).fetchall()
        today = int((time.time() + 10800) // 86400)
        return [(ts, price) for ts, price in rows if ts and int((ts + 10800) // 86400) < today]

    def backfill_iv(self, underlying, expiry):
        """Дозаполнить историю волатильности закрытиями прошлых дней, которых в iv_points ещё нет
        (вызывается в фоновом потоке: запросы по option_quotes на большой базе небыстрые)."""
        have = {int((ts + 10800) // 86400) for ts, *_rest in self.iv_points(underlying, expiry)}
        added = 0
        for ts, price in self.day_closes(underlying, expiry):
            if int((ts + 10800) // 86400) in have:
                continue
            snap = ol.vol_snapshot(self.chain_at(underlying, expiry, ts), price, expiry,
                                   today=datetime.fromtimestamp(ts, ol_msk()).date())
            if snap:
                self.save_iv_point(underlying, expiry, snap, ts=ts)
                added += 1
        return added

    def history(self, underlying, symbol, limit=HISTORY_LIMIT):
        with closing(self._connect()) as con:
            return con.execute("""SELECT ts,bid,ask,last,close,theoretical,iv FROM option_quotes
                WHERE underlying=? AND symbol=? ORDER BY ts DESC LIMIT ?""", (underlying, symbol, limit)).fetchall()[::-1]


class StreamWorker(QObject):
    """Фоновый воркер: запрашивает цепочку (OptionsChain) у клиента терминала.

    Клиент создан в ГЛАВНОМ потоке и передан сюда готовым (первый SSL/gRPC-вызов из фонового
    потока на Windows ронял python.exe); воркер его не создаёт и не закрывает.
    Котировки подписывает виджет в хабе (в GUI-потоке, по chain_ready), а воркер после этого
    ждёт stop() — так перезапуск при смене инструмента идёт одним путём
    (stop -> stopped -> новый воркер)."""
    status = Signal(str)
    chain_ready = Signal(str, object)
    error = Signal(str)
    stopped = Signal()

    def __init__(self, underlying: str, client):
        super().__init__()
        self.underlying = underlying
        self._client = client
        self._stop = threading.Event()
        self._main_thread = None
        self.running = False

    def start(self):
        self.running = True
        self._main_thread = threading.Thread(target=self._run, daemon=True, name="OptionsChainWorker")
        self._main_thread.start()

    def stop(self):
        self._stop.set()

    def _run(self):
        try:
            if self._client is None:
                raise RuntimeError("Нет клиента Finam.")
            self.status.emit(f"Запрашиваем цепочку {short_symbol(self.underlying)}…")
            response = self._client._client.assets.OptionsChain(OptionsChainRequest(underlying_symbol=self.underlying))
            data = _message_dict(response)
            options = data.get("options", data.get("option", []))
            if isinstance(options, dict):
                options = [options]
            if not isinstance(options, list):
                options = []
            records = {}
            for item in options:
                if not isinstance(item, dict):
                    continue
                meta = _extract_metadata(item)
                if meta["symbol"]:
                    records[meta["symbol"]] = {**meta, "values": {}}
            if not records:
                raise RuntimeError(f"Finam вернул пустую/нераспознанную цепочку для {short_symbol(self.underlying)}.")
            if self._stop.is_set():
                return
            self.chain_ready.emit(str(data.get("symbol") or self.underlying), records)
            self._stop.wait()                # котировки — в хабе (виджет, _on_chain)
        except Exception as exc:
            self.error.emit(f"{type(exc).__name__}: {exc}")
        finally:
            self.stop()
            self.running = False
            self.stopped.emit()


class OptionsChainChartWidget(QWidget):
    """Виджет цепочки опционов и истории котировок.

    Нагрузка (02.11, замер: «Qt Timer → QTimer [Опционы]» до 120–176 мс/с в пиковую секунду):
    * раз в секунду цепочка пересчитывается и перерисовывается, только если с прошлого раза пришли котировки
      (_plots_dirty) и окно видно (_view_visible); смена экспирации, метрики, вкладки и новая цепочка —
      как раньше, сразу. Опционные уровни для графиков и стаканов (_publish_levels) считаются всегда;
    * снимок цепочки и итоги OI пишутся в SQLite в фоновом потоке (_saver), интерфейс его не ждёт:
      в поток уходит копия записей, по окончании — сигнал _saved (история перечитывается в GUI)."""
    _saved = Signal(int, bool, str)          # (записано котировок, записаны итоги OI, текст ошибки) — из _saver

    def __init__(self, underlying=None, parent=None, client=None, hub=None):
        super().__init__(parent)
        from concurrent.futures import ThreadPoolExecutor
        self._saver = ThreadPoolExecutor(max_workers=1, thread_name_prefix="options-sqlite")
        self._save_busy = False              # снимок ещё пишется — следующий таймер пропускаем
        self._plots_dirty = True             # пришли котировки после последнего пересчёта цепочки
        self._saved.connect(self._on_saved)
        underlying = underlying or default_underlying()
        self.underlying = underlying
        self.store = QuoteStore(DB_FILE)
        self.records = {}
        self.underlying_values = {}
        self.chain_symbol = underlying
        self._closing = False
        self._restart_pending = False
        self._auto_pick_pending = True   # выбрать опцион у денег, когда придёт цена базового актива
        self._pending_underlying = None  # куда переключаемся; self.underlying меняется только в _begin_restart
        self._last_quote_time = 0.0
        self._chain_loaded_at = 0.0
        self._client = client            # общий клиент терминала — виджет его не закрывает
        # Хаб подписок терминала: котировки цепочки берутся из него (см. _subscribe_hub).
        self._hub = hub
        self._hub_subs = []
        self._hub_symbols = {}       # InstrumentId -> символ, как в records / self.underlying
        self.worker = None
        self._build_ui()

        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._on_refresh_timer)
        self.refresh_timer.start(1000)

        # Снимки сохраняются таймером, а не только при поступлении котировки.
        # PreciseTimer: «грубый» таймер Qt может срабатывать на 5% раньше интервала.
        self.snapshot_timer = QTimer(self)
        self.snapshot_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.snapshot_timer.timeout.connect(self._save_snapshot)
        self.snapshot_timer.start(SNAPSHOT_SECONDS * 1000)
        self._start_worker()

    # ---- воркер ------------------------------------------------------------
    def _start_worker(self):
        if self._client is None or self._hub is None:
            self._set_status("Нет подключения к Finam: откройте «Настройки…» и подключитесь.")
            return
        self.worker = StreamWorker(self.underlying, self._client)
        self.worker.status.connect(self._set_status)
        self.worker.chain_ready.connect(self._on_chain)
        self.worker.error.connect(self._on_error)
        self.worker.stopped.connect(self._on_stopped)
        self.worker.start()

    def _begin_restart(self):
        # Только теперь, когда старый воркер остановлен, а старая цепочка очищена,
        # меняем рабочий инструмент: иначе снимки старой цепочки писались бы в БД
        # под именем нового инструмента.
        ol.registry().clear(self.underlying)          # уровни прежнего инструмента с графиков и стаканов
        self._levels_at = 0
        if self._pending_underlying:
            self.underlying = self._pending_underlying
        self._pending_underlying = None
        self._close_hub_subs()
        self.setWindowTitle(f"Options Chain — {short_symbol(self.underlying)}")
        self.records.clear()
        self.underlying_values.clear()
        self.underlying_label.setText(f"{underlying_kind(self.underlying)}: ожидаем котировку")
        self.option_combo.clear()
        self.expiry_combo.clear()
        self._auto_pick_pending = True
        self.chain_plot.enableAutoRange()
        self.oi_view.clear()
        self.vol_view.clear()
        self.gex_view.clear()
        self._start_worker()

    def _build_ui(self):
        pal = palette()
        self.setWindowTitle(f"Options Chain — {short_symbol(self.underlying)}")
        self.resize(1250, 850)
        root = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Базовый инструмент:"))
        self.underlying_combo = QComboBox()
        self.underlying_combo.setEditable(True)
        self._fill_underlying_combo(self.underlying)
        self.underlying_combo.activated.connect(self._on_underlying_chosen)   # только выбор пользователем
        top.addWidget(self.underlying_combo)
        top.addWidget(QLabel("Экспирация:"))
        self.expiry_combo = QComboBox()
        self.expiry_combo.currentIndexChanged.connect(self._on_expiry_changed)
        top.addWidget(self.expiry_combo)
        top.addWidget(QLabel("Метрика цепочки:"))
        self.metric_combo = QComboBox()
        self.metric_combo.addItem("Mid (Bid/Ask)", "mid")
        self.metric_combo.addItem("Bid", "bid")
        self.metric_combo.addItem("Ask", "ask")
        self.metric_combo.addItem("Last", "last")
        self.metric_combo.addItem("Теоретическая цена", "theoretical")
        self.metric_combo.addItem("IV", "iv")
        # Греки и GEX — расчёт по модели Блэка (option_levels.greeks_of), не поля котировки
        self.metric_combo.addItem("Дельта", "delta")
        self.metric_combo.addItem("Гамма", "gamma")
        self.metric_combo.addItem("Тета, ₽ в день", "theta")
        self.metric_combo.addItem("Вега, ₽ на 1 п. IV", "vega")
        self.metric_combo.addItem("GEX, фьюч. на 1% (колл +, пут −)", "gex")
        self.metric_combo.setToolTip(
            "Греки — модель Блэка для опционов на фьючерс (ставка 0), волатильность — IV из котировки,\n"
            "нет её — подразумеваемая из середины спреда.\n"
            "GEX — сколько фьючерсов придётся купить / продать хеджерам страйка при движении цены на 1%:\n"
            "гамма × OI × цена × 1%, колл «+», пут «−» (опционы покупают клиенты, продают маркет-мейкеры).")
        self.metric_combo.currentIndexChanged.connect(self._on_metric_changed)
        top.addWidget(self.metric_combo)
        self.start_button = QPushButton("Переподключить")
        self.start_button.clicked.connect(self._restart)
        top.addWidget(self.start_button)
        self.note_button = QPushButton("Заметка")
        self.note_button.setToolTip("Итоги за последний час по выбранной экспирации — в «Заметки»:\n"
                                    "цена базового актива, OI CALL / PUT и PCR, где больше всего прибавилось OI")
        self.note_button.clicked.connect(self._add_hour_note)
        top.addWidget(self.note_button)
        self.levels_check = QCheckBox("Уровни на графиках и в стаканах")
        self.levels_check.setToolTip("Max Pain, Call / Put wall, Gamma flip и коридор ожидаемого движения выбранной\n"
                                     "экспирации — линиями на графиках и в стаканах базового актива")
        self.levels_check.setChecked(ol.registry().enabled)
        self.levels_check.toggled.connect(ol.registry().set_enabled)
        top.addWidget(self.levels_check)
        root.addLayout(top)

        self.status_label = QLabel("Подключение…")
        self.status_label.setWordWrap(True)
        root.addWidget(self.status_label)
        self.underlying_label = QLabel(f"{underlying_kind(self.underlying)}: ожидаем котировку")
        root.addWidget(self.underlying_label)

        splitter = QSplitter(Qt.Orientation.Vertical)
        self.chain_plot = pg.PlotWidget(title="Премии CALL / PUT по страйкам")
        self.chain_plot.setLabel("bottom", "Страйк")
        self.chain_plot.setLabel("left", "Значение метрики")
        self.chain_plot.showGrid(x=True, y=True, alpha=0.25)
        _mirror_price_axis(self.chain_plot)
        self.chain_plot.addLegend()
        self.chain_plot.setBackground(pal["bg"])
        self.call_curve = self.chain_plot.plot([], [], pen=pg.mkPen(pal["call"], width=2), symbol="o", symbolSize=5, name="CALL")
        self.put_curve = self.chain_plot.plot([], [], pen=pg.mkPen(pal["put"], width=2), symbol="o", symbolSize=5, name="PUT")
        splitter.addWidget(self.chain_plot)

        bottom = QWidget()
        bottom_layout = QVBoxLayout(bottom)
        controls = QHBoxLayout()
        controls.addWidget(QLabel("Опцион для истории:"))
        self.option_combo = QComboBox()
        self.option_combo.currentIndexChanged.connect(self._refresh_history)
        self.option_combo.activated.connect(self._on_option_chosen)   # только выбор пользователем
        self.option_combo.setMinimumWidth(300)
        self.option_combo.setMaximumWidth(340)
        controls.addWidget(self.option_combo)
        controls.addWidget(QLabel(f"Точек истории: {HISTORY_LIMIT}"))
        controls.addStretch(1)
        bottom_layout.addLayout(controls)
        self.history_plot = pg.PlotWidget(
            title="История выбранного опциона",
            axisItems={"bottom": pg.DateAxisItem(orientation="bottom")},
        )
        self.history_plot.setLabel("bottom", "Время")
        self.history_plot.setBackground(pal["bg"])
        self.history_plot.setLabel("left", "Цена")
        self.history_plot.showGrid(x=True, y=True, alpha=0.25)
        _mirror_price_axis(self.history_plot)
        self.history_plot.addLegend()
        self.hist_bid = self.history_plot.plot([], [], pen=pg.mkPen("#36a2ff", width=1.5), name="Bid")
        self.hist_ask = self.history_plot.plot([], [], pen=pg.mkPen("#ff9f43", width=1.5), name="Ask")
        self.hist_last = self.history_plot.plot([], [], pen=pg.mkPen("#f5f5f5", width=1.5), name="Last")
        self.hist_mid = self.history_plot.plot([], [], pen=pg.mkPen("#b084f5", width=1.5, style=Qt.PenStyle.DashLine), name="Mid")
        bottom_layout.addWidget(self.history_plot)
        splitter.addWidget(bottom)
        splitter.setSizes([450, 350])

        self.tabs = QTabWidget()
        self.tabs.addTab(splitter, "Премии")
        self.oi_view = OIProfileView()
        self.oi_view.modeChanged.connect(lambda _i: self._refresh_changes(force=True))
        self.tabs.addTab(self.oi_view, "Открытый интерес")
        self.vol_view = VolatilityView()
        self.tabs.addTab(self.vol_view, "Волатильность")
        self.gex_view = GexView()
        self.gex_view.unitsChanged.connect(lambda: self._refresh_gex(force=True))
        self.tabs.addTab(self.gex_view, "Гамма (GEX)")
        self._iv_saved_at: dict[tuple[str, str], float] = {}    # (базовый актив, экспирация) -> время точки истории
        self._iv_backfilled: set[tuple[str, str]] = set()       # для них прошлые дни уже восстановлены
        self._iv_backfill_busy = False
        self.tabs.currentChanged.connect(self._on_tab_changed)
        root.addWidget(self.tabs, 1)
        qss = """
            QWidget { background: #0b0d13; color: #d9deea; }
            QComboBox, QPushButton { background: #171b25; border: 1px solid #303849; border-radius: 6px; padding: 6px; }
            QPushButton:hover { background: #222a39; }
            QTabWidget::pane { border: 1px solid #303849; top: -1px; }
            QTabBar::tab { background: #171b25; border: 1px solid #303849; padding: 6px 14px;
                           border-top-left-radius: 6px; border-top-right-radius: 6px; }
            QTabBar::tab:selected { background: #222a39; }
        """
        if not pal["themed"]:      # с темой FX Terminal оформление берётся из QSS приложения
            self.setStyleSheet(qss)

    # ---- слоты -----------------------------------------------------------
    @Slot(str)
    def _set_status(self, text):
        self.status_label.setText(text)

    @Slot(str)
    def _on_error(self, message):
        self.status_label.setText("Ошибка: " + message)

    @Slot()
    def _on_stopped(self):
        if self._closing:
            return
        if self._restart_pending:
            self._restart_pending = False
            self._begin_restart()
        else:
            self.status_label.setText(self.status_label.text() + " | Поток остановлен.")

    @Slot(str, object)
    def _on_chain(self, chain_symbol, records):
        self.chain_symbol = chain_symbol
        self.records = records
        # Экспирации: на одном графике разные серии смешивать нельзя —
        # одинаковые страйки разных дат дают зигзаг.
        expiries = sorted({r.get("expiry") or "" for r in records.values()})
        self.expiry_combo.blockSignals(True)
        self.expiry_combo.clear()
        for exp in expiries:
            self.expiry_combo.addItem(exp or "—", exp)
        self.expiry_combo.blockSignals(False)
        self._auto_pick_pending = True
        self._chain_loaded_at = time.time()
        self.chain_plot.enableAutoRange()   # диапазон осей мог остаться от прошлого инструмента
        self.oi_view.reset_view()
        self._fill_option_combo()
        self._try_auto_pick()
        self._set_status(f"Цепочка {short_symbol(chain_symbol)}: {len(records)} опционов, экспираций: {len(expiries)}. Ожидаем котировки; сохранение в {DB_FILE.name} каждые {SNAPSHOT_SECONDS} сек.")
        self._subscribe_hub()
        self._refresh_plots()
        self._refresh_history()
        self._refresh_oi_history()

    def _current_expiry(self):
        return self.expiry_combo.currentData() if self.expiry_combo.count() else None

    def _fill_option_combo(self):
        expiry = self._current_expiry()
        previous = self.option_combo.currentData()
        ordered = sorted(
            (r for r in self.records.values() if expiry is None or (r.get("expiry") or "") == expiry),
            key=lambda r: (r.get("strike") is None, r.get("strike") or 0, r.get("type", "")),
        )
        self.option_combo.blockSignals(True)
        self.option_combo.clear()
        for rec in ordered:
            label = f"{rec['type']} {rec['strike'] if rec['strike'] is not None else '?'} — {short_symbol(rec['symbol'])}"
            self.option_combo.addItem(label, rec["symbol"])
        idx = self.option_combo.findData(previous)
        if idx >= 0:
            self.option_combo.setCurrentIndex(idx)
        self.option_combo.blockSignals(False)

    @Slot()
    def _on_expiry_changed(self, *_):
        self._levels_at = 0                           # уровни новой экспирации — сразу
        self._auto_pick_pending = True
        self.chain_plot.enableAutoRange()
        self.oi_view.reset_view()
        self.vol_view.clear()
        self._vol_at = 0.0
        self.gex_view.clear()
        self._gex_at = 0.0
        self._fill_option_combo()
        self._try_auto_pick()
        self._refresh_plots()
        self._refresh_history()
        self._refresh_oi_history()

    @Slot()
    def _on_tab_changed(self, index):
        # Заполняем вкладку после того, как Qt её покажет (singleShot 0): переключение мгновенное,
        # данные дорисовываются следом. Раньше расчёт шёл до показа, и вкладка открывалась с задержкой.
        QTimer.singleShot(0, lambda i=index: self._fill_tab(i))

    def _fill_tab(self, index):
        if self._closing or self.tabs.currentIndex() != index:
            return
        t0 = time.perf_counter()
        if index == 1:
            self._refresh_oi(force=True)
            self._refresh_oi_history()
        elif index == 2:
            self._refresh_vol(force=True)
        elif index == GEX_TAB:
            self._refresh_gex(force=True)
        spent = (time.perf_counter() - t0) * 1000
        if spent > SLOW_TAB_MS:
            print(f"[опционы] вкладка «{self.tabs.tabText(index)}» заполнялась {spent:.0f} мс")

    # ---- волатильность -----------------------------------------------------

    def _vol_snapshot(self, expiry):
        """Текущая улыбка, ATM IV и перекос экспирации (option_levels.vol_snapshot) или None."""
        recs = [r for r in self.records.values() if (r.get("expiry") or "") == expiry and r.get("strike")]
        return ol.vol_snapshot(recs, self._ref_price(), expiry)

    def _record_iv_point(self, expiry, snap):
        """Точка истории волатильности — раз в IV_POINT_SECONDS, пока лента котировок жива."""
        now = time.time()
        key = (self.underlying, expiry)
        if not snap or snap.get("atm") is None or now - self._last_quote_time > STALE_QUOTE_SECONDS:
            return
        if now - self._chain_loaded_at < OI_WARMUP_SECONDS or now - self._iv_saved_at.get(key, 0.0) < IV_POINT_SECONDS:
            return
        self._iv_saved_at[key] = now
        try:
            self.store.save_iv_point(self.underlying, expiry, snap)
        except Exception as exc:
            self.status_label.setText(f"Ошибка записи SQLite: {exc}")

    def _start_iv_backfill(self, expiry):
        """Восстановить историю волатильности прошлых дней из сохранённых котировок — один раз на экспирацию,
        в фоновом потоке (на большой базе это секунды). По окончании вкладка перерисуется таймером."""
        key = (self.underlying, expiry)
        if key in self._iv_backfilled or self._iv_backfill_busy:
            return
        self._iv_backfilled.add(key)
        self._iv_backfill_busy = True
        store, underlying = self.store, self.underlying

        def run():
            try:
                store.backfill_iv(underlying, expiry)
            except Exception as exc:                       # база занята / повреждена — история просто короче
                print(f"[опционы] история волатильности не восстановлена: {exc}")
            finally:
                self._iv_backfill_busy = False
                self._vol_at = 0.0                          # перерисовать с новыми точками

        threading.Thread(target=run, daemon=True, name="IvBackfill").start()

    def _refresh_vol(self, force=False):
        """Вкладка «Волатильность» — только когда открыта, не чаще VOL_REFRESH_SECONDS."""
        if self.tabs.currentIndex() != 2 or not self.records:
            return
        now = time.time()
        if not force and now - getattr(self, "_vol_at", 0.0) < VOL_REFRESH_SECONDS:
            return
        self._vol_at = now
        expiry = self._current_expiry()
        if expiry is None:
            return
        self._start_iv_backfill(expiry)
        try:
            points = self.store.iv_points(self.underlying, expiry)
        except Exception as exc:
            self.status_label.setText(f"Ошибка чтения SQLite: {exc}")
            return
        self.vol_view.set_data(self._vol_snapshot(expiry), points,
                               f"{short_symbol(self.underlying)}, экспирация {expiry}")

    # ---- гамма-экспозиция ----------------------------------------------------

    def _refresh_gex(self, force=False):
        """Вкладка «Гамма (GEX)» — только когда открыта, не чаще GEX_REFRESH_SECONDS (option_levels.gex_profile)."""
        if self.tabs.currentIndex() != GEX_TAB or not self.records:
            return
        now = time.time()
        if not force and now - getattr(self, "_gex_at", 0.0) < GEX_REFRESH_SECONDS:
            return
        self._gex_at = now
        expiry = self._current_expiry()
        if expiry is None:
            return
        recs = [r for r in self.records.values() if (r.get("expiry") or "") == expiry and r.get("strike")]
        profile = ol.gex_profile(recs, self._ref_price(), ol.years_to_expiry(expiry))
        self.gex_view.set_data(profile, f"{short_symbol(self.underlying)}, экспирация {expiry}",
                               ol.contract_units(self.underlying))

    def _oi_rows(self, expiry):
        rows = []
        for rec in self.records.values():
            if expiry is not None and (rec.get("expiry") or "") != expiry:
                continue
            if rec.get("strike") is None or rec.get("type") not in ("CALL", "PUT"):
                continue
            rows.append({
                "type": rec["type"], "strike": rec["strike"], "symbol": rec["symbol"],
                "oi": rec.get("values", {}).get("oi"),
            })
        return rows

    def _refresh_oi(self, force=False):
        """Обновляет вкладку «Открытый интерес», только если она открыта."""
        if self.tabs.currentIndex() != 1 or not self.records:
            return
        expiry = self._current_expiry()
        self._refresh_changes()
        title = f"{short_symbol(self.underlying)}, экспирация {expiry or '—'}"
        self.oi_view.set_rows(self._oi_rows(expiry), self._ref_price(),
                              self.underlying_values.get("oi"), title, force=force,
                              kind=underlying_kind(self.underlying))

    def _refresh_changes(self, force=False):
        """Изменение OI по страйкам (режимы «за час» / «с начала дня» профиля и колонки Δ таблицы).
        История — из SQLite (option_quotes), поэтому не чаще раза в CHANGES_SECONDS."""
        mode = self.oi_view.profile_mode_index()
        expiry = self._current_expiry()
        key = (mode, expiry, self.underlying)
        now = time.time()
        if not force and key == getattr(self, "_changes_key", None) and now - getattr(self, "_changes_at", 0) < CHANGES_SECONDS:
            return
        self._changes_key, self._changes_at = key, now
        if not self.records or expiry is None:
            self.oi_view.set_changes(None)
            return
        if mode == 2:                                     # с начала дня (по Москве)
            day = datetime.now(ol_msk()).replace(hour=0, minute=0, second=0, microsecond=0)
            since, caption = day.timestamp(), "с начала дня"
        else:
            since, caption = now - 3600, "за час"
        rows = self._oi_rows(expiry)
        # Только опционы с известным OI: для остальных запрос «последний OI не позже since» перебирал всю
        # их историю в базе (OI там пустой) — на 30 днях истории это секунды при открытии вкладки.
        symbols = [r["symbol"] for r in rows if r["oi"] is not None]
        try:
            base = self.store.oi_at(self.underlying, symbols, since)
            changes = ol.oi_changes(rows, base)
            # «С начала дня» в выходной или до первых сделок по опционам: за сегодня OI не менялся (31.10, суббота —
            # профиль был пустым). Тогда показываем изменение за последний день, когда оно было (до 7 дней назад).
            back = 0
            while mode == 2 and base and not any(v for pair in changes.values() for v in pair) and back < 7:
                back += 1
                day_back = day - timedelta(days=back)
                base = self.store.oi_at(self.underlying, symbols, day_back.timestamp())
                changes = ol.oi_changes(rows, base)
                caption = f"с начала дня {day_back:%d.%m} (сегодня OI не менялся)"
        except Exception as exc:
            self.status_label.setText(f"Ошибка чтения SQLite: {exc}")
            return
        if base and "сегодня OI не менялся" not in caption:
            first = min(ts for ts, _oi in base.values())
            if first > since + 60:                        # история короче периода — честно пишем, с какого времени
                caption += f" (с {datetime.fromtimestamp(first).strftime('%H:%M')})"
        self.oi_view.set_changes(changes, caption)
        if force:
            self._refresh_oi(force=True)

    def _publish_levels(self):
        """Опционные уровни выбранной экспирации — в карточки «Открытого интереса» и в общий реестр
        (графики и стаканы базового актива). Раз в LEVELS_SECONDS."""
        now = time.time()
        if now - getattr(self, "_levels_at", 0) < LEVELS_SECONDS:
            return
        self._levels_at = now
        expiry = self._current_expiry()
        if not self.records or expiry is None:
            return
        rows = self._oi_rows(expiry)
        recs = [r for r in self.records.values() if (r.get("expiry") or "") == expiry and r.get("strike")]
        price = self._ref_price()
        call_wall, put_wall = ol.walls(rows, price)         # только опционы «вне денег»
        em, method = ol.expected_move(recs, price, expiry)
        years = ol.years_to_expiry(expiry)
        levels = ol.Levels(self.underlying, expiry, price=price, max_pain=ol.max_pain(rows),
                           call_wall=call_wall, put_wall=put_wall, em=em, em_method=method,
                           gamma_flip=ol.gamma_flip(recs, price, years), gex=ol.gex_total(recs, price, years))
        self.oi_view.set_levels(levels)
        if levels.max_pain is not None or levels.em:
            ol.registry().set(levels)
        self._record_iv_point(expiry, self._vol_snapshot(expiry))

    def _refresh_oi_history(self):
        if self.tabs.currentIndex() != 1:
            return
        expiry = self._current_expiry()
        if expiry is None:
            return
        try:
            self.oi_view.set_history(self.store.oi_history(self.underlying, expiry))
        except Exception as exc:
            self.status_label.setText(f"Ошибка чтения SQLite: {exc}")

    def _oi_totals(self):
        """Итоги OI по экспирациям для истории ({экспирация: (call, put, с OI, всего)}) или None — лента
        молчит или цепочка ещё не «прогрелась». Пишет их _save_snapshot (в фоновом потоке)."""
        now = time.time()
        if now - self._last_quote_time > STALE_QUOTE_SECONDS or now - self._chain_loaded_at < OI_WARMUP_SECONDS:
            return None
        totals = {}
        for rec in self.records.values():
            # Те же правила отбора, что и в _oi_rows, чтобы итоги в истории совпадали с профилем.
            if rec.get("strike") is None or rec.get("type") not in ("CALL", "PUT"):
                continue
            expiry = rec.get("expiry") or ""
            call, put, with_oi, total = totals.get(expiry, (None, None, 0, 0))
            total += 1
            oi = rec.get("values", {}).get("oi")
            if oi is not None:
                with_oi += 1
                if rec["type"] == "CALL":
                    call = (call or 0.0) + oi
                else:
                    put = (put or 0.0) + oi
            totals[expiry] = (call, put, with_oi, total)
        return totals

    @Slot()
    def _on_metric_changed(self, *_):
        self.chain_plot.enableAutoRange()   # у IV и цены разные масштабы
        self._refresh_plots()

    @Slot()
    def _on_option_chosen(self, *_):
        self._auto_pick_pending = False     # пользователь выбрал сам — не перебиваем

    def _add_hour_note(self):
        """Итоги за час по выбранной экспирации — в окно «Заметки» (hour_notes.py)."""
        import hour_notes as hn
        expiry = self._current_expiry()
        if not self.records or expiry is None:
            self.status_label.setText("Для заметки пока нет цепочки")
            return
        now = time.time()
        since = now - hn.HOUR_SEC
        lines = [f"{short_symbol(self.underlying)}, экспирация {expiry}"]
        price = self._ref_price()
        try:
            totals = self.store.oi_totals_since(self.underlying, expiry, since)
            rows = self._oi_rows(expiry)
            then = self.store.oi_at(self.underlying, [r["symbol"] for r in rows], since)
        except Exception as exc:
            self.status_label.setText(f"Заметка: ошибка чтения истории ({exc})")
            return
        if totals:
            t0, call0, put0, pcr0, fut0 = totals[0]
            t1, call1, put1, pcr1, fut1 = totals[-1]
            span = hn.span_text(t0, now)
            if price is not None and fut0:
                lines.append(f"Цена базового актива: {hn.fmt_num(price)}, "
                             f"{span} {hn.fmt_delta(price - fut0, 4)}")
            lines.append(f"OI CALL {hn.fmt_int(call1)} ({span} {hn.fmt_delta((call1 or 0) - (call0 or 0))}), "
                         f"PUT {hn.fmt_int(put1)} ({hn.fmt_delta((put1 or 0) - (put0 or 0))})")
            if pcr1 is not None:
                lines.append(f"PCR {hn.fmt_num(pcr1, 3)}" + (f" ({span} {hn.fmt_delta(pcr1 - pcr0, 3)})"
                                                            if pcr0 is not None else ""))
        elif price is not None:
            lines.append(f"Цена: {hn.fmt_num(price)} (истории OI за час ещё нет)")
        # Где за час больше всего прибавилось / убавилось OI (по страйкам).
        changes = []
        for r in rows:
            base = then.get(r["symbol"])
            if base is not None and r.get("oi") is not None:
                changes.append((r["oi"] - base[1], r["type"], r["strike"], r["oi"]))
        for title, picked in (("Прибавилось OI", sorted((c for c in changes if c[0] > 0), reverse=True)[:3]),
                              ("Убавилось OI", sorted(c for c in changes if c[0] < 0)[:3])):
            if picked:
                lines.append(f"{title}: " + "; ".join(
                    f"{kind} {hn.fmt_num(strike, 4)} {hn.fmt_delta(delta)} (сейчас {hn.fmt_int(oi)})"
                    for delta, kind, strike, oi in picked))
        top = sorted((r for r in rows if r.get("oi")), key=lambda r: r["oi"], reverse=True)
        for kind in ("CALL", "PUT"):
            best = next((r for r in top if r["type"] == kind), None)
            if best is not None:
                lines.append(f"Больше всего OI {kind}: страйк {hn.fmt_num(best['strike'], 4)} — {hn.fmt_int(best['oi'])}")
        self.status_label.setText(hn.add_hour_note(
            self, "Опционы", short_symbol(self.underlying), lines[1] if len(lines) > 1 else lines[0],
            "\n".join(lines)))

    def _ref_price(self):
        """Текущая цена базового актива (mid, иначе last) или None."""
        u = self.underlying_values
        bid, ask = u.get("bid"), u.get("ask")
        if bid and ask and bid > 0 and ask > 0:
            return (bid + ask) / 2
        return u.get("last")

    def _try_auto_pick(self):
        """Ставит в «Опцион для истории» страйк, ближайший к цене базового актива
        (по умолчанию в списке самый дальний страйк без котировок)."""
        if not self._auto_pick_pending or not self.option_combo.count():
            return
        ref = self._ref_price()
        if ref is None:
            return
        expiry = self._current_expiry()
        best, best_key = None, None
        for rec in self.records.values():
            if rec.get("strike") is None:
                continue
            if expiry is not None and (rec.get("expiry") or "") != expiry:
                continue
            key = (abs(rec["strike"] - ref), rec.get("type") != "CALL")
            if best_key is None or key < best_key:
                best, best_key = rec, key
        if best is None:
            return
        idx = self.option_combo.findData(best["symbol"])
        if idx >= 0:
            self._auto_pick_pending = False
            self.option_combo.setCurrentIndex(idx)

    def _price_is_sane(self, rec, values, price, ref):
        """Отсекает котировки, невозможные по границам арбитража, и заглушки
        с огромным спрэдом (иначе они ломают масштаб графика)."""
        if price < 0:
            return False
        if ref is not None:
            if rec.get("type") == "CALL" and price > ref:
                return False
            if rec.get("type") == "PUT" and price > rec["strike"]:
                return False
        if self.metric_combo.currentData() == "mid":
            bid, ask = values["bid"], values["ask"]
            if (ask - bid) / price > MAX_REL_SPREAD:
                return False
        return True

    @Slot(str, object)
    def _on_quote(self, symbol, values):
        self._last_quote_time = time.time()
        self._plots_dirty = True
        if symbol == self.underlying:
            self.underlying_values.update({k: v for k, v in values.items() if v is not None})
            bid, ask, last = (self.underlying_values.get(k) for k in ("bid", "ask", "last"))
            self.underlying_label.setText(f"{underlying_kind(self.underlying)} {short_symbol(self.underlying)}: Bid={bid if bid is not None else '—'} | Ask={ask if ask is not None else '—'} | Last={last if last is not None else '—'}")
            self._try_auto_pick()
            return
        rec = self.records.get(symbol)
        if rec is None:
            return
        current = rec.setdefault("values", {})
        current.update({k: v for k, v in values.items() if v is not None})

    @Slot()
    def _save_snapshot(self):
        """Сохраняет изменившиеся значения опционов и итоги OI — в фоновом потоке (_saver): в него уходит
        копия записей цепочки, интерфейс запись в SQLite не ждёт. Готово — _on_saved перечитает историю.
        Пока прежний снимок пишется, новый не ставится в очередь."""
        if not self.records or self._closing or self._save_busy:
            return
        records = {sym: {"type": r.get("type"), "strike": r.get("strike"), "expiry": r.get("expiry"),
                         "values": dict(r.get("values", {}))} for sym, r in self.records.items()}
        totals = self._oi_totals()
        underlying, price, store = self.underlying, self._ref_price(), self.store
        self._save_busy = True

        def work():
            saved, oi_saved, error = 0, False, ""
            try:
                saved = store.save_snapshot(underlying, records)
                if totals is not None:
                    oi_saved = bool(store.save_oi_totals(underlying, totals, price))
            except Exception as exc:                  # noqa: BLE001 — покажем в строке состояния
                error = str(exc)
            try:
                self._saved.emit(int(saved or 0), oi_saved, error)
            except RuntimeError:                      # окно уже удалено
                pass

        try:
            self._saver.submit(work)
        except RuntimeError:                          # поток записи остановлен (закрытие)
            self._save_busy = False

    @Slot(int, bool, str)
    def _on_saved(self, saved, oi_saved, error):
        self._save_busy = False
        if self._closing:
            return
        if error:
            self.status_label.setText(f"Ошибка записи SQLite: {error}")
            return
        if saved:
            self._refresh_history()
        if oi_saved:
            self._refresh_oi_history()

    def _selected_metric(self, values):
        metric = self.metric_combo.currentData()
        if metric == "mid":
            bid, ask = values.get("bid"), values.get("ask")
            return (bid + ask) / 2 if bid is not None and ask is not None and bid > 0 and ask > 0 else None
        return values.get(metric)

    def _view_visible(self) -> bool:
        """Окно «Опционы» видно: не скрыто за другой вкладкой рабочего пространства и не свёрнуто."""
        if not self.isVisible():
            return False
        win = self.window()
        return not (win is not None and win.isMinimized()) and not self.visibleRegion().isEmpty()

    def _on_refresh_timer(self):
        """Раз в секунду: цепочку пересчитать, только если пришли котировки и окно видно; уровни для графиков
        и стаканов — всегда (у них свой шаг LEVELS_SECONDS). Скрытое окно с новыми котировками пересчитается
        на первой секунде, когда его снова покажут (_plots_dirty остаётся поднятым)."""
        if self._closing:
            return
        if self._plots_dirty and self._view_visible():
            self._refresh_plots()
        else:
            self._publish_levels()

    def _refresh_plots(self, *_):
        if not self.records:
            return
        self._plots_dirty = False
        expiry = self._current_expiry()
        ref = self._ref_price()
        metric = self.metric_combo.currentData()
        check = metric in PRICE_METRICS
        greek = metric in ol.GREEK_KEYS
        years = ol.years_to_expiry(expiry) if greek and expiry else None
        hidden = 0
        calls, puts = [], []
        for rec in self.records.values():
            if expiry is not None and (rec.get("expiry") or "") != expiry:
                continue
            strike = rec.get("strike")
            values = rec.get("values", {})
            if greek:
                g = ol.greeks_of(rec, ref, years)
                price = g.get(metric) if g else None
            else:
                price = self._selected_metric(values)
            if strike is None or price is None:
                continue
            if check and not self._price_is_sane(rec, values, price, ref):
                hidden += 1
                continue
            point = (strike, price)
            if rec.get("type") == "CALL":
                calls.append(point)
            elif rec.get("type") == "PUT":
                puts.append(point)
        calls.sort()
        puts.sort()
        self.call_curve.setData([p[0] for p in calls], [p[1] for p in calls])
        self.put_curve.setData([p[0] for p in puts], [p[1] for p in puts])
        exp_text = f" — экспирация {expiry}" if expiry else ""
        hid_text = f" (скрыто как нерыночные: {hidden})" if hidden else ""
        self.chain_plot.setTitle(f"CALL / PUT по страйкам — {self.metric_combo.currentText()}{exp_text}{hid_text}")
        # История здесь не перерисовывается: она меняется только при записи
        # снимка (_save_snapshot) или смене опциона.
        self._publish_levels()
        self._refresh_oi()
        self._refresh_vol()
        self._refresh_gex()

    @Slot()
    def _refresh_history(self, *_):
        symbol = self.option_combo.currentData()
        if not symbol:
            return
        try:
            rows = self.store.history(self.underlying, symbol, HISTORY_LIMIT)
        except Exception as exc:
            self.status_label.setText(f"Ошибка чтения SQLite: {exc}")
            return
        if not rows:
            self.hist_bid.setData([], [])
            self.hist_ask.setData([], [])
            self.hist_last.setData([], [])
            self.hist_mid.setData([], [])
            self.history_plot.setTitle(f"История {short_symbol(symbol)} — данных пока нет")
            return
        nan = float("nan")
        ts = [r[0] for r in rows]
        bids, asks, lasts, mids = [], [], [], []
        for row in rows:
            bid, ask, last = row[1], row[2], row[3]
            bids.append(bid if bid is not None else nan)
            asks.append(ask if ask is not None else nan)
            lasts.append(last if last is not None else nan)
            mids.append((bid + ask) / 2 if bid is not None and ask is not None and bid > 0 and ask > 0 else nan)
        self.hist_bid.setData(ts, bids)
        self.hist_ask.setData(ts, asks)
        self.hist_last.setData(ts, lasts)
        self.hist_mid.setData(ts, mids)
        self.history_plot.setTitle(f"История {short_symbol(symbol)} — {len(rows)} записей")

    def _fill_underlying_combo(self, current):
        """Список: «тикер — имя инструмента», тикер хранится в данных пункта.
        Квартальные контракты пересчитываются по дате (ролловер); текущий выбор
        остаётся, даже если он уже не ближайший."""
        symbols = underlying_choices()
        if current and current not in symbols:
            symbols.insert(0, current)
        self.underlying_combo.clear()
        for sym in symbols:
            self.underlying_combo.addItem(underlying_label(sym), sym)
        if current:
            self.underlying_combo.setCurrentIndex(max(0, self.underlying_combo.findData(current)))

    def _underlying_from_ui(self):
        """Тикер из комбобокса: выбранный пункт (по данным) или введённый вручную."""
        text = self.underlying_combo.currentText().strip()
        idx = self.underlying_combo.findText(text)
        if idx >= 0:
            return str(self.underlying_combo.itemData(idx))
        return full_symbol(text)

    # ---- котировки из хаба терминала ------------------------------------
    def _subscribe_hub(self):
        """Базовый актив и все опционы цепочки — одной пакетной подпиской хаба (GUI-поток)."""
        from core.models import InstrumentId

        self._close_hub_subs()
        symbols = [self.underlying] + [s for s in self.records if s != self.underlying]
        mapping = {}
        for symbol in symbols:
            try:
                mapping[InstrumentId.parse(symbol)] = symbol
            except ValueError:
                continue
        self._hub_symbols = mapping
        try:
            self._hub_subs = self._hub.subscribe_quotes_many(list(mapping), self._on_hub_quote)
        except Exception as exc:
            self._hub_subs = []
            self._set_status(f"Ошибка подписки в хабе: {type(exc).__name__}: {exc}")
            return
        self._set_status(self.status_label.text() + " Котировки — из хаба терминала, группами по 10.")

    def _on_hub_quote(self, quote):
        symbol = self._hub_symbols.get(quote.instrument)
        if symbol is not None and not self._closing:
            self._on_quote(symbol, _values_from_quote(quote))

    def _close_hub_subs(self):
        subs, self._hub_subs = self._hub_subs, []
        self._hub_symbols = {}
        for sub in subs:
            try:
                sub.close()
            except Exception:
                pass

    @Slot()
    def _on_underlying_chosen(self, *_):
        # Выбор другого инструмента сразу переключает подписки; откладываем на цикл событий,
        # потому что _restart пересобирает сам комбобокс.
        QTimer.singleShot(0, self._restart)

    def _restart(self):
        target = self._underlying_from_ui()
        if not target:
            QMessageBox.warning(self, "Options Chain", "Укажи тикер базового инструмента.")
            return
        self._fill_underlying_combo(target)   # обновить квартальные контракты
        self._pending_underlying = target
        self._close_hub_subs()             # котировки прежней цепочки больше не нужны
        if self.worker is not None and self.worker.running:
            # Старые стримы отменяются в worker.stop(); новый воркер стартует из _on_stopped,
            # когда старый реально завершился.
            self._restart_pending = True
            self.status_label.setText("Останавливаем прежние подписки…")
            self.worker.stop()
        else:
            # Поток уже завершился (ошибка и т.п.) — stopped больше не придёт.
            self._restart_pending = False
            self._begin_restart()

    def shutdown(self):
        """Остановка без закрытия окна (встраивание в терминал, закрытие окна): таймеры, воркер
        и подписки в хабе. Клиент общий — его закрывает терминал."""
        if self._closing:
            return
        self._closing = True
        ol.registry().clear(self.underlying)          # вкладка закрыта — уровни с графиков и стаканов снимаются
        self.refresh_timer.stop()
        self.snapshot_timer.stop()
        self._saver.shutdown(wait=False)              # начатая запись снимка допишется сама
        self._close_hub_subs()
        worker = self.worker
        if worker is not None:
            # Отключаем сигналы, чтобы запоздавшие события не дошли до уже остановленного виджета.
            for signal in (worker.status, worker.chain_ready, worker.error, worker.stopped):
                try:
                    signal.disconnect()
                except Exception:
                    pass
            worker.stop()

    def closeEvent(self, event):
        self.shutdown()
        event.accept()
